(get-info :version)
; (:version "4.8.7")
; Started: 2025-12-05 13:18:01
; Silicon.version: 1.1-SNAPSHOT (95328487@(detached))
; Input file: ./sequences/predicates-lseg.vpr
; Verifier id: 00
; ------------------------------------------------------------
; Begin preamble
; ////////// Static preamble
; 
; ; /z3config.smt2
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :smt.qi.max_multi_patterns 1000)
; 
; ; /preamble.smt2
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(define-fun $Perm.min ((p1 $Perm) (p2 $Perm)) Real
    (ite (<= p1 p2) p1 p2))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
; ////////// Sorts
(declare-sort Seq<Int> 0)
; ////////// Sort wrappers
; Declaring additional sort wrappers
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.Seq<Int>To$Snap (Seq<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<Int> ($Snap) Seq<Int>)
(assert (forall ((x Seq<Int>)) (!
    (= x ($SortWrappers.$SnapToSeq<Int>($SortWrappers.Seq<Int>To$Snap x)))
    :pattern (($SortWrappers.Seq<Int>To$Snap x))
    :qid |$Snap.$SnapToSeq<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<Int>To$Snap($SortWrappers.$SnapToSeq<Int> x)))
    :pattern (($SortWrappers.$SnapToSeq<Int> x))
    :qid |$Snap.Seq<Int>To$SnapToSeq<Int>|
    )))
; ////////// Symbols
(declare-fun Seq_length (Seq<Int>) Int)
(declare-const Seq_empty Seq<Int>)
(declare-fun Seq_singleton (Int) Seq<Int>)
(declare-fun Seq_append (Seq<Int> Seq<Int>) Seq<Int>)
(declare-fun Seq_index (Seq<Int> Int) Int)
(declare-fun Seq_add (Int Int) Int)
(declare-fun Seq_sub (Int Int) Int)
(declare-fun Seq_update (Seq<Int> Int Int) Seq<Int>)
(declare-fun Seq_take (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_drop (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_contains (Seq<Int> Int) Bool)
(declare-fun Seq_contains_trigger (Seq<Int> Int) Bool)
(declare-fun Seq_skolem (Seq<Int> Int) Int)
(declare-fun Seq_equal (Seq<Int> Seq<Int>) Bool)
(declare-fun Seq_skolem_diff (Seq<Int> Seq<Int>) Int)
(declare-fun Seq_range (Int Int) Seq<Int>)
; Declaring symbols related to program functions (from program analysis)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
; Declaring predicate trigger functions
(declare-fun lseg%trigger ($Snap $Ref $Ref Seq<Int>) Bool)
; ////////// Uniqueness assumptions from domains
; ////////// Axioms
(assert (forall ((s Seq<Int>)) (!
  (<= 0 (Seq_length s))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty  Seq<Int>)) 0))
(assert (forall ((s Seq<Int>)) (!
  (=> (= (Seq_length s) 0) (= s (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_zero|)))
(assert (forall ((e Int)) (!
  (= (Seq_length (Seq_singleton e)) 1)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (not (= s1 (as Seq_empty  Seq<Int>))))
    (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1))))
  :pattern ((Seq_length (Seq_append s0 s1)))
  :qid |$Seq[Int]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (and
    (=> (= s0 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s1))
    (=> (= s1 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s0)))
  :pattern ((Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_empty|)))
(assert (forall ((e Int)) (!
  (= (Seq_index (Seq_singleton e) 0) e)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_add i j) (+ i j))
  :pattern ((Seq_add i j))
  :qid |$Seq[Int]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_sub i j) (- i j))
  :pattern ((Seq_sub i j))
  :qid |$Seq[Int]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= 0 n) (< n (Seq_length s0)))))
    (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n)))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :pattern ((Seq_index s0 n) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1))))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n)
      (=
        (Seq_index (Seq_append s0 s1) n)
        (Seq_index s1 (Seq_sub n (Seq_length s0))))))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :qid |$Seq[Int]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (m Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= 0 m) (< m (Seq_length s1)))))
    (and
      (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m)
      (=
        (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0)))
        (Seq_index s1 m))))
  :pattern ((Seq_index s1 m) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (Seq_length (Seq_update s i v)) (Seq_length s)))
  :pattern ((Seq_length (Seq_update s i v)))
  :pattern ((Seq_length s) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_length|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int) (n Int)) (!
  (=>
    (and (<= 0 n) (< n (Seq_length s)))
    (and
      (=> (= i n) (= (Seq_index (Seq_update s i v) n) v))
      (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n)))))
  :pattern ((Seq_index (Seq_update s i v) n))
  :pattern ((Seq_index s n) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s)))))
    (=> (< n 0) (= (Seq_length (Seq_take s n)) 0)))
  :pattern ((Seq_length (Seq_take s n)))
  :pattern ((Seq_take s n) (Seq_length s))
  :qid |$Seq[Int]_prog.Seq_take_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (<= 0 j) (and (< j n) (< j (Seq_length s))))
    (= (Seq_index (Seq_take s n) j) (Seq_index s j)))
  :pattern ((Seq_index (Seq_take s n) j))
  :pattern ((Seq_index s j) (Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=>
          (<= n (Seq_length s))
          (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n)))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0))))
    (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s))))
  :pattern ((Seq_length (Seq_drop s n)))
  :pattern ((Seq_length s) (Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n))))
    (and
      (= (Seq_sub (Seq_add j n) n) j)
      (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n)))))
  :pattern ((Seq_index (Seq_drop s n) j))
  :qid |$Seq[Int]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<Int>) (n Int) (i Int)) (!
  (=>
    (and (< 0 n) (and (<= n i) (< i (Seq_length s))))
    (and
      (= (Seq_add (Seq_sub i n) n) i)
      (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i))))
  :pattern ((Seq_drop s n) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_take (Seq_append s t) n) (Seq_take s n)))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (=
        (Seq_take (Seq_append s t) n)
        (Seq_append s (Seq_take t (Seq_sub n (Seq_length s)))))))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t)))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (> n (Seq_length s)))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s))))))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_take s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_drop s n) s))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_take s n) s))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_all|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<Int>) (x Int)) (!
  (=>
    (Seq_contains s x)
    (and
      (<= 0 (Seq_skolem s x))
      (and
        (< (Seq_skolem s x) (Seq_length s))
        (= (Seq_index s (Seq_skolem s x)) x))))
  :pattern ((Seq_contains s x))
  :qid |$Seq[Int]_prog.Seq_contains1|)))
(assert (forall ((s Seq<Int>) (x Int) (i Int)) (!
  (=>
    (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x)))
    (Seq_contains s x))
  :pattern ((Seq_contains s x) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains2|)))
(assert (forall ((s Seq<Int>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (Seq_contains_trigger s (Seq_index s i)))
  :pattern ((Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (or
    (and (= s0 s1) (Seq_equal s0 s1))
    (or
      (and
        (not (= s0 s1))
        (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1)))))
      (and
        (not (= s0 s1))
        (and
          (not (Seq_equal s0 s1))
          (and
            (= (Seq_length s0) (Seq_length s1))
            (and
              (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0))
              (and
                (<= 0 (Seq_skolem_diff s0 s1))
                (and
                  (< (Seq_skolem_diff s0 s1) (Seq_length s0))
                  (not
                    (=
                      (Seq_index s0 (Seq_skolem_diff s0 s1))
                      (Seq_index s1 (Seq_skolem_diff s0 s1))))))))))))
  :pattern ((Seq_equal s0 s1))
  :qid |$Seq[Int]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<Int>) (b Seq<Int>)) (!
  (=> (Seq_equal a b) (= a b))
  :pattern ((Seq_equal a b))
  :qid |$Seq[Int]_prog.Seq_equal_ext|)))
(assert (forall ((x Int) (y Int)) (!
  (= (Seq_contains (Seq_singleton x) y) (= x y))
  :pattern ((Seq_contains (Seq_singleton x) y))
  :qid |$Seq[Int]_prog.Seq_singleton_contains|)))
(assert (forall ((min_ Int) (max Int)) (!
  (and
    (=> (< min_ max) (= (Seq_length (Seq_range min_ max)) (- max min_)))
    (=> (<= max min_) (= (Seq_length (Seq_range min_ max)) 0)))
  :pattern ((Seq_length (Seq_range min_ max)))
  :qid |$Seq[Int]_prog.Seq_range_length|)))
(assert (forall ((min_ Int) (max Int) (j Int)) (!
  (=>
    (and (<= 0 j) (< j (- max min_)))
    (= (Seq_index (Seq_range min_ max) j) (+ min_ j)))
  :pattern ((Seq_index (Seq_range min_ max) j))
  :qid |$Seq[Int]_prog.Seq_range_index|)))
(assert (forall ((min_ Int) (max Int) (v Int)) (!
  (= (Seq_contains (Seq_range min_ max) v) (and (<= min_ v) (< v max)))
  :pattern ((Seq_contains (Seq_range min_ max) v))
  :qid |$Seq[Int]_prog.Seq_range_contains|)))
; End preamble
; ------------------------------------------------------------
; State saturation: after preamble
(set-option :rlimit 160000)
(check-sat)
; unknown
; ------------------------------------------------------------
; Begin function- and predicate-related preamble
; Declaring symbols related to program functions (from verification)
; Declaring symbols related to program functions (from verification)
; End function- and predicate-related preamble
; ------------------------------------------------------------
; ---------- findFirst ----------
(declare-const first@0@01 $Ref)
(declare-const last@1@01 $Ref)
(declare-const values@2@01 Seq<Int>)
(declare-const value@3@01 Int)
(declare-const second@4@01 $Ref)
(declare-const first@5@01 $Ref)
(declare-const last@6@01 $Ref)
(declare-const values@7@01 Seq<Int>)
(declare-const value@8@01 Int)
(declare-const second@9@01 $Ref)
(set-option :rlimit 0)
(push) ; 1
(declare-const $t@10@01 $Snap)
(assert (= $t@10@01 ($Snap.combine ($Snap.first $t@10@01) ($Snap.second $t@10@01))))
(assert (= ($Snap.second $t@10@01) $Snap.unit))
; [eval] first != last
(assert (not (= first@5@01 last@6@01)))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
; [eval] values[1..]
(declare-const $t@11@01 $Snap)
(pop) ; 2
(push) ; 2
; [exec]
; unfold acc(lseg(first, last, values), write)
; [eval] first != last
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= first@5@01 last@6@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 0 | first@5@01 != last@6@01 | live]
; [else-branch: 0 | first@5@01 == last@6@01 | dead]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 0 | first@5@01 != last@6@01]
(assert (=
  ($Snap.first $t@10@01)
  ($Snap.combine
    ($Snap.first ($Snap.first $t@10@01))
    ($Snap.second ($Snap.first $t@10@01)))))
(assert (not (= first@5@01 $Ref.null)))
(assert (=
  ($Snap.second ($Snap.first $t@10@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.first $t@10@01)))
    ($Snap.second ($Snap.second ($Snap.first $t@10@01))))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.first $t@10@01)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.first $t@10@01))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.first $t@10@01)))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.first $t@10@01)))) $Snap.unit))
; [eval] 0 < |values|
; [eval] |values|
(assert (< 0 (Seq_length values@7@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.first $t@10@01))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first $t@10@01)))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.first $t@10@01))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.first $t@10@01)))))
  $Snap.unit))
; [eval] first.elem == values[0]
; [eval] values[0]
(assert (=
  ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first $t@10@01)))
  (Seq_index values@7@01 0)))
; [eval] values[1..]
; State saturation: after unfold
(set-option :rlimit 64000)
(check-sat)
; unknown
(assert (lseg%trigger ($Snap.first $t@10@01) first@5@01 last@6@01 values@7@01))
; [exec]
; value := first.elem
(declare-const value@12@01 Int)
(assert (= value@12@01 ($SortWrappers.$SnapToInt ($Snap.first ($Snap.first $t@10@01)))))
; [exec]
; second := first.next
(declare-const second@13@01 $Ref)
(assert (=
  second@13@01
  ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first $t@10@01))))))
; [eval] values[1..]
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not (=
  ($SortWrappers.$SnapTo$Ref ($Snap.first ($Snap.second ($Snap.first $t@10@01))))
  second@13@01)))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(pop) ; 3
(pop) ; 2
(pop) ; 1
; ---------- prependFails ----------
(declare-const first@14@01 $Ref)
(declare-const last@15@01 $Ref)
(declare-const values@16@01 Seq<Int>)
(declare-const toAdd@17@01 Int)
(declare-const r@18@01 $Ref)
(declare-const first@19@01 $Ref)
(declare-const last@20@01 $Ref)
(declare-const values@21@01 Seq<Int>)
(declare-const toAdd@22@01 Int)
(declare-const r@23@01 $Ref)
(set-option :rlimit 0)
(push) ; 1
(declare-const $t@24@01 $Snap)
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
; [eval] Seq(toAdd) ++ values
; [eval] Seq(toAdd)
(assert (= (Seq_length (Seq_singleton toAdd@22@01)) 1))
(declare-const $t@25@01 $Snap)
(pop) ; 2
(push) ; 2
; [exec]
; r := new(elem, next)
(declare-const r@26@01 $Ref)
(assert (not (= r@26@01 $Ref.null)))
(declare-const elem@27@01 Int)
(declare-const next@28@01 $Ref)
(assert (not (= r@26@01 first@19@01)))
(assert (not (= r@26@01 r@23@01)))
(assert (not (= r@26@01 last@20@01)))
; [exec]
; r.elem := toAdd
; [exec]
; r.next := first
; [exec]
; fold acc(lseg(r, last, Seq(toAdd) ++ values), write)
; [eval] Seq(toAdd) ++ values
; [eval] Seq(toAdd)
(assert (= (Seq_length (Seq_singleton toAdd@22@01)) 1))
; [eval] first != last
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= r@26@01 last@20@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1 | r@26@01 != last@20@01 | live]
; [else-branch: 1 | r@26@01 == last@20@01 | dead]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 1 | r@26@01 != last@20@01]
; [eval] 0 < |values|
; [eval] |values|
(push) ; 4
(assert (not (< 0 (Seq_length (Seq_append (Seq_singleton toAdd@22@01) values@21@01)))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(assert (< 0 (Seq_length (Seq_append (Seq_singleton toAdd@22@01) values@21@01))))
; [eval] first.elem == values[0]
; [eval] values[0]
(push) ; 4
(assert (not (=
  toAdd@22@01
  (Seq_index (Seq_append (Seq_singleton toAdd@22@01) values@21@01) 0))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(assert (=
  toAdd@22@01
  (Seq_index (Seq_append (Seq_singleton toAdd@22@01) values@21@01) 0)))
; [eval] values[1..]
(push) ; 4
(set-option :rlimit 16000)
(assert (not (Seq_equal
  values@21@01
  (Seq_drop (Seq_append (Seq_singleton toAdd@22@01) values@21@01) 1))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(assert (lseg%trigger ($Snap.combine
  ($SortWrappers.IntTo$Snap toAdd@22@01)
  ($Snap.combine
    ($SortWrappers.$RefTo$Snap first@19@01)
    ($Snap.combine $Snap.unit ($Snap.combine $Snap.unit $t@24@01)))) r@26@01 last@20@01 (Seq_append
  (Seq_singleton toAdd@22@01)
  values@21@01)))
; [eval] Seq(toAdd) ++ values
; [eval] Seq(toAdd)
(pop) ; 3
(pop) ; 2
(pop) ; 1
; ---------- prepend ----------
(declare-const first@29@01 $Ref)
(declare-const last@30@01 $Ref)
(declare-const values@31@01 Seq<Int>)
(declare-const toAdd@32@01 Int)
(declare-const r@33@01 $Ref)
(declare-const first@34@01 $Ref)
(declare-const last@35@01 $Ref)
(declare-const values@36@01 Seq<Int>)
(declare-const toAdd@37@01 Int)
(declare-const r@38@01 $Ref)
(set-option :rlimit 0)
(push) ; 1
(declare-const $t@39@01 $Snap)
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
; [eval] Seq(toAdd) ++ values
; [eval] Seq(toAdd)
(assert (= (Seq_length (Seq_singleton toAdd@37@01)) 1))
(declare-const $t@40@01 $Snap)
(pop) ; 2
(push) ; 2
; [exec]
; r := new(elem, next)
(declare-const r@41@01 $Ref)
(assert (not (= r@41@01 $Ref.null)))
(declare-const elem@42@01 Int)
(declare-const next@43@01 $Ref)
(assert (not (= r@41@01 r@38@01)))
(assert (not (= r@41@01 last@35@01)))
(assert (not (= r@41@01 first@34@01)))
; [exec]
; r.elem := toAdd
; [exec]
; r.next := first
; [exec]
; assert Seq(toAdd) ++ values[1..] == values
; [eval] Seq(toAdd) ++ values[1..] == values
; [eval] Seq(toAdd) ++ values[1..]
; [eval] Seq(toAdd) ++ values
; [eval] Seq(toAdd)
(assert (= (Seq_length (Seq_singleton toAdd@37@01)) 1))
(push) ; 3
(assert (not (Seq_equal
  (Seq_drop (Seq_append (Seq_singleton toAdd@37@01) values@36@01) 1)
  values@36@01)))
(check-sat)
; unsat
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(assert (Seq_equal
  (Seq_drop (Seq_append (Seq_singleton toAdd@37@01) values@36@01) 1)
  values@36@01))
; [exec]
; fold acc(lseg(r, last, Seq(toAdd) ++ values), write)
; [eval] Seq(toAdd) ++ values
; [eval] Seq(toAdd)
; [eval] first != last
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= r@41@01 last@35@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 2 | r@41@01 != last@35@01 | live]
; [else-branch: 2 | r@41@01 == last@35@01 | dead]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 2 | r@41@01 != last@35@01]
; [eval] 0 < |values|
; [eval] |values|
(push) ; 4
(assert (not (< 0 (Seq_length (Seq_append (Seq_singleton toAdd@37@01) values@36@01)))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(assert (< 0 (Seq_length (Seq_append (Seq_singleton toAdd@37@01) values@36@01))))
; [eval] first.elem == values[0]
; [eval] values[0]
(push) ; 4
(assert (not (=
  toAdd@37@01
  (Seq_index (Seq_append (Seq_singleton toAdd@37@01) values@36@01) 0))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(assert (=
  toAdd@37@01
  (Seq_index (Seq_append (Seq_singleton toAdd@37@01) values@36@01) 0)))
; [eval] values[1..]
(push) ; 4
(set-option :rlimit 16000)
(assert (not (Seq_equal
  values@36@01
  (Seq_drop (Seq_append (Seq_singleton toAdd@37@01) values@36@01) 1))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(assert (lseg%trigger ($Snap.combine
  ($SortWrappers.IntTo$Snap toAdd@37@01)
  ($Snap.combine
    ($SortWrappers.$RefTo$Snap first@34@01)
    ($Snap.combine $Snap.unit ($Snap.combine $Snap.unit $t@39@01)))) r@41@01 last@35@01 (Seq_append
  (Seq_singleton toAdd@37@01)
  values@36@01)))
; [eval] Seq(toAdd) ++ values
; [eval] Seq(toAdd)
(pop) ; 3
(pop) ; 2
(pop) ; 1
