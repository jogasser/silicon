(get-info :version)
; (:version "4.8.7")
