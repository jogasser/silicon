(get-info :version)
; (:version "4.8.7")
; Started: 2025-12-05 14:06:32
; Silicon.version: 1.1-SNAPSHOT (95328487@(detached))
; Input file: ./sets/pldi16_so_CollItem_false.vpr
; Verifier id: 00
; ------------------------------------------------------------
; Begin preamble
; ////////// Static preamble
; 
; ; /z3config.smt2
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :smt.qi.max_multi_patterns 1000)
; 
; ; /preamble.smt2
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(define-fun $Perm.min ((p1 $Perm) (p2 $Perm)) Real
    (ite (<= p1 p2) p1 p2))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
; ////////// Sorts
; ////////// Sort wrappers
; Declaring additional sort wrappers
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
; ////////// Symbols
; Declaring symbols related to program functions (from program analysis)
(declare-fun getCardId ($Snap $Ref) Int)
(declare-fun getCardId%limited ($Snap $Ref) Int)
(declare-fun getCardId%stateless ($Ref) Bool)
(declare-fun getCardId%precondition ($Snap $Ref) Bool)
(declare-fun getCardRarity ($Snap $Ref) Int)
(declare-fun getCardRarity%limited ($Snap $Ref) Int)
(declare-fun getCardRarity%stateless ($Ref) Bool)
(declare-fun getCardRarity%precondition ($Snap $Ref) Bool)
(declare-fun getCardSet ($Snap $Ref) Int)
(declare-fun getCardSet%limited ($Snap $Ref) Int)
(declare-fun getCardSet%stateless ($Ref) Bool)
(declare-fun getCardSet%precondition ($Snap $Ref) Bool)
(declare-fun sgn ($Snap Int) Int)
(declare-fun sgn%limited ($Snap Int) Int)
(declare-fun sgn%stateless (Int) Bool)
(declare-fun sgn%precondition ($Snap Int) Bool)
(declare-fun cardType ($Snap $Ref) Int)
(declare-fun cardType%limited ($Snap $Ref) Int)
(declare-fun cardType%stateless ($Ref) Bool)
(declare-fun cardType%precondition ($Snap $Ref) Bool)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
; Declaring predicate trigger functions
; ////////// Uniqueness assumptions from domains
; ////////// Axioms
; End preamble
; ------------------------------------------------------------
; State saturation: after preamble
(set-option :rlimit 160000)
(check-sat)
; unknown
; ---------- FUNCTION getCardId----------
(declare-fun self@0@00 () $Ref)
(declare-fun result@1@00 () Int)
; ----- Well-definedness of specifications -----
(set-option :rlimit 0)
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@0@00 $Ref)) (!
  (= (getCardId%limited s@$ self@0@00) (getCardId s@$ self@0@00))
  :pattern ((getCardId s@$ self@0@00))
  :qid |quant-u-0|)))
(assert (forall ((s@$ $Snap) (self@0@00 $Ref)) (!
  (getCardId%stateless self@0@00)
  :pattern ((getCardId%limited s@$ self@0@00))
  :qid |quant-u-1|)))
; ---------- FUNCTION getCardRarity----------
(declare-fun self@2@00 () $Ref)
(declare-fun result@3@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@2@00 $Ref)) (!
  (= (getCardRarity%limited s@$ self@2@00) (getCardRarity s@$ self@2@00))
  :pattern ((getCardRarity s@$ self@2@00))
  :qid |quant-u-2|)))
(assert (forall ((s@$ $Snap) (self@2@00 $Ref)) (!
  (getCardRarity%stateless self@2@00)
  :pattern ((getCardRarity%limited s@$ self@2@00))
  :qid |quant-u-3|)))
; ---------- FUNCTION getCardSet----------
(declare-fun self@4@00 () $Ref)
(declare-fun result@5@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@4@00 $Ref)) (!
  (= (getCardSet%limited s@$ self@4@00) (getCardSet s@$ self@4@00))
  :pattern ((getCardSet s@$ self@4@00))
  :qid |quant-u-4|)))
(assert (forall ((s@$ $Snap) (self@4@00 $Ref)) (!
  (getCardSet%stateless self@4@00)
  :pattern ((getCardSet%limited s@$ self@4@00))
  :qid |quant-u-5|)))
; ---------- FUNCTION sgn----------
(declare-fun i@6@00 () Int)
(declare-fun result@7@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@10@00 $Snap)
(assert (= $t@10@00 ($Snap.combine ($Snap.first $t@10@00) ($Snap.second $t@10@00))))
(assert (= ($Snap.first $t@10@00) $Snap.unit))
; [eval] i > 0 ==> result == 1
; [eval] i > 0
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (> i@6@00 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (> i@6@00 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 0 | i@6@00 > 0 | live]
; [else-branch: 0 | !(i@6@00 > 0) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 0 | i@6@00 > 0]
(assert (> i@6@00 0))
; [eval] result == 1
(pop) ; 3
(push) ; 3
; [else-branch: 0 | !(i@6@00 > 0)]
(assert (not (> i@6@00 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (> i@6@00 0)) (> i@6@00 0)))
(assert (=> (> i@6@00 0) (= result@7@00 1)))
(assert (=
  ($Snap.second $t@10@00)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@10@00))
    ($Snap.second ($Snap.second $t@10@00)))))
(assert (= ($Snap.first ($Snap.second $t@10@00)) $Snap.unit))
; [eval] i == 0 ==> result == 0
; [eval] i == 0
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= i@6@00 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= i@6@00 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1 | i@6@00 == 0 | live]
; [else-branch: 1 | i@6@00 != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 1 | i@6@00 == 0]
(assert (= i@6@00 0))
; [eval] result == 0
(pop) ; 3
(push) ; 3
; [else-branch: 1 | i@6@00 != 0]
(assert (not (= i@6@00 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= i@6@00 0)) (= i@6@00 0)))
(assert (=> (= i@6@00 0) (= result@7@00 0)))
(assert (= ($Snap.second ($Snap.second $t@10@00)) $Snap.unit))
; [eval] i < 0 ==> result == -1
; [eval] i < 0
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (< i@6@00 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (< i@6@00 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 2 | i@6@00 < 0 | live]
; [else-branch: 2 | !(i@6@00 < 0) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 2 | i@6@00 < 0]
(assert (< i@6@00 0))
; [eval] result == -1
; [eval] -1
(pop) ; 3
(push) ; 3
; [else-branch: 2 | !(i@6@00 < 0)]
(assert (not (< i@6@00 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (< i@6@00 0)) (< i@6@00 0)))
(assert (=> (< i@6@00 0) (= result@7@00 (- 0 1))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (i@6@00 Int)) (!
  (= (sgn%limited s@$ i@6@00) (sgn s@$ i@6@00))
  :pattern ((sgn s@$ i@6@00))
  :qid |quant-u-6|)))
(assert (forall ((s@$ $Snap) (i@6@00 Int)) (!
  (sgn%stateless i@6@00)
  :pattern ((sgn%limited s@$ i@6@00))
  :qid |quant-u-7|)))
(assert (forall ((s@$ $Snap) (i@6@00 Int)) (!
  (let ((result@7@00 (sgn%limited s@$ i@6@00))) (=>
    (sgn%precondition s@$ i@6@00)
    (and
      (=> (> i@6@00 0) (= result@7@00 1))
      (=> (= i@6@00 0) (= result@7@00 0))
      (=> (< i@6@00 0) (= result@7@00 (- 0 1))))))
  :pattern ((sgn%limited s@$ i@6@00))
  :qid |quant-u-10|)))
(assert (forall ((s@$ $Snap) (i@6@00 Int)) (!
  (let ((result@7@00 (sgn%limited s@$ i@6@00))) true)
  :pattern ((sgn%limited s@$ i@6@00))
  :qid |quant-u-11|)))
(assert (forall ((s@$ $Snap) (i@6@00 Int)) (!
  (let ((result@7@00 (sgn%limited s@$ i@6@00))) true)
  :pattern ((sgn%limited s@$ i@6@00))
  :qid |quant-u-12|)))
(assert (forall ((s@$ $Snap) (i@6@00 Int)) (!
  (let ((result@7@00 (sgn%limited s@$ i@6@00))) true)
  :pattern ((sgn%limited s@$ i@6@00))
  :qid |quant-u-13|)))
; ---------- FUNCTION cardType----------
(declare-fun self@8@00 () $Ref)
(declare-fun result@9@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (self@8@00 $Ref)) (!
  (= (cardType%limited s@$ self@8@00) (cardType s@$ self@8@00))
  :pattern ((cardType s@$ self@8@00))
  :qid |quant-u-8|)))
(assert (forall ((s@$ $Snap) (self@8@00 $Ref)) (!
  (cardType%stateless self@8@00)
  :pattern ((cardType%limited s@$ self@8@00))
  :qid |quant-u-9|)))
