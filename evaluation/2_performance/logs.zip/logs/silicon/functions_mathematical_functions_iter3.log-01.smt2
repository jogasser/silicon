(get-info :version)
; (:version "4.8.7")
; Started: 2025-12-05 12:25:38
; Silicon.version: 1.1-SNAPSHOT (95328487@(detached))
; Input file: ./functions/mathematical_functions.vpr
; Verifier id: 00
; ------------------------------------------------------------
; Begin preamble
; ////////// Static preamble
; 
; ; /z3config.smt2
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :smt.qi.max_multi_patterns 1000)
; 
; ; /preamble.smt2
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(define-fun $Perm.min ((p1 $Perm) (p2 $Perm)) Real
    (ite (<= p1 p2) p1 p2))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
; ////////// Sorts
; ////////// Sort wrappers
; Declaring additional sort wrappers
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
; ////////// Symbols
; Declaring symbols related to program functions (from program analysis)
(declare-fun factorial ($Snap Int) Int)
(declare-fun factorial%limited ($Snap Int) Int)
(declare-fun factorial%stateless (Int) Bool)
(declare-fun factorial%precondition ($Snap Int) Bool)
(declare-fun fib ($Snap Int) Int)
(declare-fun fib%limited ($Snap Int) Int)
(declare-fun fib%stateless (Int) Bool)
(declare-fun fib%precondition ($Snap Int) Bool)
(declare-fun ackermann ($Snap Int Int) Int)
(declare-fun ackermann%limited ($Snap Int Int) Int)
(declare-fun ackermann%stateless (Int Int) Bool)
(declare-fun ackermann%precondition ($Snap Int Int) Bool)
(declare-fun gcd ($Snap Int Int) Int)
(declare-fun gcd%limited ($Snap Int Int) Int)
(declare-fun gcd%stateless (Int Int) Bool)
(declare-fun gcd%precondition ($Snap Int Int) Bool)
(declare-fun power ($Snap Int Int) Int)
(declare-fun power%limited ($Snap Int Int) Int)
(declare-fun power%stateless (Int Int) Bool)
(declare-fun power%precondition ($Snap Int Int) Bool)
(declare-fun sum_n ($Snap Int) Int)
(declare-fun sum_n%limited ($Snap Int) Int)
(declare-fun sum_n%stateless (Int) Bool)
(declare-fun sum_n%precondition ($Snap Int) Bool)
(declare-fun binomial ($Snap Int Int) Int)
(declare-fun binomial%limited ($Snap Int Int) Int)
(declare-fun binomial%stateless (Int Int) Bool)
(declare-fun binomial%precondition ($Snap Int Int) Bool)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
; Declaring predicate trigger functions
; ////////// Uniqueness assumptions from domains
; ////////// Axioms
; End preamble
; ------------------------------------------------------------
; State saturation: after preamble
(set-option :rlimit 160000)
(check-sat)
; unknown
; ------------------------------------------------------------
; Begin function- and predicate-related preamble
; Declaring symbols related to program functions (from verification)
; Declaring symbols related to program functions (from verification)
(assert (forall ((s@$ $Snap) (n@0@00 Int)) (!
  (= (factorial%limited s@$ n@0@00) (factorial s@$ n@0@00))
  :pattern ((factorial s@$ n@0@00))
  :qid |quant-u-0|)))
(assert (forall ((s@$ $Snap) (n@0@00 Int)) (!
  (factorial%stateless n@0@00)
  :pattern ((factorial%limited s@$ n@0@00))
  :qid |quant-u-1|)))
(assert (forall ((s@$ $Snap) (n@0@00 Int)) (!
  (let ((result@1@00 (factorial%limited s@$ n@0@00))) (=>
    (factorial%precondition s@$ n@0@00)
    (> result@1@00 0)))
  :pattern ((factorial%limited s@$ n@0@00))
  :qid |quant-u-14|)))
(assert (forall ((s@$ $Snap) (n@0@00 Int)) (!
  (let ((result@1@00 (factorial%limited s@$ n@0@00))) true)
  :pattern ((factorial%limited s@$ n@0@00))
  :qid |quant-u-15|)))
(assert (forall ((s@$ $Snap) (n@0@00 Int)) (!
  (=>
    (factorial%precondition s@$ n@0@00)
    (=
      (factorial s@$ n@0@00)
      (ite (= n@0@00 0) 1 (* n@0@00 (factorial%limited $Snap.unit (- n@0@00 1))))))
  :pattern ((factorial s@$ n@0@00))
  :qid |quant-u-16|)))
(assert (forall ((s@$ $Snap) (n@0@00 Int)) (!
  (=>
    (factorial%precondition s@$ n@0@00)
    (ite (= n@0@00 0) true (factorial%precondition $Snap.unit (- n@0@00 1))))
  :pattern ((factorial s@$ n@0@00))
  :qid |quant-u-17|)))
(assert (forall ((s@$ $Snap) (n@2@00 Int)) (!
  (= (fib%limited s@$ n@2@00) (fib s@$ n@2@00))
  :pattern ((fib s@$ n@2@00))
  :qid |quant-u-2|)))
(assert (forall ((s@$ $Snap) (n@2@00 Int)) (!
  (fib%stateless n@2@00)
  :pattern ((fib%limited s@$ n@2@00))
  :qid |quant-u-3|)))
(assert (forall ((s@$ $Snap) (n@2@00 Int)) (!
  (let ((result@3@00 (fib%limited s@$ n@2@00))) (=>
    (fib%precondition s@$ n@2@00)
    (>= result@3@00 0)))
  :pattern ((fib%limited s@$ n@2@00))
  :qid |quant-u-18|)))
(assert (forall ((s@$ $Snap) (n@2@00 Int)) (!
  (let ((result@3@00 (fib%limited s@$ n@2@00))) true)
  :pattern ((fib%limited s@$ n@2@00))
  :qid |quant-u-19|)))
(assert (forall ((s@$ $Snap) (n@2@00 Int)) (!
  (=>
    (fib%precondition s@$ n@2@00)
    (=
      (fib s@$ n@2@00)
      (ite
        (<= n@2@00 1)
        n@2@00
        (+
          (fib%limited $Snap.unit (- n@2@00 1))
          (fib%limited $Snap.unit (- n@2@00 2))))))
  :pattern ((fib s@$ n@2@00))
  :qid |quant-u-20|)))
(assert (forall ((s@$ $Snap) (n@2@00 Int)) (!
  (=>
    (fib%precondition s@$ n@2@00)
    (ite
      (<= n@2@00 1)
      true
      (and
        (fib%precondition $Snap.unit (- n@2@00 1))
        (fib%precondition $Snap.unit (- n@2@00 2)))))
  :pattern ((fib s@$ n@2@00))
  :qid |quant-u-21|)))
(assert (forall ((s@$ $Snap) (m@4@00 Int) (n@5@00 Int)) (!
  (= (ackermann%limited s@$ m@4@00 n@5@00) (ackermann s@$ m@4@00 n@5@00))
  :pattern ((ackermann s@$ m@4@00 n@5@00))
  :qid |quant-u-4|)))
(assert (forall ((s@$ $Snap) (m@4@00 Int) (n@5@00 Int)) (!
  (ackermann%stateless m@4@00 n@5@00)
  :pattern ((ackermann%limited s@$ m@4@00 n@5@00))
  :qid |quant-u-5|)))
(assert (forall ((s@$ $Snap) (m@4@00 Int) (n@5@00 Int)) (!
  (let ((result@6@00 (ackermann%limited s@$ m@4@00 n@5@00))) (=>
    (ackermann%precondition s@$ m@4@00 n@5@00)
    (>= result@6@00 0)))
  :pattern ((ackermann%limited s@$ m@4@00 n@5@00))
  :qid |quant-u-22|)))
(assert (forall ((s@$ $Snap) (m@4@00 Int) (n@5@00 Int)) (!
  (let ((result@6@00 (ackermann%limited s@$ m@4@00 n@5@00))) true)
  :pattern ((ackermann%limited s@$ m@4@00 n@5@00))
  :qid |quant-u-23|)))
(assert (forall ((s@$ $Snap) (m@4@00 Int) (n@5@00 Int)) (!
  (=>
    (ackermann%precondition s@$ m@4@00 n@5@00)
    (=
      (ackermann s@$ m@4@00 n@5@00)
      (ite
        (= m@4@00 0)
        (+ n@5@00 1)
        (ite
          (= n@5@00 0)
          (ackermann%limited ($Snap.combine
            $Snap.unit
            ($Snap.combine $Snap.unit $Snap.unit)) (- m@4@00 1) 1)
          (ackermann%limited ($Snap.combine
            $Snap.unit
            ($Snap.combine $Snap.unit $Snap.unit)) (- m@4@00 1) (ackermann%limited ($Snap.combine
            $Snap.unit
            ($Snap.combine $Snap.unit $Snap.unit)) m@4@00 (- n@5@00 1)))))))
  :pattern ((ackermann s@$ m@4@00 n@5@00))
  :qid |quant-u-24|)))
(assert (forall ((s@$ $Snap) (m@4@00 Int) (n@5@00 Int)) (!
  (=>
    (ackermann%precondition s@$ m@4@00 n@5@00)
    (ite
      (= m@4@00 0)
      true
      (ite
        (= n@5@00 0)
        (ackermann%precondition ($Snap.combine
          $Snap.unit
          ($Snap.combine $Snap.unit $Snap.unit)) (- m@4@00 1) 1)
        (and
          (ackermann%precondition ($Snap.combine
            $Snap.unit
            ($Snap.combine $Snap.unit $Snap.unit)) m@4@00 (- n@5@00 1))
          (ackermann%precondition ($Snap.combine
            $Snap.unit
            ($Snap.combine $Snap.unit $Snap.unit)) (- m@4@00 1) (ackermann%limited ($Snap.combine
            $Snap.unit
            ($Snap.combine $Snap.unit $Snap.unit)) m@4@00 (- n@5@00 1)))))))
  :pattern ((ackermann s@$ m@4@00 n@5@00))
  :qid |quant-u-25|)))
(assert (forall ((s@$ $Snap) (a@7@00 Int) (b@8@00 Int)) (!
  (= (gcd%limited s@$ a@7@00 b@8@00) (gcd s@$ a@7@00 b@8@00))
  :pattern ((gcd s@$ a@7@00 b@8@00))
  :qid |quant-u-6|)))
(assert (forall ((s@$ $Snap) (a@7@00 Int) (b@8@00 Int)) (!
  (gcd%stateless a@7@00 b@8@00)
  :pattern ((gcd%limited s@$ a@7@00 b@8@00))
  :qid |quant-u-7|)))
(assert (forall ((s@$ $Snap) (a@7@00 Int) (b@8@00 Int)) (!
  (let ((result@9@00 (gcd%limited s@$ a@7@00 b@8@00))) (=>
    (gcd%precondition s@$ a@7@00 b@8@00)
    (and (> result@9@00 0) (and (<= result@9@00 a@7@00) (<= result@9@00 b@8@00)))))
  :pattern ((gcd%limited s@$ a@7@00 b@8@00))
  :qid |quant-u-26|)))
(assert (forall ((s@$ $Snap) (a@7@00 Int) (b@8@00 Int)) (!
  (let ((result@9@00 (gcd%limited s@$ a@7@00 b@8@00))) true)
  :pattern ((gcd%limited s@$ a@7@00 b@8@00))
  :qid |quant-u-27|)))
(assert (forall ((s@$ $Snap) (a@7@00 Int) (b@8@00 Int)) (!
  (let ((result@9@00 (gcd%limited s@$ a@7@00 b@8@00))) true)
  :pattern ((gcd%limited s@$ a@7@00 b@8@00))
  :qid |quant-u-28|)))
(assert (forall ((s@$ $Snap) (base@10@00 Int) (exp@11@00 Int)) (!
  (= (power%limited s@$ base@10@00 exp@11@00) (power s@$ base@10@00 exp@11@00))
  :pattern ((power s@$ base@10@00 exp@11@00))
  :qid |quant-u-8|)))
(assert (forall ((s@$ $Snap) (base@10@00 Int) (exp@11@00 Int)) (!
  (power%stateless base@10@00 exp@11@00)
  :pattern ((power%limited s@$ base@10@00 exp@11@00))
  :qid |quant-u-9|)))
(assert (forall ((s@$ $Snap) (base@10@00 Int) (exp@11@00 Int)) (!
  (=>
    (power%precondition s@$ base@10@00 exp@11@00)
    (=
      (power s@$ base@10@00 exp@11@00)
      (ite
        (= exp@11@00 0)
        1
        (* base@10@00 (power%limited $Snap.unit base@10@00 (- exp@11@00 1))))))
  :pattern ((power s@$ base@10@00 exp@11@00))
  :qid |quant-u-29|)))
(assert (forall ((s@$ $Snap) (base@10@00 Int) (exp@11@00 Int)) (!
  (=>
    (power%precondition s@$ base@10@00 exp@11@00)
    (ite
      (= exp@11@00 0)
      true
      (power%precondition $Snap.unit base@10@00 (- exp@11@00 1))))
  :pattern ((power s@$ base@10@00 exp@11@00))
  :qid |quant-u-30|)))
(assert (forall ((s@$ $Snap) (n@13@00 Int)) (!
  (= (sum_n%limited s@$ n@13@00) (sum_n s@$ n@13@00))
  :pattern ((sum_n s@$ n@13@00))
  :qid |quant-u-10|)))
(assert (forall ((s@$ $Snap) (n@13@00 Int)) (!
  (sum_n%stateless n@13@00)
  :pattern ((sum_n%limited s@$ n@13@00))
  :qid |quant-u-11|)))
(assert (forall ((s@$ $Snap) (n@13@00 Int)) (!
  (let ((result@14@00 (sum_n%limited s@$ n@13@00))) (=>
    (sum_n%precondition s@$ n@13@00)
    (and (>= result@14@00 0) (= result@14@00 (div (* n@13@00 (+ n@13@00 1)) 2)))))
  :pattern ((sum_n%limited s@$ n@13@00))
  :qid |quant-u-31|)))
(assert (forall ((s@$ $Snap) (n@13@00 Int)) (!
  (let ((result@14@00 (sum_n%limited s@$ n@13@00))) true)
  :pattern ((sum_n%limited s@$ n@13@00))
  :qid |quant-u-32|)))
(assert (forall ((s@$ $Snap) (n@13@00 Int)) (!
  (let ((result@14@00 (sum_n%limited s@$ n@13@00))) true)
  :pattern ((sum_n%limited s@$ n@13@00))
  :qid |quant-u-33|)))
(assert (forall ((s@$ $Snap) (n@13@00 Int)) (!
  (=>
    (sum_n%precondition s@$ n@13@00)
    (=
      (sum_n s@$ n@13@00)
      (ite (= n@13@00 0) 0 (+ n@13@00 (sum_n%limited $Snap.unit (- n@13@00 1))))))
  :pattern ((sum_n s@$ n@13@00))
  :qid |quant-u-34|)))
(assert (forall ((s@$ $Snap) (n@13@00 Int)) (!
  (=>
    (sum_n%precondition s@$ n@13@00)
    (ite (= n@13@00 0) true (sum_n%precondition $Snap.unit (- n@13@00 1))))
  :pattern ((sum_n s@$ n@13@00))
  :qid |quant-u-35|)))
(assert (forall ((s@$ $Snap) (n@15@00 Int) (k@16@00 Int)) (!
  (= (binomial%limited s@$ n@15@00 k@16@00) (binomial s@$ n@15@00 k@16@00))
  :pattern ((binomial s@$ n@15@00 k@16@00))
  :qid |quant-u-12|)))
(assert (forall ((s@$ $Snap) (n@15@00 Int) (k@16@00 Int)) (!
  (binomial%stateless n@15@00 k@16@00)
  :pattern ((binomial%limited s@$ n@15@00 k@16@00))
  :qid |quant-u-13|)))
(assert (forall ((s@$ $Snap) (n@15@00 Int) (k@16@00 Int)) (!
  (let ((result@17@00 (binomial%limited s@$ n@15@00 k@16@00))) (=>
    (binomial%precondition s@$ n@15@00 k@16@00)
    (>= result@17@00 0)))
  :pattern ((binomial%limited s@$ n@15@00 k@16@00))
  :qid |quant-u-36|)))
(assert (forall ((s@$ $Snap) (n@15@00 Int) (k@16@00 Int)) (!
  (let ((result@17@00 (binomial%limited s@$ n@15@00 k@16@00))) true)
  :pattern ((binomial%limited s@$ n@15@00 k@16@00))
  :qid |quant-u-37|)))
(assert (forall ((s@$ $Snap) (n@15@00 Int) (k@16@00 Int)) (!
  (=>
    (binomial%precondition s@$ n@15@00 k@16@00)
    (=
      (binomial s@$ n@15@00 k@16@00)
      (ite
        (> k@16@00 n@15@00)
        0
        (ite
          (or (= k@16@00 0) (= k@16@00 n@15@00))
          1
          (+
            (binomial%limited ($Snap.combine $Snap.unit $Snap.unit) (- n@15@00 1) (-
              k@16@00
              1))
            (binomial%limited ($Snap.combine $Snap.unit $Snap.unit) (- n@15@00 1) k@16@00))))))
  :pattern ((binomial s@$ n@15@00 k@16@00))
  :qid |quant-u-38|)))
(assert (forall ((s@$ $Snap) (n@15@00 Int) (k@16@00 Int)) (!
  (=>
    (binomial%precondition s@$ n@15@00 k@16@00)
    (ite
      (> k@16@00 n@15@00)
      true
      (ite
        (or (= k@16@00 0) (= k@16@00 n@15@00))
        true
        (and
          (binomial%precondition ($Snap.combine $Snap.unit $Snap.unit) (-
            n@15@00
            1) (- k@16@00 1))
          (binomial%precondition ($Snap.combine $Snap.unit $Snap.unit) (-
            n@15@00
            1) k@16@00)))))
  :pattern ((binomial s@$ n@15@00 k@16@00))
  :qid |quant-u-39|)))
; End function- and predicate-related preamble
; ------------------------------------------------------------
; ---------- test_math_functions ----------
(set-option :rlimit 0)
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
(pop) ; 2
(push) ; 2
; [exec]
; assert fib(0) == 0
; [eval] fib(0) == 0
; [eval] fib(0)
(push) ; 3
; [eval] n >= 0
(assert (fib%precondition $Snap.unit 0))
(pop) ; 3
; Joined path conditions
(assert (fib%precondition $Snap.unit 0))
(push) ; 3
(assert (not (= (fib $Snap.unit 0) 0)))
(check-sat)
; unsat
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(assert (= (fib $Snap.unit 0) 0))
; [exec]
; assert fib(1) == 1
; [eval] fib(1) == 1
; [eval] fib(1)
(push) ; 3
; [eval] n >= 0
(assert (fib%precondition $Snap.unit 1))
(pop) ; 3
; Joined path conditions
(assert (fib%precondition $Snap.unit 1))
(push) ; 3
(assert (not (= (fib $Snap.unit 1) 1)))
(check-sat)
; unsat
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(assert (= (fib $Snap.unit 1) 1))
; [exec]
; assert fib(5) == 5
; [eval] fib(5) == 5
; [eval] fib(5)
(push) ; 3
; [eval] n >= 0
(assert (fib%precondition $Snap.unit 5))
(pop) ; 3
; Joined path conditions
(assert (fib%precondition $Snap.unit 5))
(push) ; 3
(assert (not (= (fib $Snap.unit 5) 5)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] fib(5) == 5
; [eval] fib(5)
(set-option :rlimit 0)
(push) ; 3
; [eval] n >= 0
(pop) ; 3
; Joined path conditions
(push) ; 3
(assert (not (= (fib $Snap.unit 5) 5)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] fib(5) == 5
; [eval] fib(5)
(set-option :rlimit 0)
(push) ; 3
; [eval] n >= 0
(pop) ; 3
; Joined path conditions
(push) ; 3
(assert (not (= (fib $Snap.unit 5) 5)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] fib(5) == 5
; [eval] fib(5)
(set-option :rlimit 0)
(push) ; 3
; [eval] n >= 0
(pop) ; 3
; Joined path conditions
(push) ; 3
(assert (not (= (fib $Snap.unit 5) 5)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(pop) ; 2
(pop) ; 1
