(get-info :version)
; (:version "4.8.7")
; Started: 2025-12-05 12:23:27
; Silicon.version: 1.1-SNAPSHOT (95328487@(detached))
; Input file: ./functions/graph_algorithms.vpr
; Verifier id: 00
; ------------------------------------------------------------
; Begin preamble
; ////////// Static preamble
; 
; ; /z3config.smt2
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :smt.qi.max_multi_patterns 1000)
; 
; ; /preamble.smt2
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(define-fun $Perm.min ((p1 $Perm) (p2 $Perm)) Real
    (ite (<= p1 p2) p1 p2))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
; ////////// Sorts
(declare-sort Set<Edge> 0)
(declare-sort Set<Int> 0)
(declare-sort Edge 0)
; ////////// Sort wrappers
; Declaring additional sort wrappers
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.Set<Edge>To$Snap (Set<Edge>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<Edge> ($Snap) Set<Edge>)
(assert (forall ((x Set<Edge>)) (!
    (= x ($SortWrappers.$SnapToSet<Edge>($SortWrappers.Set<Edge>To$Snap x)))
    :pattern (($SortWrappers.Set<Edge>To$Snap x))
    :qid |$Snap.$SnapToSet<Edge>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<Edge>To$Snap($SortWrappers.$SnapToSet<Edge> x)))
    :pattern (($SortWrappers.$SnapToSet<Edge> x))
    :qid |$Snap.Set<Edge>To$SnapToSet<Edge>|
    )))
(declare-fun $SortWrappers.Set<Int>To$Snap (Set<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<Int> ($Snap) Set<Int>)
(assert (forall ((x Set<Int>)) (!
    (= x ($SortWrappers.$SnapToSet<Int>($SortWrappers.Set<Int>To$Snap x)))
    :pattern (($SortWrappers.Set<Int>To$Snap x))
    :qid |$Snap.$SnapToSet<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<Int>To$Snap($SortWrappers.$SnapToSet<Int> x)))
    :pattern (($SortWrappers.$SnapToSet<Int> x))
    :qid |$Snap.Set<Int>To$SnapToSet<Int>|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.EdgeTo$Snap (Edge) $Snap)
(declare-fun $SortWrappers.$SnapToEdge ($Snap) Edge)
(assert (forall ((x Edge)) (!
    (= x ($SortWrappers.$SnapToEdge($SortWrappers.EdgeTo$Snap x)))
    :pattern (($SortWrappers.EdgeTo$Snap x))
    :qid |$Snap.$SnapToEdgeTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.EdgeTo$Snap($SortWrappers.$SnapToEdge x)))
    :pattern (($SortWrappers.$SnapToEdge x))
    :qid |$Snap.EdgeTo$SnapToEdge|
    )))
; ////////// Symbols
(declare-fun Set_card (Set<Edge>) Int)
(declare-const Set_empty Set<Edge>)
(declare-fun Set_in (Edge Set<Edge>) Bool)
(declare-fun Set_singleton (Edge) Set<Edge>)
(declare-fun Set_unionone (Set<Edge> Edge) Set<Edge>)
(declare-fun Set_union (Set<Edge> Set<Edge>) Set<Edge>)
(declare-fun Set_intersection (Set<Edge> Set<Edge>) Set<Edge>)
(declare-fun Set_difference (Set<Edge> Set<Edge>) Set<Edge>)
(declare-fun Set_subset (Set<Edge> Set<Edge>) Bool)
(declare-fun Set_equal (Set<Edge> Set<Edge>) Bool)
(declare-fun Set_skolem_diff (Set<Edge> Set<Edge>) Edge)
(declare-fun Set_card (Set<Int>) Int)
(declare-const Set_empty Set<Int>)
(declare-fun Set_in (Int Set<Int>) Bool)
(declare-fun Set_singleton (Int) Set<Int>)
(declare-fun Set_unionone (Set<Int> Int) Set<Int>)
(declare-fun Set_union (Set<Int> Set<Int>) Set<Int>)
(declare-fun Set_intersection (Set<Int> Set<Int>) Set<Int>)
(declare-fun Set_difference (Set<Int> Set<Int>) Set<Int>)
(declare-fun Set_subset (Set<Int> Set<Int>) Bool)
(declare-fun Set_equal (Set<Int> Set<Int>) Bool)
(declare-fun Set_skolem_diff (Set<Int> Set<Int>) Int)
(declare-fun MkEdge<Edge> (Int Int) Edge)
(declare-fun get_Edge_from<Int> (Edge) Int)
(declare-fun get_Edge_to<Int> (Edge) Int)
(declare-fun Edge_tag<Int> (Edge) Int)
; Declaring symbols related to program functions (from program analysis)
(declare-fun choose_one ($Snap Set<Int>) Int)
(declare-fun choose_one%limited ($Snap Set<Int>) Int)
(declare-fun choose_one%stateless (Set<Int>) Bool)
(declare-fun choose_one%precondition ($Snap Set<Int>) Bool)
(declare-fun has_edge ($Snap Set<Edge> Int Int) Bool)
(declare-fun has_edge%limited ($Snap Set<Edge> Int Int) Bool)
(declare-fun has_edge%stateless (Set<Edge> Int Int) Bool)
(declare-fun has_edge%precondition ($Snap Set<Edge> Int Int) Bool)
(declare-fun get_neighbors ($Snap Set<Edge> Int Set<Int>) Set<Int>)
(declare-fun get_neighbors%limited ($Snap Set<Edge> Int Set<Int>) Set<Int>)
(declare-fun get_neighbors%stateless (Set<Edge> Int Set<Int>) Bool)
(declare-fun get_neighbors%precondition ($Snap Set<Edge> Int Set<Int>) Bool)
(declare-fun path_exists_bounded ($Snap Set<Edge> Int Int Int Set<Int> Set<Int>) Bool)
(declare-fun path_exists_bounded%limited ($Snap Set<Edge> Int Int Int Set<Int> Set<Int>) Bool)
(declare-fun path_exists_bounded%stateless (Set<Edge> Int Int Int Set<Int> Set<Int>) Bool)
(declare-fun path_exists_bounded%precondition ($Snap Set<Edge> Int Int Int Set<Int> Set<Int>) Bool)
(declare-fun path_exists_any_neighbor ($Snap Set<Edge> Int Int Int Set<Int> Set<Int> Set<Int>) Bool)
(declare-fun path_exists_any_neighbor%limited ($Snap Set<Edge> Int Int Int Set<Int> Set<Int> Set<Int>) Bool)
(declare-fun path_exists_any_neighbor%stateless (Set<Edge> Int Int Int Set<Int> Set<Int> Set<Int>) Bool)
(declare-fun path_exists_any_neighbor%precondition ($Snap Set<Edge> Int Int Int Set<Int> Set<Int> Set<Int>) Bool)
(declare-fun all_connected_from ($Snap Set<Edge> Int Set<Int> Set<Int>) Bool)
(declare-fun all_connected_from%limited ($Snap Set<Edge> Int Set<Int> Set<Int>) Bool)
(declare-fun all_connected_from%stateless (Set<Edge> Int Set<Int> Set<Int>) Bool)
(declare-fun all_connected_from%precondition ($Snap Set<Edge> Int Set<Int> Set<Int>) Bool)
(declare-fun has_incoming_edge ($Snap Set<Edge> Int Set<Int>) Bool)
(declare-fun has_incoming_edge%limited ($Snap Set<Edge> Int Set<Int>) Bool)
(declare-fun has_incoming_edge%stateless (Set<Edge> Int Set<Int>) Bool)
(declare-fun has_incoming_edge%precondition ($Snap Set<Edge> Int Set<Int>) Bool)
(declare-fun has_cycle_through_neighbors ($Snap Set<Edge> Int Int Int Set<Int> Set<Int> Set<Int>) Bool)
(declare-fun has_cycle_through_neighbors%limited ($Snap Set<Edge> Int Int Int Set<Int> Set<Int> Set<Int>) Bool)
(declare-fun has_cycle_through_neighbors%stateless (Set<Edge> Int Int Int Set<Int> Set<Int> Set<Int>) Bool)
(declare-fun has_cycle_through_neighbors%precondition ($Snap Set<Edge> Int Int Int Set<Int> Set<Int> Set<Int>) Bool)
(declare-fun has_self_loop ($Snap Set<Edge> Int Set<Int>) Bool)
(declare-fun has_self_loop%limited ($Snap Set<Edge> Int Set<Int>) Bool)
(declare-fun has_self_loop%stateless (Set<Edge> Int Set<Int>) Bool)
(declare-fun has_self_loop%precondition ($Snap Set<Edge> Int Set<Int>) Bool)
(declare-fun count_edges ($Snap Set<Edge>) Int)
(declare-fun count_edges%limited ($Snap Set<Edge>) Int)
(declare-fun count_edges%stateless (Set<Edge>) Bool)
(declare-fun count_edges%precondition ($Snap Set<Edge>) Bool)
(declare-fun is_complete_graph ($Snap Set<Edge> Set<Int> Set<Int>) Bool)
(declare-fun is_complete_graph%limited ($Snap Set<Edge> Set<Int> Set<Int>) Bool)
(declare-fun is_complete_graph%stateless (Set<Edge> Set<Int> Set<Int>) Bool)
(declare-fun is_complete_graph%precondition ($Snap Set<Edge> Set<Int> Set<Int>) Bool)
(declare-fun is_source ($Snap Set<Edge> Int Set<Int>) Bool)
(declare-fun is_source%limited ($Snap Set<Edge> Int Set<Int>) Bool)
(declare-fun is_source%stateless (Set<Edge> Int Set<Int>) Bool)
(declare-fun is_source%precondition ($Snap Set<Edge> Int Set<Int>) Bool)
(declare-fun is_sink ($Snap Set<Edge> Int Set<Int>) Bool)
(declare-fun is_sink%limited ($Snap Set<Edge> Int Set<Int>) Bool)
(declare-fun is_sink%stateless (Set<Edge> Int Set<Int>) Bool)
(declare-fun is_sink%precondition ($Snap Set<Edge> Int Set<Int>) Bool)
(declare-fun transitive_closure_from ($Snap Set<Edge> Int Int Set<Int> Set<Int>) Set<Int>)
(declare-fun transitive_closure_from%limited ($Snap Set<Edge> Int Int Set<Int> Set<Int>) Set<Int>)
(declare-fun transitive_closure_from%stateless (Set<Edge> Int Int Set<Int> Set<Int>) Bool)
(declare-fun transitive_closure_from%precondition ($Snap Set<Edge> Int Int Set<Int> Set<Int>) Bool)
(declare-fun count_nodes ($Snap Set<Int>) Int)
(declare-fun count_nodes%limited ($Snap Set<Int>) Int)
(declare-fun count_nodes%stateless (Set<Int>) Bool)
(declare-fun count_nodes%precondition ($Snap Set<Int>) Bool)
(declare-fun has_cycle_bounded ($Snap Set<Edge> Int Int Set<Int>) Bool)
(declare-fun has_cycle_bounded%limited ($Snap Set<Edge> Int Int Set<Int>) Bool)
(declare-fun has_cycle_bounded%stateless (Set<Edge> Int Int Set<Int>) Bool)
(declare-fun has_cycle_bounded%precondition ($Snap Set<Edge> Int Int Set<Int>) Bool)
(declare-fun count_outgoing ($Snap Set<Edge> Int Set<Int>) Int)
(declare-fun count_outgoing%limited ($Snap Set<Edge> Int Set<Int>) Int)
(declare-fun count_outgoing%stateless (Set<Edge> Int Set<Int>) Bool)
(declare-fun count_outgoing%precondition ($Snap Set<Edge> Int Set<Int>) Bool)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
; Declaring predicate trigger functions
; ////////// Uniqueness assumptions from domains
; ////////// Axioms
(assert (forall ((s Set<Edge>)) (!
  (<= 0 (Set_card s))
  :pattern ((Set_card s))
  :qid |$Set[Edge]_prog.Set_card_nonneg|)))
(assert (forall ((o Edge)) (!
  (not (Set_in o (as Set_empty  Set<Edge>)))
  :pattern ((Set_in o (as Set_empty  Set<Edge>)))
  :qid |$Set[Edge]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<Edge>)) (!
  (and
    (=> (= (Set_card s) 0) (= s (as Set_empty  Set<Edge>)))
    (=> (not (= (Set_card s) 0)) (exists ((x Edge))  (Set_in x s))))
  :pattern ((Set_card s))
  :qid |$Set[Edge]_prog.Set_card_zero|)))
(assert (forall ((r Edge)) (!
  (Set_in r (Set_singleton r))
  :pattern ((Set_singleton r))
  :qid |$Set[Edge]_prog.Set_singleton_contains1|)))
(assert (forall ((r Edge) (o Edge)) (!
  (= (Set_in o (Set_singleton r)) (= r o))
  :pattern ((Set_in o (Set_singleton r)))
  :qid |$Set[Edge]_prog.Set_singleton_contains2|)))
(assert (forall ((r Edge)) (!
  (= (Set_card (Set_singleton r)) 1)
  :pattern ((Set_card (Set_singleton r)))
  :qid |$Set[Edge]_prog.Set_singleton_card|)))
(assert (forall ((a Set<Edge>) (x Edge) (o Edge)) (!
  (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a)))
  :pattern ((Set_in o (Set_unionone a x)))
  :qid |$Set[Edge]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<Edge>) (x Edge)) (!
  (Set_in x (Set_unionone a x))
  :pattern ((Set_unionone a x))
  :qid |$Set[Edge]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<Edge>) (x Edge) (y Edge)) (!
  (=> (Set_in y a) (Set_in y (Set_unionone a x)))
  :pattern ((Set_unionone a x) (Set_in y a))
  :qid |$Set[Edge]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<Edge>) (x Edge)) (!
  (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[Edge]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<Edge>) (x Edge)) (!
  (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[Edge]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<Edge>) (b Set<Edge>) (o Edge)) (!
  (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_union a b)))
  :qid |$Set[Edge]_prog.Set_union_contains1|)))
(assert (forall ((a Set<Edge>) (b Set<Edge>) (y Edge)) (!
  (=> (Set_in y a) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y a))
  :qid |$Set[Edge]_prog.Set_union_contains2|)))
(assert (forall ((a Set<Edge>) (b Set<Edge>) (y Edge)) (!
  (=> (Set_in y b) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y b))
  :qid |$Set[Edge]_prog.Set_union_contains3|)))
(assert (forall ((a Set<Edge>) (b Set<Edge>) (o Edge)) (!
  (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_intersection a b)))
  :pattern ((Set_intersection a b) (Set_in o a))
  :pattern ((Set_intersection a b) (Set_in o b))
  :qid |$Set[Edge]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<Edge>) (b Set<Edge>)) (!
  (= (Set_union (Set_union a b) b) (Set_union a b))
  :pattern ((Set_union (Set_union a b) b))
  :qid |$Set[Edge]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<Edge>) (b Set<Edge>)) (!
  (= (Set_union a (Set_union a b)) (Set_union a b))
  :pattern ((Set_union a (Set_union a b)))
  :qid |$Set[Edge]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<Edge>) (b Set<Edge>)) (!
  (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b))
  :pattern ((Set_intersection (Set_intersection a b) b))
  :qid |$Set[Edge]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<Edge>) (b Set<Edge>)) (!
  (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b))
  :pattern ((Set_intersection a (Set_intersection a b)))
  :qid |$Set[Edge]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<Edge>) (b Set<Edge>)) (!
  (=
    (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b)))
    (+ (Set_card a) (Set_card b)))
  :pattern ((Set_card (Set_union a b)))
  :pattern ((Set_card (Set_intersection a b)))
  :qid |$Set[Edge]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<Edge>) (b Set<Edge>) (o Edge)) (!
  (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b))))
  :pattern ((Set_in o (Set_difference a b)))
  :pattern ((Set_difference a b) (Set_in o a))
  :qid |$Set[Edge]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<Edge>) (b Set<Edge>) (y Edge)) (!
  (=> (Set_in y b) (not (Set_in y (Set_difference a b))))
  :pattern ((Set_difference a b) (Set_in y b))
  :qid |$Set[Edge]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<Edge>) (b Set<Edge>)) (!
  (and
    (=
      (+
        (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a)))
        (Set_card (Set_intersection a b)))
      (Set_card (Set_union a b)))
    (=
      (Set_card (Set_difference a b))
      (- (Set_card a) (Set_card (Set_intersection a b)))))
  :pattern ((Set_card (Set_difference a b)))
  :qid |$Set[Edge]_prog.Set_diff_card|)))
(assert (forall ((a Set<Edge>) (b Set<Edge>)) (!
  (=
    (Set_subset a b)
    (forall ((o Edge)) (!
      (=> (Set_in o a) (Set_in o b))
      :pattern ((Set_in o a))
      :pattern ((Set_in o b))
      )))
  :pattern ((Set_subset a b))
  :qid |$Set[Edge]_prog.Set_subset_def|)))
(assert (forall ((a Set<Edge>) (b Set<Edge>)) (!
  (or
    (and (Set_equal a b) (= a b))
    (and
      (not (Set_equal a b))
      (and
        (not (= a b))
        (and
          (= (Set_skolem_diff a b) (Set_skolem_diff b a))
          (not
            (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b)))))))
  :pattern ((Set_equal a b))
  :qid |$Set[Edge]_prog.Set_equal_def|)))
(assert (forall ((a Set<Edge>) (b Set<Edge>)) (!
  (=> (Set_equal a b) (= a b))
  :pattern ((Set_equal a b))
  :qid |$Set[Edge]_prog.Set_equal_ext|)))
(assert (forall ((s Set<Int>)) (!
  (<= 0 (Set_card s))
  :pattern ((Set_card s))
  :qid |$Set[Int]_prog.Set_card_nonneg|)))
(assert (forall ((o Int)) (!
  (not (Set_in o (as Set_empty  Set<Int>)))
  :pattern ((Set_in o (as Set_empty  Set<Int>)))
  :qid |$Set[Int]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<Int>)) (!
  (and
    (=> (= (Set_card s) 0) (= s (as Set_empty  Set<Int>)))
    (=> (not (= (Set_card s) 0)) (exists ((x Int))  (Set_in x s))))
  :pattern ((Set_card s))
  :qid |$Set[Int]_prog.Set_card_zero|)))
(assert (forall ((r Int)) (!
  (Set_in r (Set_singleton r))
  :pattern ((Set_singleton r))
  :qid |$Set[Int]_prog.Set_singleton_contains1|)))
(assert (forall ((r Int) (o Int)) (!
  (= (Set_in o (Set_singleton r)) (= r o))
  :pattern ((Set_in o (Set_singleton r)))
  :qid |$Set[Int]_prog.Set_singleton_contains2|)))
(assert (forall ((r Int)) (!
  (= (Set_card (Set_singleton r)) 1)
  :pattern ((Set_card (Set_singleton r)))
  :qid |$Set[Int]_prog.Set_singleton_card|)))
(assert (forall ((a Set<Int>) (x Int) (o Int)) (!
  (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a)))
  :pattern ((Set_in o (Set_unionone a x)))
  :qid |$Set[Int]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<Int>) (x Int)) (!
  (Set_in x (Set_unionone a x))
  :pattern ((Set_unionone a x))
  :qid |$Set[Int]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<Int>) (x Int) (y Int)) (!
  (=> (Set_in y a) (Set_in y (Set_unionone a x)))
  :pattern ((Set_unionone a x) (Set_in y a))
  :qid |$Set[Int]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<Int>) (x Int)) (!
  (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[Int]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<Int>) (x Int)) (!
  (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[Int]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (o Int)) (!
  (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_union a b)))
  :qid |$Set[Int]_prog.Set_union_contains1|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (y Int)) (!
  (=> (Set_in y a) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y a))
  :qid |$Set[Int]_prog.Set_union_contains2|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (y Int)) (!
  (=> (Set_in y b) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y b))
  :qid |$Set[Int]_prog.Set_union_contains3|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (o Int)) (!
  (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_intersection a b)))
  :pattern ((Set_intersection a b) (Set_in o a))
  :pattern ((Set_intersection a b) (Set_in o b))
  :qid |$Set[Int]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (= (Set_union (Set_union a b) b) (Set_union a b))
  :pattern ((Set_union (Set_union a b) b))
  :qid |$Set[Int]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (= (Set_union a (Set_union a b)) (Set_union a b))
  :pattern ((Set_union a (Set_union a b)))
  :qid |$Set[Int]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b))
  :pattern ((Set_intersection (Set_intersection a b) b))
  :qid |$Set[Int]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b))
  :pattern ((Set_intersection a (Set_intersection a b)))
  :qid |$Set[Int]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (=
    (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b)))
    (+ (Set_card a) (Set_card b)))
  :pattern ((Set_card (Set_union a b)))
  :pattern ((Set_card (Set_intersection a b)))
  :qid |$Set[Int]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (o Int)) (!
  (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b))))
  :pattern ((Set_in o (Set_difference a b)))
  :pattern ((Set_difference a b) (Set_in o a))
  :qid |$Set[Int]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (y Int)) (!
  (=> (Set_in y b) (not (Set_in y (Set_difference a b))))
  :pattern ((Set_difference a b) (Set_in y b))
  :qid |$Set[Int]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (and
    (=
      (+
        (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a)))
        (Set_card (Set_intersection a b)))
      (Set_card (Set_union a b)))
    (=
      (Set_card (Set_difference a b))
      (- (Set_card a) (Set_card (Set_intersection a b)))))
  :pattern ((Set_card (Set_difference a b)))
  :qid |$Set[Int]_prog.Set_diff_card|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (=
    (Set_subset a b)
    (forall ((o Int)) (!
      (=> (Set_in o a) (Set_in o b))
      :pattern ((Set_in o a))
      :pattern ((Set_in o b))
      )))
  :pattern ((Set_subset a b))
  :qid |$Set[Int]_prog.Set_subset_def|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (or
    (and (Set_equal a b) (= a b))
    (and
      (not (Set_equal a b))
      (and
        (not (= a b))
        (and
          (= (Set_skolem_diff a b) (Set_skolem_diff b a))
          (not
            (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b)))))))
  :pattern ((Set_equal a b))
  :qid |$Set[Int]_prog.Set_equal_def|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (=> (Set_equal a b) (= a b))
  :pattern ((Set_equal a b))
  :qid |$Set[Int]_prog.Set_equal_ext|)))
(assert (forall ((from Int) (to Int)) (!
  (= from (get_Edge_from<Int> (MkEdge<Edge> from to)))
  :pattern ((MkEdge<Edge> from to))
  )))
(assert (forall ((from Int) (to Int)) (!
  (= to (get_Edge_to<Int> (MkEdge<Edge> from to)))
  :pattern ((MkEdge<Edge> from to))
  )))
(assert (forall ((from Int) (to Int)) (!
  (= (Edge_tag<Int> (MkEdge<Edge> from to)) 0)
  :pattern ((MkEdge<Edge> from to))
  )))
(assert (forall ((t Edge)) (!
  (= t (MkEdge<Edge> (get_Edge_from<Int> t) (get_Edge_to<Int> t)))
  :pattern ((Edge_tag<Int> t))
  :pattern ((get_Edge_from<Int> t))
  :pattern ((get_Edge_to<Int> t))
  )))
; End preamble
; ------------------------------------------------------------
; State saturation: after preamble
(set-option :rlimit 160000)
(check-sat)
; unknown
; ---------- FUNCTION choose_one----------
(declare-fun s@0@00 () Set<Int>)
(declare-fun result@1@00 () Int)
; ----- Well-definedness of specifications -----
(set-option :rlimit 0)
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] |s| > 0
; [eval] |s|
(assert (> (Set_card s@0@00) 0))
(declare-const $t@77@00 $Snap)
(assert (= $t@77@00 $Snap.unit))
; [eval] (result in s)
(assert (Set_in result@1@00 s@0@00))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@0@00 Set<Int>)) (!
  (= (choose_one%limited s@$ s@0@00) (choose_one s@$ s@0@00))
  :pattern ((choose_one s@$ s@0@00))
  :qid |quant-u-0|)))
(assert (forall ((s@$ $Snap) (s@0@00 Set<Int>)) (!
  (choose_one%stateless s@0@00)
  :pattern ((choose_one%limited s@$ s@0@00))
  :qid |quant-u-1|)))
(assert (forall ((s@$ $Snap) (s@0@00 Set<Int>)) (!
  (let ((result@1@00 (choose_one%limited s@$ s@0@00))) (=>
    (choose_one%precondition s@$ s@0@00)
    (Set_in result@1@00 s@0@00)))
  :pattern ((choose_one%limited s@$ s@0@00))
  :qid |quant-u-34|)))
(assert (forall ((s@$ $Snap) (s@0@00 Set<Int>)) (!
  (let ((result@1@00 (choose_one%limited s@$ s@0@00))) true)
  :pattern ((choose_one%limited s@$ s@0@00))
  :qid |quant-u-35|)))
; ---------- FUNCTION has_edge----------
(declare-fun edges@2@00 () Set<Edge>)
(declare-fun from@3@00 () Int)
(declare-fun to@4@00 () Int)
(declare-fun result@5@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@2@00 Set<Edge>) (from@3@00 Int) (to@4@00 Int)) (!
  (=
    (has_edge%limited s@$ edges@2@00 from@3@00 to@4@00)
    (has_edge s@$ edges@2@00 from@3@00 to@4@00))
  :pattern ((has_edge s@$ edges@2@00 from@3@00 to@4@00))
  :qid |quant-u-2|)))
(assert (forall ((s@$ $Snap) (edges@2@00 Set<Edge>) (from@3@00 Int) (to@4@00 Int)) (!
  (has_edge%stateless edges@2@00 from@3@00 to@4@00)
  :pattern ((has_edge%limited s@$ edges@2@00 from@3@00 to@4@00))
  :qid |quant-u-3|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (MkEdge(from, to) in edges)
; [eval] MkEdge(from, to)
(assert (= result@5@00 (Set_in (MkEdge<Edge> from@3@00 to@4@00) edges@2@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@2@00 Set<Edge>) (from@3@00 Int) (to@4@00 Int)) (!
  (=>
    (has_edge%precondition s@$ edges@2@00 from@3@00 to@4@00)
    (=
      (has_edge s@$ edges@2@00 from@3@00 to@4@00)
      (Set_in (MkEdge<Edge> from@3@00 to@4@00) edges@2@00)))
  :pattern ((has_edge s@$ edges@2@00 from@3@00 to@4@00))
  :qid |quant-u-36|)))
(assert (forall ((s@$ $Snap) (edges@2@00 Set<Edge>) (from@3@00 Int) (to@4@00 Int)) (!
  true
  :pattern ((has_edge s@$ edges@2@00 from@3@00 to@4@00))
  :qid |quant-u-37|)))
; ---------- FUNCTION get_neighbors----------
(declare-fun edges@6@00 () Set<Edge>)
(declare-fun node@7@00 () Int)
(declare-fun allNodes@8@00 () Set<Int>)
(declare-fun result@9@00 () Set<Int>)
; ----- Well-definedness of specifications -----
(set-option :rlimit 0)
(push) ; 1
(declare-const $t@78@00 $Snap)
(assert (= $t@78@00 $Snap.unit))
; [eval] (forall n: Int :: { (n in result) } { has_edge(edges, node, n) } (n in result) ==> has_edge(edges, node, n))
(declare-const n@79@00 Int)
(push) ; 2
; [eval] (n in result) ==> has_edge(edges, node, n)
; [eval] (n in result)
(push) ; 3
; [then-branch: 0 | n@79@00 in result@9@00 | live]
; [else-branch: 0 | !(n@79@00 in result@9@00) | live]
(push) ; 4
; [then-branch: 0 | n@79@00 in result@9@00]
(assert (Set_in n@79@00 result@9@00))
; [eval] has_edge(edges, node, n)
(push) ; 5
(assert (has_edge%precondition $Snap.unit edges@6@00 node@7@00 n@79@00))
(pop) ; 5
; Joined path conditions
(assert (has_edge%precondition $Snap.unit edges@6@00 node@7@00 n@79@00))
(pop) ; 4
(push) ; 4
; [else-branch: 0 | !(n@79@00 in result@9@00)]
(assert (not (Set_in n@79@00 result@9@00)))
(pop) ; 4
(pop) ; 3
; Joined path conditions
(assert (=>
  (Set_in n@79@00 result@9@00)
  (and
    (Set_in n@79@00 result@9@00)
    (has_edge%precondition $Snap.unit edges@6@00 node@7@00 n@79@00))))
; Joined path conditions
(assert (or (not (Set_in n@79@00 result@9@00)) (Set_in n@79@00 result@9@00)))
(pop) ; 2
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@79@00 Int)) (!
  (and
    (=>
      (Set_in n@79@00 result@9@00)
      (and
        (Set_in n@79@00 result@9@00)
        (has_edge%precondition $Snap.unit edges@6@00 node@7@00 n@79@00)))
    (or (not (Set_in n@79@00 result@9@00)) (Set_in n@79@00 result@9@00)))
  :pattern ((Set_in n@79@00 result@9@00))
  :qid |prog./root/evaluation/2_performance/functions/graph_algorithms.vpr@17@11@17@68-aux|)))
(assert (forall ((n@79@00 Int)) (!
  (and
    (=>
      (Set_in n@79@00 result@9@00)
      (and
        (Set_in n@79@00 result@9@00)
        (has_edge%precondition $Snap.unit edges@6@00 node@7@00 n@79@00)))
    (or (not (Set_in n@79@00 result@9@00)) (Set_in n@79@00 result@9@00)))
  :pattern ((has_edge%limited $Snap.unit edges@6@00 node@7@00 n@79@00))
  :qid |prog./root/evaluation/2_performance/functions/graph_algorithms.vpr@17@11@17@68-aux|)))
(assert (forall ((n@79@00 Int)) (!
  (=>
    (Set_in n@79@00 result@9@00)
    (has_edge $Snap.unit edges@6@00 node@7@00 n@79@00))
  :pattern ((Set_in n@79@00 result@9@00))
  :pattern ((has_edge%limited $Snap.unit edges@6@00 node@7@00 n@79@00))
  :qid |prog./root/evaluation/2_performance/functions/graph_algorithms.vpr@17@11@17@68|)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@6@00 Set<Edge>) (node@7@00 Int) (allNodes@8@00 Set<Int>)) (!
  (=
    (get_neighbors%limited s@$ edges@6@00 node@7@00 allNodes@8@00)
    (get_neighbors s@$ edges@6@00 node@7@00 allNodes@8@00))
  :pattern ((get_neighbors s@$ edges@6@00 node@7@00 allNodes@8@00))
  :qid |quant-u-4|)))
(assert (forall ((s@$ $Snap) (edges@6@00 Set<Edge>) (node@7@00 Int) (allNodes@8@00 Set<Int>)) (!
  (get_neighbors%stateless edges@6@00 node@7@00 allNodes@8@00)
  :pattern ((get_neighbors%limited s@$ edges@6@00 node@7@00 allNodes@8@00))
  :qid |quant-u-5|)))
(assert (forall ((s@$ $Snap) (edges@6@00 Set<Edge>) (node@7@00 Int) (allNodes@8@00 Set<Int>)) (!
  (let ((result@9@00 (get_neighbors%limited s@$ edges@6@00 node@7@00 allNodes@8@00))) (=>
    (get_neighbors%precondition s@$ edges@6@00 node@7@00 allNodes@8@00)
    (forall ((n Int)) (!
      (=> (Set_in n result@9@00) (has_edge $Snap.unit edges@6@00 node@7@00 n))
      :pattern ((Set_in n result@9@00))
      :pattern ((has_edge%limited $Snap.unit edges@6@00 node@7@00 n))
      ))))
  :pattern ((get_neighbors%limited s@$ edges@6@00 node@7@00 allNodes@8@00))
  :qid |quant-u-38|)))
(assert (forall ((s@$ $Snap) (edges@6@00 Set<Edge>) (node@7@00 Int) (allNodes@8@00 Set<Int>)) (!
  (let ((result@9@00 (get_neighbors%limited s@$ edges@6@00 node@7@00 allNodes@8@00))) (=>
    (get_neighbors%precondition s@$ edges@6@00 node@7@00 allNodes@8@00)
    (forall ((n Int)) (!
      (=>
        (Set_in n result@9@00)
        (has_edge%precondition $Snap.unit edges@6@00 node@7@00 n))
      :pattern ((Set_in n result@9@00))
      :pattern ((has_edge%limited $Snap.unit edges@6@00 node@7@00 n))
      ))))
  :pattern ((get_neighbors%limited s@$ edges@6@00 node@7@00 allNodes@8@00))
  :qid |quant-u-39|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|allNodes| == 0 ? Set[Int]() : (let n == (choose_one(allNodes)) in (has_edge(edges, node, n) ? (Set(n) union get_neighbors(edges, node, (allNodes setminus Set(n)))) : get_neighbors(edges, node, (allNodes setminus Set(n))))))
; [eval] |allNodes| == 0
; [eval] |allNodes|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Set_card allNodes@8@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Set_card allNodes@8@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1 | |allNodes@8@00| == 0 | live]
; [else-branch: 1 | |allNodes@8@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 1 | |allNodes@8@00| == 0]
(assert (= (Set_card allNodes@8@00) 0))
; [eval] Set[Int]()
(pop) ; 3
(push) ; 3
; [else-branch: 1 | |allNodes@8@00| != 0]
(assert (not (= (Set_card allNodes@8@00) 0)))
; [eval] (let n == (choose_one(allNodes)) in (has_edge(edges, node, n) ? (Set(n) union get_neighbors(edges, node, (allNodes setminus Set(n)))) : get_neighbors(edges, node, (allNodes setminus Set(n)))))
; [eval] choose_one(allNodes)
(push) ; 4
; [eval] |s| > 0
; [eval] |s|
(push) ; 5
(assert (not (> (Set_card allNodes@8@00) 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (> (Set_card allNodes@8@00) 0))
(assert (choose_one%precondition $Snap.unit allNodes@8@00))
(pop) ; 4
; Joined path conditions
(assert (and
  (> (Set_card allNodes@8@00) 0)
  (choose_one%precondition $Snap.unit allNodes@8@00)))
(declare-fun letvar@80@00 ($Snap Set<Edge> Int Set<Int>) Int)
(assert (=
  (letvar@80@00 s@$ edges@6@00 node@7@00 allNodes@8@00)
  (choose_one $Snap.unit allNodes@8@00)))
; [eval] (has_edge(edges, node, n) ? (Set(n) union get_neighbors(edges, node, (allNodes setminus Set(n)))) : get_neighbors(edges, node, (allNodes setminus Set(n))))
; [eval] has_edge(edges, node, n)
(push) ; 4
(assert (has_edge%precondition $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00)))
(pop) ; 4
; Joined path conditions
(assert (has_edge%precondition $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00)))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (has_edge $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00)))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (has_edge $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 2 | has_edge(_, edges@6@00, node@7@00, choose_one(_, allNodes@8@00)) | live]
; [else-branch: 2 | !(has_edge(_, edges@6@00, node@7@00, choose_one(_, allNodes@8@00))) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 2 | has_edge(_, edges@6@00, node@7@00, choose_one(_, allNodes@8@00))]
(assert (has_edge $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00)))
; [eval] (Set(n) union get_neighbors(edges, node, (allNodes setminus Set(n))))
; [eval] Set(n)
; [eval] get_neighbors(edges, node, (allNodes setminus Set(n)))
; [eval] (allNodes setminus Set(n))
; [eval] Set(n)
(push) ; 6
(assert (get_neighbors%precondition $Snap.unit edges@6@00 node@7@00 (Set_difference allNodes@8@00 (Set_singleton (choose_one $Snap.unit allNodes@8@00)))))
(pop) ; 6
; Joined path conditions
(assert (get_neighbors%precondition $Snap.unit edges@6@00 node@7@00 (Set_difference allNodes@8@00 (Set_singleton (choose_one $Snap.unit allNodes@8@00)))))
(pop) ; 5
(push) ; 5
; [else-branch: 2 | !(has_edge(_, edges@6@00, node@7@00, choose_one(_, allNodes@8@00)))]
(assert (not
  (has_edge $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00))))
; [eval] get_neighbors(edges, node, (allNodes setminus Set(n)))
; [eval] (allNodes setminus Set(n))
; [eval] Set(n)
(push) ; 6
(assert (get_neighbors%precondition $Snap.unit edges@6@00 node@7@00 (Set_difference allNodes@8@00 (Set_singleton (choose_one $Snap.unit allNodes@8@00)))))
(pop) ; 6
; Joined path conditions
(assert (get_neighbors%precondition $Snap.unit edges@6@00 node@7@00 (Set_difference allNodes@8@00 (Set_singleton (choose_one $Snap.unit allNodes@8@00)))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=>
  (has_edge $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00))
  (and
    (has_edge $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00))
    (get_neighbors%precondition $Snap.unit edges@6@00 node@7@00 (Set_difference allNodes@8@00 (Set_singleton (choose_one $Snap.unit allNodes@8@00)))))))
; Joined path conditions
(assert (=>
  (not
    (has_edge $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00)))
  (and
    (not
      (has_edge $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00)))
    (get_neighbors%precondition $Snap.unit edges@6@00 node@7@00 (Set_difference allNodes@8@00 (Set_singleton (choose_one $Snap.unit allNodes@8@00)))))))
(assert (or
  (not
    (has_edge $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00)))
  (has_edge $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Set_card allNodes@8@00) 0))
  (and
    (not (= (Set_card allNodes@8@00) 0))
    (> (Set_card allNodes@8@00) 0)
    (choose_one%precondition $Snap.unit allNodes@8@00)
    (=
      (letvar@80@00 s@$ edges@6@00 node@7@00 allNodes@8@00)
      (choose_one $Snap.unit allNodes@8@00))
    (has_edge%precondition $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00))
    (=>
      (has_edge $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00))
      (and
        (has_edge $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00))
        (get_neighbors%precondition $Snap.unit edges@6@00 node@7@00 (Set_difference allNodes@8@00 (Set_singleton (choose_one $Snap.unit allNodes@8@00))))))
    (=>
      (not
        (has_edge $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00)))
      (and
        (not
          (has_edge $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00)))
        (get_neighbors%precondition $Snap.unit edges@6@00 node@7@00 (Set_difference allNodes@8@00 (Set_singleton (choose_one $Snap.unit allNodes@8@00))))))
    (or
      (not
        (has_edge $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00)))
      (has_edge $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00))))))
(assert (or (not (= (Set_card allNodes@8@00) 0)) (= (Set_card allNodes@8@00) 0)))
(assert (=
  result@9@00
  (ite
    (= (Set_card allNodes@8@00) 0)
    (as Set_empty  Set<Int>)
    (ite
      (has_edge $Snap.unit edges@6@00 node@7@00 (choose_one $Snap.unit allNodes@8@00))
      (Set_union (Set_singleton (choose_one $Snap.unit allNodes@8@00)) (get_neighbors $Snap.unit edges@6@00 node@7@00 (Set_difference allNodes@8@00 (Set_singleton (choose_one $Snap.unit allNodes@8@00)))))
      (get_neighbors $Snap.unit edges@6@00 node@7@00 (Set_difference allNodes@8@00 (Set_singleton (choose_one $Snap.unit allNodes@8@00))))))))
; [eval] (forall n: Int :: { (n in result) } { has_edge(edges, node, n) } (n in result) ==> has_edge(edges, node, n))
(declare-const n@81@00 Int)
(push) ; 2
; [eval] (n in result) ==> has_edge(edges, node, n)
; [eval] (n in result)
(push) ; 3
; [then-branch: 3 | n@81@00 in result@9@00 | live]
; [else-branch: 3 | !(n@81@00 in result@9@00) | live]
(push) ; 4
; [then-branch: 3 | n@81@00 in result@9@00]
(assert (Set_in n@81@00 result@9@00))
; [eval] has_edge(edges, node, n)
(push) ; 5
(assert (has_edge%precondition $Snap.unit edges@6@00 node@7@00 n@81@00))
(pop) ; 5
; Joined path conditions
(assert (has_edge%precondition $Snap.unit edges@6@00 node@7@00 n@81@00))
(pop) ; 4
(push) ; 4
; [else-branch: 3 | !(n@81@00 in result@9@00)]
(assert (not (Set_in n@81@00 result@9@00)))
(pop) ; 4
(pop) ; 3
; Joined path conditions
(assert (=>
  (Set_in n@81@00 result@9@00)
  (and
    (Set_in n@81@00 result@9@00)
    (has_edge%precondition $Snap.unit edges@6@00 node@7@00 n@81@00))))
; Joined path conditions
(assert (or (not (Set_in n@81@00 result@9@00)) (Set_in n@81@00 result@9@00)))
(pop) ; 2
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((n@81@00 Int)) (!
  (and
    (=>
      (Set_in n@81@00 result@9@00)
      (and
        (Set_in n@81@00 result@9@00)
        (has_edge%precondition $Snap.unit edges@6@00 node@7@00 n@81@00)))
    (or (not (Set_in n@81@00 result@9@00)) (Set_in n@81@00 result@9@00)))
  :pattern ((Set_in n@81@00 result@9@00))
  :qid |prog./root/evaluation/2_performance/functions/graph_algorithms.vpr@17@11@17@68-aux|)))
(assert (forall ((n@81@00 Int)) (!
  (and
    (=>
      (Set_in n@81@00 result@9@00)
      (and
        (Set_in n@81@00 result@9@00)
        (has_edge%precondition $Snap.unit edges@6@00 node@7@00 n@81@00)))
    (or (not (Set_in n@81@00 result@9@00)) (Set_in n@81@00 result@9@00)))
  :pattern ((has_edge%limited $Snap.unit edges@6@00 node@7@00 n@81@00))
  :qid |prog./root/evaluation/2_performance/functions/graph_algorithms.vpr@17@11@17@68-aux|)))
(assert (forall ((n@81@00 Int)) (!
  (=>
    (Set_in n@81@00 result@9@00)
    (has_edge%precondition $Snap.unit edges@6@00 node@7@00 n@81@00))
  :pattern ((Set_in n@81@00 result@9@00))
  :pattern ((has_edge%limited $Snap.unit edges@6@00 node@7@00 n@81@00))
  :qid |prog./root/evaluation/2_performance/functions/graph_algorithms.vpr@17@11@17@68_precondition|)))
(push) ; 2
(assert (not (forall ((n@81@00 Int)) (!
  (=>
    (and
      (=>
        (Set_in n@81@00 result@9@00)
        (has_edge%precondition $Snap.unit edges@6@00 node@7@00 n@81@00))
      (Set_in n@81@00 result@9@00))
    (has_edge $Snap.unit edges@6@00 node@7@00 n@81@00))
  :pattern ((Set_in n@81@00 result@9@00))
  :pattern ((has_edge%limited $Snap.unit edges@6@00 node@7@00 n@81@00))
  :qid |prog./root/evaluation/2_performance/functions/graph_algorithms.vpr@17@11@17@68|))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (forall ((n@81@00 Int)) (!
  (=>
    (Set_in n@81@00 result@9@00)
    (has_edge $Snap.unit edges@6@00 node@7@00 n@81@00))
  :pattern ((Set_in n@81@00 result@9@00))
  :pattern ((has_edge%limited $Snap.unit edges@6@00 node@7@00 n@81@00))
  :qid |prog./root/evaluation/2_performance/functions/graph_algorithms.vpr@17@11@17@68|)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@6@00 Set<Edge>) (node@7@00 Int) (allNodes@8@00 Set<Int>)) (!
  (=>
    (get_neighbors%precondition s@$ edges@6@00 node@7@00 allNodes@8@00)
    (=
      (get_neighbors s@$ edges@6@00 node@7@00 allNodes@8@00)
      (ite
        (= (Set_card allNodes@8@00) 0)
        (as Set_empty  Set<Int>)
        (let ((n (choose_one $Snap.unit allNodes@8@00))) (ite
          (has_edge $Snap.unit edges@6@00 node@7@00 n)
          (Set_union (Set_singleton n) (get_neighbors%limited $Snap.unit edges@6@00 node@7@00 (Set_difference allNodes@8@00 (Set_singleton n))))
          (get_neighbors%limited $Snap.unit edges@6@00 node@7@00 (Set_difference allNodes@8@00 (Set_singleton n))))))))
  :pattern ((get_neighbors s@$ edges@6@00 node@7@00 allNodes@8@00))
  :qid |quant-u-40|)))
(assert (forall ((s@$ $Snap) (edges@6@00 Set<Edge>) (node@7@00 Int) (allNodes@8@00 Set<Int>)) (!
  (=>
    (get_neighbors%precondition s@$ edges@6@00 node@7@00 allNodes@8@00)
    (ite
      (= (Set_card allNodes@8@00) 0)
      true
      (and
        (choose_one%precondition $Snap.unit allNodes@8@00)
        (let ((n (choose_one $Snap.unit allNodes@8@00))) (and
          (has_edge%precondition $Snap.unit edges@6@00 node@7@00 n)
          (get_neighbors%precondition $Snap.unit edges@6@00 node@7@00 (Set_difference allNodes@8@00 (Set_singleton n))))))))
  :pattern ((get_neighbors s@$ edges@6@00 node@7@00 allNodes@8@00))
  :qid |quant-u-41|)))
; ---------- FUNCTION path_exists_bounded----------
(declare-fun edges@10@00 () Set<Edge>)
(declare-fun from@11@00 () Int)
(declare-fun to@12@00 () Int)
(declare-fun depth@13@00 () Int)
(declare-fun visited@14@00 () Set<Int>)
(declare-fun allNodes@15@00 () Set<Int>)
(declare-fun result@16@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] depth >= 0
(assert (>= depth@13@00 0))
(declare-const $t@82@00 $Snap)
(assert (= $t@82@00 ($Snap.combine ($Snap.first $t@82@00) ($Snap.second $t@82@00))))
(assert (= ($Snap.first $t@82@00) $Snap.unit))
; [eval] from == to ==> result
; [eval] from == to
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= from@11@00 to@12@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= from@11@00 to@12@00)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 4 | from@11@00 == to@12@00 | live]
; [else-branch: 4 | from@11@00 != to@12@00 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 4 | from@11@00 == to@12@00]
(assert (= from@11@00 to@12@00))
(pop) ; 3
(push) ; 3
; [else-branch: 4 | from@11@00 != to@12@00]
(assert (not (= from@11@00 to@12@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= from@11@00 to@12@00)) (= from@11@00 to@12@00)))
(assert (=> (= from@11@00 to@12@00) result@16@00))
(assert (= ($Snap.second $t@82@00) $Snap.unit))
; [eval] depth == 0 && from != to ==> !result
; [eval] depth == 0 && from != to
; [eval] depth == 0
(push) ; 2
; [then-branch: 5 | depth@13@00 != 0 | live]
; [else-branch: 5 | depth@13@00 == 0 | live]
(push) ; 3
; [then-branch: 5 | depth@13@00 != 0]
(assert (not (= depth@13@00 0)))
(pop) ; 3
(push) ; 3
; [else-branch: 5 | depth@13@00 == 0]
(assert (= depth@13@00 0))
; [eval] from != to
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (= depth@13@00 0) (not (= depth@13@00 0))))
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (and (= depth@13@00 0) (not (= from@11@00 to@12@00))))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (and (= depth@13@00 0) (not (= from@11@00 to@12@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 6 | depth@13@00 == 0 && from@11@00 != to@12@00 | live]
; [else-branch: 6 | !(depth@13@00 == 0 && from@11@00 != to@12@00) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 6 | depth@13@00 == 0 && from@11@00 != to@12@00]
(assert (and (= depth@13@00 0) (not (= from@11@00 to@12@00))))
; [eval] !result
(pop) ; 3
(push) ; 3
; [else-branch: 6 | !(depth@13@00 == 0 && from@11@00 != to@12@00)]
(assert (not (and (= depth@13@00 0) (not (= from@11@00 to@12@00)))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or
  (not (and (= depth@13@00 0) (not (= from@11@00 to@12@00))))
  (and (= depth@13@00 0) (not (= from@11@00 to@12@00)))))
(assert (=> (and (= depth@13@00 0) (not (= from@11@00 to@12@00))) (not result@16@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@10@00 Set<Edge>) (from@11@00 Int) (to@12@00 Int) (depth@13@00 Int) (visited@14@00 Set<Int>) (allNodes@15@00 Set<Int>)) (!
  (=
    (path_exists_bounded%limited s@$ edges@10@00 from@11@00 to@12@00 depth@13@00 visited@14@00 allNodes@15@00)
    (path_exists_bounded s@$ edges@10@00 from@11@00 to@12@00 depth@13@00 visited@14@00 allNodes@15@00))
  :pattern ((path_exists_bounded s@$ edges@10@00 from@11@00 to@12@00 depth@13@00 visited@14@00 allNodes@15@00))
  :qid |quant-u-6|)))
(assert (forall ((s@$ $Snap) (edges@10@00 Set<Edge>) (from@11@00 Int) (to@12@00 Int) (depth@13@00 Int) (visited@14@00 Set<Int>) (allNodes@15@00 Set<Int>)) (!
  (path_exists_bounded%stateless edges@10@00 from@11@00 to@12@00 depth@13@00 visited@14@00 allNodes@15@00)
  :pattern ((path_exists_bounded%limited s@$ edges@10@00 from@11@00 to@12@00 depth@13@00 visited@14@00 allNodes@15@00))
  :qid |quant-u-7|)))
(assert (forall ((s@$ $Snap) (edges@10@00 Set<Edge>) (from@11@00 Int) (to@12@00 Int) (depth@13@00 Int) (visited@14@00 Set<Int>) (allNodes@15@00 Set<Int>)) (!
  (let ((result@16@00 (path_exists_bounded%limited s@$ edges@10@00 from@11@00 to@12@00 depth@13@00 visited@14@00 allNodes@15@00))) (=>
    (path_exists_bounded%precondition s@$ edges@10@00 from@11@00 to@12@00 depth@13@00 visited@14@00 allNodes@15@00)
    (and
      (=> (= from@11@00 to@12@00) result@16@00)
      (=>
        (and (= depth@13@00 0) (not (= from@11@00 to@12@00)))
        (not result@16@00)))))
  :pattern ((path_exists_bounded%limited s@$ edges@10@00 from@11@00 to@12@00 depth@13@00 visited@14@00 allNodes@15@00))
  :qid |quant-u-42|)))
(assert (forall ((s@$ $Snap) (edges@10@00 Set<Edge>) (from@11@00 Int) (to@12@00 Int) (depth@13@00 Int) (visited@14@00 Set<Int>) (allNodes@15@00 Set<Int>)) (!
  (let ((result@16@00 (path_exists_bounded%limited s@$ edges@10@00 from@11@00 to@12@00 depth@13@00 visited@14@00 allNodes@15@00))) true)
  :pattern ((path_exists_bounded%limited s@$ edges@10@00 from@11@00 to@12@00 depth@13@00 visited@14@00 allNodes@15@00))
  :qid |quant-u-43|)))
(assert (forall ((s@$ $Snap) (edges@10@00 Set<Edge>) (from@11@00 Int) (to@12@00 Int) (depth@13@00 Int) (visited@14@00 Set<Int>) (allNodes@15@00 Set<Int>)) (!
  (let ((result@16@00 (path_exists_bounded%limited s@$ edges@10@00 from@11@00 to@12@00 depth@13@00 visited@14@00 allNodes@15@00))) true)
  :pattern ((path_exists_bounded%limited s@$ edges@10@00 from@11@00 to@12@00 depth@13@00 visited@14@00 allNodes@15@00))
  :qid |quant-u-44|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (>= depth@13@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (depth == 0 ? from == to : (from == to ? true : ((from in visited) ? false : path_exists_any_neighbor(edges, from, to, depth - 1, (visited union Set(from)), allNodes, get_neighbors(edges, from, allNodes)))))
; [eval] depth == 0
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= depth@13@00 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= depth@13@00 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 7 | depth@13@00 == 0 | live]
; [else-branch: 7 | depth@13@00 != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 7 | depth@13@00 == 0]
(assert (= depth@13@00 0))
; [eval] from == to
(pop) ; 3
(push) ; 3
; [else-branch: 7 | depth@13@00 != 0]
(assert (not (= depth@13@00 0)))
; [eval] (from == to ? true : ((from in visited) ? false : path_exists_any_neighbor(edges, from, to, depth - 1, (visited union Set(from)), allNodes, get_neighbors(edges, from, allNodes))))
; [eval] from == to
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (= from@11@00 to@12@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= from@11@00 to@12@00)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 8 | from@11@00 == to@12@00 | live]
; [else-branch: 8 | from@11@00 != to@12@00 | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 8 | from@11@00 == to@12@00]
(assert (= from@11@00 to@12@00))
(pop) ; 5
(push) ; 5
; [else-branch: 8 | from@11@00 != to@12@00]
(assert (not (= from@11@00 to@12@00)))
; [eval] ((from in visited) ? false : path_exists_any_neighbor(edges, from, to, depth - 1, (visited union Set(from)), allNodes, get_neighbors(edges, from, allNodes)))
; [eval] (from in visited)
(push) ; 6
(push) ; 7
(set-option :rlimit 16000)
(assert (not (not (Set_in from@11@00 visited@14@00))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 16000)
(assert (not (Set_in from@11@00 visited@14@00)))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 9 | from@11@00 in visited@14@00 | live]
; [else-branch: 9 | !(from@11@00 in visited@14@00) | live]
(set-option :rlimit 0)
(push) ; 7
; [then-branch: 9 | from@11@00 in visited@14@00]
(assert (Set_in from@11@00 visited@14@00))
(pop) ; 7
(push) ; 7
; [else-branch: 9 | !(from@11@00 in visited@14@00)]
(assert (not (Set_in from@11@00 visited@14@00)))
; [eval] path_exists_any_neighbor(edges, from, to, depth - 1, (visited union Set(from)), allNodes, get_neighbors(edges, from, allNodes))
; [eval] depth - 1
; [eval] (visited union Set(from))
; [eval] Set(from)
; [eval] get_neighbors(edges, from, allNodes)
(push) ; 8
(assert (get_neighbors%precondition $Snap.unit edges@10@00 from@11@00 allNodes@15@00))
(pop) ; 8
; Joined path conditions
(assert (get_neighbors%precondition $Snap.unit edges@10@00 from@11@00 allNodes@15@00))
(push) ; 8
; [eval] depth >= 0
(push) ; 9
(assert (not (>= (- depth@13@00 1) 0)))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(assert (>= (- depth@13@00 1) 0))
(assert (path_exists_any_neighbor%precondition $Snap.unit edges@10@00 from@11@00 to@12@00 (-
  depth@13@00
  1) (Set_union visited@14@00 (Set_singleton from@11@00)) allNodes@15@00 (get_neighbors $Snap.unit edges@10@00 from@11@00 allNodes@15@00)))
(pop) ; 8
; Joined path conditions
(assert (and
  (>= (- depth@13@00 1) 0)
  (path_exists_any_neighbor%precondition $Snap.unit edges@10@00 from@11@00 to@12@00 (-
    depth@13@00
    1) (Set_union visited@14@00 (Set_singleton from@11@00)) allNodes@15@00 (get_neighbors $Snap.unit edges@10@00 from@11@00 allNodes@15@00))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (Set_in from@11@00 visited@14@00))
  (and
    (not (Set_in from@11@00 visited@14@00))
    (get_neighbors%precondition $Snap.unit edges@10@00 from@11@00 allNodes@15@00)
    (>= (- depth@13@00 1) 0)
    (path_exists_any_neighbor%precondition $Snap.unit edges@10@00 from@11@00 to@12@00 (-
      depth@13@00
      1) (Set_union visited@14@00 (Set_singleton from@11@00)) allNodes@15@00 (get_neighbors $Snap.unit edges@10@00 from@11@00 allNodes@15@00)))))
(assert (or (not (Set_in from@11@00 visited@14@00)) (Set_in from@11@00 visited@14@00)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= from@11@00 to@12@00))
  (and
    (not (= from@11@00 to@12@00))
    (=>
      (not (Set_in from@11@00 visited@14@00))
      (and
        (not (Set_in from@11@00 visited@14@00))
        (get_neighbors%precondition $Snap.unit edges@10@00 from@11@00 allNodes@15@00)
        (>= (- depth@13@00 1) 0)
        (path_exists_any_neighbor%precondition $Snap.unit edges@10@00 from@11@00 to@12@00 (-
          depth@13@00
          1) (Set_union visited@14@00 (Set_singleton from@11@00)) allNodes@15@00 (get_neighbors $Snap.unit edges@10@00 from@11@00 allNodes@15@00))))
    (or
      (not (Set_in from@11@00 visited@14@00))
      (Set_in from@11@00 visited@14@00)))))
(assert (or (not (= from@11@00 to@12@00)) (= from@11@00 to@12@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= depth@13@00 0))
  (and
    (not (= depth@13@00 0))
    (=>
      (not (= from@11@00 to@12@00))
      (and
        (not (= from@11@00 to@12@00))
        (=>
          (not (Set_in from@11@00 visited@14@00))
          (and
            (not (Set_in from@11@00 visited@14@00))
            (get_neighbors%precondition $Snap.unit edges@10@00 from@11@00 allNodes@15@00)
            (>= (- depth@13@00 1) 0)
            (path_exists_any_neighbor%precondition $Snap.unit edges@10@00 from@11@00 to@12@00 (-
              depth@13@00
              1) (Set_union visited@14@00 (Set_singleton from@11@00)) allNodes@15@00 (get_neighbors $Snap.unit edges@10@00 from@11@00 allNodes@15@00))))
        (or
          (not (Set_in from@11@00 visited@14@00))
          (Set_in from@11@00 visited@14@00))))
    (or (not (= from@11@00 to@12@00)) (= from@11@00 to@12@00)))))
(assert (or (not (= depth@13@00 0)) (= depth@13@00 0)))
(assert (=
  result@16@00
  (ite
    (= depth@13@00 0)
    (= from@11@00 to@12@00)
    (ite
      (= from@11@00 to@12@00)
      true
      (ite
        (Set_in from@11@00 visited@14@00)
        false
        (path_exists_any_neighbor $Snap.unit edges@10@00 from@11@00 to@12@00 (-
          depth@13@00
          1) (Set_union visited@14@00 (Set_singleton from@11@00)) allNodes@15@00 (get_neighbors $Snap.unit edges@10@00 from@11@00 allNodes@15@00)))))))
; [eval] from == to ==> result
; [eval] from == to
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= from@11@00 to@12@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= from@11@00 to@12@00)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 10 | from@11@00 == to@12@00 | live]
; [else-branch: 10 | from@11@00 != to@12@00 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 10 | from@11@00 == to@12@00]
(assert (= from@11@00 to@12@00))
(pop) ; 3
(push) ; 3
; [else-branch: 10 | from@11@00 != to@12@00]
(assert (not (= from@11@00 to@12@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= from@11@00 to@12@00)) (= from@11@00 to@12@00)))
(push) ; 2
(assert (not (=> (= from@11@00 to@12@00) result@16@00)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=> (= from@11@00 to@12@00) result@16@00))
; [eval] depth == 0 && from != to ==> !result
; [eval] depth == 0 && from != to
; [eval] depth == 0
(push) ; 2
; [then-branch: 11 | depth@13@00 != 0 | live]
; [else-branch: 11 | depth@13@00 == 0 | live]
(push) ; 3
; [then-branch: 11 | depth@13@00 != 0]
(assert (not (= depth@13@00 0)))
(pop) ; 3
(push) ; 3
; [else-branch: 11 | depth@13@00 == 0]
(assert (= depth@13@00 0))
; [eval] from != to
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (= depth@13@00 0) (not (= depth@13@00 0))))
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (and (= depth@13@00 0) (not (= from@11@00 to@12@00))))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (and (= depth@13@00 0) (not (= from@11@00 to@12@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 12 | depth@13@00 == 0 && from@11@00 != to@12@00 | live]
; [else-branch: 12 | !(depth@13@00 == 0 && from@11@00 != to@12@00) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 12 | depth@13@00 == 0 && from@11@00 != to@12@00]
(assert (and (= depth@13@00 0) (not (= from@11@00 to@12@00))))
; [eval] !result
(pop) ; 3
(push) ; 3
; [else-branch: 12 | !(depth@13@00 == 0 && from@11@00 != to@12@00)]
(assert (not (and (= depth@13@00 0) (not (= from@11@00 to@12@00)))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or
  (not (and (= depth@13@00 0) (not (= from@11@00 to@12@00))))
  (and (= depth@13@00 0) (not (= from@11@00 to@12@00)))))
(push) ; 2
(assert (not (=> (and (= depth@13@00 0) (not (= from@11@00 to@12@00))) (not result@16@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=> (and (= depth@13@00 0) (not (= from@11@00 to@12@00))) (not result@16@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@10@00 Set<Edge>) (from@11@00 Int) (to@12@00 Int) (depth@13@00 Int) (visited@14@00 Set<Int>) (allNodes@15@00 Set<Int>)) (!
  (=>
    (path_exists_bounded%precondition s@$ edges@10@00 from@11@00 to@12@00 depth@13@00 visited@14@00 allNodes@15@00)
    (=
      (path_exists_bounded s@$ edges@10@00 from@11@00 to@12@00 depth@13@00 visited@14@00 allNodes@15@00)
      (ite
        (= depth@13@00 0)
        (= from@11@00 to@12@00)
        (ite
          (= from@11@00 to@12@00)
          true
          (ite
            (Set_in from@11@00 visited@14@00)
            false
            (path_exists_any_neighbor%limited $Snap.unit edges@10@00 from@11@00 to@12@00 (-
              depth@13@00
              1) (Set_union visited@14@00 (Set_singleton from@11@00)) allNodes@15@00 (get_neighbors $Snap.unit edges@10@00 from@11@00 allNodes@15@00)))))))
  :pattern ((path_exists_bounded s@$ edges@10@00 from@11@00 to@12@00 depth@13@00 visited@14@00 allNodes@15@00))
  :qid |quant-u-45|)))
(assert (forall ((s@$ $Snap) (edges@10@00 Set<Edge>) (from@11@00 Int) (to@12@00 Int) (depth@13@00 Int) (visited@14@00 Set<Int>) (allNodes@15@00 Set<Int>)) (!
  (=>
    (path_exists_bounded%precondition s@$ edges@10@00 from@11@00 to@12@00 depth@13@00 visited@14@00 allNodes@15@00)
    (ite
      (= depth@13@00 0)
      true
      (ite
        (= from@11@00 to@12@00)
        true
        (ite
          (Set_in from@11@00 visited@14@00)
          true
          (and
            (get_neighbors%precondition $Snap.unit edges@10@00 from@11@00 allNodes@15@00)
            (path_exists_any_neighbor%precondition $Snap.unit edges@10@00 from@11@00 to@12@00 (-
              depth@13@00
              1) (Set_union visited@14@00 (Set_singleton from@11@00)) allNodes@15@00 (get_neighbors $Snap.unit edges@10@00 from@11@00 allNodes@15@00)))))))
  :pattern ((path_exists_bounded s@$ edges@10@00 from@11@00 to@12@00 depth@13@00 visited@14@00 allNodes@15@00))
  :qid |quant-u-46|)))
; ---------- FUNCTION path_exists_any_neighbor----------
(declare-fun edges@17@00 () Set<Edge>)
(declare-fun from@18@00 () Int)
(declare-fun to@19@00 () Int)
(declare-fun depth@20@00 () Int)
(declare-fun visited@21@00 () Set<Int>)
(declare-fun allNodes@22@00 () Set<Int>)
(declare-fun neighbors@23@00 () Set<Int>)
(declare-fun result@24@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] depth >= 0
(assert (>= depth@20@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@17@00 Set<Edge>) (from@18@00 Int) (to@19@00 Int) (depth@20@00 Int) (visited@21@00 Set<Int>) (allNodes@22@00 Set<Int>) (neighbors@23@00 Set<Int>)) (!
  (=
    (path_exists_any_neighbor%limited s@$ edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 neighbors@23@00)
    (path_exists_any_neighbor s@$ edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 neighbors@23@00))
  :pattern ((path_exists_any_neighbor s@$ edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 neighbors@23@00))
  :qid |quant-u-8|)))
(assert (forall ((s@$ $Snap) (edges@17@00 Set<Edge>) (from@18@00 Int) (to@19@00 Int) (depth@20@00 Int) (visited@21@00 Set<Int>) (allNodes@22@00 Set<Int>) (neighbors@23@00 Set<Int>)) (!
  (path_exists_any_neighbor%stateless edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 neighbors@23@00)
  :pattern ((path_exists_any_neighbor%limited s@$ edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 neighbors@23@00))
  :qid |quant-u-9|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (>= depth@20@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|neighbors| == 0 ? false : (let n == (choose_one(neighbors)) in path_exists_bounded(edges, n, to, depth, visited, allNodes) || path_exists_any_neighbor(edges, from, to, depth, visited, allNodes, (neighbors setminus Set(n)))))
; [eval] |neighbors| == 0
; [eval] |neighbors|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Set_card neighbors@23@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Set_card neighbors@23@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 13 | |neighbors@23@00| == 0 | live]
; [else-branch: 13 | |neighbors@23@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 13 | |neighbors@23@00| == 0]
(assert (= (Set_card neighbors@23@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 13 | |neighbors@23@00| != 0]
(assert (not (= (Set_card neighbors@23@00) 0)))
; [eval] (let n == (choose_one(neighbors)) in path_exists_bounded(edges, n, to, depth, visited, allNodes) || path_exists_any_neighbor(edges, from, to, depth, visited, allNodes, (neighbors setminus Set(n))))
; [eval] choose_one(neighbors)
(push) ; 4
; [eval] |s| > 0
; [eval] |s|
(push) ; 5
(assert (not (> (Set_card neighbors@23@00) 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (> (Set_card neighbors@23@00) 0))
(assert (choose_one%precondition $Snap.unit neighbors@23@00))
(pop) ; 4
; Joined path conditions
(assert (and
  (> (Set_card neighbors@23@00) 0)
  (choose_one%precondition $Snap.unit neighbors@23@00)))
(declare-fun letvar@83@00 ($Snap Set<Edge> Int Int Int Set<Int> Set<Int> Set<Int>) Int)
(assert (=
  (letvar@83@00 s@$ edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 neighbors@23@00)
  (choose_one $Snap.unit neighbors@23@00)))
; [eval] path_exists_bounded(edges, n, to, depth, visited, allNodes) || path_exists_any_neighbor(edges, from, to, depth, visited, allNodes, (neighbors setminus Set(n)))
; [eval] path_exists_bounded(edges, n, to, depth, visited, allNodes)
(push) ; 4
; [eval] depth >= 0
(assert (path_exists_bounded%precondition $Snap.unit edges@17@00 (choose_one $Snap.unit neighbors@23@00) to@19@00 depth@20@00 visited@21@00 allNodes@22@00))
(pop) ; 4
; Joined path conditions
(assert (path_exists_bounded%precondition $Snap.unit edges@17@00 (choose_one $Snap.unit neighbors@23@00) to@19@00 depth@20@00 visited@21@00 allNodes@22@00))
(push) ; 4
; [then-branch: 14 | path_exists_bounded(_, edges@17@00, choose_one(_, neighbors@23@00), to@19@00, depth@20@00, visited@21@00, allNodes@22@00) | live]
; [else-branch: 14 | !(path_exists_bounded(_, edges@17@00, choose_one(_, neighbors@23@00), to@19@00, depth@20@00, visited@21@00, allNodes@22@00)) | live]
(push) ; 5
; [then-branch: 14 | path_exists_bounded(_, edges@17@00, choose_one(_, neighbors@23@00), to@19@00, depth@20@00, visited@21@00, allNodes@22@00)]
(assert (path_exists_bounded $Snap.unit edges@17@00 (choose_one $Snap.unit neighbors@23@00) to@19@00 depth@20@00 visited@21@00 allNodes@22@00))
(pop) ; 5
(push) ; 5
; [else-branch: 14 | !(path_exists_bounded(_, edges@17@00, choose_one(_, neighbors@23@00), to@19@00, depth@20@00, visited@21@00, allNodes@22@00))]
(assert (not
  (path_exists_bounded $Snap.unit edges@17@00 (choose_one $Snap.unit neighbors@23@00) to@19@00 depth@20@00 visited@21@00 allNodes@22@00)))
; [eval] path_exists_any_neighbor(edges, from, to, depth, visited, allNodes, (neighbors setminus Set(n)))
; [eval] (neighbors setminus Set(n))
; [eval] Set(n)
(push) ; 6
; [eval] depth >= 0
(assert (path_exists_any_neighbor%precondition $Snap.unit edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 (Set_difference neighbors@23@00 (Set_singleton (choose_one $Snap.unit neighbors@23@00)))))
(pop) ; 6
; Joined path conditions
(assert (path_exists_any_neighbor%precondition $Snap.unit edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 (Set_difference neighbors@23@00 (Set_singleton (choose_one $Snap.unit neighbors@23@00)))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not
    (path_exists_bounded $Snap.unit edges@17@00 (choose_one $Snap.unit neighbors@23@00) to@19@00 depth@20@00 visited@21@00 allNodes@22@00))
  (and
    (not
      (path_exists_bounded $Snap.unit edges@17@00 (choose_one $Snap.unit neighbors@23@00) to@19@00 depth@20@00 visited@21@00 allNodes@22@00))
    (path_exists_any_neighbor%precondition $Snap.unit edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 (Set_difference neighbors@23@00 (Set_singleton (choose_one $Snap.unit neighbors@23@00)))))))
(assert (or
  (not
    (path_exists_bounded $Snap.unit edges@17@00 (choose_one $Snap.unit neighbors@23@00) to@19@00 depth@20@00 visited@21@00 allNodes@22@00))
  (path_exists_bounded $Snap.unit edges@17@00 (choose_one $Snap.unit neighbors@23@00) to@19@00 depth@20@00 visited@21@00 allNodes@22@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Set_card neighbors@23@00) 0))
  (and
    (not (= (Set_card neighbors@23@00) 0))
    (> (Set_card neighbors@23@00) 0)
    (choose_one%precondition $Snap.unit neighbors@23@00)
    (=
      (letvar@83@00 s@$ edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 neighbors@23@00)
      (choose_one $Snap.unit neighbors@23@00))
    (path_exists_bounded%precondition $Snap.unit edges@17@00 (choose_one $Snap.unit neighbors@23@00) to@19@00 depth@20@00 visited@21@00 allNodes@22@00)
    (=>
      (not
        (path_exists_bounded $Snap.unit edges@17@00 (choose_one $Snap.unit neighbors@23@00) to@19@00 depth@20@00 visited@21@00 allNodes@22@00))
      (and
        (not
          (path_exists_bounded $Snap.unit edges@17@00 (choose_one $Snap.unit neighbors@23@00) to@19@00 depth@20@00 visited@21@00 allNodes@22@00))
        (path_exists_any_neighbor%precondition $Snap.unit edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 (Set_difference neighbors@23@00 (Set_singleton (choose_one $Snap.unit neighbors@23@00))))))
    (or
      (not
        (path_exists_bounded $Snap.unit edges@17@00 (choose_one $Snap.unit neighbors@23@00) to@19@00 depth@20@00 visited@21@00 allNodes@22@00))
      (path_exists_bounded $Snap.unit edges@17@00 (choose_one $Snap.unit neighbors@23@00) to@19@00 depth@20@00 visited@21@00 allNodes@22@00)))))
(assert (or (not (= (Set_card neighbors@23@00) 0)) (= (Set_card neighbors@23@00) 0)))
(assert (=
  result@24@00
  (ite
    (= (Set_card neighbors@23@00) 0)
    false
    (or
      (path_exists_bounded $Snap.unit edges@17@00 (choose_one $Snap.unit neighbors@23@00) to@19@00 depth@20@00 visited@21@00 allNodes@22@00)
      (path_exists_any_neighbor $Snap.unit edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 (Set_difference neighbors@23@00 (Set_singleton (choose_one $Snap.unit neighbors@23@00))))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@17@00 Set<Edge>) (from@18@00 Int) (to@19@00 Int) (depth@20@00 Int) (visited@21@00 Set<Int>) (allNodes@22@00 Set<Int>) (neighbors@23@00 Set<Int>)) (!
  (=>
    (path_exists_any_neighbor%precondition s@$ edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 neighbors@23@00)
    (=
      (path_exists_any_neighbor s@$ edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 neighbors@23@00)
      (ite
        (= (Set_card neighbors@23@00) 0)
        false
        (let ((n (choose_one $Snap.unit neighbors@23@00))) (or
          (path_exists_bounded%limited $Snap.unit edges@17@00 n to@19@00 depth@20@00 visited@21@00 allNodes@22@00)
          (path_exists_any_neighbor%limited $Snap.unit edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 (Set_difference neighbors@23@00 (Set_singleton n))))))))
  :pattern ((path_exists_any_neighbor s@$ edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 neighbors@23@00))
  :qid |quant-u-47|)))
(assert (forall ((s@$ $Snap) (edges@17@00 Set<Edge>) (from@18@00 Int) (to@19@00 Int) (depth@20@00 Int) (visited@21@00 Set<Int>) (allNodes@22@00 Set<Int>) (neighbors@23@00 Set<Int>)) (!
  (=>
    (path_exists_any_neighbor%precondition s@$ edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 neighbors@23@00)
    (ite
      (= (Set_card neighbors@23@00) 0)
      true
      (and
        (choose_one%precondition $Snap.unit neighbors@23@00)
        (let ((n (choose_one $Snap.unit neighbors@23@00))) (and
          (path_exists_bounded%precondition $Snap.unit edges@17@00 n to@19@00 depth@20@00 visited@21@00 allNodes@22@00)
          (=>
            (not
              (path_exists_bounded%limited $Snap.unit edges@17@00 n to@19@00 depth@20@00 visited@21@00 allNodes@22@00))
            (path_exists_any_neighbor%precondition $Snap.unit edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 (Set_difference neighbors@23@00 (Set_singleton n)))))))))
  :pattern ((path_exists_any_neighbor s@$ edges@17@00 from@18@00 to@19@00 depth@20@00 visited@21@00 allNodes@22@00 neighbors@23@00))
  :qid |quant-u-48|)))
; ---------- FUNCTION all_connected_from----------
(declare-fun edges@25@00 () Set<Edge>)
(declare-fun from@26@00 () Int)
(declare-fun targets@27@00 () Set<Int>)
(declare-fun checked@28@00 () Set<Int>)
(declare-fun result@29@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@84@00 $Snap)
(assert (= $t@84@00 $Snap.unit))
; [eval] |targets| == 0 ==> result
; [eval] |targets| == 0
; [eval] |targets|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Set_card targets@27@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Set_card targets@27@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 15 | |targets@27@00| == 0 | live]
; [else-branch: 15 | |targets@27@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 15 | |targets@27@00| == 0]
(assert (= (Set_card targets@27@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 15 | |targets@27@00| != 0]
(assert (not (= (Set_card targets@27@00) 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= (Set_card targets@27@00) 0)) (= (Set_card targets@27@00) 0)))
(assert (=> (= (Set_card targets@27@00) 0) result@29@00))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@25@00 Set<Edge>) (from@26@00 Int) (targets@27@00 Set<Int>) (checked@28@00 Set<Int>)) (!
  (=
    (all_connected_from%limited s@$ edges@25@00 from@26@00 targets@27@00 checked@28@00)
    (all_connected_from s@$ edges@25@00 from@26@00 targets@27@00 checked@28@00))
  :pattern ((all_connected_from s@$ edges@25@00 from@26@00 targets@27@00 checked@28@00))
  :qid |quant-u-10|)))
(assert (forall ((s@$ $Snap) (edges@25@00 Set<Edge>) (from@26@00 Int) (targets@27@00 Set<Int>) (checked@28@00 Set<Int>)) (!
  (all_connected_from%stateless edges@25@00 from@26@00 targets@27@00 checked@28@00)
  :pattern ((all_connected_from%limited s@$ edges@25@00 from@26@00 targets@27@00 checked@28@00))
  :qid |quant-u-11|)))
(assert (forall ((s@$ $Snap) (edges@25@00 Set<Edge>) (from@26@00 Int) (targets@27@00 Set<Int>) (checked@28@00 Set<Int>)) (!
  (let ((result@29@00 (all_connected_from%limited s@$ edges@25@00 from@26@00 targets@27@00 checked@28@00))) (=>
    (and
      (all_connected_from%precondition s@$ edges@25@00 from@26@00 targets@27@00 checked@28@00)
      (= (Set_card targets@27@00) 0))
    result@29@00))
  :pattern ((all_connected_from%limited s@$ edges@25@00 from@26@00 targets@27@00 checked@28@00))
  :qid |quant-u-49|)))
(assert (forall ((s@$ $Snap) (edges@25@00 Set<Edge>) (from@26@00 Int) (targets@27@00 Set<Int>) (checked@28@00 Set<Int>)) (!
  (let ((result@29@00 (all_connected_from%limited s@$ edges@25@00 from@26@00 targets@27@00 checked@28@00))) true)
  :pattern ((all_connected_from%limited s@$ edges@25@00 from@26@00 targets@27@00 checked@28@00))
  :qid |quant-u-50|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|checked| == |targets| ? true : (let t == (choose_one((targets setminus checked))) in has_edge(edges, from, t) && all_connected_from(edges, from, targets, (checked union Set(t)))))
; [eval] |checked| == |targets|
; [eval] |checked|
; [eval] |targets|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Set_card checked@28@00) (Set_card targets@27@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Set_card checked@28@00) (Set_card targets@27@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 16 | |checked@28@00| == |targets@27@00| | live]
; [else-branch: 16 | |checked@28@00| != |targets@27@00| | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 16 | |checked@28@00| == |targets@27@00|]
(assert (= (Set_card checked@28@00) (Set_card targets@27@00)))
(pop) ; 3
(push) ; 3
; [else-branch: 16 | |checked@28@00| != |targets@27@00|]
(assert (not (= (Set_card checked@28@00) (Set_card targets@27@00))))
; [eval] (let t == (choose_one((targets setminus checked))) in has_edge(edges, from, t) && all_connected_from(edges, from, targets, (checked union Set(t))))
; [eval] choose_one((targets setminus checked))
; [eval] (targets setminus checked)
(push) ; 4
; [eval] |s| > 0
; [eval] |s|
(push) ; 5
(assert (not (> (Set_card (Set_difference targets@27@00 checked@28@00)) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] |s| > 0
; [eval] |s|
(set-option :rlimit 0)
(push) ; 5
(assert (not (> (Set_card (Set_difference targets@27@00 checked@28@00)) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] |s| > 0
; [eval] |s|
(set-option :rlimit 0)
(push) ; 5
(assert (not (> (Set_card (Set_difference targets@27@00 checked@28@00)) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] |s| > 0
; [eval] |s|
(set-option :rlimit 0)
(push) ; 5
(assert (not (> (Set_card (Set_difference targets@27@00 checked@28@00)) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(pop) ; 4
(pop) ; 3
(pop) ; 2
(pop) ; 1
; ---------- FUNCTION has_incoming_edge----------
(declare-fun edges@30@00 () Set<Edge>)
(declare-fun to@31@00 () Int)
(declare-fun from_nodes@32@00 () Set<Int>)
(declare-fun result@33@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@30@00 Set<Edge>) (to@31@00 Int) (from_nodes@32@00 Set<Int>)) (!
  (=
    (has_incoming_edge%limited s@$ edges@30@00 to@31@00 from_nodes@32@00)
    (has_incoming_edge s@$ edges@30@00 to@31@00 from_nodes@32@00))
  :pattern ((has_incoming_edge s@$ edges@30@00 to@31@00 from_nodes@32@00))
  :qid |quant-u-12|)))
(assert (forall ((s@$ $Snap) (edges@30@00 Set<Edge>) (to@31@00 Int) (from_nodes@32@00 Set<Int>)) (!
  (has_incoming_edge%stateless edges@30@00 to@31@00 from_nodes@32@00)
  :pattern ((has_incoming_edge%limited s@$ edges@30@00 to@31@00 from_nodes@32@00))
  :qid |quant-u-13|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|from_nodes| == 0 ? false : (let n == (choose_one(from_nodes)) in has_edge(edges, n, to) || has_incoming_edge(edges, to, (from_nodes setminus Set(n)))))
; [eval] |from_nodes| == 0
; [eval] |from_nodes|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Set_card from_nodes@32@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Set_card from_nodes@32@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 17 | |from_nodes@32@00| == 0 | live]
; [else-branch: 17 | |from_nodes@32@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 17 | |from_nodes@32@00| == 0]
(assert (= (Set_card from_nodes@32@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 17 | |from_nodes@32@00| != 0]
(assert (not (= (Set_card from_nodes@32@00) 0)))
; [eval] (let n == (choose_one(from_nodes)) in has_edge(edges, n, to) || has_incoming_edge(edges, to, (from_nodes setminus Set(n))))
; [eval] choose_one(from_nodes)
(push) ; 4
; [eval] |s| > 0
; [eval] |s|
(push) ; 5
(assert (not (> (Set_card from_nodes@32@00) 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (> (Set_card from_nodes@32@00) 0))
(assert (choose_one%precondition $Snap.unit from_nodes@32@00))
(pop) ; 4
; Joined path conditions
(assert (and
  (> (Set_card from_nodes@32@00) 0)
  (choose_one%precondition $Snap.unit from_nodes@32@00)))
(declare-fun letvar@85@00 ($Snap Set<Edge> Int Set<Int>) Int)
(assert (=
  (letvar@85@00 s@$ edges@30@00 to@31@00 from_nodes@32@00)
  (choose_one $Snap.unit from_nodes@32@00)))
; [eval] has_edge(edges, n, to) || has_incoming_edge(edges, to, (from_nodes setminus Set(n)))
; [eval] has_edge(edges, n, to)
(push) ; 4
(assert (has_edge%precondition $Snap.unit edges@30@00 (choose_one $Snap.unit from_nodes@32@00) to@31@00))
(pop) ; 4
; Joined path conditions
(assert (has_edge%precondition $Snap.unit edges@30@00 (choose_one $Snap.unit from_nodes@32@00) to@31@00))
(push) ; 4
; [then-branch: 18 | has_edge(_, edges@30@00, choose_one(_, from_nodes@32@00), to@31@00) | live]
; [else-branch: 18 | !(has_edge(_, edges@30@00, choose_one(_, from_nodes@32@00), to@31@00)) | live]
(push) ; 5
; [then-branch: 18 | has_edge(_, edges@30@00, choose_one(_, from_nodes@32@00), to@31@00)]
(assert (has_edge $Snap.unit edges@30@00 (choose_one $Snap.unit from_nodes@32@00) to@31@00))
(pop) ; 5
(push) ; 5
; [else-branch: 18 | !(has_edge(_, edges@30@00, choose_one(_, from_nodes@32@00), to@31@00))]
(assert (not
  (has_edge $Snap.unit edges@30@00 (choose_one $Snap.unit from_nodes@32@00) to@31@00)))
; [eval] has_incoming_edge(edges, to, (from_nodes setminus Set(n)))
; [eval] (from_nodes setminus Set(n))
; [eval] Set(n)
(push) ; 6
(assert (has_incoming_edge%precondition $Snap.unit edges@30@00 to@31@00 (Set_difference from_nodes@32@00 (Set_singleton (choose_one $Snap.unit from_nodes@32@00)))))
(pop) ; 6
; Joined path conditions
(assert (has_incoming_edge%precondition $Snap.unit edges@30@00 to@31@00 (Set_difference from_nodes@32@00 (Set_singleton (choose_one $Snap.unit from_nodes@32@00)))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not
    (has_edge $Snap.unit edges@30@00 (choose_one $Snap.unit from_nodes@32@00) to@31@00))
  (and
    (not
      (has_edge $Snap.unit edges@30@00 (choose_one $Snap.unit from_nodes@32@00) to@31@00))
    (has_incoming_edge%precondition $Snap.unit edges@30@00 to@31@00 (Set_difference from_nodes@32@00 (Set_singleton (choose_one $Snap.unit from_nodes@32@00)))))))
(assert (or
  (not
    (has_edge $Snap.unit edges@30@00 (choose_one $Snap.unit from_nodes@32@00) to@31@00))
  (has_edge $Snap.unit edges@30@00 (choose_one $Snap.unit from_nodes@32@00) to@31@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Set_card from_nodes@32@00) 0))
  (and
    (not (= (Set_card from_nodes@32@00) 0))
    (> (Set_card from_nodes@32@00) 0)
    (choose_one%precondition $Snap.unit from_nodes@32@00)
    (=
      (letvar@85@00 s@$ edges@30@00 to@31@00 from_nodes@32@00)
      (choose_one $Snap.unit from_nodes@32@00))
    (has_edge%precondition $Snap.unit edges@30@00 (choose_one $Snap.unit from_nodes@32@00) to@31@00)
    (=>
      (not
        (has_edge $Snap.unit edges@30@00 (choose_one $Snap.unit from_nodes@32@00) to@31@00))
      (and
        (not
          (has_edge $Snap.unit edges@30@00 (choose_one $Snap.unit from_nodes@32@00) to@31@00))
        (has_incoming_edge%precondition $Snap.unit edges@30@00 to@31@00 (Set_difference from_nodes@32@00 (Set_singleton (choose_one $Snap.unit from_nodes@32@00))))))
    (or
      (not
        (has_edge $Snap.unit edges@30@00 (choose_one $Snap.unit from_nodes@32@00) to@31@00))
      (has_edge $Snap.unit edges@30@00 (choose_one $Snap.unit from_nodes@32@00) to@31@00)))))
(assert (or (not (= (Set_card from_nodes@32@00) 0)) (= (Set_card from_nodes@32@00) 0)))
(assert (=
  result@33@00
  (ite
    (= (Set_card from_nodes@32@00) 0)
    false
    (or
      (has_edge $Snap.unit edges@30@00 (choose_one $Snap.unit from_nodes@32@00) to@31@00)
      (has_incoming_edge $Snap.unit edges@30@00 to@31@00 (Set_difference from_nodes@32@00 (Set_singleton (choose_one $Snap.unit from_nodes@32@00))))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@30@00 Set<Edge>) (to@31@00 Int) (from_nodes@32@00 Set<Int>)) (!
  (=>
    (has_incoming_edge%precondition s@$ edges@30@00 to@31@00 from_nodes@32@00)
    (=
      (has_incoming_edge s@$ edges@30@00 to@31@00 from_nodes@32@00)
      (ite
        (= (Set_card from_nodes@32@00) 0)
        false
        (let ((n (choose_one $Snap.unit from_nodes@32@00))) (or
          (has_edge $Snap.unit edges@30@00 n to@31@00)
          (has_incoming_edge%limited $Snap.unit edges@30@00 to@31@00 (Set_difference from_nodes@32@00 (Set_singleton n))))))))
  :pattern ((has_incoming_edge s@$ edges@30@00 to@31@00 from_nodes@32@00))
  :qid |quant-u-51|)))
(assert (forall ((s@$ $Snap) (edges@30@00 Set<Edge>) (to@31@00 Int) (from_nodes@32@00 Set<Int>)) (!
  (=>
    (has_incoming_edge%precondition s@$ edges@30@00 to@31@00 from_nodes@32@00)
    (ite
      (= (Set_card from_nodes@32@00) 0)
      true
      (and
        (choose_one%precondition $Snap.unit from_nodes@32@00)
        (let ((n (choose_one $Snap.unit from_nodes@32@00))) (and
          (has_edge%precondition $Snap.unit edges@30@00 n to@31@00)
          (=>
            (not (has_edge $Snap.unit edges@30@00 n to@31@00))
            (has_incoming_edge%precondition $Snap.unit edges@30@00 to@31@00 (Set_difference from_nodes@32@00 (Set_singleton n)))))))))
  :pattern ((has_incoming_edge s@$ edges@30@00 to@31@00 from_nodes@32@00))
  :qid |quant-u-52|)))
; ---------- FUNCTION has_cycle_through_neighbors----------
(declare-fun edges@34@00 () Set<Edge>)
(declare-fun original@35@00 () Int)
(declare-fun current@36@00 () Int)
(declare-fun depth@37@00 () Int)
(declare-fun visited@38@00 () Set<Int>)
(declare-fun allNodes@39@00 () Set<Int>)
(declare-fun neighbors@40@00 () Set<Int>)
(declare-fun result@41@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] depth >= 0
(assert (>= depth@37@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@34@00 Set<Edge>) (original@35@00 Int) (current@36@00 Int) (depth@37@00 Int) (visited@38@00 Set<Int>) (allNodes@39@00 Set<Int>) (neighbors@40@00 Set<Int>)) (!
  (=
    (has_cycle_through_neighbors%limited s@$ edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 neighbors@40@00)
    (has_cycle_through_neighbors s@$ edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 neighbors@40@00))
  :pattern ((has_cycle_through_neighbors s@$ edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 neighbors@40@00))
  :qid |quant-u-14|)))
(assert (forall ((s@$ $Snap) (edges@34@00 Set<Edge>) (original@35@00 Int) (current@36@00 Int) (depth@37@00 Int) (visited@38@00 Set<Int>) (allNodes@39@00 Set<Int>) (neighbors@40@00 Set<Int>)) (!
  (has_cycle_through_neighbors%stateless edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 neighbors@40@00)
  :pattern ((has_cycle_through_neighbors%limited s@$ edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 neighbors@40@00))
  :qid |quant-u-15|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (>= depth@37@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|neighbors| == 0 ? false : (let n == (choose_one(neighbors)) in (n == original ? true : !((n in visited)) && (depth > 0 && path_exists_bounded(edges, n, original, depth, (visited union Set(n)), allNodes))) || has_cycle_through_neighbors(edges, original, current, depth, visited, allNodes, (neighbors setminus Set(n)))))
; [eval] |neighbors| == 0
; [eval] |neighbors|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Set_card neighbors@40@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Set_card neighbors@40@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 19 | |neighbors@40@00| == 0 | live]
; [else-branch: 19 | |neighbors@40@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 19 | |neighbors@40@00| == 0]
(assert (= (Set_card neighbors@40@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 19 | |neighbors@40@00| != 0]
(assert (not (= (Set_card neighbors@40@00) 0)))
; [eval] (let n == (choose_one(neighbors)) in (n == original ? true : !((n in visited)) && (depth > 0 && path_exists_bounded(edges, n, original, depth, (visited union Set(n)), allNodes))) || has_cycle_through_neighbors(edges, original, current, depth, visited, allNodes, (neighbors setminus Set(n))))
; [eval] choose_one(neighbors)
(push) ; 4
; [eval] |s| > 0
; [eval] |s|
(push) ; 5
(assert (not (> (Set_card neighbors@40@00) 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (> (Set_card neighbors@40@00) 0))
(assert (choose_one%precondition $Snap.unit neighbors@40@00))
(pop) ; 4
; Joined path conditions
(assert (and
  (> (Set_card neighbors@40@00) 0)
  (choose_one%precondition $Snap.unit neighbors@40@00)))
(declare-fun letvar@86@00 ($Snap Set<Edge> Int Int Int Set<Int> Set<Int> Set<Int>) Int)
(assert (=
  (letvar@86@00 s@$ edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 neighbors@40@00)
  (choose_one $Snap.unit neighbors@40@00)))
; [eval] (n == original ? true : !((n in visited)) && (depth > 0 && path_exists_bounded(edges, n, original, depth, (visited union Set(n)), allNodes))) || has_cycle_through_neighbors(edges, original, current, depth, visited, allNodes, (neighbors setminus Set(n)))
; [eval] (n == original ? true : !((n in visited)) && (depth > 0 && path_exists_bounded(edges, n, original, depth, (visited union Set(n)), allNodes)))
; [eval] n == original
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (= (choose_one $Snap.unit neighbors@40@00) original@35@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= (choose_one $Snap.unit neighbors@40@00) original@35@00)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 20 | choose_one(_, neighbors@40@00) == original@35@00 | live]
; [else-branch: 20 | choose_one(_, neighbors@40@00) != original@35@00 | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 20 | choose_one(_, neighbors@40@00) == original@35@00]
(assert (= (choose_one $Snap.unit neighbors@40@00) original@35@00))
(pop) ; 5
(push) ; 5
; [else-branch: 20 | choose_one(_, neighbors@40@00) != original@35@00]
(assert (not (= (choose_one $Snap.unit neighbors@40@00) original@35@00)))
; [eval] !((n in visited)) && (depth > 0 && path_exists_bounded(edges, n, original, depth, (visited union Set(n)), allNodes))
; [eval] !((n in visited))
; [eval] (n in visited)
(push) ; 6
; [then-branch: 21 | choose_one(_, neighbors@40@00) in visited@38@00 | live]
; [else-branch: 21 | !(choose_one(_, neighbors@40@00) in visited@38@00) | live]
(push) ; 7
; [then-branch: 21 | choose_one(_, neighbors@40@00) in visited@38@00]
(assert (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
(pop) ; 7
(push) ; 7
; [else-branch: 21 | !(choose_one(_, neighbors@40@00) in visited@38@00)]
(assert (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00)))
; [eval] depth > 0
(push) ; 8
; [then-branch: 22 | !(depth@37@00 > 0) | live]
; [else-branch: 22 | depth@37@00 > 0 | live]
(push) ; 9
; [then-branch: 22 | !(depth@37@00 > 0)]
(assert (not (> depth@37@00 0)))
(pop) ; 9
(push) ; 9
; [else-branch: 22 | depth@37@00 > 0]
(assert (> depth@37@00 0))
; [eval] path_exists_bounded(edges, n, original, depth, (visited union Set(n)), allNodes)
; [eval] (visited union Set(n))
; [eval] Set(n)
(push) ; 10
; [eval] depth >= 0
(assert (path_exists_bounded%precondition $Snap.unit edges@34@00 (choose_one $Snap.unit neighbors@40@00) original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))) allNodes@39@00))
(pop) ; 10
; Joined path conditions
(assert (path_exists_bounded%precondition $Snap.unit edges@34@00 (choose_one $Snap.unit neighbors@40@00) original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))) allNodes@39@00))
(pop) ; 9
(pop) ; 8
; Joined path conditions
; Joined path conditions
(assert (=>
  (> depth@37@00 0)
  (and
    (> depth@37@00 0)
    (path_exists_bounded%precondition $Snap.unit edges@34@00 (choose_one $Snap.unit neighbors@40@00) original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))) allNodes@39@00))))
(assert (or (> depth@37@00 0) (not (> depth@37@00 0))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
  (and
    (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
    (=>
      (> depth@37@00 0)
      (and
        (> depth@37@00 0)
        (path_exists_bounded%precondition $Snap.unit edges@34@00 (choose_one $Snap.unit neighbors@40@00) original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))) allNodes@39@00)))
    (or (> depth@37@00 0) (not (> depth@37@00 0))))))
(assert (or
  (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
  (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (choose_one $Snap.unit neighbors@40@00) original@35@00))
  (and
    (not (= (choose_one $Snap.unit neighbors@40@00) original@35@00))
    (=>
      (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
      (and
        (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
        (=>
          (> depth@37@00 0)
          (and
            (> depth@37@00 0)
            (path_exists_bounded%precondition $Snap.unit edges@34@00 (choose_one $Snap.unit neighbors@40@00) original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))) allNodes@39@00)))
        (or (> depth@37@00 0) (not (> depth@37@00 0)))))
    (or
      (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
      (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00)))))
(assert (or
  (not (= (choose_one $Snap.unit neighbors@40@00) original@35@00))
  (= (choose_one $Snap.unit neighbors@40@00) original@35@00)))
(push) ; 4
; [then-branch: 23 | (choose_one(_, neighbors@40@00) == original@35@00 ? True : !(choose_one(_, neighbors@40@00) in visited@38@00) && depth@37@00 > 0 && path_exists_bounded(_, edges@34@00, choose_one(_, neighbors@40@00), original@35@00, depth@37@00, visited@38@00 ∪ {choose_one(_, neighbors@40@00)}, allNodes@39@00)) | live]
; [else-branch: 23 | !((choose_one(_, neighbors@40@00) == original@35@00 ? True : !(choose_one(_, neighbors@40@00) in visited@38@00) && depth@37@00 > 0 && path_exists_bounded(_, edges@34@00, choose_one(_, neighbors@40@00), original@35@00, depth@37@00, visited@38@00 ∪ {choose_one(_, neighbors@40@00)}, allNodes@39@00))) | live]
(push) ; 5
; [then-branch: 23 | (choose_one(_, neighbors@40@00) == original@35@00 ? True : !(choose_one(_, neighbors@40@00) in visited@38@00) && depth@37@00 > 0 && path_exists_bounded(_, edges@34@00, choose_one(_, neighbors@40@00), original@35@00, depth@37@00, visited@38@00 ∪ {choose_one(_, neighbors@40@00)}, allNodes@39@00))]
(assert (ite
  (= (choose_one $Snap.unit neighbors@40@00) original@35@00)
  true
  (and
    (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
    (and
      (> depth@37@00 0)
      (path_exists_bounded $Snap.unit edges@34@00 (choose_one $Snap.unit neighbors@40@00) original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))) allNodes@39@00)))))
(pop) ; 5
(push) ; 5
; [else-branch: 23 | !((choose_one(_, neighbors@40@00) == original@35@00 ? True : !(choose_one(_, neighbors@40@00) in visited@38@00) && depth@37@00 > 0 && path_exists_bounded(_, edges@34@00, choose_one(_, neighbors@40@00), original@35@00, depth@37@00, visited@38@00 ∪ {choose_one(_, neighbors@40@00)}, allNodes@39@00)))]
(assert (not
  (ite
    (= (choose_one $Snap.unit neighbors@40@00) original@35@00)
    true
    (and
      (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
      (and
        (> depth@37@00 0)
        (path_exists_bounded $Snap.unit edges@34@00 (choose_one $Snap.unit neighbors@40@00) original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))) allNodes@39@00))))))
; [eval] has_cycle_through_neighbors(edges, original, current, depth, visited, allNodes, (neighbors setminus Set(n)))
; [eval] (neighbors setminus Set(n))
; [eval] Set(n)
(push) ; 6
; [eval] depth >= 0
(assert (has_cycle_through_neighbors%precondition $Snap.unit edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 (Set_difference neighbors@40@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00)))))
(pop) ; 6
; Joined path conditions
(assert (has_cycle_through_neighbors%precondition $Snap.unit edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 (Set_difference neighbors@40@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00)))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not
    (ite
      (= (choose_one $Snap.unit neighbors@40@00) original@35@00)
      true
      (and
        (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
        (and
          (> depth@37@00 0)
          (path_exists_bounded $Snap.unit edges@34@00 (choose_one $Snap.unit neighbors@40@00) original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))) allNodes@39@00)))))
  (and
    (not
      (ite
        (= (choose_one $Snap.unit neighbors@40@00) original@35@00)
        true
        (and
          (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
          (and
            (> depth@37@00 0)
            (path_exists_bounded $Snap.unit edges@34@00 (choose_one $Snap.unit neighbors@40@00) original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))) allNodes@39@00)))))
    (has_cycle_through_neighbors%precondition $Snap.unit edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 (Set_difference neighbors@40@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00)))))))
(assert (or
  (not
    (ite
      (= (choose_one $Snap.unit neighbors@40@00) original@35@00)
      true
      (and
        (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
        (and
          (> depth@37@00 0)
          (path_exists_bounded $Snap.unit edges@34@00 (choose_one $Snap.unit neighbors@40@00) original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))) allNodes@39@00)))))
  (ite
    (= (choose_one $Snap.unit neighbors@40@00) original@35@00)
    true
    (and
      (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
      (and
        (> depth@37@00 0)
        (path_exists_bounded $Snap.unit edges@34@00 (choose_one $Snap.unit neighbors@40@00) original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))) allNodes@39@00))))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Set_card neighbors@40@00) 0))
  (and
    (not (= (Set_card neighbors@40@00) 0))
    (> (Set_card neighbors@40@00) 0)
    (choose_one%precondition $Snap.unit neighbors@40@00)
    (=
      (letvar@86@00 s@$ edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 neighbors@40@00)
      (choose_one $Snap.unit neighbors@40@00))
    (=>
      (not (= (choose_one $Snap.unit neighbors@40@00) original@35@00))
      (and
        (not (= (choose_one $Snap.unit neighbors@40@00) original@35@00))
        (=>
          (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
          (and
            (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
            (=>
              (> depth@37@00 0)
              (and
                (> depth@37@00 0)
                (path_exists_bounded%precondition $Snap.unit edges@34@00 (choose_one $Snap.unit neighbors@40@00) original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))) allNodes@39@00)))
            (or (> depth@37@00 0) (not (> depth@37@00 0)))))
        (or
          (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
          (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))))
    (or
      (not (= (choose_one $Snap.unit neighbors@40@00) original@35@00))
      (= (choose_one $Snap.unit neighbors@40@00) original@35@00))
    (=>
      (not
        (ite
          (= (choose_one $Snap.unit neighbors@40@00) original@35@00)
          true
          (and
            (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
            (and
              (> depth@37@00 0)
              (path_exists_bounded $Snap.unit edges@34@00 (choose_one $Snap.unit neighbors@40@00) original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))) allNodes@39@00)))))
      (and
        (not
          (ite
            (= (choose_one $Snap.unit neighbors@40@00) original@35@00)
            true
            (and
              (not
                (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
              (and
                (> depth@37@00 0)
                (path_exists_bounded $Snap.unit edges@34@00 (choose_one $Snap.unit neighbors@40@00) original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))) allNodes@39@00)))))
        (has_cycle_through_neighbors%precondition $Snap.unit edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 (Set_difference neighbors@40@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))))))
    (or
      (not
        (ite
          (= (choose_one $Snap.unit neighbors@40@00) original@35@00)
          true
          (and
            (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
            (and
              (> depth@37@00 0)
              (path_exists_bounded $Snap.unit edges@34@00 (choose_one $Snap.unit neighbors@40@00) original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))) allNodes@39@00)))))
      (ite
        (= (choose_one $Snap.unit neighbors@40@00) original@35@00)
        true
        (and
          (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
          (and
            (> depth@37@00 0)
            (path_exists_bounded $Snap.unit edges@34@00 (choose_one $Snap.unit neighbors@40@00) original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))) allNodes@39@00))))))))
(assert (or (not (= (Set_card neighbors@40@00) 0)) (= (Set_card neighbors@40@00) 0)))
(assert (=
  result@41@00
  (ite
    (= (Set_card neighbors@40@00) 0)
    false
    (or
      (ite
        (= (choose_one $Snap.unit neighbors@40@00) original@35@00)
        true
        (and
          (not (Set_in (choose_one $Snap.unit neighbors@40@00) visited@38@00))
          (and
            (> depth@37@00 0)
            (path_exists_bounded $Snap.unit edges@34@00 (choose_one $Snap.unit neighbors@40@00) original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))) allNodes@39@00))))
      (has_cycle_through_neighbors $Snap.unit edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 (Set_difference neighbors@40@00 (Set_singleton (choose_one $Snap.unit neighbors@40@00))))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@34@00 Set<Edge>) (original@35@00 Int) (current@36@00 Int) (depth@37@00 Int) (visited@38@00 Set<Int>) (allNodes@39@00 Set<Int>) (neighbors@40@00 Set<Int>)) (!
  (=>
    (has_cycle_through_neighbors%precondition s@$ edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 neighbors@40@00)
    (=
      (has_cycle_through_neighbors s@$ edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 neighbors@40@00)
      (ite
        (= (Set_card neighbors@40@00) 0)
        false
        (let ((n (choose_one $Snap.unit neighbors@40@00))) (or
          (ite
            (= n original@35@00)
            true
            (and
              (not (Set_in n visited@38@00))
              (and
                (> depth@37@00 0)
                (path_exists_bounded $Snap.unit edges@34@00 n original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton n)) allNodes@39@00))))
          (has_cycle_through_neighbors%limited $Snap.unit edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 (Set_difference neighbors@40@00 (Set_singleton n))))))))
  :pattern ((has_cycle_through_neighbors s@$ edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 neighbors@40@00))
  :qid |quant-u-53|)))
(assert (forall ((s@$ $Snap) (edges@34@00 Set<Edge>) (original@35@00 Int) (current@36@00 Int) (depth@37@00 Int) (visited@38@00 Set<Int>) (allNodes@39@00 Set<Int>) (neighbors@40@00 Set<Int>)) (!
  (=>
    (has_cycle_through_neighbors%precondition s@$ edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 neighbors@40@00)
    (ite
      (= (Set_card neighbors@40@00) 0)
      true
      (and
        (choose_one%precondition $Snap.unit neighbors@40@00)
        (let ((n (choose_one $Snap.unit neighbors@40@00))) (and
          (ite
            (= n original@35@00)
            true
            (=>
              (and (not (Set_in n visited@38@00)) (> depth@37@00 0))
              (path_exists_bounded%precondition $Snap.unit edges@34@00 n original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton n)) allNodes@39@00)))
          (=>
            (not
              (ite
                (= n original@35@00)
                true
                (and
                  (not (Set_in n visited@38@00))
                  (and
                    (> depth@37@00 0)
                    (path_exists_bounded $Snap.unit edges@34@00 n original@35@00 depth@37@00 (Set_union visited@38@00 (Set_singleton n)) allNodes@39@00)))))
            (has_cycle_through_neighbors%precondition $Snap.unit edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 (Set_difference neighbors@40@00 (Set_singleton n)))))))))
  :pattern ((has_cycle_through_neighbors s@$ edges@34@00 original@35@00 current@36@00 depth@37@00 visited@38@00 allNodes@39@00 neighbors@40@00))
  :qid |quant-u-54|)))
; ---------- FUNCTION has_self_loop----------
(declare-fun edges@42@00 () Set<Edge>)
(declare-fun node@43@00 () Int)
(declare-fun allNodes@44@00 () Set<Int>)
(declare-fun result@45@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@42@00 Set<Edge>) (node@43@00 Int) (allNodes@44@00 Set<Int>)) (!
  (=
    (has_self_loop%limited s@$ edges@42@00 node@43@00 allNodes@44@00)
    (has_self_loop s@$ edges@42@00 node@43@00 allNodes@44@00))
  :pattern ((has_self_loop s@$ edges@42@00 node@43@00 allNodes@44@00))
  :qid |quant-u-16|)))
(assert (forall ((s@$ $Snap) (edges@42@00 Set<Edge>) (node@43@00 Int) (allNodes@44@00 Set<Int>)) (!
  (has_self_loop%stateless edges@42@00 node@43@00 allNodes@44@00)
  :pattern ((has_self_loop%limited s@$ edges@42@00 node@43@00 allNodes@44@00))
  :qid |quant-u-17|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] has_edge(edges, node, node)
(set-option :rlimit 0)
(push) ; 2
(assert (has_edge%precondition $Snap.unit edges@42@00 node@43@00 node@43@00))
(pop) ; 2
; Joined path conditions
(assert (has_edge%precondition $Snap.unit edges@42@00 node@43@00 node@43@00))
(assert (= result@45@00 (has_edge $Snap.unit edges@42@00 node@43@00 node@43@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@42@00 Set<Edge>) (node@43@00 Int) (allNodes@44@00 Set<Int>)) (!
  (=>
    (has_self_loop%precondition s@$ edges@42@00 node@43@00 allNodes@44@00)
    (=
      (has_self_loop s@$ edges@42@00 node@43@00 allNodes@44@00)
      (has_edge $Snap.unit edges@42@00 node@43@00 node@43@00)))
  :pattern ((has_self_loop s@$ edges@42@00 node@43@00 allNodes@44@00))
  :qid |quant-u-55|)))
(assert (forall ((s@$ $Snap) (edges@42@00 Set<Edge>) (node@43@00 Int) (allNodes@44@00 Set<Int>)) (!
  (=>
    (has_self_loop%precondition s@$ edges@42@00 node@43@00 allNodes@44@00)
    (has_edge%precondition $Snap.unit edges@42@00 node@43@00 node@43@00))
  :pattern ((has_self_loop s@$ edges@42@00 node@43@00 allNodes@44@00))
  :qid |quant-u-56|)))
; ---------- FUNCTION count_edges----------
(declare-fun edges@46@00 () Set<Edge>)
(declare-fun result@47@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@87@00 $Snap)
(assert (= $t@87@00 ($Snap.combine ($Snap.first $t@87@00) ($Snap.second $t@87@00))))
(assert (= ($Snap.first $t@87@00) $Snap.unit))
; [eval] result >= 0
(assert (>= result@47@00 0))
(assert (= ($Snap.second $t@87@00) $Snap.unit))
; [eval] result == |edges|
; [eval] |edges|
(assert (= result@47@00 (Set_card edges@46@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@46@00 Set<Edge>)) (!
  (= (count_edges%limited s@$ edges@46@00) (count_edges s@$ edges@46@00))
  :pattern ((count_edges s@$ edges@46@00))
  :qid |quant-u-18|)))
(assert (forall ((s@$ $Snap) (edges@46@00 Set<Edge>)) (!
  (count_edges%stateless edges@46@00)
  :pattern ((count_edges%limited s@$ edges@46@00))
  :qid |quant-u-19|)))
(assert (forall ((s@$ $Snap) (edges@46@00 Set<Edge>)) (!
  (let ((result@47@00 (count_edges%limited s@$ edges@46@00))) (=>
    (count_edges%precondition s@$ edges@46@00)
    (and (>= result@47@00 0) (= result@47@00 (Set_card edges@46@00)))))
  :pattern ((count_edges%limited s@$ edges@46@00))
  :qid |quant-u-57|)))
(assert (forall ((s@$ $Snap) (edges@46@00 Set<Edge>)) (!
  (let ((result@47@00 (count_edges%limited s@$ edges@46@00))) true)
  :pattern ((count_edges%limited s@$ edges@46@00))
  :qid |quant-u-58|)))
(assert (forall ((s@$ $Snap) (edges@46@00 Set<Edge>)) (!
  (let ((result@47@00 (count_edges%limited s@$ edges@46@00))) true)
  :pattern ((count_edges%limited s@$ edges@46@00))
  :qid |quant-u-59|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] |edges|
(assert (= result@47@00 (Set_card edges@46@00)))
; [eval] result >= 0
(set-option :rlimit 0)
(push) ; 2
(assert (not (>= result@47@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@47@00 0))
; [eval] result == |edges|
; [eval] |edges|
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@46@00 Set<Edge>)) (!
  (=>
    (count_edges%precondition s@$ edges@46@00)
    (= (count_edges s@$ edges@46@00) (Set_card edges@46@00)))
  :pattern ((count_edges s@$ edges@46@00))
  :qid |quant-u-60|)))
(assert (forall ((s@$ $Snap) (edges@46@00 Set<Edge>)) (!
  true
  :pattern ((count_edges s@$ edges@46@00))
  :qid |quant-u-61|)))
; ---------- FUNCTION is_complete_graph----------
(declare-fun edges@48@00 () Set<Edge>)
(declare-fun nodes@49@00 () Set<Int>)
(declare-fun checked@50@00 () Set<Int>)
(declare-fun result@51@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@88@00 $Snap)
(assert (= $t@88@00 $Snap.unit))
; [eval] |nodes| <= 1 ==> result
; [eval] |nodes| <= 1
; [eval] |nodes|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (<= (Set_card nodes@49@00) 1))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (<= (Set_card nodes@49@00) 1)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 24 | |nodes@49@00| <= 1 | live]
; [else-branch: 24 | !(|nodes@49@00| <= 1) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 24 | |nodes@49@00| <= 1]
(assert (<= (Set_card nodes@49@00) 1))
(pop) ; 3
(push) ; 3
; [else-branch: 24 | !(|nodes@49@00| <= 1)]
(assert (not (<= (Set_card nodes@49@00) 1)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (<= (Set_card nodes@49@00) 1)) (<= (Set_card nodes@49@00) 1)))
(assert (=> (<= (Set_card nodes@49@00) 1) result@51@00))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@48@00 Set<Edge>) (nodes@49@00 Set<Int>) (checked@50@00 Set<Int>)) (!
  (=
    (is_complete_graph%limited s@$ edges@48@00 nodes@49@00 checked@50@00)
    (is_complete_graph s@$ edges@48@00 nodes@49@00 checked@50@00))
  :pattern ((is_complete_graph s@$ edges@48@00 nodes@49@00 checked@50@00))
  :qid |quant-u-20|)))
(assert (forall ((s@$ $Snap) (edges@48@00 Set<Edge>) (nodes@49@00 Set<Int>) (checked@50@00 Set<Int>)) (!
  (is_complete_graph%stateless edges@48@00 nodes@49@00 checked@50@00)
  :pattern ((is_complete_graph%limited s@$ edges@48@00 nodes@49@00 checked@50@00))
  :qid |quant-u-21|)))
(assert (forall ((s@$ $Snap) (edges@48@00 Set<Edge>) (nodes@49@00 Set<Int>) (checked@50@00 Set<Int>)) (!
  (let ((result@51@00 (is_complete_graph%limited s@$ edges@48@00 nodes@49@00 checked@50@00))) (=>
    (and
      (is_complete_graph%precondition s@$ edges@48@00 nodes@49@00 checked@50@00)
      (<= (Set_card nodes@49@00) 1))
    result@51@00))
  :pattern ((is_complete_graph%limited s@$ edges@48@00 nodes@49@00 checked@50@00))
  :qid |quant-u-62|)))
(assert (forall ((s@$ $Snap) (edges@48@00 Set<Edge>) (nodes@49@00 Set<Int>) (checked@50@00 Set<Int>)) (!
  (let ((result@51@00 (is_complete_graph%limited s@$ edges@48@00 nodes@49@00 checked@50@00))) true)
  :pattern ((is_complete_graph%limited s@$ edges@48@00 nodes@49@00 checked@50@00))
  :qid |quant-u-63|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|checked| == |nodes| ? true : (let n == (choose_one((nodes setminus checked))) in all_connected_from(edges, n, (nodes setminus Set(n)), Set[Int]()) && is_complete_graph(edges, nodes, (checked union Set(n)))))
; [eval] |checked| == |nodes|
; [eval] |checked|
; [eval] |nodes|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Set_card checked@50@00) (Set_card nodes@49@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Set_card checked@50@00) (Set_card nodes@49@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 25 | |checked@50@00| == |nodes@49@00| | live]
; [else-branch: 25 | |checked@50@00| != |nodes@49@00| | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 25 | |checked@50@00| == |nodes@49@00|]
(assert (= (Set_card checked@50@00) (Set_card nodes@49@00)))
(pop) ; 3
(push) ; 3
; [else-branch: 25 | |checked@50@00| != |nodes@49@00|]
(assert (not (= (Set_card checked@50@00) (Set_card nodes@49@00))))
; [eval] (let n == (choose_one((nodes setminus checked))) in all_connected_from(edges, n, (nodes setminus Set(n)), Set[Int]()) && is_complete_graph(edges, nodes, (checked union Set(n))))
; [eval] choose_one((nodes setminus checked))
; [eval] (nodes setminus checked)
(push) ; 4
; [eval] |s| > 0
; [eval] |s|
(push) ; 5
(assert (not (> (Set_card (Set_difference nodes@49@00 checked@50@00)) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] |s| > 0
; [eval] |s|
(set-option :rlimit 0)
(push) ; 5
(assert (not (> (Set_card (Set_difference nodes@49@00 checked@50@00)) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] |s| > 0
; [eval] |s|
(set-option :rlimit 0)
(push) ; 5
(assert (not (> (Set_card (Set_difference nodes@49@00 checked@50@00)) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] |s| > 0
; [eval] |s|
(set-option :rlimit 0)
(push) ; 5
(assert (not (> (Set_card (Set_difference nodes@49@00 checked@50@00)) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(pop) ; 4
(pop) ; 3
(pop) ; 2
(pop) ; 1
; ---------- FUNCTION is_source----------
(declare-fun edges@52@00 () Set<Edge>)
(declare-fun node@53@00 () Int)
(declare-fun allNodes@54@00 () Set<Int>)
(declare-fun result@55@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@52@00 Set<Edge>) (node@53@00 Int) (allNodes@54@00 Set<Int>)) (!
  (=
    (is_source%limited s@$ edges@52@00 node@53@00 allNodes@54@00)
    (is_source s@$ edges@52@00 node@53@00 allNodes@54@00))
  :pattern ((is_source s@$ edges@52@00 node@53@00 allNodes@54@00))
  :qid |quant-u-22|)))
(assert (forall ((s@$ $Snap) (edges@52@00 Set<Edge>) (node@53@00 Int) (allNodes@54@00 Set<Int>)) (!
  (is_source%stateless edges@52@00 node@53@00 allNodes@54@00)
  :pattern ((is_source%limited s@$ edges@52@00 node@53@00 allNodes@54@00))
  :qid |quant-u-23|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] !has_incoming_edge(edges, node, allNodes)
; [eval] has_incoming_edge(edges, node, allNodes)
(set-option :rlimit 0)
(push) ; 2
(assert (has_incoming_edge%precondition $Snap.unit edges@52@00 node@53@00 allNodes@54@00))
(pop) ; 2
; Joined path conditions
(assert (has_incoming_edge%precondition $Snap.unit edges@52@00 node@53@00 allNodes@54@00))
(assert (=
  result@55@00
  (not (has_incoming_edge $Snap.unit edges@52@00 node@53@00 allNodes@54@00))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@52@00 Set<Edge>) (node@53@00 Int) (allNodes@54@00 Set<Int>)) (!
  (=>
    (is_source%precondition s@$ edges@52@00 node@53@00 allNodes@54@00)
    (=
      (is_source s@$ edges@52@00 node@53@00 allNodes@54@00)
      (not (has_incoming_edge $Snap.unit edges@52@00 node@53@00 allNodes@54@00))))
  :pattern ((is_source s@$ edges@52@00 node@53@00 allNodes@54@00))
  :qid |quant-u-64|)))
(assert (forall ((s@$ $Snap) (edges@52@00 Set<Edge>) (node@53@00 Int) (allNodes@54@00 Set<Int>)) (!
  (=>
    (is_source%precondition s@$ edges@52@00 node@53@00 allNodes@54@00)
    (has_incoming_edge%precondition $Snap.unit edges@52@00 node@53@00 allNodes@54@00))
  :pattern ((is_source s@$ edges@52@00 node@53@00 allNodes@54@00))
  :qid |quant-u-65|)))
; ---------- FUNCTION is_sink----------
(declare-fun edges@56@00 () Set<Edge>)
(declare-fun node@57@00 () Int)
(declare-fun allNodes@58@00 () Set<Int>)
(declare-fun result@59@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@56@00 Set<Edge>) (node@57@00 Int) (allNodes@58@00 Set<Int>)) (!
  (=
    (is_sink%limited s@$ edges@56@00 node@57@00 allNodes@58@00)
    (is_sink s@$ edges@56@00 node@57@00 allNodes@58@00))
  :pattern ((is_sink s@$ edges@56@00 node@57@00 allNodes@58@00))
  :qid |quant-u-24|)))
(assert (forall ((s@$ $Snap) (edges@56@00 Set<Edge>) (node@57@00 Int) (allNodes@58@00 Set<Int>)) (!
  (is_sink%stateless edges@56@00 node@57@00 allNodes@58@00)
  :pattern ((is_sink%limited s@$ edges@56@00 node@57@00 allNodes@58@00))
  :qid |quant-u-25|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] |get_neighbors(edges, node, allNodes)| == 0
; [eval] |get_neighbors(edges, node, allNodes)|
; [eval] get_neighbors(edges, node, allNodes)
(set-option :rlimit 0)
(push) ; 2
(assert (get_neighbors%precondition $Snap.unit edges@56@00 node@57@00 allNodes@58@00))
(pop) ; 2
; Joined path conditions
(assert (get_neighbors%precondition $Snap.unit edges@56@00 node@57@00 allNodes@58@00))
(assert (=
  result@59@00
  (=
    (Set_card (get_neighbors $Snap.unit edges@56@00 node@57@00 allNodes@58@00))
    0)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@56@00 Set<Edge>) (node@57@00 Int) (allNodes@58@00 Set<Int>)) (!
  (=>
    (is_sink%precondition s@$ edges@56@00 node@57@00 allNodes@58@00)
    (=
      (is_sink s@$ edges@56@00 node@57@00 allNodes@58@00)
      (=
        (Set_card (get_neighbors $Snap.unit edges@56@00 node@57@00 allNodes@58@00))
        0)))
  :pattern ((is_sink s@$ edges@56@00 node@57@00 allNodes@58@00))
  :qid |quant-u-66|)))
(assert (forall ((s@$ $Snap) (edges@56@00 Set<Edge>) (node@57@00 Int) (allNodes@58@00 Set<Int>)) (!
  (=>
    (is_sink%precondition s@$ edges@56@00 node@57@00 allNodes@58@00)
    (get_neighbors%precondition $Snap.unit edges@56@00 node@57@00 allNodes@58@00))
  :pattern ((is_sink s@$ edges@56@00 node@57@00 allNodes@58@00))
  :qid |quant-u-67|)))
; ---------- FUNCTION transitive_closure_from----------
(declare-fun edges@60@00 () Set<Edge>)
(declare-fun from@61@00 () Int)
(declare-fun depth@62@00 () Int)
(declare-fun allNodes@63@00 () Set<Int>)
(declare-fun toCheck@64@00 () Set<Int>)
(declare-fun result@65@00 () Set<Int>)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] depth >= 0
(assert (>= depth@62@00 0))
(declare-const $t@89@00 $Snap)
(assert (= $t@89@00 $Snap.unit))
; [eval] (from in result) || depth == 0
; [eval] (from in result)
(push) ; 2
; [then-branch: 26 | from@61@00 in result@65@00 | live]
; [else-branch: 26 | !(from@61@00 in result@65@00) | live]
(push) ; 3
; [then-branch: 26 | from@61@00 in result@65@00]
(assert (Set_in from@61@00 result@65@00))
(pop) ; 3
(push) ; 3
; [else-branch: 26 | !(from@61@00 in result@65@00)]
(assert (not (Set_in from@61@00 result@65@00)))
; [eval] depth == 0
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (Set_in from@61@00 result@65@00)) (Set_in from@61@00 result@65@00)))
(assert (or (Set_in from@61@00 result@65@00) (= depth@62@00 0)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@60@00 Set<Edge>) (from@61@00 Int) (depth@62@00 Int) (allNodes@63@00 Set<Int>) (toCheck@64@00 Set<Int>)) (!
  (=
    (transitive_closure_from%limited s@$ edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00)
    (transitive_closure_from s@$ edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00))
  :pattern ((transitive_closure_from s@$ edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00))
  :qid |quant-u-26|)))
(assert (forall ((s@$ $Snap) (edges@60@00 Set<Edge>) (from@61@00 Int) (depth@62@00 Int) (allNodes@63@00 Set<Int>) (toCheck@64@00 Set<Int>)) (!
  (transitive_closure_from%stateless edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00)
  :pattern ((transitive_closure_from%limited s@$ edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00))
  :qid |quant-u-27|)))
(assert (forall ((s@$ $Snap) (edges@60@00 Set<Edge>) (from@61@00 Int) (depth@62@00 Int) (allNodes@63@00 Set<Int>) (toCheck@64@00 Set<Int>)) (!
  (let ((result@65@00 (transitive_closure_from%limited s@$ edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00))) (=>
    (transitive_closure_from%precondition s@$ edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00)
    (or (Set_in from@61@00 result@65@00) (= depth@62@00 0))))
  :pattern ((transitive_closure_from%limited s@$ edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00))
  :qid |quant-u-68|)))
(assert (forall ((s@$ $Snap) (edges@60@00 Set<Edge>) (from@61@00 Int) (depth@62@00 Int) (allNodes@63@00 Set<Int>) (toCheck@64@00 Set<Int>)) (!
  (let ((result@65@00 (transitive_closure_from%limited s@$ edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00))) true)
  :pattern ((transitive_closure_from%limited s@$ edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00))
  :qid |quant-u-69|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (>= depth@62@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (depth == 0 ? Set(from) : (|toCheck| == 0 ? Set(from) : (let n == (choose_one(toCheck)) in (path_exists_bounded(edges, from, n, depth, Set[Int](), allNodes) ? (Set(n) union transitive_closure_from(edges, from, depth, allNodes, (toCheck setminus Set(n)))) : transitive_closure_from(edges, from, depth, allNodes, (toCheck setminus Set(n)))))))
; [eval] depth == 0
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= depth@62@00 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= depth@62@00 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 27 | depth@62@00 == 0 | live]
; [else-branch: 27 | depth@62@00 != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 27 | depth@62@00 == 0]
(assert (= depth@62@00 0))
; [eval] Set(from)
(pop) ; 3
(push) ; 3
; [else-branch: 27 | depth@62@00 != 0]
(assert (not (= depth@62@00 0)))
; [eval] (|toCheck| == 0 ? Set(from) : (let n == (choose_one(toCheck)) in (path_exists_bounded(edges, from, n, depth, Set[Int](), allNodes) ? (Set(n) union transitive_closure_from(edges, from, depth, allNodes, (toCheck setminus Set(n)))) : transitive_closure_from(edges, from, depth, allNodes, (toCheck setminus Set(n))))))
; [eval] |toCheck| == 0
; [eval] |toCheck|
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (= (Set_card toCheck@64@00) 0))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= (Set_card toCheck@64@00) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 28 | |toCheck@64@00| == 0 | live]
; [else-branch: 28 | |toCheck@64@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 28 | |toCheck@64@00| == 0]
(assert (= (Set_card toCheck@64@00) 0))
; [eval] Set(from)
(pop) ; 5
(push) ; 5
; [else-branch: 28 | |toCheck@64@00| != 0]
(assert (not (= (Set_card toCheck@64@00) 0)))
; [eval] (let n == (choose_one(toCheck)) in (path_exists_bounded(edges, from, n, depth, Set[Int](), allNodes) ? (Set(n) union transitive_closure_from(edges, from, depth, allNodes, (toCheck setminus Set(n)))) : transitive_closure_from(edges, from, depth, allNodes, (toCheck setminus Set(n)))))
; [eval] choose_one(toCheck)
(push) ; 6
; [eval] |s| > 0
; [eval] |s|
(push) ; 7
(assert (not (> (Set_card toCheck@64@00) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (> (Set_card toCheck@64@00) 0))
(assert (choose_one%precondition $Snap.unit toCheck@64@00))
(pop) ; 6
; Joined path conditions
(assert (and
  (> (Set_card toCheck@64@00) 0)
  (choose_one%precondition $Snap.unit toCheck@64@00)))
(declare-fun letvar@90@00 ($Snap Set<Edge> Int Int Set<Int> Set<Int>) Int)
(assert (=
  (letvar@90@00 s@$ edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00)
  (choose_one $Snap.unit toCheck@64@00)))
; [eval] (path_exists_bounded(edges, from, n, depth, Set[Int](), allNodes) ? (Set(n) union transitive_closure_from(edges, from, depth, allNodes, (toCheck setminus Set(n)))) : transitive_closure_from(edges, from, depth, allNodes, (toCheck setminus Set(n))))
; [eval] path_exists_bounded(edges, from, n, depth, Set[Int](), allNodes)
; [eval] Set[Int]()
(push) ; 6
; [eval] depth >= 0
(assert (path_exists_bounded%precondition $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00))
(pop) ; 6
; Joined path conditions
(assert (path_exists_bounded%precondition $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00))
(push) ; 6
(push) ; 7
(set-option :rlimit 16000)
(assert (not (not
  (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 16000)
(assert (not (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00)))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 29 | path_exists_bounded(_, edges@60@00, from@61@00, choose_one(_, toCheck@64@00), depth@62@00, Ø, allNodes@63@00) | live]
; [else-branch: 29 | !(path_exists_bounded(_, edges@60@00, from@61@00, choose_one(_, toCheck@64@00), depth@62@00, Ø, allNodes@63@00)) | live]
(set-option :rlimit 0)
(push) ; 7
; [then-branch: 29 | path_exists_bounded(_, edges@60@00, from@61@00, choose_one(_, toCheck@64@00), depth@62@00, Ø, allNodes@63@00)]
(assert (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00))
; [eval] (Set(n) union transitive_closure_from(edges, from, depth, allNodes, (toCheck setminus Set(n))))
; [eval] Set(n)
; [eval] transitive_closure_from(edges, from, depth, allNodes, (toCheck setminus Set(n)))
; [eval] (toCheck setminus Set(n))
; [eval] Set(n)
(push) ; 8
; [eval] depth >= 0
(assert (transitive_closure_from%precondition $Snap.unit edges@60@00 from@61@00 depth@62@00 allNodes@63@00 (Set_difference toCheck@64@00 (Set_singleton (choose_one $Snap.unit toCheck@64@00)))))
(pop) ; 8
; Joined path conditions
(assert (transitive_closure_from%precondition $Snap.unit edges@60@00 from@61@00 depth@62@00 allNodes@63@00 (Set_difference toCheck@64@00 (Set_singleton (choose_one $Snap.unit toCheck@64@00)))))
(pop) ; 7
(push) ; 7
; [else-branch: 29 | !(path_exists_bounded(_, edges@60@00, from@61@00, choose_one(_, toCheck@64@00), depth@62@00, Ø, allNodes@63@00))]
(assert (not
  (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00)))
; [eval] transitive_closure_from(edges, from, depth, allNodes, (toCheck setminus Set(n)))
; [eval] (toCheck setminus Set(n))
; [eval] Set(n)
(push) ; 8
; [eval] depth >= 0
(assert (transitive_closure_from%precondition $Snap.unit edges@60@00 from@61@00 depth@62@00 allNodes@63@00 (Set_difference toCheck@64@00 (Set_singleton (choose_one $Snap.unit toCheck@64@00)))))
(pop) ; 8
; Joined path conditions
(assert (transitive_closure_from%precondition $Snap.unit edges@60@00 from@61@00 depth@62@00 allNodes@63@00 (Set_difference toCheck@64@00 (Set_singleton (choose_one $Snap.unit toCheck@64@00)))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=>
  (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00)
  (and
    (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00)
    (transitive_closure_from%precondition $Snap.unit edges@60@00 from@61@00 depth@62@00 allNodes@63@00 (Set_difference toCheck@64@00 (Set_singleton (choose_one $Snap.unit toCheck@64@00)))))))
; Joined path conditions
(assert (=>
  (not
    (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00))
  (and
    (not
      (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00))
    (transitive_closure_from%precondition $Snap.unit edges@60@00 from@61@00 depth@62@00 allNodes@63@00 (Set_difference toCheck@64@00 (Set_singleton (choose_one $Snap.unit toCheck@64@00)))))))
(assert (or
  (not
    (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00))
  (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Set_card toCheck@64@00) 0))
  (and
    (not (= (Set_card toCheck@64@00) 0))
    (> (Set_card toCheck@64@00) 0)
    (choose_one%precondition $Snap.unit toCheck@64@00)
    (=
      (letvar@90@00 s@$ edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00)
      (choose_one $Snap.unit toCheck@64@00))
    (path_exists_bounded%precondition $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00)
    (=>
      (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00)
      (and
        (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00)
        (transitive_closure_from%precondition $Snap.unit edges@60@00 from@61@00 depth@62@00 allNodes@63@00 (Set_difference toCheck@64@00 (Set_singleton (choose_one $Snap.unit toCheck@64@00))))))
    (=>
      (not
        (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00))
      (and
        (not
          (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00))
        (transitive_closure_from%precondition $Snap.unit edges@60@00 from@61@00 depth@62@00 allNodes@63@00 (Set_difference toCheck@64@00 (Set_singleton (choose_one $Snap.unit toCheck@64@00))))))
    (or
      (not
        (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00))
      (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00)))))
(assert (or (not (= (Set_card toCheck@64@00) 0)) (= (Set_card toCheck@64@00) 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= depth@62@00 0))
  (and
    (not (= depth@62@00 0))
    (=>
      (not (= (Set_card toCheck@64@00) 0))
      (and
        (not (= (Set_card toCheck@64@00) 0))
        (> (Set_card toCheck@64@00) 0)
        (choose_one%precondition $Snap.unit toCheck@64@00)
        (=
          (letvar@90@00 s@$ edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00)
          (choose_one $Snap.unit toCheck@64@00))
        (path_exists_bounded%precondition $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00)
        (=>
          (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00)
          (and
            (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00)
            (transitive_closure_from%precondition $Snap.unit edges@60@00 from@61@00 depth@62@00 allNodes@63@00 (Set_difference toCheck@64@00 (Set_singleton (choose_one $Snap.unit toCheck@64@00))))))
        (=>
          (not
            (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00))
          (and
            (not
              (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00))
            (transitive_closure_from%precondition $Snap.unit edges@60@00 from@61@00 depth@62@00 allNodes@63@00 (Set_difference toCheck@64@00 (Set_singleton (choose_one $Snap.unit toCheck@64@00))))))
        (or
          (not
            (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00))
          (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00))))
    (or (not (= (Set_card toCheck@64@00) 0)) (= (Set_card toCheck@64@00) 0)))))
(assert (or (not (= depth@62@00 0)) (= depth@62@00 0)))
(assert (=
  result@65@00
  (ite
    (= depth@62@00 0)
    (Set_singleton from@61@00)
    (ite
      (= (Set_card toCheck@64@00) 0)
      (Set_singleton from@61@00)
      (ite
        (path_exists_bounded $Snap.unit edges@60@00 from@61@00 (choose_one $Snap.unit toCheck@64@00) depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00)
        (Set_union (Set_singleton (choose_one $Snap.unit toCheck@64@00)) (transitive_closure_from $Snap.unit edges@60@00 from@61@00 depth@62@00 allNodes@63@00 (Set_difference toCheck@64@00 (Set_singleton (choose_one $Snap.unit toCheck@64@00)))))
        (transitive_closure_from $Snap.unit edges@60@00 from@61@00 depth@62@00 allNodes@63@00 (Set_difference toCheck@64@00 (Set_singleton (choose_one $Snap.unit toCheck@64@00)))))))))
; [eval] (from in result) || depth == 0
; [eval] (from in result)
(push) ; 2
; [then-branch: 30 | from@61@00 in result@65@00 | live]
; [else-branch: 30 | !(from@61@00 in result@65@00) | live]
(push) ; 3
; [then-branch: 30 | from@61@00 in result@65@00]
(assert (Set_in from@61@00 result@65@00))
(pop) ; 3
(push) ; 3
; [else-branch: 30 | !(from@61@00 in result@65@00)]
(assert (not (Set_in from@61@00 result@65@00)))
; [eval] depth == 0
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (Set_in from@61@00 result@65@00)) (Set_in from@61@00 result@65@00)))
(push) ; 2
(assert (not (or (Set_in from@61@00 result@65@00) (= depth@62@00 0))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (or (Set_in from@61@00 result@65@00) (= depth@62@00 0)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@60@00 Set<Edge>) (from@61@00 Int) (depth@62@00 Int) (allNodes@63@00 Set<Int>) (toCheck@64@00 Set<Int>)) (!
  (=>
    (transitive_closure_from%precondition s@$ edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00)
    (=
      (transitive_closure_from s@$ edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00)
      (ite
        (= depth@62@00 0)
        (Set_singleton from@61@00)
        (ite
          (= (Set_card toCheck@64@00) 0)
          (Set_singleton from@61@00)
          (let ((n (choose_one $Snap.unit toCheck@64@00))) (ite
            (path_exists_bounded $Snap.unit edges@60@00 from@61@00 n depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00)
            (Set_union (Set_singleton n) (transitive_closure_from%limited $Snap.unit edges@60@00 from@61@00 depth@62@00 allNodes@63@00 (Set_difference toCheck@64@00 (Set_singleton n))))
            (transitive_closure_from%limited $Snap.unit edges@60@00 from@61@00 depth@62@00 allNodes@63@00 (Set_difference toCheck@64@00 (Set_singleton n)))))))))
  :pattern ((transitive_closure_from s@$ edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00))
  :qid |quant-u-70|)))
(assert (forall ((s@$ $Snap) (edges@60@00 Set<Edge>) (from@61@00 Int) (depth@62@00 Int) (allNodes@63@00 Set<Int>) (toCheck@64@00 Set<Int>)) (!
  (=>
    (transitive_closure_from%precondition s@$ edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00)
    (ite
      (= depth@62@00 0)
      true
      (ite
        (= (Set_card toCheck@64@00) 0)
        true
        (and
          (choose_one%precondition $Snap.unit toCheck@64@00)
          (let ((n (choose_one $Snap.unit toCheck@64@00))) (and
            (path_exists_bounded%precondition $Snap.unit edges@60@00 from@61@00 n depth@62@00 (as Set_empty  Set<Int>) allNodes@63@00)
            (transitive_closure_from%precondition $Snap.unit edges@60@00 from@61@00 depth@62@00 allNodes@63@00 (Set_difference toCheck@64@00 (Set_singleton n)))))))))
  :pattern ((transitive_closure_from s@$ edges@60@00 from@61@00 depth@62@00 allNodes@63@00 toCheck@64@00))
  :qid |quant-u-71|)))
; ---------- FUNCTION count_nodes----------
(declare-fun nodes@66@00 () Set<Int>)
(declare-fun result@67@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@91@00 $Snap)
(assert (= $t@91@00 ($Snap.combine ($Snap.first $t@91@00) ($Snap.second $t@91@00))))
(assert (= ($Snap.first $t@91@00) $Snap.unit))
; [eval] result >= 0
(assert (>= result@67@00 0))
(assert (= ($Snap.second $t@91@00) $Snap.unit))
; [eval] result == |nodes|
; [eval] |nodes|
(assert (= result@67@00 (Set_card nodes@66@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (nodes@66@00 Set<Int>)) (!
  (= (count_nodes%limited s@$ nodes@66@00) (count_nodes s@$ nodes@66@00))
  :pattern ((count_nodes s@$ nodes@66@00))
  :qid |quant-u-28|)))
(assert (forall ((s@$ $Snap) (nodes@66@00 Set<Int>)) (!
  (count_nodes%stateless nodes@66@00)
  :pattern ((count_nodes%limited s@$ nodes@66@00))
  :qid |quant-u-29|)))
(assert (forall ((s@$ $Snap) (nodes@66@00 Set<Int>)) (!
  (let ((result@67@00 (count_nodes%limited s@$ nodes@66@00))) (=>
    (count_nodes%precondition s@$ nodes@66@00)
    (and (>= result@67@00 0) (= result@67@00 (Set_card nodes@66@00)))))
  :pattern ((count_nodes%limited s@$ nodes@66@00))
  :qid |quant-u-72|)))
(assert (forall ((s@$ $Snap) (nodes@66@00 Set<Int>)) (!
  (let ((result@67@00 (count_nodes%limited s@$ nodes@66@00))) true)
  :pattern ((count_nodes%limited s@$ nodes@66@00))
  :qid |quant-u-73|)))
(assert (forall ((s@$ $Snap) (nodes@66@00 Set<Int>)) (!
  (let ((result@67@00 (count_nodes%limited s@$ nodes@66@00))) true)
  :pattern ((count_nodes%limited s@$ nodes@66@00))
  :qid |quant-u-74|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] |nodes|
(assert (= result@67@00 (Set_card nodes@66@00)))
; [eval] result >= 0
(set-option :rlimit 0)
(push) ; 2
(assert (not (>= result@67@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@67@00 0))
; [eval] result == |nodes|
; [eval] |nodes|
(pop) ; 1
(assert (forall ((s@$ $Snap) (nodes@66@00 Set<Int>)) (!
  (=>
    (count_nodes%precondition s@$ nodes@66@00)
    (= (count_nodes s@$ nodes@66@00) (Set_card nodes@66@00)))
  :pattern ((count_nodes s@$ nodes@66@00))
  :qid |quant-u-75|)))
(assert (forall ((s@$ $Snap) (nodes@66@00 Set<Int>)) (!
  true
  :pattern ((count_nodes s@$ nodes@66@00))
  :qid |quant-u-76|)))
; ---------- FUNCTION has_cycle_bounded----------
(declare-fun edges@68@00 () Set<Edge>)
(declare-fun start@69@00 () Int)
(declare-fun depth@70@00 () Int)
(declare-fun allNodes@71@00 () Set<Int>)
(declare-fun result@72@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] depth > 0
(assert (> depth@70@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@68@00 Set<Edge>) (start@69@00 Int) (depth@70@00 Int) (allNodes@71@00 Set<Int>)) (!
  (=
    (has_cycle_bounded%limited s@$ edges@68@00 start@69@00 depth@70@00 allNodes@71@00)
    (has_cycle_bounded s@$ edges@68@00 start@69@00 depth@70@00 allNodes@71@00))
  :pattern ((has_cycle_bounded s@$ edges@68@00 start@69@00 depth@70@00 allNodes@71@00))
  :qid |quant-u-30|)))
(assert (forall ((s@$ $Snap) (edges@68@00 Set<Edge>) (start@69@00 Int) (depth@70@00 Int) (allNodes@71@00 Set<Int>)) (!
  (has_cycle_bounded%stateless edges@68@00 start@69@00 depth@70@00 allNodes@71@00)
  :pattern ((has_cycle_bounded%limited s@$ edges@68@00 start@69@00 depth@70@00 allNodes@71@00))
  :qid |quant-u-31|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (> depth@70@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] has_self_loop(edges, start, allNodes) || depth > 1 && has_cycle_through_neighbors(edges, start, start, depth - 1, Set(start), allNodes, get_neighbors(edges, start, allNodes))
; [eval] has_self_loop(edges, start, allNodes)
(set-option :rlimit 0)
(push) ; 2
(assert (has_self_loop%precondition $Snap.unit edges@68@00 start@69@00 allNodes@71@00))
(pop) ; 2
; Joined path conditions
(assert (has_self_loop%precondition $Snap.unit edges@68@00 start@69@00 allNodes@71@00))
(push) ; 2
; [then-branch: 31 | has_self_loop(_, edges@68@00, start@69@00, allNodes@71@00) | live]
; [else-branch: 31 | !(has_self_loop(_, edges@68@00, start@69@00, allNodes@71@00)) | live]
(push) ; 3
; [then-branch: 31 | has_self_loop(_, edges@68@00, start@69@00, allNodes@71@00)]
(assert (has_self_loop $Snap.unit edges@68@00 start@69@00 allNodes@71@00))
(pop) ; 3
(push) ; 3
; [else-branch: 31 | !(has_self_loop(_, edges@68@00, start@69@00, allNodes@71@00))]
(assert (not (has_self_loop $Snap.unit edges@68@00 start@69@00 allNodes@71@00)))
; [eval] depth > 1 && has_cycle_through_neighbors(edges, start, start, depth - 1, Set(start), allNodes, get_neighbors(edges, start, allNodes))
; [eval] depth > 1
(push) ; 4
; [then-branch: 32 | !(depth@70@00 > 1) | live]
; [else-branch: 32 | depth@70@00 > 1 | live]
(push) ; 5
; [then-branch: 32 | !(depth@70@00 > 1)]
(assert (not (> depth@70@00 1)))
(pop) ; 5
(push) ; 5
; [else-branch: 32 | depth@70@00 > 1]
(assert (> depth@70@00 1))
; [eval] has_cycle_through_neighbors(edges, start, start, depth - 1, Set(start), allNodes, get_neighbors(edges, start, allNodes))
; [eval] depth - 1
; [eval] Set(start)
; [eval] get_neighbors(edges, start, allNodes)
(push) ; 6
(assert (get_neighbors%precondition $Snap.unit edges@68@00 start@69@00 allNodes@71@00))
(pop) ; 6
; Joined path conditions
(assert (get_neighbors%precondition $Snap.unit edges@68@00 start@69@00 allNodes@71@00))
(push) ; 6
; [eval] depth >= 0
(push) ; 7
(assert (not (>= (- depth@70@00 1) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (>= (- depth@70@00 1) 0))
(assert (has_cycle_through_neighbors%precondition $Snap.unit edges@68@00 start@69@00 start@69@00 (-
  depth@70@00
  1) (Set_singleton start@69@00) allNodes@71@00 (get_neighbors $Snap.unit edges@68@00 start@69@00 allNodes@71@00)))
(pop) ; 6
; Joined path conditions
(assert (and
  (>= (- depth@70@00 1) 0)
  (has_cycle_through_neighbors%precondition $Snap.unit edges@68@00 start@69@00 start@69@00 (-
    depth@70@00
    1) (Set_singleton start@69@00) allNodes@71@00 (get_neighbors $Snap.unit edges@68@00 start@69@00 allNodes@71@00))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (> depth@70@00 1)
  (and
    (> depth@70@00 1)
    (get_neighbors%precondition $Snap.unit edges@68@00 start@69@00 allNodes@71@00)
    (>= (- depth@70@00 1) 0)
    (has_cycle_through_neighbors%precondition $Snap.unit edges@68@00 start@69@00 start@69@00 (-
      depth@70@00
      1) (Set_singleton start@69@00) allNodes@71@00 (get_neighbors $Snap.unit edges@68@00 start@69@00 allNodes@71@00)))))
(assert (or (> depth@70@00 1) (not (> depth@70@00 1))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (has_self_loop $Snap.unit edges@68@00 start@69@00 allNodes@71@00))
  (and
    (not (has_self_loop $Snap.unit edges@68@00 start@69@00 allNodes@71@00))
    (=>
      (> depth@70@00 1)
      (and
        (> depth@70@00 1)
        (get_neighbors%precondition $Snap.unit edges@68@00 start@69@00 allNodes@71@00)
        (>= (- depth@70@00 1) 0)
        (has_cycle_through_neighbors%precondition $Snap.unit edges@68@00 start@69@00 start@69@00 (-
          depth@70@00
          1) (Set_singleton start@69@00) allNodes@71@00 (get_neighbors $Snap.unit edges@68@00 start@69@00 allNodes@71@00))))
    (or (> depth@70@00 1) (not (> depth@70@00 1))))))
(assert (or
  (not (has_self_loop $Snap.unit edges@68@00 start@69@00 allNodes@71@00))
  (has_self_loop $Snap.unit edges@68@00 start@69@00 allNodes@71@00)))
(assert (=
  result@72@00
  (or
    (has_self_loop $Snap.unit edges@68@00 start@69@00 allNodes@71@00)
    (and
      (> depth@70@00 1)
      (has_cycle_through_neighbors $Snap.unit edges@68@00 start@69@00 start@69@00 (-
        depth@70@00
        1) (Set_singleton start@69@00) allNodes@71@00 (get_neighbors $Snap.unit edges@68@00 start@69@00 allNodes@71@00))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@68@00 Set<Edge>) (start@69@00 Int) (depth@70@00 Int) (allNodes@71@00 Set<Int>)) (!
  (=>
    (has_cycle_bounded%precondition s@$ edges@68@00 start@69@00 depth@70@00 allNodes@71@00)
    (=
      (has_cycle_bounded s@$ edges@68@00 start@69@00 depth@70@00 allNodes@71@00)
      (or
        (has_self_loop $Snap.unit edges@68@00 start@69@00 allNodes@71@00)
        (and
          (> depth@70@00 1)
          (has_cycle_through_neighbors $Snap.unit edges@68@00 start@69@00 start@69@00 (-
            depth@70@00
            1) (Set_singleton start@69@00) allNodes@71@00 (get_neighbors $Snap.unit edges@68@00 start@69@00 allNodes@71@00))))))
  :pattern ((has_cycle_bounded s@$ edges@68@00 start@69@00 depth@70@00 allNodes@71@00))
  :qid |quant-u-77|)))
(assert (forall ((s@$ $Snap) (edges@68@00 Set<Edge>) (start@69@00 Int) (depth@70@00 Int) (allNodes@71@00 Set<Int>)) (!
  (=>
    (has_cycle_bounded%precondition s@$ edges@68@00 start@69@00 depth@70@00 allNodes@71@00)
    (and
      (has_self_loop%precondition $Snap.unit edges@68@00 start@69@00 allNodes@71@00)
      (=>
        (and
          (not (has_self_loop $Snap.unit edges@68@00 start@69@00 allNodes@71@00))
          (> depth@70@00 1))
        (and
          (get_neighbors%precondition $Snap.unit edges@68@00 start@69@00 allNodes@71@00)
          (has_cycle_through_neighbors%precondition $Snap.unit edges@68@00 start@69@00 start@69@00 (-
            depth@70@00
            1) (Set_singleton start@69@00) allNodes@71@00 (get_neighbors $Snap.unit edges@68@00 start@69@00 allNodes@71@00))))))
  :pattern ((has_cycle_bounded s@$ edges@68@00 start@69@00 depth@70@00 allNodes@71@00))
  :qid |quant-u-78|)))
; ---------- FUNCTION count_outgoing----------
(declare-fun edges@73@00 () Set<Edge>)
(declare-fun from@74@00 () Int)
(declare-fun allNodes@75@00 () Set<Int>)
(declare-fun result@76@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@92@00 $Snap)
(assert (= $t@92@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@76@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@73@00 Set<Edge>) (from@74@00 Int) (allNodes@75@00 Set<Int>)) (!
  (=
    (count_outgoing%limited s@$ edges@73@00 from@74@00 allNodes@75@00)
    (count_outgoing s@$ edges@73@00 from@74@00 allNodes@75@00))
  :pattern ((count_outgoing s@$ edges@73@00 from@74@00 allNodes@75@00))
  :qid |quant-u-32|)))
(assert (forall ((s@$ $Snap) (edges@73@00 Set<Edge>) (from@74@00 Int) (allNodes@75@00 Set<Int>)) (!
  (count_outgoing%stateless edges@73@00 from@74@00 allNodes@75@00)
  :pattern ((count_outgoing%limited s@$ edges@73@00 from@74@00 allNodes@75@00))
  :qid |quant-u-33|)))
(assert (forall ((s@$ $Snap) (edges@73@00 Set<Edge>) (from@74@00 Int) (allNodes@75@00 Set<Int>)) (!
  (let ((result@76@00 (count_outgoing%limited s@$ edges@73@00 from@74@00 allNodes@75@00))) (=>
    (count_outgoing%precondition s@$ edges@73@00 from@74@00 allNodes@75@00)
    (>= result@76@00 0)))
  :pattern ((count_outgoing%limited s@$ edges@73@00 from@74@00 allNodes@75@00))
  :qid |quant-u-79|)))
(assert (forall ((s@$ $Snap) (edges@73@00 Set<Edge>) (from@74@00 Int) (allNodes@75@00 Set<Int>)) (!
  (let ((result@76@00 (count_outgoing%limited s@$ edges@73@00 from@74@00 allNodes@75@00))) true)
  :pattern ((count_outgoing%limited s@$ edges@73@00 from@74@00 allNodes@75@00))
  :qid |quant-u-80|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] |get_neighbors(edges, from, allNodes)|
; [eval] get_neighbors(edges, from, allNodes)
(set-option :rlimit 0)
(push) ; 2
(assert (get_neighbors%precondition $Snap.unit edges@73@00 from@74@00 allNodes@75@00))
(pop) ; 2
; Joined path conditions
(assert (get_neighbors%precondition $Snap.unit edges@73@00 from@74@00 allNodes@75@00))
(assert (=
  result@76@00
  (Set_card (get_neighbors $Snap.unit edges@73@00 from@74@00 allNodes@75@00))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@76@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@76@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (edges@73@00 Set<Edge>) (from@74@00 Int) (allNodes@75@00 Set<Int>)) (!
  (=>
    (count_outgoing%precondition s@$ edges@73@00 from@74@00 allNodes@75@00)
    (=
      (count_outgoing s@$ edges@73@00 from@74@00 allNodes@75@00)
      (Set_card (get_neighbors $Snap.unit edges@73@00 from@74@00 allNodes@75@00))))
  :pattern ((count_outgoing s@$ edges@73@00 from@74@00 allNodes@75@00))
  :qid |quant-u-81|)))
(assert (forall ((s@$ $Snap) (edges@73@00 Set<Edge>) (from@74@00 Int) (allNodes@75@00 Set<Int>)) (!
  (=>
    (count_outgoing%precondition s@$ edges@73@00 from@74@00 allNodes@75@00)
    (get_neighbors%precondition $Snap.unit edges@73@00 from@74@00 allNodes@75@00))
  :pattern ((count_outgoing s@$ edges@73@00 from@74@00 allNodes@75@00))
  :qid |quant-u-82|)))
