(get-info :version)
; (:version "4.8.7")
; Started: 2025-12-05 12:20:13
; Silicon.version: 1.1-SNAPSHOT (95328487@(detached))
; Input file: ./functions/data_structures.vpr
; Verifier id: 00
; ------------------------------------------------------------
; Begin preamble
; ////////// Static preamble
; 
; ; /z3config.smt2
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :smt.qi.max_multi_patterns 1000)
; 
; ; /preamble.smt2
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(define-fun $Perm.min ((p1 $Perm) (p2 $Perm)) Real
    (ite (<= p1 p2) p1 p2))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
; ////////// Sorts
(declare-sort Seq<RoseTree> 0)
(declare-sort Seq<Trie> 0)
(declare-sort Seq<Int> 0)
(declare-sort RoseTree 0)
(declare-sort BST 0)
(declare-sort Trie 0)
(declare-sort Option<Int> 0)
(declare-sort ListZipper<Int> 0)
; ////////// Sort wrappers
; Declaring additional sort wrappers
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.Seq<RoseTree>To$Snap (Seq<RoseTree>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<RoseTree> ($Snap) Seq<RoseTree>)
(assert (forall ((x Seq<RoseTree>)) (!
    (= x ($SortWrappers.$SnapToSeq<RoseTree>($SortWrappers.Seq<RoseTree>To$Snap x)))
    :pattern (($SortWrappers.Seq<RoseTree>To$Snap x))
    :qid |$Snap.$SnapToSeq<RoseTree>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<RoseTree>To$Snap($SortWrappers.$SnapToSeq<RoseTree> x)))
    :pattern (($SortWrappers.$SnapToSeq<RoseTree> x))
    :qid |$Snap.Seq<RoseTree>To$SnapToSeq<RoseTree>|
    )))
(declare-fun $SortWrappers.Seq<Trie>To$Snap (Seq<Trie>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<Trie> ($Snap) Seq<Trie>)
(assert (forall ((x Seq<Trie>)) (!
    (= x ($SortWrappers.$SnapToSeq<Trie>($SortWrappers.Seq<Trie>To$Snap x)))
    :pattern (($SortWrappers.Seq<Trie>To$Snap x))
    :qid |$Snap.$SnapToSeq<Trie>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<Trie>To$Snap($SortWrappers.$SnapToSeq<Trie> x)))
    :pattern (($SortWrappers.$SnapToSeq<Trie> x))
    :qid |$Snap.Seq<Trie>To$SnapToSeq<Trie>|
    )))
(declare-fun $SortWrappers.Seq<Int>To$Snap (Seq<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<Int> ($Snap) Seq<Int>)
(assert (forall ((x Seq<Int>)) (!
    (= x ($SortWrappers.$SnapToSeq<Int>($SortWrappers.Seq<Int>To$Snap x)))
    :pattern (($SortWrappers.Seq<Int>To$Snap x))
    :qid |$Snap.$SnapToSeq<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<Int>To$Snap($SortWrappers.$SnapToSeq<Int> x)))
    :pattern (($SortWrappers.$SnapToSeq<Int> x))
    :qid |$Snap.Seq<Int>To$SnapToSeq<Int>|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.RoseTreeTo$Snap (RoseTree) $Snap)
(declare-fun $SortWrappers.$SnapToRoseTree ($Snap) RoseTree)
(assert (forall ((x RoseTree)) (!
    (= x ($SortWrappers.$SnapToRoseTree($SortWrappers.RoseTreeTo$Snap x)))
    :pattern (($SortWrappers.RoseTreeTo$Snap x))
    :qid |$Snap.$SnapToRoseTreeTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.RoseTreeTo$Snap($SortWrappers.$SnapToRoseTree x)))
    :pattern (($SortWrappers.$SnapToRoseTree x))
    :qid |$Snap.RoseTreeTo$SnapToRoseTree|
    )))
(declare-fun $SortWrappers.BSTTo$Snap (BST) $Snap)
(declare-fun $SortWrappers.$SnapToBST ($Snap) BST)
(assert (forall ((x BST)) (!
    (= x ($SortWrappers.$SnapToBST($SortWrappers.BSTTo$Snap x)))
    :pattern (($SortWrappers.BSTTo$Snap x))
    :qid |$Snap.$SnapToBSTTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BSTTo$Snap($SortWrappers.$SnapToBST x)))
    :pattern (($SortWrappers.$SnapToBST x))
    :qid |$Snap.BSTTo$SnapToBST|
    )))
(declare-fun $SortWrappers.TrieTo$Snap (Trie) $Snap)
(declare-fun $SortWrappers.$SnapToTrie ($Snap) Trie)
(assert (forall ((x Trie)) (!
    (= x ($SortWrappers.$SnapToTrie($SortWrappers.TrieTo$Snap x)))
    :pattern (($SortWrappers.TrieTo$Snap x))
    :qid |$Snap.$SnapToTrieTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.TrieTo$Snap($SortWrappers.$SnapToTrie x)))
    :pattern (($SortWrappers.$SnapToTrie x))
    :qid |$Snap.TrieTo$SnapToTrie|
    )))
(declare-fun $SortWrappers.Option<Int>To$Snap (Option<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToOption<Int> ($Snap) Option<Int>)
(assert (forall ((x Option<Int>)) (!
    (= x ($SortWrappers.$SnapToOption<Int>($SortWrappers.Option<Int>To$Snap x)))
    :pattern (($SortWrappers.Option<Int>To$Snap x))
    :qid |$Snap.$SnapToOption<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Option<Int>To$Snap($SortWrappers.$SnapToOption<Int> x)))
    :pattern (($SortWrappers.$SnapToOption<Int> x))
    :qid |$Snap.Option<Int>To$SnapToOption<Int>|
    )))
(declare-fun $SortWrappers.ListZipper<Int>To$Snap (ListZipper<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToListZipper<Int> ($Snap) ListZipper<Int>)
(assert (forall ((x ListZipper<Int>)) (!
    (= x ($SortWrappers.$SnapToListZipper<Int>($SortWrappers.ListZipper<Int>To$Snap x)))
    :pattern (($SortWrappers.ListZipper<Int>To$Snap x))
    :qid |$Snap.$SnapToListZipper<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.ListZipper<Int>To$Snap($SortWrappers.$SnapToListZipper<Int> x)))
    :pattern (($SortWrappers.$SnapToListZipper<Int> x))
    :qid |$Snap.ListZipper<Int>To$SnapToListZipper<Int>|
    )))
; ////////// Symbols
(declare-fun Seq_length (Seq<RoseTree>) Int)
(declare-const Seq_empty Seq<RoseTree>)
(declare-fun Seq_singleton (RoseTree) Seq<RoseTree>)
(declare-fun Seq_append (Seq<RoseTree> Seq<RoseTree>) Seq<RoseTree>)
(declare-fun Seq_index (Seq<RoseTree> Int) RoseTree)
(declare-fun Seq_add (Int Int) Int)
(declare-fun Seq_sub (Int Int) Int)
(declare-fun Seq_update (Seq<RoseTree> Int RoseTree) Seq<RoseTree>)
(declare-fun Seq_take (Seq<RoseTree> Int) Seq<RoseTree>)
(declare-fun Seq_drop (Seq<RoseTree> Int) Seq<RoseTree>)
(declare-fun Seq_contains (Seq<RoseTree> RoseTree) Bool)
(declare-fun Seq_contains_trigger (Seq<RoseTree> RoseTree) Bool)
(declare-fun Seq_skolem (Seq<RoseTree> RoseTree) Int)
(declare-fun Seq_equal (Seq<RoseTree> Seq<RoseTree>) Bool)
(declare-fun Seq_skolem_diff (Seq<RoseTree> Seq<RoseTree>) Int)
(declare-fun Seq_length (Seq<Trie>) Int)
(declare-const Seq_empty Seq<Trie>)
(declare-fun Seq_singleton (Trie) Seq<Trie>)
(declare-fun Seq_append (Seq<Trie> Seq<Trie>) Seq<Trie>)
(declare-fun Seq_index (Seq<Trie> Int) Trie)
(declare-fun Seq_update (Seq<Trie> Int Trie) Seq<Trie>)
(declare-fun Seq_take (Seq<Trie> Int) Seq<Trie>)
(declare-fun Seq_drop (Seq<Trie> Int) Seq<Trie>)
(declare-fun Seq_contains (Seq<Trie> Trie) Bool)
(declare-fun Seq_contains_trigger (Seq<Trie> Trie) Bool)
(declare-fun Seq_skolem (Seq<Trie> Trie) Int)
(declare-fun Seq_equal (Seq<Trie> Seq<Trie>) Bool)
(declare-fun Seq_skolem_diff (Seq<Trie> Seq<Trie>) Int)
(declare-fun Seq_length (Seq<Int>) Int)
(declare-const Seq_empty Seq<Int>)
(declare-fun Seq_singleton (Int) Seq<Int>)
(declare-fun Seq_append (Seq<Int> Seq<Int>) Seq<Int>)
(declare-fun Seq_index (Seq<Int> Int) Int)
(declare-fun Seq_update (Seq<Int> Int Int) Seq<Int>)
(declare-fun Seq_take (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_drop (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_contains (Seq<Int> Int) Bool)
(declare-fun Seq_contains_trigger (Seq<Int> Int) Bool)
(declare-fun Seq_skolem (Seq<Int> Int) Int)
(declare-fun Seq_equal (Seq<Int> Seq<Int>) Bool)
(declare-fun Seq_skolem_diff (Seq<Int> Seq<Int>) Int)
(declare-fun Seq_range (Int Int) Seq<Int>)
(declare-fun Zipper<ListZipper<Int>> (Seq<Int> Option<Int> Seq<Int>) ListZipper<Int>)
(declare-fun get_ListZipper_before<Seq<Int>> (ListZipper<Int>) Seq<Int>)
(declare-fun get_ListZipper_focus<Option<Int>> (ListZipper<Int>) Option<Int>)
(declare-fun get_ListZipper_after<Seq<Int>> (ListZipper<Int>) Seq<Int>)
(declare-fun ListZipper_tag<Int> (ListZipper<Int>) Int)
(declare-const Empty<RoseTree> RoseTree)
(declare-fun RoseNode<RoseTree> (Int Seq<RoseTree>) RoseTree)
(declare-fun get_RoseTree_value<Int> (RoseTree) Int)
(declare-fun get_RoseTree_children<Seq<RoseTree>> (RoseTree) Seq<RoseTree>)
(declare-fun RoseTree_tag<Int> (RoseTree) Int)
(declare-const BSTLeaf<BST> BST)
(declare-fun BSTNode<BST> (BST Int BST) BST)
(declare-fun get_BST_left<BST> (BST) BST)
(declare-fun get_BST_value<Int> (BST) Int)
(declare-fun get_BST_right<BST> (BST) BST)
(declare-fun BST_tag<Int> (BST) Int)
(declare-const None<Option<Int>> Option<Int>)
(declare-fun Some<Option<Int>> (Int) Option<Int>)
(declare-fun get_Option_value<Int> (Option<Int>) Int)
(declare-fun Option_tag<Int> (Option<Int>) Int)
(declare-const EmptyTrie<Trie> Trie)
(declare-fun TrieNode<Trie> (Bool Seq<Trie>) Trie)
(declare-fun get_Trie_isEnd<Bool> (Trie) Bool)
(declare-fun get_Trie_children<Seq<Trie>> (Trie) Seq<Trie>)
(declare-fun Trie_tag<Int> (Trie) Int)
; Declaring symbols related to program functions (from program analysis)
(declare-fun find_root ($Snap Seq<Int> Int Int) Int)
(declare-fun find_root%limited ($Snap Seq<Int> Int Int) Int)
(declare-fun find_root%stateless (Seq<Int> Int Int) Bool)
(declare-fun find_root%precondition ($Snap Seq<Int> Int Int) Bool)
(declare-fun trie_is_empty ($Snap Trie) Bool)
(declare-fun trie_is_empty%limited ($Snap Trie) Bool)
(declare-fun trie_is_empty%stateless (Trie) Bool)
(declare-fun trie_is_empty%precondition ($Snap Trie) Bool)
(declare-fun bst_max ($Snap BST) Option<Int>)
(declare-fun bst_max%limited ($Snap BST) Option<Int>)
(declare-fun bst_max%stateless (BST) Bool)
(declare-fun bst_max%precondition ($Snap BST) Bool)
(declare-fun zipper_backward ($Snap ListZipper<Int>) ListZipper<Int>)
(declare-fun zipper_backward%limited ($Snap ListZipper<Int>) ListZipper<Int>)
(declare-fun zipper_backward%stateless (ListZipper<Int>) Bool)
(declare-fun zipper_backward%precondition ($Snap ListZipper<Int>) Bool)
(declare-fun rose_size ($Snap RoseTree) Int)
(declare-fun rose_size%limited ($Snap RoseTree) Int)
(declare-fun rose_size%stateless (RoseTree) Bool)
(declare-fun rose_size%precondition ($Snap RoseTree) Bool)
(declare-fun rose_children_size ($Snap Seq<RoseTree> Int) Int)
(declare-fun rose_children_size%limited ($Snap Seq<RoseTree> Int) Int)
(declare-fun rose_children_size%stateless (Seq<RoseTree> Int) Bool)
(declare-fun rose_children_size%precondition ($Snap Seq<RoseTree> Int) Bool)
(declare-fun trie_count_words ($Snap Trie) Int)
(declare-fun trie_count_words%limited ($Snap Trie) Int)
(declare-fun trie_count_words%stateless (Trie) Bool)
(declare-fun trie_count_words%precondition ($Snap Trie) Bool)
(declare-fun trie_count_children_words ($Snap Seq<Trie> Int) Int)
(declare-fun trie_count_children_words%limited ($Snap Seq<Trie> Int) Int)
(declare-fun trie_count_children_words%stateless (Seq<Trie> Int) Bool)
(declare-fun trie_count_children_words%precondition ($Snap Seq<Trie> Int) Bool)
(declare-fun bst_insert ($Snap BST Int) BST)
(declare-fun bst_insert%limited ($Snap BST Int) BST)
(declare-fun bst_insert%stateless (BST Int) Bool)
(declare-fun bst_insert%precondition ($Snap BST Int) Bool)
(declare-fun is_valid_bst ($Snap BST Int Int) Bool)
(declare-fun is_valid_bst%limited ($Snap BST Int Int) Bool)
(declare-fun is_valid_bst%stateless (BST Int Int) Bool)
(declare-fun is_valid_bst%precondition ($Snap BST Int Int) Bool)
(declare-fun bst_search ($Snap BST Int) Bool)
(declare-fun bst_search%limited ($Snap BST Int) Bool)
(declare-fun bst_search%stateless (BST Int) Bool)
(declare-fun bst_search%precondition ($Snap BST Int) Bool)
(declare-fun bst_min ($Snap BST) Option<Int>)
(declare-fun bst_min%limited ($Snap BST) Option<Int>)
(declare-fun bst_min%stateless (BST) Bool)
(declare-fun bst_min%precondition ($Snap BST) Bool)
(declare-fun is_same_set ($Snap Seq<Int> Int Int Int) Bool)
(declare-fun is_same_set%limited ($Snap Seq<Int> Int Int Int) Bool)
(declare-fun is_same_set%stateless (Seq<Int> Int Int Int) Bool)
(declare-fun is_same_set%precondition ($Snap Seq<Int> Int Int Int) Bool)
(declare-fun is_max_heap ($Snap Seq<Int> Int) Bool)
(declare-fun is_max_heap%limited ($Snap Seq<Int> Int) Bool)
(declare-fun is_max_heap%stateless (Seq<Int> Int) Bool)
(declare-fun is_max_heap%precondition ($Snap Seq<Int> Int) Bool)
(declare-fun skip_list_level ($Snap Int Int) Int)
(declare-fun skip_list_level%limited ($Snap Int Int) Int)
(declare-fun skip_list_level%stateless (Int Int) Bool)
(declare-fun skip_list_level%precondition ($Snap Int Int) Bool)
(declare-fun is_min_heap ($Snap Seq<Int> Int) Bool)
(declare-fun is_min_heap%limited ($Snap Seq<Int> Int) Bool)
(declare-fun is_min_heap%stateless (Seq<Int> Int) Bool)
(declare-fun is_min_heap%precondition ($Snap Seq<Int> Int) Bool)
(declare-fun zipper_forward ($Snap ListZipper<Int>) ListZipper<Int>)
(declare-fun zipper_forward%limited ($Snap ListZipper<Int>) ListZipper<Int>)
(declare-fun zipper_forward%stateless (ListZipper<Int>) Bool)
(declare-fun zipper_forward%precondition ($Snap ListZipper<Int>) Bool)
(declare-fun rose_height ($Snap RoseTree) Int)
(declare-fun rose_height%limited ($Snap RoseTree) Int)
(declare-fun rose_height%stateless (RoseTree) Bool)
(declare-fun rose_height%precondition ($Snap RoseTree) Bool)
(declare-fun rose_children_max_height ($Snap Seq<RoseTree> Int Int) Int)
(declare-fun rose_children_max_height%limited ($Snap Seq<RoseTree> Int Int) Int)
(declare-fun rose_children_max_height%stateless (Seq<RoseTree> Int Int) Bool)
(declare-fun rose_children_max_height%precondition ($Snap Seq<RoseTree> Int Int) Bool)
(declare-fun segment_tree_query ($Snap Seq<Int> Int Int Int Int Int) Int)
(declare-fun segment_tree_query%limited ($Snap Seq<Int> Int Int Int Int Int) Int)
(declare-fun segment_tree_query%stateless (Seq<Int> Int Int Int Int Int) Bool)
(declare-fun segment_tree_query%precondition ($Snap Seq<Int> Int Int Int Int Int) Bool)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
; Declaring predicate trigger functions
; ////////// Uniqueness assumptions from domains
; ////////// Axioms
(assert (forall ((s Seq<RoseTree>)) (!
  (<= 0 (Seq_length s))
  :pattern ((Seq_length s))
  :qid |$Seq[RoseTree]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty  Seq<RoseTree>)) 0))
(assert (forall ((s Seq<RoseTree>)) (!
  (=> (= (Seq_length s) 0) (= s (as Seq_empty  Seq<RoseTree>)))
  :pattern ((Seq_length s))
  :qid |$Seq[RoseTree]_prog.Seq_length_zero|)))
(assert (forall ((e RoseTree)) (!
  (= (Seq_length (Seq_singleton e)) 1)
  :pattern ((Seq_singleton e))
  :qid |$Seq[RoseTree]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<RoseTree>) (s1 Seq<RoseTree>)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<RoseTree>)))
      (not (= s1 (as Seq_empty  Seq<RoseTree>))))
    (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1))))
  :pattern ((Seq_length (Seq_append s0 s1)))
  :qid |$Seq[RoseTree]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<RoseTree>) (s1 Seq<RoseTree>)) (!
  (and
    (=> (= s0 (as Seq_empty  Seq<RoseTree>)) (= (Seq_append s0 s1) s1))
    (=> (= s1 (as Seq_empty  Seq<RoseTree>)) (= (Seq_append s0 s1) s0)))
  :pattern ((Seq_append s0 s1))
  :qid |$Seq[RoseTree]_prog.Seq_append_empty|)))
(assert (forall ((e RoseTree)) (!
  (= (Seq_index (Seq_singleton e) 0) e)
  :pattern ((Seq_singleton e))
  :qid |$Seq[RoseTree]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_add i j) (+ i j))
  :pattern ((Seq_add i j))
  :qid |$Seq[RoseTree]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_sub i j) (- i j))
  :pattern ((Seq_sub i j))
  :qid |$Seq[RoseTree]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<RoseTree>) (s1 Seq<RoseTree>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<RoseTree>)))
      (and
        (not (= s1 (as Seq_empty  Seq<RoseTree>)))
        (and (<= 0 n) (< n (Seq_length s0)))))
    (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n)))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :pattern ((Seq_index s0 n) (Seq_append s0 s1))
  :qid |$Seq[RoseTree]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<RoseTree>) (s1 Seq<RoseTree>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<RoseTree>)))
      (and
        (not (= s1 (as Seq_empty  Seq<RoseTree>)))
        (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1))))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n)
      (=
        (Seq_index (Seq_append s0 s1) n)
        (Seq_index s1 (Seq_sub n (Seq_length s0))))))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :qid |$Seq[RoseTree]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<RoseTree>) (s1 Seq<RoseTree>) (m Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<RoseTree>)))
      (and
        (not (= s1 (as Seq_empty  Seq<RoseTree>)))
        (and (<= 0 m) (< m (Seq_length s1)))))
    (and
      (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m)
      (=
        (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0)))
        (Seq_index s1 m))))
  :pattern ((Seq_index s1 m) (Seq_append s0 s1))
  :qid |$Seq[RoseTree]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<RoseTree>) (i Int) (v RoseTree)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (Seq_length (Seq_update s i v)) (Seq_length s)))
  :pattern ((Seq_length (Seq_update s i v)))
  :pattern ((Seq_length s) (Seq_update s i v))
  :qid |$Seq[RoseTree]_prog.Seq_update_length|)))
(assert (forall ((s Seq<RoseTree>) (i Int) (v RoseTree) (n Int)) (!
  (=>
    (and (<= 0 n) (< n (Seq_length s)))
    (and
      (=> (= i n) (= (Seq_index (Seq_update s i v) n) v))
      (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n)))))
  :pattern ((Seq_index (Seq_update s i v) n))
  :pattern ((Seq_index s n) (Seq_update s i v))
  :qid |$Seq[RoseTree]_prog.Seq_update_index|)))
(assert (forall ((s Seq<RoseTree>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s)))))
    (=> (< n 0) (= (Seq_length (Seq_take s n)) 0)))
  :pattern ((Seq_length (Seq_take s n)))
  :pattern ((Seq_take s n) (Seq_length s))
  :qid |$Seq[RoseTree]_prog.Seq_take_length|)))
(assert (forall ((s Seq<RoseTree>) (n Int) (j Int)) (!
  (=>
    (and (<= 0 j) (and (< j n) (< j (Seq_length s))))
    (= (Seq_index (Seq_take s n) j) (Seq_index s j)))
  :pattern ((Seq_index (Seq_take s n) j))
  :pattern ((Seq_index s j) (Seq_take s n))
  :qid |$Seq[RoseTree]_prog.Seq_take_index|)))
(assert (forall ((s Seq<RoseTree>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=>
          (<= n (Seq_length s))
          (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n)))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0))))
    (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s))))
  :pattern ((Seq_length (Seq_drop s n)))
  :pattern ((Seq_length s) (Seq_drop s n))
  :qid |$Seq[RoseTree]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<RoseTree>) (n Int) (j Int)) (!
  (=>
    (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n))))
    (and
      (= (Seq_sub (Seq_add j n) n) j)
      (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n)))))
  :pattern ((Seq_index (Seq_drop s n) j))
  :qid |$Seq[RoseTree]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<RoseTree>) (n Int) (i Int)) (!
  (=>
    (and (< 0 n) (and (<= n i) (< i (Seq_length s))))
    (and
      (= (Seq_add (Seq_sub i n) n) i)
      (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i))))
  :pattern ((Seq_drop s n) (Seq_index s i))
  :qid |$Seq[RoseTree]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<RoseTree>) (t Seq<RoseTree>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_take (Seq_append s t) n) (Seq_take s n)))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[RoseTree]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<RoseTree>) (t Seq<RoseTree>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (=
        (Seq_take (Seq_append s t) n)
        (Seq_append s (Seq_take t (Seq_sub n (Seq_length s)))))))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[RoseTree]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<RoseTree>) (t Seq<RoseTree>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t)))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[RoseTree]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<RoseTree>) (t Seq<RoseTree>) (n Int)) (!
  (=>
    (and (> n 0) (> n (Seq_length s)))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s))))))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[RoseTree]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<RoseTree>) (n Int)) (!
  (=> (<= n 0) (= (Seq_take s n) (as Seq_empty  Seq<RoseTree>)))
  :pattern ((Seq_take s n))
  :qid |$Seq[RoseTree]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<RoseTree>) (n Int)) (!
  (=> (<= n 0) (= (Seq_drop s n) s))
  :pattern ((Seq_drop s n))
  :qid |$Seq[RoseTree]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<RoseTree>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_take s n) s))
  :pattern ((Seq_take s n))
  :qid |$Seq[RoseTree]_prog.Seq_take_all|)))
(assert (forall ((s Seq<RoseTree>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty  Seq<RoseTree>)))
  :pattern ((Seq_drop s n))
  :qid |$Seq[RoseTree]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<RoseTree>) (x RoseTree)) (!
  (=>
    (Seq_contains s x)
    (and
      (<= 0 (Seq_skolem s x))
      (and
        (< (Seq_skolem s x) (Seq_length s))
        (= (Seq_index s (Seq_skolem s x)) x))))
  :pattern ((Seq_contains s x))
  :qid |$Seq[RoseTree]_prog.Seq_contains1|)))
(assert (forall ((s Seq<RoseTree>) (x RoseTree) (i Int)) (!
  (=>
    (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x)))
    (Seq_contains s x))
  :pattern ((Seq_contains s x) (Seq_index s i))
  :qid |$Seq[RoseTree]_prog.Seq_contains2|)))
(assert (forall ((s Seq<RoseTree>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (Seq_contains_trigger s (Seq_index s i)))
  :pattern ((Seq_index s i))
  :qid |$Seq[RoseTree]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<RoseTree>) (s1 Seq<RoseTree>)) (!
  (or
    (and (= s0 s1) (Seq_equal s0 s1))
    (or
      (and
        (not (= s0 s1))
        (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1)))))
      (and
        (not (= s0 s1))
        (and
          (not (Seq_equal s0 s1))
          (and
            (= (Seq_length s0) (Seq_length s1))
            (and
              (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0))
              (and
                (<= 0 (Seq_skolem_diff s0 s1))
                (and
                  (< (Seq_skolem_diff s0 s1) (Seq_length s0))
                  (not
                    (=
                      (Seq_index s0 (Seq_skolem_diff s0 s1))
                      (Seq_index s1 (Seq_skolem_diff s0 s1))))))))))))
  :pattern ((Seq_equal s0 s1))
  :qid |$Seq[RoseTree]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<RoseTree>) (b Seq<RoseTree>)) (!
  (=> (Seq_equal a b) (= a b))
  :pattern ((Seq_equal a b))
  :qid |$Seq[RoseTree]_prog.Seq_equal_ext|)))
(assert (forall ((x RoseTree) (y RoseTree)) (!
  (= (Seq_contains (Seq_singleton x) y) (= x y))
  :pattern ((Seq_contains (Seq_singleton x) y))
  :qid |$Seq[RoseTree]_prog.Seq_singleton_contains|)))
(assert (forall ((s Seq<Trie>)) (!
  (<= 0 (Seq_length s))
  :pattern ((Seq_length s))
  :qid |$Seq[Trie]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty  Seq<Trie>)) 0))
(assert (forall ((s Seq<Trie>)) (!
  (=> (= (Seq_length s) 0) (= s (as Seq_empty  Seq<Trie>)))
  :pattern ((Seq_length s))
  :qid |$Seq[Trie]_prog.Seq_length_zero|)))
(assert (forall ((e Trie)) (!
  (= (Seq_length (Seq_singleton e)) 1)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Trie]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<Trie>) (s1 Seq<Trie>)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Trie>)))
      (not (= s1 (as Seq_empty  Seq<Trie>))))
    (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1))))
  :pattern ((Seq_length (Seq_append s0 s1)))
  :qid |$Seq[Trie]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<Trie>) (s1 Seq<Trie>)) (!
  (and
    (=> (= s0 (as Seq_empty  Seq<Trie>)) (= (Seq_append s0 s1) s1))
    (=> (= s1 (as Seq_empty  Seq<Trie>)) (= (Seq_append s0 s1) s0)))
  :pattern ((Seq_append s0 s1))
  :qid |$Seq[Trie]_prog.Seq_append_empty|)))
(assert (forall ((e Trie)) (!
  (= (Seq_index (Seq_singleton e) 0) e)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Trie]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_add i j) (+ i j))
  :pattern ((Seq_add i j))
  :qid |$Seq[Trie]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_sub i j) (- i j))
  :pattern ((Seq_sub i j))
  :qid |$Seq[Trie]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<Trie>) (s1 Seq<Trie>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Trie>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Trie>)))
        (and (<= 0 n) (< n (Seq_length s0)))))
    (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n)))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :pattern ((Seq_index s0 n) (Seq_append s0 s1))
  :qid |$Seq[Trie]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<Trie>) (s1 Seq<Trie>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Trie>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Trie>)))
        (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1))))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n)
      (=
        (Seq_index (Seq_append s0 s1) n)
        (Seq_index s1 (Seq_sub n (Seq_length s0))))))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :qid |$Seq[Trie]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<Trie>) (s1 Seq<Trie>) (m Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Trie>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Trie>)))
        (and (<= 0 m) (< m (Seq_length s1)))))
    (and
      (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m)
      (=
        (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0)))
        (Seq_index s1 m))))
  :pattern ((Seq_index s1 m) (Seq_append s0 s1))
  :qid |$Seq[Trie]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<Trie>) (i Int) (v Trie)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (Seq_length (Seq_update s i v)) (Seq_length s)))
  :pattern ((Seq_length (Seq_update s i v)))
  :pattern ((Seq_length s) (Seq_update s i v))
  :qid |$Seq[Trie]_prog.Seq_update_length|)))
(assert (forall ((s Seq<Trie>) (i Int) (v Trie) (n Int)) (!
  (=>
    (and (<= 0 n) (< n (Seq_length s)))
    (and
      (=> (= i n) (= (Seq_index (Seq_update s i v) n) v))
      (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n)))))
  :pattern ((Seq_index (Seq_update s i v) n))
  :pattern ((Seq_index s n) (Seq_update s i v))
  :qid |$Seq[Trie]_prog.Seq_update_index|)))
(assert (forall ((s Seq<Trie>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s)))))
    (=> (< n 0) (= (Seq_length (Seq_take s n)) 0)))
  :pattern ((Seq_length (Seq_take s n)))
  :pattern ((Seq_take s n) (Seq_length s))
  :qid |$Seq[Trie]_prog.Seq_take_length|)))
(assert (forall ((s Seq<Trie>) (n Int) (j Int)) (!
  (=>
    (and (<= 0 j) (and (< j n) (< j (Seq_length s))))
    (= (Seq_index (Seq_take s n) j) (Seq_index s j)))
  :pattern ((Seq_index (Seq_take s n) j))
  :pattern ((Seq_index s j) (Seq_take s n))
  :qid |$Seq[Trie]_prog.Seq_take_index|)))
(assert (forall ((s Seq<Trie>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=>
          (<= n (Seq_length s))
          (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n)))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0))))
    (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s))))
  :pattern ((Seq_length (Seq_drop s n)))
  :pattern ((Seq_length s) (Seq_drop s n))
  :qid |$Seq[Trie]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<Trie>) (n Int) (j Int)) (!
  (=>
    (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n))))
    (and
      (= (Seq_sub (Seq_add j n) n) j)
      (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n)))))
  :pattern ((Seq_index (Seq_drop s n) j))
  :qid |$Seq[Trie]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<Trie>) (n Int) (i Int)) (!
  (=>
    (and (< 0 n) (and (<= n i) (< i (Seq_length s))))
    (and
      (= (Seq_add (Seq_sub i n) n) i)
      (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i))))
  :pattern ((Seq_drop s n) (Seq_index s i))
  :qid |$Seq[Trie]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<Trie>) (t Seq<Trie>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_take (Seq_append s t) n) (Seq_take s n)))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Trie]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<Trie>) (t Seq<Trie>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (=
        (Seq_take (Seq_append s t) n)
        (Seq_append s (Seq_take t (Seq_sub n (Seq_length s)))))))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Trie]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<Trie>) (t Seq<Trie>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t)))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Trie]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<Trie>) (t Seq<Trie>) (n Int)) (!
  (=>
    (and (> n 0) (> n (Seq_length s)))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s))))))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Trie]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<Trie>) (n Int)) (!
  (=> (<= n 0) (= (Seq_take s n) (as Seq_empty  Seq<Trie>)))
  :pattern ((Seq_take s n))
  :qid |$Seq[Trie]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<Trie>) (n Int)) (!
  (=> (<= n 0) (= (Seq_drop s n) s))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Trie]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<Trie>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_take s n) s))
  :pattern ((Seq_take s n))
  :qid |$Seq[Trie]_prog.Seq_take_all|)))
(assert (forall ((s Seq<Trie>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty  Seq<Trie>)))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Trie]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<Trie>) (x Trie)) (!
  (=>
    (Seq_contains s x)
    (and
      (<= 0 (Seq_skolem s x))
      (and
        (< (Seq_skolem s x) (Seq_length s))
        (= (Seq_index s (Seq_skolem s x)) x))))
  :pattern ((Seq_contains s x))
  :qid |$Seq[Trie]_prog.Seq_contains1|)))
(assert (forall ((s Seq<Trie>) (x Trie) (i Int)) (!
  (=>
    (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x)))
    (Seq_contains s x))
  :pattern ((Seq_contains s x) (Seq_index s i))
  :qid |$Seq[Trie]_prog.Seq_contains2|)))
(assert (forall ((s Seq<Trie>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (Seq_contains_trigger s (Seq_index s i)))
  :pattern ((Seq_index s i))
  :qid |$Seq[Trie]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<Trie>) (s1 Seq<Trie>)) (!
  (or
    (and (= s0 s1) (Seq_equal s0 s1))
    (or
      (and
        (not (= s0 s1))
        (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1)))))
      (and
        (not (= s0 s1))
        (and
          (not (Seq_equal s0 s1))
          (and
            (= (Seq_length s0) (Seq_length s1))
            (and
              (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0))
              (and
                (<= 0 (Seq_skolem_diff s0 s1))
                (and
                  (< (Seq_skolem_diff s0 s1) (Seq_length s0))
                  (not
                    (=
                      (Seq_index s0 (Seq_skolem_diff s0 s1))
                      (Seq_index s1 (Seq_skolem_diff s0 s1))))))))))))
  :pattern ((Seq_equal s0 s1))
  :qid |$Seq[Trie]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<Trie>) (b Seq<Trie>)) (!
  (=> (Seq_equal a b) (= a b))
  :pattern ((Seq_equal a b))
  :qid |$Seq[Trie]_prog.Seq_equal_ext|)))
(assert (forall ((x Trie) (y Trie)) (!
  (= (Seq_contains (Seq_singleton x) y) (= x y))
  :pattern ((Seq_contains (Seq_singleton x) y))
  :qid |$Seq[Trie]_prog.Seq_singleton_contains|)))
(assert (forall ((s Seq<Int>)) (!
  (<= 0 (Seq_length s))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty  Seq<Int>)) 0))
(assert (forall ((s Seq<Int>)) (!
  (=> (= (Seq_length s) 0) (= s (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_zero|)))
(assert (forall ((e Int)) (!
  (= (Seq_length (Seq_singleton e)) 1)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (not (= s1 (as Seq_empty  Seq<Int>))))
    (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1))))
  :pattern ((Seq_length (Seq_append s0 s1)))
  :qid |$Seq[Int]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (and
    (=> (= s0 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s1))
    (=> (= s1 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s0)))
  :pattern ((Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_empty|)))
(assert (forall ((e Int)) (!
  (= (Seq_index (Seq_singleton e) 0) e)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_add i j) (+ i j))
  :pattern ((Seq_add i j))
  :qid |$Seq[Int]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_sub i j) (- i j))
  :pattern ((Seq_sub i j))
  :qid |$Seq[Int]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= 0 n) (< n (Seq_length s0)))))
    (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n)))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :pattern ((Seq_index s0 n) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1))))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n)
      (=
        (Seq_index (Seq_append s0 s1) n)
        (Seq_index s1 (Seq_sub n (Seq_length s0))))))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :qid |$Seq[Int]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (m Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= 0 m) (< m (Seq_length s1)))))
    (and
      (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m)
      (=
        (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0)))
        (Seq_index s1 m))))
  :pattern ((Seq_index s1 m) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (Seq_length (Seq_update s i v)) (Seq_length s)))
  :pattern ((Seq_length (Seq_update s i v)))
  :pattern ((Seq_length s) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_length|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int) (n Int)) (!
  (=>
    (and (<= 0 n) (< n (Seq_length s)))
    (and
      (=> (= i n) (= (Seq_index (Seq_update s i v) n) v))
      (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n)))))
  :pattern ((Seq_index (Seq_update s i v) n))
  :pattern ((Seq_index s n) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s)))))
    (=> (< n 0) (= (Seq_length (Seq_take s n)) 0)))
  :pattern ((Seq_length (Seq_take s n)))
  :pattern ((Seq_take s n) (Seq_length s))
  :qid |$Seq[Int]_prog.Seq_take_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (<= 0 j) (and (< j n) (< j (Seq_length s))))
    (= (Seq_index (Seq_take s n) j) (Seq_index s j)))
  :pattern ((Seq_index (Seq_take s n) j))
  :pattern ((Seq_index s j) (Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=>
          (<= n (Seq_length s))
          (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n)))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0))))
    (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s))))
  :pattern ((Seq_length (Seq_drop s n)))
  :pattern ((Seq_length s) (Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n))))
    (and
      (= (Seq_sub (Seq_add j n) n) j)
      (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n)))))
  :pattern ((Seq_index (Seq_drop s n) j))
  :qid |$Seq[Int]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<Int>) (n Int) (i Int)) (!
  (=>
    (and (< 0 n) (and (<= n i) (< i (Seq_length s))))
    (and
      (= (Seq_add (Seq_sub i n) n) i)
      (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i))))
  :pattern ((Seq_drop s n) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_take (Seq_append s t) n) (Seq_take s n)))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (=
        (Seq_take (Seq_append s t) n)
        (Seq_append s (Seq_take t (Seq_sub n (Seq_length s)))))))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t)))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (> n (Seq_length s)))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s))))))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_take s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_drop s n) s))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_take s n) s))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_all|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<Int>) (x Int)) (!
  (=>
    (Seq_contains s x)
    (and
      (<= 0 (Seq_skolem s x))
      (and
        (< (Seq_skolem s x) (Seq_length s))
        (= (Seq_index s (Seq_skolem s x)) x))))
  :pattern ((Seq_contains s x))
  :qid |$Seq[Int]_prog.Seq_contains1|)))
(assert (forall ((s Seq<Int>) (x Int) (i Int)) (!
  (=>
    (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x)))
    (Seq_contains s x))
  :pattern ((Seq_contains s x) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains2|)))
(assert (forall ((s Seq<Int>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (Seq_contains_trigger s (Seq_index s i)))
  :pattern ((Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (or
    (and (= s0 s1) (Seq_equal s0 s1))
    (or
      (and
        (not (= s0 s1))
        (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1)))))
      (and
        (not (= s0 s1))
        (and
          (not (Seq_equal s0 s1))
          (and
            (= (Seq_length s0) (Seq_length s1))
            (and
              (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0))
              (and
                (<= 0 (Seq_skolem_diff s0 s1))
                (and
                  (< (Seq_skolem_diff s0 s1) (Seq_length s0))
                  (not
                    (=
                      (Seq_index s0 (Seq_skolem_diff s0 s1))
                      (Seq_index s1 (Seq_skolem_diff s0 s1))))))))))))
  :pattern ((Seq_equal s0 s1))
  :qid |$Seq[Int]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<Int>) (b Seq<Int>)) (!
  (=> (Seq_equal a b) (= a b))
  :pattern ((Seq_equal a b))
  :qid |$Seq[Int]_prog.Seq_equal_ext|)))
(assert (forall ((x Int) (y Int)) (!
  (= (Seq_contains (Seq_singleton x) y) (= x y))
  :pattern ((Seq_contains (Seq_singleton x) y))
  :qid |$Seq[Int]_prog.Seq_singleton_contains|)))
(assert (forall ((min_ Int) (max Int)) (!
  (and
    (=> (< min_ max) (= (Seq_length (Seq_range min_ max)) (- max min_)))
    (=> (<= max min_) (= (Seq_length (Seq_range min_ max)) 0)))
  :pattern ((Seq_length (Seq_range min_ max)))
  :qid |$Seq[Int]_prog.Seq_range_length|)))
(assert (forall ((min_ Int) (max Int) (j Int)) (!
  (=>
    (and (<= 0 j) (< j (- max min_)))
    (= (Seq_index (Seq_range min_ max) j) (+ min_ j)))
  :pattern ((Seq_index (Seq_range min_ max) j))
  :qid |$Seq[Int]_prog.Seq_range_index|)))
(assert (forall ((min_ Int) (max Int) (v Int)) (!
  (= (Seq_contains (Seq_range min_ max) v) (and (<= min_ v) (< v max)))
  :pattern ((Seq_contains (Seq_range min_ max) v))
  :qid |$Seq[Int]_prog.Seq_range_contains|)))
(assert (forall ((before Seq<Int>) (focus Option<Int>) (after Seq<Int>)) (!
  (Seq_equal
    before
    (get_ListZipper_before<Seq<Int>> (Zipper<ListZipper<Int>> before focus after)))
  :pattern ((Zipper<ListZipper<Int>> before focus after))
  )))
(assert (forall ((before Seq<Int>) (focus Option<Int>) (after Seq<Int>)) (!
  (=
    focus
    (get_ListZipper_focus<Option<Int>> (Zipper<ListZipper<Int>> before focus after)))
  :pattern ((Zipper<ListZipper<Int>> before focus after))
  )))
(assert (forall ((before Seq<Int>) (focus Option<Int>) (after Seq<Int>)) (!
  (Seq_equal
    after
    (get_ListZipper_after<Seq<Int>> (Zipper<ListZipper<Int>> before focus after)))
  :pattern ((Zipper<ListZipper<Int>> before focus after))
  )))
(assert (forall ((before Seq<Int>) (focus Option<Int>) (after Seq<Int>)) (!
  (= (ListZipper_tag<Int> (Zipper<ListZipper<Int>> before focus after)) 0)
  :pattern ((Zipper<ListZipper<Int>> before focus after))
  )))
(assert (forall ((t ListZipper<Int>)) (!
  (=
    t
    (Zipper<ListZipper<Int>> (get_ListZipper_before<Seq<Int>> t) (get_ListZipper_focus<Option<Int>> t) (get_ListZipper_after<Seq<Int>> t)))
  :pattern ((ListZipper_tag<Int> t))
  :pattern ((get_ListZipper_before<Seq<Int>> t))
  :pattern ((get_ListZipper_focus<Option<Int>> t))
  :pattern ((get_ListZipper_after<Seq<Int>> t))
  )))
(assert (forall ((value Int) (children Seq<RoseTree>)) (!
  (= value (get_RoseTree_value<Int> (RoseNode<RoseTree> value children)))
  :pattern ((RoseNode<RoseTree> value children))
  )))
(assert (forall ((value Int) (children Seq<RoseTree>)) (!
  (Seq_equal
    children
    (get_RoseTree_children<Seq<RoseTree>> (RoseNode<RoseTree> value children)))
  :pattern ((RoseNode<RoseTree> value children))
  )))
(assert (= (RoseTree_tag<Int> (as Empty<RoseTree>  RoseTree)) 0))
(assert (forall ((value Int) (children Seq<RoseTree>)) (!
  (= (RoseTree_tag<Int> (RoseNode<RoseTree> value children)) 1)
  :pattern ((RoseNode<RoseTree> value children))
  )))
(assert (forall ((t RoseTree)) (!
  (or
    (= t (as Empty<RoseTree>  RoseTree))
    (=
      t
      (RoseNode<RoseTree> (get_RoseTree_value<Int> t) (get_RoseTree_children<Seq<RoseTree>> t))))
  :pattern ((RoseTree_tag<Int> t))
  :pattern ((get_RoseTree_value<Int> t))
  :pattern ((get_RoseTree_children<Seq<RoseTree>> t))
  )))
(assert (forall ((left BST) (value Int) (right BST)) (!
  (= left (get_BST_left<BST> (BSTNode<BST> left value right)))
  :pattern ((BSTNode<BST> left value right))
  )))
(assert (forall ((left BST) (value Int) (right BST)) (!
  (= value (get_BST_value<Int> (BSTNode<BST> left value right)))
  :pattern ((BSTNode<BST> left value right))
  )))
(assert (forall ((left BST) (value Int) (right BST)) (!
  (= right (get_BST_right<BST> (BSTNode<BST> left value right)))
  :pattern ((BSTNode<BST> left value right))
  )))
(assert (= (BST_tag<Int> (as BSTLeaf<BST>  BST)) 0))
(assert (forall ((left BST) (value Int) (right BST)) (!
  (= (BST_tag<Int> (BSTNode<BST> left value right)) 1)
  :pattern ((BSTNode<BST> left value right))
  )))
(assert (forall ((t BST)) (!
  (or
    (= t (as BSTLeaf<BST>  BST))
    (=
      t
      (BSTNode<BST> (get_BST_left<BST> t) (get_BST_value<Int> t) (get_BST_right<BST> t))))
  :pattern ((BST_tag<Int> t))
  :pattern ((get_BST_left<BST> t))
  :pattern ((get_BST_value<Int> t))
  :pattern ((get_BST_right<BST> t))
  )))
(assert (forall ((value Int)) (!
  (= value (get_Option_value<Int> (Some<Option<Int>> value)))
  :pattern ((Some<Option<Int>> value))
  )))
(assert (= (Option_tag<Int> (as None<Option<Int>>  Option<Int>)) 0))
(assert (forall ((value Int)) (!
  (= (Option_tag<Int> (Some<Option<Int>> value)) 1)
  :pattern ((Some<Option<Int>> value))
  )))
(assert (forall ((t Option<Int>)) (!
  (or
    (= t (as None<Option<Int>>  Option<Int>))
    (= t (Some<Option<Int>> (get_Option_value<Int> t))))
  :pattern ((Option_tag<Int> t))
  :pattern ((get_Option_value<Int> t))
  )))
(assert (forall ((isEnd Bool) (children Seq<Trie>)) (!
  (= isEnd (get_Trie_isEnd<Bool> (TrieNode<Trie> isEnd children)))
  :pattern ((TrieNode<Trie> isEnd children))
  )))
(assert (forall ((isEnd Bool) (children Seq<Trie>)) (!
  (Seq_equal
    children
    (get_Trie_children<Seq<Trie>> (TrieNode<Trie> isEnd children)))
  :pattern ((TrieNode<Trie> isEnd children))
  )))
(assert (= (Trie_tag<Int> (as EmptyTrie<Trie>  Trie)) 0))
(assert (forall ((isEnd Bool) (children Seq<Trie>)) (!
  (= (Trie_tag<Int> (TrieNode<Trie> isEnd children)) 1)
  :pattern ((TrieNode<Trie> isEnd children))
  )))
(assert (forall ((t Trie)) (!
  (or
    (= t (as EmptyTrie<Trie>  Trie))
    (=
      t
      (TrieNode<Trie> (get_Trie_isEnd<Bool> t) (get_Trie_children<Seq<Trie>> t))))
  :pattern ((Trie_tag<Int> t))
  :pattern ((get_Trie_isEnd<Bool> t))
  :pattern ((get_Trie_children<Seq<Trie>> t))
  )))
; End preamble
; ------------------------------------------------------------
; State saturation: after preamble
(set-option :rlimit 160000)
(check-sat)
; unknown
; ------------------------------------------------------------
; Begin function- and predicate-related preamble
; Declaring symbols related to program functions (from verification)
; Declaring symbols related to program functions (from verification)
(declare-fun letvar@65@00 ($Snap Seq<Int> Int) Int)
(declare-fun letvar@66@00 ($Snap Seq<Int> Int) Int)
(declare-fun letvar@68@00 ($Snap Seq<Int> Int) Int)
(declare-fun letvar@69@00 ($Snap Seq<Int> Int) Int)
(declare-fun letvar@71@00 ($Snap Seq<RoseTree> Int Int) Int)
(assert (forall ((s@$ $Snap) (parent@0@00 Seq<Int>) (x@1@00 Int) (depth@2@00 Int)) (!
  (=
    (find_root%limited s@$ parent@0@00 x@1@00 depth@2@00)
    (find_root s@$ parent@0@00 x@1@00 depth@2@00))
  :pattern ((find_root s@$ parent@0@00 x@1@00 depth@2@00))
  :qid |quant-u-0|)))
(assert (forall ((s@$ $Snap) (parent@0@00 Seq<Int>) (x@1@00 Int) (depth@2@00 Int)) (!
  (find_root%stateless parent@0@00 x@1@00 depth@2@00)
  :pattern ((find_root%limited s@$ parent@0@00 x@1@00 depth@2@00))
  :qid |quant-u-1|)))
(assert (forall ((s@$ $Snap) (parent@0@00 Seq<Int>) (x@1@00 Int) (depth@2@00 Int)) (!
  (let ((result@3@00 (find_root%limited s@$ parent@0@00 x@1@00 depth@2@00))) (=>
    (find_root%precondition s@$ parent@0@00 x@1@00 depth@2@00)
    (>= result@3@00 0)))
  :pattern ((find_root%limited s@$ parent@0@00 x@1@00 depth@2@00))
  :qid |quant-u-40|)))
(assert (forall ((s@$ $Snap) (parent@0@00 Seq<Int>) (x@1@00 Int) (depth@2@00 Int)) (!
  (let ((result@3@00 (find_root%limited s@$ parent@0@00 x@1@00 depth@2@00))) true)
  :pattern ((find_root%limited s@$ parent@0@00 x@1@00 depth@2@00))
  :qid |quant-u-41|)))
(assert (forall ((s@$ $Snap) (t@4@00 Trie)) (!
  (= (trie_is_empty%limited s@$ t@4@00) (trie_is_empty s@$ t@4@00))
  :pattern ((trie_is_empty s@$ t@4@00))
  :qid |quant-u-2|)))
(assert (forall ((s@$ $Snap) (t@4@00 Trie)) (!
  (trie_is_empty%stateless t@4@00)
  :pattern ((trie_is_empty%limited s@$ t@4@00))
  :qid |quant-u-3|)))
(assert (forall ((s@$ $Snap) (t@4@00 Trie)) (!
  (=>
    (trie_is_empty%precondition s@$ t@4@00)
    (=
      (trie_is_empty s@$ t@4@00)
      (and
        (not (get_Trie_isEnd<Bool> t@4@00))
        (= (Seq_length (get_Trie_children<Seq<Trie>> t@4@00)) 0))))
  :pattern ((trie_is_empty s@$ t@4@00))
  :qid |quant-u-42|)))
(assert (forall ((s@$ $Snap) (t@4@00 Trie)) (!
  true
  :pattern ((trie_is_empty s@$ t@4@00))
  :qid |quant-u-43|)))
(assert (forall ((s@$ $Snap) (t@6@00 BST)) (!
  (= (bst_max%limited s@$ t@6@00) (bst_max s@$ t@6@00))
  :pattern ((bst_max s@$ t@6@00))
  :qid |quant-u-4|)))
(assert (forall ((s@$ $Snap) (t@6@00 BST)) (!
  (bst_max%stateless t@6@00)
  :pattern ((bst_max%limited s@$ t@6@00))
  :qid |quant-u-5|)))
(assert (forall ((s@$ $Snap) (t@6@00 BST)) (!
  (=>
    (bst_max%precondition s@$ t@6@00)
    (=
      (bst_max s@$ t@6@00)
      (ite
        (= (BST_tag<Int> t@6@00) 0)
        (as None<Option<Int>>  Option<Int>)
        (ite
          (= (BST_tag<Int> (get_BST_right<BST> t@6@00)) 0)
          (Some<Option<Int>> (get_BST_value<Int> t@6@00))
          (bst_max%limited $Snap.unit (get_BST_right<BST> t@6@00))))))
  :pattern ((bst_max s@$ t@6@00))
  :qid |quant-u-44|)))
(assert (forall ((s@$ $Snap) (t@6@00 BST)) (!
  (=>
    (bst_max%precondition s@$ t@6@00)
    (ite
      (= (BST_tag<Int> t@6@00) 0)
      true
      (ite
        (= (BST_tag<Int> (get_BST_right<BST> t@6@00)) 0)
        true
        (bst_max%precondition $Snap.unit (get_BST_right<BST> t@6@00)))))
  :pattern ((bst_max s@$ t@6@00))
  :qid |quant-u-45|)))
(assert (forall ((s@$ $Snap) (z@8@00 ListZipper<Int>)) (!
  (= (zipper_backward%limited s@$ z@8@00) (zipper_backward s@$ z@8@00))
  :pattern ((zipper_backward s@$ z@8@00))
  :qid |quant-u-6|)))
(assert (forall ((s@$ $Snap) (z@8@00 ListZipper<Int>)) (!
  (zipper_backward%stateless z@8@00)
  :pattern ((zipper_backward%limited s@$ z@8@00))
  :qid |quant-u-7|)))
(assert (forall ((s@$ $Snap) (z@8@00 ListZipper<Int>)) (!
  (=>
    (zipper_backward%precondition s@$ z@8@00)
    (=
      (zipper_backward s@$ z@8@00)
      (ite
        (= (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 0)
        z@8@00
        (Zipper<ListZipper<Int>> (Seq_take
          (get_ListZipper_before<Seq<Int>> z@8@00)
          (- (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 1)) (Some<Option<Int>> (Seq_index
          (get_ListZipper_before<Seq<Int>> z@8@00)
          (- (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 1))) (ite
          (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@8@00)) 0)
          (get_ListZipper_after<Seq<Int>> z@8@00)
          (Seq_append
            (Seq_singleton (get_Option_value<Int> (get_ListZipper_focus<Option<Int>> z@8@00)))
            (get_ListZipper_after<Seq<Int>> z@8@00)))))))
  :pattern ((zipper_backward s@$ z@8@00))
  :qid |quant-u-46|)))
(assert (forall ((s@$ $Snap) (z@8@00 ListZipper<Int>)) (!
  true
  :pattern ((zipper_backward s@$ z@8@00))
  :qid |quant-u-47|)))
(assert (forall ((s@$ $Snap) (t@10@00 RoseTree)) (!
  (= (rose_size%limited s@$ t@10@00) (rose_size s@$ t@10@00))
  :pattern ((rose_size s@$ t@10@00))
  :qid |quant-u-8|)))
(assert (forall ((s@$ $Snap) (t@10@00 RoseTree)) (!
  (rose_size%stateless t@10@00)
  :pattern ((rose_size%limited s@$ t@10@00))
  :qid |quant-u-9|)))
(assert (forall ((s@$ $Snap) (t@10@00 RoseTree)) (!
  (=>
    (rose_size%precondition s@$ t@10@00)
    (=
      (rose_size s@$ t@10@00)
      (+
        1
        (rose_children_size%limited $Snap.unit (get_RoseTree_children<Seq<RoseTree>> t@10@00) 0))))
  :pattern ((rose_size s@$ t@10@00))
  :qid |quant-u-48|)))
(assert (forall ((s@$ $Snap) (t@10@00 RoseTree)) (!
  (=>
    (rose_size%precondition s@$ t@10@00)
    (rose_children_size%precondition $Snap.unit (get_RoseTree_children<Seq<RoseTree>> t@10@00) 0))
  :pattern ((rose_size s@$ t@10@00))
  :qid |quant-u-49|)))
(assert (forall ((s@$ $Snap) (children@12@00 Seq<RoseTree>) (idx@13@00 Int)) (!
  (=
    (rose_children_size%limited s@$ children@12@00 idx@13@00)
    (rose_children_size s@$ children@12@00 idx@13@00))
  :pattern ((rose_children_size s@$ children@12@00 idx@13@00))
  :qid |quant-u-10|)))
(assert (forall ((s@$ $Snap) (children@12@00 Seq<RoseTree>) (idx@13@00 Int)) (!
  (rose_children_size%stateless children@12@00 idx@13@00)
  :pattern ((rose_children_size%limited s@$ children@12@00 idx@13@00))
  :qid |quant-u-11|)))
(assert (forall ((s@$ $Snap) (children@12@00 Seq<RoseTree>) (idx@13@00 Int)) (!
  (let ((result@14@00 (rose_children_size%limited s@$ children@12@00 idx@13@00))) (=>
    (rose_children_size%precondition s@$ children@12@00 idx@13@00)
    (>= result@14@00 0)))
  :pattern ((rose_children_size%limited s@$ children@12@00 idx@13@00))
  :qid |quant-u-50|)))
(assert (forall ((s@$ $Snap) (children@12@00 Seq<RoseTree>) (idx@13@00 Int)) (!
  (let ((result@14@00 (rose_children_size%limited s@$ children@12@00 idx@13@00))) true)
  :pattern ((rose_children_size%limited s@$ children@12@00 idx@13@00))
  :qid |quant-u-51|)))
(assert (forall ((s@$ $Snap) (children@12@00 Seq<RoseTree>) (idx@13@00 Int)) (!
  (=>
    (rose_children_size%precondition s@$ children@12@00 idx@13@00)
    (=
      (rose_children_size s@$ children@12@00 idx@13@00)
      (ite
        (>= idx@13@00 (Seq_length children@12@00))
        0
        (+
          (rose_size%limited $Snap.unit (Seq_index children@12@00 idx@13@00))
          (rose_children_size%limited $Snap.unit children@12@00 (+ idx@13@00 1))))))
  :pattern ((rose_children_size s@$ children@12@00 idx@13@00))
  :qid |quant-u-52|)))
(assert (forall ((s@$ $Snap) (children@12@00 Seq<RoseTree>) (idx@13@00 Int)) (!
  (=>
    (rose_children_size%precondition s@$ children@12@00 idx@13@00)
    (ite
      (>= idx@13@00 (Seq_length children@12@00))
      true
      (and
        (rose_size%precondition $Snap.unit (Seq_index children@12@00 idx@13@00))
        (rose_children_size%precondition $Snap.unit children@12@00 (+
          idx@13@00
          1)))))
  :pattern ((rose_children_size s@$ children@12@00 idx@13@00))
  :qid |quant-u-53|)))
(assert (forall ((s@$ $Snap) (t@15@00 Trie)) (!
  (= (trie_count_words%limited s@$ t@15@00) (trie_count_words s@$ t@15@00))
  :pattern ((trie_count_words s@$ t@15@00))
  :qid |quant-u-12|)))
(assert (forall ((s@$ $Snap) (t@15@00 Trie)) (!
  (trie_count_words%stateless t@15@00)
  :pattern ((trie_count_words%limited s@$ t@15@00))
  :qid |quant-u-13|)))
(assert (forall ((s@$ $Snap) (t@15@00 Trie)) (!
  (let ((result@16@00 (trie_count_words%limited s@$ t@15@00))) (=>
    (trie_count_words%precondition s@$ t@15@00)
    (>= result@16@00 0)))
  :pattern ((trie_count_words%limited s@$ t@15@00))
  :qid |quant-u-54|)))
(assert (forall ((s@$ $Snap) (t@15@00 Trie)) (!
  (let ((result@16@00 (trie_count_words%limited s@$ t@15@00))) true)
  :pattern ((trie_count_words%limited s@$ t@15@00))
  :qid |quant-u-55|)))
(assert (forall ((s@$ $Snap) (children@17@00 Seq<Trie>) (idx@18@00 Int)) (!
  (=
    (trie_count_children_words%limited s@$ children@17@00 idx@18@00)
    (trie_count_children_words s@$ children@17@00 idx@18@00))
  :pattern ((trie_count_children_words s@$ children@17@00 idx@18@00))
  :qid |quant-u-14|)))
(assert (forall ((s@$ $Snap) (children@17@00 Seq<Trie>) (idx@18@00 Int)) (!
  (trie_count_children_words%stateless children@17@00 idx@18@00)
  :pattern ((trie_count_children_words%limited s@$ children@17@00 idx@18@00))
  :qid |quant-u-15|)))
(assert (forall ((s@$ $Snap) (children@17@00 Seq<Trie>) (idx@18@00 Int)) (!
  (let ((result@19@00 (trie_count_children_words%limited s@$ children@17@00 idx@18@00))) (=>
    (trie_count_children_words%precondition s@$ children@17@00 idx@18@00)
    (>= result@19@00 0)))
  :pattern ((trie_count_children_words%limited s@$ children@17@00 idx@18@00))
  :qid |quant-u-56|)))
(assert (forall ((s@$ $Snap) (children@17@00 Seq<Trie>) (idx@18@00 Int)) (!
  (let ((result@19@00 (trie_count_children_words%limited s@$ children@17@00 idx@18@00))) true)
  :pattern ((trie_count_children_words%limited s@$ children@17@00 idx@18@00))
  :qid |quant-u-57|)))
(assert (forall ((s@$ $Snap) (children@17@00 Seq<Trie>) (idx@18@00 Int)) (!
  (=>
    (trie_count_children_words%precondition s@$ children@17@00 idx@18@00)
    (=
      (trie_count_children_words s@$ children@17@00 idx@18@00)
      (ite
        (>= idx@18@00 (Seq_length children@17@00))
        0
        (+
          (trie_count_words%limited $Snap.unit (Seq_index
            children@17@00
            idx@18@00))
          (trie_count_children_words%limited $Snap.unit children@17@00 (+
            idx@18@00
            1))))))
  :pattern ((trie_count_children_words s@$ children@17@00 idx@18@00))
  :qid |quant-u-58|)))
(assert (forall ((s@$ $Snap) (children@17@00 Seq<Trie>) (idx@18@00 Int)) (!
  (=>
    (trie_count_children_words%precondition s@$ children@17@00 idx@18@00)
    (ite
      (>= idx@18@00 (Seq_length children@17@00))
      true
      (and
        (trie_count_words%precondition $Snap.unit (Seq_index
          children@17@00
          idx@18@00))
        (trie_count_children_words%precondition $Snap.unit children@17@00 (+
          idx@18@00
          1)))))
  :pattern ((trie_count_children_words s@$ children@17@00 idx@18@00))
  :qid |quant-u-59|)))
(assert (forall ((s@$ $Snap) (t@20@00 BST) (x@21@00 Int)) (!
  (= (bst_insert%limited s@$ t@20@00 x@21@00) (bst_insert s@$ t@20@00 x@21@00))
  :pattern ((bst_insert s@$ t@20@00 x@21@00))
  :qid |quant-u-16|)))
(assert (forall ((s@$ $Snap) (t@20@00 BST) (x@21@00 Int)) (!
  (bst_insert%stateless t@20@00 x@21@00)
  :pattern ((bst_insert%limited s@$ t@20@00 x@21@00))
  :qid |quant-u-17|)))
(assert (forall ((s@$ $Snap) (t@20@00 BST) (x@21@00 Int)) (!
  (=>
    (bst_insert%precondition s@$ t@20@00 x@21@00)
    (=
      (bst_insert s@$ t@20@00 x@21@00)
      (ite
        (= (BST_tag<Int> t@20@00) 0)
        (BSTNode<BST> (as BSTLeaf<BST>  BST) x@21@00 (as BSTLeaf<BST>  BST))
        (ite
          (< x@21@00 (get_BST_value<Int> t@20@00))
          (BSTNode<BST> (bst_insert%limited $Snap.unit (get_BST_left<BST> t@20@00) x@21@00) (get_BST_value<Int> t@20@00) (get_BST_right<BST> t@20@00))
          (ite
            (> x@21@00 (get_BST_value<Int> t@20@00))
            (BSTNode<BST> (get_BST_left<BST> t@20@00) (get_BST_value<Int> t@20@00) (bst_insert%limited $Snap.unit (get_BST_right<BST> t@20@00) x@21@00))
            t@20@00)))))
  :pattern ((bst_insert s@$ t@20@00 x@21@00))
  :qid |quant-u-60|)))
(assert (forall ((s@$ $Snap) (t@20@00 BST) (x@21@00 Int)) (!
  (=>
    (bst_insert%precondition s@$ t@20@00 x@21@00)
    (ite
      (= (BST_tag<Int> t@20@00) 0)
      true
      (ite
        (< x@21@00 (get_BST_value<Int> t@20@00))
        (bst_insert%precondition $Snap.unit (get_BST_left<BST> t@20@00) x@21@00)
        (ite
          (> x@21@00 (get_BST_value<Int> t@20@00))
          (bst_insert%precondition $Snap.unit (get_BST_right<BST> t@20@00) x@21@00)
          true))))
  :pattern ((bst_insert s@$ t@20@00 x@21@00))
  :qid |quant-u-61|)))
(assert (forall ((s@$ $Snap) (t@23@00 BST) (min@24@00 Int) (max@25@00 Int)) (!
  (=
    (is_valid_bst%limited s@$ t@23@00 min@24@00 max@25@00)
    (is_valid_bst s@$ t@23@00 min@24@00 max@25@00))
  :pattern ((is_valid_bst s@$ t@23@00 min@24@00 max@25@00))
  :qid |quant-u-18|)))
(assert (forall ((s@$ $Snap) (t@23@00 BST) (min@24@00 Int) (max@25@00 Int)) (!
  (is_valid_bst%stateless t@23@00 min@24@00 max@25@00)
  :pattern ((is_valid_bst%limited s@$ t@23@00 min@24@00 max@25@00))
  :qid |quant-u-19|)))
(assert (forall ((s@$ $Snap) (t@23@00 BST) (min@24@00 Int) (max@25@00 Int)) (!
  (=>
    (is_valid_bst%precondition s@$ t@23@00 min@24@00 max@25@00)
    (=
      (is_valid_bst s@$ t@23@00 min@24@00 max@25@00)
      (ite
        (= (BST_tag<Int> t@23@00) 0)
        true
        (ite
          (or
            (<= (get_BST_value<Int> t@23@00) min@24@00)
            (>= (get_BST_value<Int> t@23@00) max@25@00))
          false
          (and
            (is_valid_bst%limited $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
            (is_valid_bst%limited $Snap.unit (get_BST_right<BST> t@23@00) (get_BST_value<Int> t@23@00) max@25@00))))))
  :pattern ((is_valid_bst s@$ t@23@00 min@24@00 max@25@00))
  :qid |quant-u-62|)))
(assert (forall ((s@$ $Snap) (t@23@00 BST) (min@24@00 Int) (max@25@00 Int)) (!
  (=>
    (is_valid_bst%precondition s@$ t@23@00 min@24@00 max@25@00)
    (ite
      (= (BST_tag<Int> t@23@00) 0)
      true
      (ite
        (or
          (<= (get_BST_value<Int> t@23@00) min@24@00)
          (>= (get_BST_value<Int> t@23@00) max@25@00))
        true
        (and
          (is_valid_bst%precondition $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
          (=>
            (is_valid_bst%limited $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
            (is_valid_bst%precondition $Snap.unit (get_BST_right<BST> t@23@00) (get_BST_value<Int> t@23@00) max@25@00))))))
  :pattern ((is_valid_bst s@$ t@23@00 min@24@00 max@25@00))
  :qid |quant-u-63|)))
(assert (forall ((s@$ $Snap) (t@27@00 BST) (x@28@00 Int)) (!
  (= (bst_search%limited s@$ t@27@00 x@28@00) (bst_search s@$ t@27@00 x@28@00))
  :pattern ((bst_search s@$ t@27@00 x@28@00))
  :qid |quant-u-20|)))
(assert (forall ((s@$ $Snap) (t@27@00 BST) (x@28@00 Int)) (!
  (bst_search%stateless t@27@00 x@28@00)
  :pattern ((bst_search%limited s@$ t@27@00 x@28@00))
  :qid |quant-u-21|)))
(assert (forall ((s@$ $Snap) (t@27@00 BST) (x@28@00 Int)) (!
  (=>
    (bst_search%precondition s@$ t@27@00 x@28@00)
    (=
      (bst_search s@$ t@27@00 x@28@00)
      (ite
        (= (BST_tag<Int> t@27@00) 0)
        false
        (ite
          (= (get_BST_value<Int> t@27@00) x@28@00)
          true
          (ite
            (< x@28@00 (get_BST_value<Int> t@27@00))
            (bst_search%limited $Snap.unit (get_BST_left<BST> t@27@00) x@28@00)
            (bst_search%limited $Snap.unit (get_BST_right<BST> t@27@00) x@28@00))))))
  :pattern ((bst_search s@$ t@27@00 x@28@00))
  :qid |quant-u-64|)))
(assert (forall ((s@$ $Snap) (t@27@00 BST) (x@28@00 Int)) (!
  (=>
    (bst_search%precondition s@$ t@27@00 x@28@00)
    (ite
      (= (BST_tag<Int> t@27@00) 0)
      true
      (ite
        (= (get_BST_value<Int> t@27@00) x@28@00)
        true
        (ite
          (< x@28@00 (get_BST_value<Int> t@27@00))
          (bst_search%precondition $Snap.unit (get_BST_left<BST> t@27@00) x@28@00)
          (bst_search%precondition $Snap.unit (get_BST_right<BST> t@27@00) x@28@00)))))
  :pattern ((bst_search s@$ t@27@00 x@28@00))
  :qid |quant-u-65|)))
(assert (forall ((s@$ $Snap) (t@30@00 BST)) (!
  (= (bst_min%limited s@$ t@30@00) (bst_min s@$ t@30@00))
  :pattern ((bst_min s@$ t@30@00))
  :qid |quant-u-22|)))
(assert (forall ((s@$ $Snap) (t@30@00 BST)) (!
  (bst_min%stateless t@30@00)
  :pattern ((bst_min%limited s@$ t@30@00))
  :qid |quant-u-23|)))
(assert (forall ((s@$ $Snap) (t@30@00 BST)) (!
  (=>
    (bst_min%precondition s@$ t@30@00)
    (=
      (bst_min s@$ t@30@00)
      (ite
        (= (BST_tag<Int> t@30@00) 0)
        (as None<Option<Int>>  Option<Int>)
        (ite
          (= (BST_tag<Int> (get_BST_left<BST> t@30@00)) 0)
          (Some<Option<Int>> (get_BST_value<Int> t@30@00))
          (bst_min%limited $Snap.unit (get_BST_left<BST> t@30@00))))))
  :pattern ((bst_min s@$ t@30@00))
  :qid |quant-u-66|)))
(assert (forall ((s@$ $Snap) (t@30@00 BST)) (!
  (=>
    (bst_min%precondition s@$ t@30@00)
    (ite
      (= (BST_tag<Int> t@30@00) 0)
      true
      (ite
        (= (BST_tag<Int> (get_BST_left<BST> t@30@00)) 0)
        true
        (bst_min%precondition $Snap.unit (get_BST_left<BST> t@30@00)))))
  :pattern ((bst_min s@$ t@30@00))
  :qid |quant-u-67|)))
(assert (forall ((s@$ $Snap) (parent@32@00 Seq<Int>) (x@33@00 Int) (y@34@00 Int) (depth@35@00 Int)) (!
  (=
    (is_same_set%limited s@$ parent@32@00 x@33@00 y@34@00 depth@35@00)
    (is_same_set s@$ parent@32@00 x@33@00 y@34@00 depth@35@00))
  :pattern ((is_same_set s@$ parent@32@00 x@33@00 y@34@00 depth@35@00))
  :qid |quant-u-24|)))
(assert (forall ((s@$ $Snap) (parent@32@00 Seq<Int>) (x@33@00 Int) (y@34@00 Int) (depth@35@00 Int)) (!
  (is_same_set%stateless parent@32@00 x@33@00 y@34@00 depth@35@00)
  :pattern ((is_same_set%limited s@$ parent@32@00 x@33@00 y@34@00 depth@35@00))
  :qid |quant-u-25|)))
(assert (forall ((s@$ $Snap) (parent@32@00 Seq<Int>) (x@33@00 Int) (y@34@00 Int) (depth@35@00 Int)) (!
  (=>
    (is_same_set%precondition s@$ parent@32@00 x@33@00 y@34@00 depth@35@00)
    (=
      (is_same_set s@$ parent@32@00 x@33@00 y@34@00 depth@35@00)
      (=
        (find_root ($Snap.combine
          $Snap.unit
          ($Snap.combine $Snap.unit $Snap.unit)) parent@32@00 x@33@00 depth@35@00)
        (find_root ($Snap.combine
          $Snap.unit
          ($Snap.combine $Snap.unit $Snap.unit)) parent@32@00 y@34@00 depth@35@00))))
  :pattern ((is_same_set s@$ parent@32@00 x@33@00 y@34@00 depth@35@00))
  :qid |quant-u-68|)))
(assert (forall ((s@$ $Snap) (parent@32@00 Seq<Int>) (x@33@00 Int) (y@34@00 Int) (depth@35@00 Int)) (!
  (=>
    (is_same_set%precondition s@$ parent@32@00 x@33@00 y@34@00 depth@35@00)
    (and
      (find_root%precondition ($Snap.combine
        $Snap.unit
        ($Snap.combine $Snap.unit $Snap.unit)) parent@32@00 x@33@00 depth@35@00)
      (find_root%precondition ($Snap.combine
        $Snap.unit
        ($Snap.combine $Snap.unit $Snap.unit)) parent@32@00 y@34@00 depth@35@00)))
  :pattern ((is_same_set s@$ parent@32@00 x@33@00 y@34@00 depth@35@00))
  :qid |quant-u-69|)))
(assert (forall ((s@$ $Snap) (arr@37@00 Seq<Int>) (idx@38@00 Int)) (!
  (=
    (is_max_heap%limited s@$ arr@37@00 idx@38@00)
    (is_max_heap s@$ arr@37@00 idx@38@00))
  :pattern ((is_max_heap s@$ arr@37@00 idx@38@00))
  :qid |quant-u-26|)))
(assert (forall ((s@$ $Snap) (arr@37@00 Seq<Int>) (idx@38@00 Int)) (!
  (is_max_heap%stateless arr@37@00 idx@38@00)
  :pattern ((is_max_heap%limited s@$ arr@37@00 idx@38@00))
  :qid |quant-u-27|)))
(assert (forall ((s@$ $Snap) (arr@37@00 Seq<Int>) (idx@38@00 Int)) (!
  (=>
    (is_max_heap%precondition s@$ arr@37@00 idx@38@00)
    (=
      (is_max_heap s@$ arr@37@00 idx@38@00)
      (ite
        (>= idx@38@00 (Seq_length arr@37@00))
        true
        (let ((left (+ (* 2 idx@38@00) 1))) (let ((right (+ (* 2 idx@38@00) 2))) (and
          (or
            (>= left (Seq_length arr@37@00))
            (>= (Seq_index arr@37@00 idx@38@00) (Seq_index arr@37@00 left)))
          (and
            (or
              (>= right (Seq_length arr@37@00))
              (>= (Seq_index arr@37@00 idx@38@00) (Seq_index arr@37@00 right)))
            (is_max_heap%limited $Snap.unit arr@37@00 (+ idx@38@00 1)))))))))
  :pattern ((is_max_heap s@$ arr@37@00 idx@38@00))
  :qid |quant-u-70|)))
(assert (forall ((s@$ $Snap) (arr@37@00 Seq<Int>) (idx@38@00 Int)) (!
  (=>
    (is_max_heap%precondition s@$ arr@37@00 idx@38@00)
    (ite
      (>= idx@38@00 (Seq_length arr@37@00))
      true
      (let ((left (+ (* 2 idx@38@00) 1))) (let ((right (+ (* 2 idx@38@00) 2))) (=>
        (and
          (or
            (>= left (Seq_length arr@37@00))
            (>= (Seq_index arr@37@00 idx@38@00) (Seq_index arr@37@00 left)))
          (or
            (>= right (Seq_length arr@37@00))
            (>= (Seq_index arr@37@00 idx@38@00) (Seq_index arr@37@00 right))))
        (is_max_heap%precondition $Snap.unit arr@37@00 (+ idx@38@00 1)))))))
  :pattern ((is_max_heap s@$ arr@37@00 idx@38@00))
  :qid |quant-u-71|)))
(assert (forall ((s@$ $Snap) (n@40@00 Int) (max_level@41@00 Int)) (!
  (=
    (skip_list_level%limited s@$ n@40@00 max_level@41@00)
    (skip_list_level s@$ n@40@00 max_level@41@00))
  :pattern ((skip_list_level s@$ n@40@00 max_level@41@00))
  :qid |quant-u-28|)))
(assert (forall ((s@$ $Snap) (n@40@00 Int) (max_level@41@00 Int)) (!
  (skip_list_level%stateless n@40@00 max_level@41@00)
  :pattern ((skip_list_level%limited s@$ n@40@00 max_level@41@00))
  :qid |quant-u-29|)))
(assert (forall ((s@$ $Snap) (n@40@00 Int) (max_level@41@00 Int)) (!
  (let ((result@42@00 (skip_list_level%limited s@$ n@40@00 max_level@41@00))) (=>
    (skip_list_level%precondition s@$ n@40@00 max_level@41@00)
    (and (>= result@42@00 0) (<= result@42@00 max_level@41@00))))
  :pattern ((skip_list_level%limited s@$ n@40@00 max_level@41@00))
  :qid |quant-u-72|)))
(assert (forall ((s@$ $Snap) (n@40@00 Int) (max_level@41@00 Int)) (!
  (let ((result@42@00 (skip_list_level%limited s@$ n@40@00 max_level@41@00))) true)
  :pattern ((skip_list_level%limited s@$ n@40@00 max_level@41@00))
  :qid |quant-u-73|)))
(assert (forall ((s@$ $Snap) (n@40@00 Int) (max_level@41@00 Int)) (!
  (let ((result@42@00 (skip_list_level%limited s@$ n@40@00 max_level@41@00))) true)
  :pattern ((skip_list_level%limited s@$ n@40@00 max_level@41@00))
  :qid |quant-u-74|)))
(assert (forall ((s@$ $Snap) (arr@43@00 Seq<Int>) (idx@44@00 Int)) (!
  (=
    (is_min_heap%limited s@$ arr@43@00 idx@44@00)
    (is_min_heap s@$ arr@43@00 idx@44@00))
  :pattern ((is_min_heap s@$ arr@43@00 idx@44@00))
  :qid |quant-u-30|)))
(assert (forall ((s@$ $Snap) (arr@43@00 Seq<Int>) (idx@44@00 Int)) (!
  (is_min_heap%stateless arr@43@00 idx@44@00)
  :pattern ((is_min_heap%limited s@$ arr@43@00 idx@44@00))
  :qid |quant-u-31|)))
(assert (forall ((s@$ $Snap) (arr@43@00 Seq<Int>) (idx@44@00 Int)) (!
  (=>
    (is_min_heap%precondition s@$ arr@43@00 idx@44@00)
    (=
      (is_min_heap s@$ arr@43@00 idx@44@00)
      (ite
        (>= idx@44@00 (Seq_length arr@43@00))
        true
        (let ((left (+ (* 2 idx@44@00) 1))) (let ((right (+ (* 2 idx@44@00) 2))) (and
          (or
            (>= left (Seq_length arr@43@00))
            (<= (Seq_index arr@43@00 idx@44@00) (Seq_index arr@43@00 left)))
          (and
            (or
              (>= right (Seq_length arr@43@00))
              (<= (Seq_index arr@43@00 idx@44@00) (Seq_index arr@43@00 right)))
            (is_min_heap%limited $Snap.unit arr@43@00 (+ idx@44@00 1)))))))))
  :pattern ((is_min_heap s@$ arr@43@00 idx@44@00))
  :qid |quant-u-75|)))
(assert (forall ((s@$ $Snap) (arr@43@00 Seq<Int>) (idx@44@00 Int)) (!
  (=>
    (is_min_heap%precondition s@$ arr@43@00 idx@44@00)
    (ite
      (>= idx@44@00 (Seq_length arr@43@00))
      true
      (let ((left (+ (* 2 idx@44@00) 1))) (let ((right (+ (* 2 idx@44@00) 2))) (=>
        (and
          (or
            (>= left (Seq_length arr@43@00))
            (<= (Seq_index arr@43@00 idx@44@00) (Seq_index arr@43@00 left)))
          (or
            (>= right (Seq_length arr@43@00))
            (<= (Seq_index arr@43@00 idx@44@00) (Seq_index arr@43@00 right))))
        (is_min_heap%precondition $Snap.unit arr@43@00 (+ idx@44@00 1)))))))
  :pattern ((is_min_heap s@$ arr@43@00 idx@44@00))
  :qid |quant-u-76|)))
(assert (forall ((s@$ $Snap) (z@46@00 ListZipper<Int>)) (!
  (= (zipper_forward%limited s@$ z@46@00) (zipper_forward s@$ z@46@00))
  :pattern ((zipper_forward s@$ z@46@00))
  :qid |quant-u-32|)))
(assert (forall ((s@$ $Snap) (z@46@00 ListZipper<Int>)) (!
  (zipper_forward%stateless z@46@00)
  :pattern ((zipper_forward%limited s@$ z@46@00))
  :qid |quant-u-33|)))
(assert (forall ((s@$ $Snap) (z@46@00 ListZipper<Int>)) (!
  (=>
    (zipper_forward%precondition s@$ z@46@00)
    (=
      (zipper_forward s@$ z@46@00)
      (ite
        (or
          (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@46@00)) 0)
          (= (Seq_length (get_ListZipper_after<Seq<Int>> z@46@00)) 0))
        z@46@00
        (Zipper<ListZipper<Int>> (Seq_append
          (get_ListZipper_before<Seq<Int>> z@46@00)
          (Seq_singleton (get_Option_value<Int> (get_ListZipper_focus<Option<Int>> z@46@00)))) (Some<Option<Int>> (Seq_index
          (get_ListZipper_after<Seq<Int>> z@46@00)
          0)) (Seq_drop (get_ListZipper_after<Seq<Int>> z@46@00) 1)))))
  :pattern ((zipper_forward s@$ z@46@00))
  :qid |quant-u-77|)))
(assert (forall ((s@$ $Snap) (z@46@00 ListZipper<Int>)) (!
  true
  :pattern ((zipper_forward s@$ z@46@00))
  :qid |quant-u-78|)))
(assert (forall ((s@$ $Snap) (t@48@00 RoseTree)) (!
  (= (rose_height%limited s@$ t@48@00) (rose_height s@$ t@48@00))
  :pattern ((rose_height s@$ t@48@00))
  :qid |quant-u-34|)))
(assert (forall ((s@$ $Snap) (t@48@00 RoseTree)) (!
  (rose_height%stateless t@48@00)
  :pattern ((rose_height%limited s@$ t@48@00))
  :qid |quant-u-35|)))
(assert (forall ((s@$ $Snap) (t@48@00 RoseTree)) (!
  (=>
    (rose_height%precondition s@$ t@48@00)
    (=
      (rose_height s@$ t@48@00)
      (+
        1
        (rose_children_max_height%limited ($Snap.combine $Snap.unit $Snap.unit) (get_RoseTree_children<Seq<RoseTree>> t@48@00) 0 0))))
  :pattern ((rose_height s@$ t@48@00))
  :qid |quant-u-79|)))
(assert (forall ((s@$ $Snap) (t@48@00 RoseTree)) (!
  (=>
    (rose_height%precondition s@$ t@48@00)
    (rose_children_max_height%precondition ($Snap.combine $Snap.unit $Snap.unit) (get_RoseTree_children<Seq<RoseTree>> t@48@00) 0 0))
  :pattern ((rose_height s@$ t@48@00))
  :qid |quant-u-80|)))
(assert (forall ((s@$ $Snap) (children@50@00 Seq<RoseTree>) (idx@51@00 Int) (max_h@52@00 Int)) (!
  (=
    (rose_children_max_height%limited s@$ children@50@00 idx@51@00 max_h@52@00)
    (rose_children_max_height s@$ children@50@00 idx@51@00 max_h@52@00))
  :pattern ((rose_children_max_height s@$ children@50@00 idx@51@00 max_h@52@00))
  :qid |quant-u-36|)))
(assert (forall ((s@$ $Snap) (children@50@00 Seq<RoseTree>) (idx@51@00 Int) (max_h@52@00 Int)) (!
  (rose_children_max_height%stateless children@50@00 idx@51@00 max_h@52@00)
  :pattern ((rose_children_max_height%limited s@$ children@50@00 idx@51@00 max_h@52@00))
  :qid |quant-u-37|)))
(assert (forall ((s@$ $Snap) (children@50@00 Seq<RoseTree>) (idx@51@00 Int) (max_h@52@00 Int)) (!
  (let ((result@53@00 (rose_children_max_height%limited s@$ children@50@00 idx@51@00 max_h@52@00))) (=>
    (rose_children_max_height%precondition s@$ children@50@00 idx@51@00 max_h@52@00)
    (>= result@53@00 max_h@52@00)))
  :pattern ((rose_children_max_height%limited s@$ children@50@00 idx@51@00 max_h@52@00))
  :qid |quant-u-81|)))
(assert (forall ((s@$ $Snap) (children@50@00 Seq<RoseTree>) (idx@51@00 Int) (max_h@52@00 Int)) (!
  (let ((result@53@00 (rose_children_max_height%limited s@$ children@50@00 idx@51@00 max_h@52@00))) true)
  :pattern ((rose_children_max_height%limited s@$ children@50@00 idx@51@00 max_h@52@00))
  :qid |quant-u-82|)))
(assert (forall ((s@$ $Snap) (children@50@00 Seq<RoseTree>) (idx@51@00 Int) (max_h@52@00 Int)) (!
  (=>
    (rose_children_max_height%precondition s@$ children@50@00 idx@51@00 max_h@52@00)
    (=
      (rose_children_max_height s@$ children@50@00 idx@51@00 max_h@52@00)
      (ite
        (>= idx@51@00 (Seq_length children@50@00))
        max_h@52@00
        (let ((h (rose_height%limited $Snap.unit (Seq_index
          children@50@00
          idx@51@00)))) (rose_children_max_height%limited ($Snap.combine
          $Snap.unit
          $Snap.unit) children@50@00 (+ idx@51@00 1) (ite
          (> h max_h@52@00)
          h
          max_h@52@00))))))
  :pattern ((rose_children_max_height s@$ children@50@00 idx@51@00 max_h@52@00))
  :qid |quant-u-83|)))
(assert (forall ((s@$ $Snap) (children@50@00 Seq<RoseTree>) (idx@51@00 Int) (max_h@52@00 Int)) (!
  (=>
    (rose_children_max_height%precondition s@$ children@50@00 idx@51@00 max_h@52@00)
    (ite
      (>= idx@51@00 (Seq_length children@50@00))
      true
      (and
        (rose_height%precondition $Snap.unit (Seq_index children@50@00 idx@51@00))
        (let ((h (rose_height%limited $Snap.unit (Seq_index
          children@50@00
          idx@51@00)))) (rose_children_max_height%precondition ($Snap.combine
          $Snap.unit
          $Snap.unit) children@50@00 (+ idx@51@00 1) (ite
          (> h max_h@52@00)
          h
          max_h@52@00))))))
  :pattern ((rose_children_max_height s@$ children@50@00 idx@51@00 max_h@52@00))
  :qid |quant-u-84|)))
(assert (forall ((s@$ $Snap) (tree@54@00 Seq<Int>) (node@55@00 Int) (node_left@56@00 Int) (node_right@57@00 Int) (query_left@58@00 Int) (query_right@59@00 Int)) (!
  (=
    (segment_tree_query%limited s@$ tree@54@00 node@55@00 node_left@56@00 node_right@57@00 query_left@58@00 query_right@59@00)
    (segment_tree_query s@$ tree@54@00 node@55@00 node_left@56@00 node_right@57@00 query_left@58@00 query_right@59@00))
  :pattern ((segment_tree_query s@$ tree@54@00 node@55@00 node_left@56@00 node_right@57@00 query_left@58@00 query_right@59@00))
  :qid |quant-u-38|)))
(assert (forall ((s@$ $Snap) (tree@54@00 Seq<Int>) (node@55@00 Int) (node_left@56@00 Int) (node_right@57@00 Int) (query_left@58@00 Int) (query_right@59@00 Int)) (!
  (segment_tree_query%stateless tree@54@00 node@55@00 node_left@56@00 node_right@57@00 query_left@58@00 query_right@59@00)
  :pattern ((segment_tree_query%limited s@$ tree@54@00 node@55@00 node_left@56@00 node_right@57@00 query_left@58@00 query_right@59@00))
  :qid |quant-u-39|)))
; End function- and predicate-related preamble
; ------------------------------------------------------------
; ---------- test_data_structures ----------
(set-option :rlimit 0)
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
(pop) ; 2
(push) ; 2
; [exec]
; var empty_bst: BST
(declare-const empty_bst@0@01 BST)
; [exec]
; var bst1: BST
(declare-const bst1@1@01 BST)
; [exec]
; var bst2: BST
(declare-const bst2@2@01 BST)
; [exec]
; var some_val: Option[Int]
(declare-const some_val@3@01 Option<Int>)
; [exec]
; var none_val: Option[Int]
(declare-const none_val@4@01 Option<Int>)
; [exec]
; var min_heap: Seq[Int]
(declare-const min_heap@5@01 Seq<Int>)
; [exec]
; var max_heap: Seq[Int]
(declare-const max_heap@6@01 Seq<Int>)
; [exec]
; var z: ListZipper[Int]
(declare-const z@7@01 ListZipper<Int>)
; [exec]
; var z2: ListZipper[Int]
(declare-const z2@8@01 ListZipper<Int>)
; [exec]
; empty_bst := BSTLeaf()
; [eval] BSTLeaf()
(declare-const empty_bst@9@01 BST)
(assert (= empty_bst@9@01 (as BSTLeaf<BST>  BST)))
; [exec]
; bst1 := bst_insert(empty_bst, 5)
; [eval] bst_insert(empty_bst, 5)
(push) ; 3
(assert (bst_insert%precondition $Snap.unit empty_bst@9@01 5))
(pop) ; 3
; Joined path conditions
(assert (bst_insert%precondition $Snap.unit empty_bst@9@01 5))
(declare-const bst1@10@01 BST)
(assert (= bst1@10@01 (bst_insert $Snap.unit empty_bst@9@01 5)))
; [exec]
; bst2 := bst_insert(bst_insert(bst1, 3), 7)
; [eval] bst_insert(bst_insert(bst1, 3), 7)
; [eval] bst_insert(bst1, 3)
(push) ; 3
(assert (bst_insert%precondition $Snap.unit bst1@10@01 3))
(pop) ; 3
; Joined path conditions
(assert (bst_insert%precondition $Snap.unit bst1@10@01 3))
(push) ; 3
(assert (bst_insert%precondition $Snap.unit (bst_insert $Snap.unit bst1@10@01 3) 7))
(pop) ; 3
; Joined path conditions
(assert (bst_insert%precondition $Snap.unit (bst_insert $Snap.unit bst1@10@01 3) 7))
(declare-const bst2@11@01 BST)
(assert (= bst2@11@01 (bst_insert $Snap.unit (bst_insert $Snap.unit bst1@10@01 3) 7)))
; [exec]
; assert bst_search(bst2, 5)
; [eval] bst_search(bst2, 5)
(push) ; 3
(assert (bst_search%precondition $Snap.unit bst2@11@01 5))
(pop) ; 3
; Joined path conditions
(assert (bst_search%precondition $Snap.unit bst2@11@01 5))
(push) ; 3
(assert (not (bst_search $Snap.unit bst2@11@01 5)))
(check-sat)
; unsat
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(assert (bst_search $Snap.unit bst2@11@01 5))
; [exec]
; assert bst_search(bst2, 3)
; [eval] bst_search(bst2, 3)
(push) ; 3
(assert (bst_search%precondition $Snap.unit bst2@11@01 3))
(pop) ; 3
; Joined path conditions
(assert (bst_search%precondition $Snap.unit bst2@11@01 3))
(push) ; 3
(assert (not (bst_search $Snap.unit bst2@11@01 3)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] bst_search(bst2, 3)
(set-option :rlimit 0)
(push) ; 3
(pop) ; 3
; Joined path conditions
(push) ; 3
(assert (not (bst_search $Snap.unit bst2@11@01 3)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] bst_search(bst2, 3)
(set-option :rlimit 0)
(push) ; 3
(pop) ; 3
; Joined path conditions
(push) ; 3
(assert (not (bst_search $Snap.unit bst2@11@01 3)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] bst_search(bst2, 3)
(set-option :rlimit 0)
(push) ; 3
(pop) ; 3
; Joined path conditions
(push) ; 3
(assert (not (bst_search $Snap.unit bst2@11@01 3)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(pop) ; 2
(pop) ; 1
