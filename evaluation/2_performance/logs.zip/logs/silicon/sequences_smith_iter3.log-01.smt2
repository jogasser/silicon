(get-info :version)
; (:version "4.8.7")
; Started: 2025-12-05 13:27:58
; Silicon.version: 1.1-SNAPSHOT (95328487@(detached))
; Input file: ./sequences/smith.vpr
; Verifier id: 00
; ------------------------------------------------------------
; Begin preamble
; ////////// Static preamble
; 
; ; /z3config.smt2
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :smt.qi.max_multi_patterns 1000)
; 
; ; /preamble.smt2
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(define-fun $Perm.min ((p1 $Perm) (p2 $Perm)) Real
    (ite (<= p1 p2) p1 p2))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
; ////////// Sorts
(declare-sort Seq<Int> 0)
; ////////// Sort wrappers
; Declaring additional sort wrappers
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.Seq<Int>To$Snap (Seq<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<Int> ($Snap) Seq<Int>)
(assert (forall ((x Seq<Int>)) (!
    (= x ($SortWrappers.$SnapToSeq<Int>($SortWrappers.Seq<Int>To$Snap x)))
    :pattern (($SortWrappers.Seq<Int>To$Snap x))
    :qid |$Snap.$SnapToSeq<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<Int>To$Snap($SortWrappers.$SnapToSeq<Int> x)))
    :pattern (($SortWrappers.$SnapToSeq<Int> x))
    :qid |$Snap.Seq<Int>To$SnapToSeq<Int>|
    )))
; ////////// Symbols
(declare-fun Seq_length (Seq<Int>) Int)
(declare-const Seq_empty Seq<Int>)
(declare-fun Seq_singleton (Int) Seq<Int>)
(declare-fun Seq_append (Seq<Int> Seq<Int>) Seq<Int>)
(declare-fun Seq_index (Seq<Int> Int) Int)
(declare-fun Seq_add (Int Int) Int)
(declare-fun Seq_sub (Int Int) Int)
(declare-fun Seq_update (Seq<Int> Int Int) Seq<Int>)
(declare-fun Seq_take (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_drop (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_contains (Seq<Int> Int) Bool)
(declare-fun Seq_contains_trigger (Seq<Int> Int) Bool)
(declare-fun Seq_skolem (Seq<Int> Int) Int)
(declare-fun Seq_equal (Seq<Int> Seq<Int>) Bool)
(declare-fun Seq_skolem_diff (Seq<Int> Seq<Int>) Int)
(declare-fun Seq_range (Int Int) Seq<Int>)
; Declaring symbols related to program functions (from program analysis)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
; Declaring predicate trigger functions
; ////////// Uniqueness assumptions from domains
; ////////// Axioms
(assert (forall ((s Seq<Int>)) (!
  (<= 0 (Seq_length s))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty  Seq<Int>)) 0))
(assert (forall ((s Seq<Int>)) (!
  (=> (= (Seq_length s) 0) (= s (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_zero|)))
(assert (forall ((e Int)) (!
  (= (Seq_length (Seq_singleton e)) 1)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (not (= s1 (as Seq_empty  Seq<Int>))))
    (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1))))
  :pattern ((Seq_length (Seq_append s0 s1)))
  :qid |$Seq[Int]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (and
    (=> (= s0 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s1))
    (=> (= s1 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s0)))
  :pattern ((Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_empty|)))
(assert (forall ((e Int)) (!
  (= (Seq_index (Seq_singleton e) 0) e)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_add i j) (+ i j))
  :pattern ((Seq_add i j))
  :qid |$Seq[Int]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_sub i j) (- i j))
  :pattern ((Seq_sub i j))
  :qid |$Seq[Int]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= 0 n) (< n (Seq_length s0)))))
    (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n)))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :pattern ((Seq_index s0 n) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1))))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n)
      (=
        (Seq_index (Seq_append s0 s1) n)
        (Seq_index s1 (Seq_sub n (Seq_length s0))))))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :qid |$Seq[Int]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (m Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= 0 m) (< m (Seq_length s1)))))
    (and
      (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m)
      (=
        (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0)))
        (Seq_index s1 m))))
  :pattern ((Seq_index s1 m) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (Seq_length (Seq_update s i v)) (Seq_length s)))
  :pattern ((Seq_length (Seq_update s i v)))
  :pattern ((Seq_length s) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_length|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int) (n Int)) (!
  (=>
    (and (<= 0 n) (< n (Seq_length s)))
    (and
      (=> (= i n) (= (Seq_index (Seq_update s i v) n) v))
      (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n)))))
  :pattern ((Seq_index (Seq_update s i v) n))
  :pattern ((Seq_index s n) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s)))))
    (=> (< n 0) (= (Seq_length (Seq_take s n)) 0)))
  :pattern ((Seq_length (Seq_take s n)))
  :pattern ((Seq_take s n) (Seq_length s))
  :qid |$Seq[Int]_prog.Seq_take_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (<= 0 j) (and (< j n) (< j (Seq_length s))))
    (= (Seq_index (Seq_take s n) j) (Seq_index s j)))
  :pattern ((Seq_index (Seq_take s n) j))
  :pattern ((Seq_index s j) (Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=>
          (<= n (Seq_length s))
          (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n)))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0))))
    (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s))))
  :pattern ((Seq_length (Seq_drop s n)))
  :pattern ((Seq_length s) (Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n))))
    (and
      (= (Seq_sub (Seq_add j n) n) j)
      (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n)))))
  :pattern ((Seq_index (Seq_drop s n) j))
  :qid |$Seq[Int]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<Int>) (n Int) (i Int)) (!
  (=>
    (and (< 0 n) (and (<= n i) (< i (Seq_length s))))
    (and
      (= (Seq_add (Seq_sub i n) n) i)
      (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i))))
  :pattern ((Seq_drop s n) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_take (Seq_append s t) n) (Seq_take s n)))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (=
        (Seq_take (Seq_append s t) n)
        (Seq_append s (Seq_take t (Seq_sub n (Seq_length s)))))))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t)))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (> n (Seq_length s)))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s))))))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_take s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_drop s n) s))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_take s n) s))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_all|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<Int>) (x Int)) (!
  (=>
    (Seq_contains s x)
    (and
      (<= 0 (Seq_skolem s x))
      (and
        (< (Seq_skolem s x) (Seq_length s))
        (= (Seq_index s (Seq_skolem s x)) x))))
  :pattern ((Seq_contains s x))
  :qid |$Seq[Int]_prog.Seq_contains1|)))
(assert (forall ((s Seq<Int>) (x Int) (i Int)) (!
  (=>
    (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x)))
    (Seq_contains s x))
  :pattern ((Seq_contains s x) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains2|)))
(assert (forall ((s Seq<Int>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (Seq_contains_trigger s (Seq_index s i)))
  :pattern ((Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (or
    (and (= s0 s1) (Seq_equal s0 s1))
    (or
      (and
        (not (= s0 s1))
        (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1)))))
      (and
        (not (= s0 s1))
        (and
          (not (Seq_equal s0 s1))
          (and
            (= (Seq_length s0) (Seq_length s1))
            (and
              (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0))
              (and
                (<= 0 (Seq_skolem_diff s0 s1))
                (and
                  (< (Seq_skolem_diff s0 s1) (Seq_length s0))
                  (not
                    (=
                      (Seq_index s0 (Seq_skolem_diff s0 s1))
                      (Seq_index s1 (Seq_skolem_diff s0 s1))))))))))))
  :pattern ((Seq_equal s0 s1))
  :qid |$Seq[Int]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<Int>) (b Seq<Int>)) (!
  (=> (Seq_equal a b) (= a b))
  :pattern ((Seq_equal a b))
  :qid |$Seq[Int]_prog.Seq_equal_ext|)))
(assert (forall ((x Int) (y Int)) (!
  (= (Seq_contains (Seq_singleton x) y) (= x y))
  :pattern ((Seq_contains (Seq_singleton x) y))
  :qid |$Seq[Int]_prog.Seq_singleton_contains|)))
(assert (forall ((min_ Int) (max Int)) (!
  (and
    (=> (< min_ max) (= (Seq_length (Seq_range min_ max)) (- max min_)))
    (=> (<= max min_) (= (Seq_length (Seq_range min_ max)) 0)))
  :pattern ((Seq_length (Seq_range min_ max)))
  :qid |$Seq[Int]_prog.Seq_range_length|)))
(assert (forall ((min_ Int) (max Int) (j Int)) (!
  (=>
    (and (<= 0 j) (< j (- max min_)))
    (= (Seq_index (Seq_range min_ max) j) (+ min_ j)))
  :pattern ((Seq_index (Seq_range min_ max) j))
  :qid |$Seq[Int]_prog.Seq_range_index|)))
(assert (forall ((min_ Int) (max Int) (v Int)) (!
  (= (Seq_contains (Seq_range min_ max) v) (and (<= min_ v) (< v max)))
  :pattern ((Seq_contains (Seq_range min_ max) v))
  :qid |$Seq[Int]_prog.Seq_range_contains|)))
; End preamble
; ------------------------------------------------------------
; State saturation: after preamble
(set-option :rlimit 160000)
(check-sat)
; unknown
; ------------------------------------------------------------
; Begin function- and predicate-related preamble
; Declaring symbols related to program functions (from verification)
; Declaring symbols related to program functions (from verification)
; End function- and predicate-related preamble
; ------------------------------------------------------------
; ---------- main_fixed ----------
(declare-const p0_1@0@01 Bool)
(declare-const p1_1@1@01 Bool)
(declare-const a_in@2@01 Seq<Int>)
(declare-const a_in_1@3@01 Seq<Int>)
(declare-const secret@4@01 Int)
(declare-const secret_1@5@01 Int)
(declare-const leak@6@01 Int)
(declare-const leak_1@7@01 Int)
(declare-const p0_1@8@01 Bool)
(declare-const p1_1@9@01 Bool)
(declare-const a_in@10@01 Seq<Int>)
(declare-const a_in_1@11@01 Seq<Int>)
(declare-const secret@12@01 Int)
(declare-const secret_1@13@01 Int)
(declare-const leak@14@01 Int)
(declare-const leak_1@15@01 Int)
(set-option :rlimit 0)
(push) ; 1
(declare-const $t@16@01 $Snap)
(assert (= $t@16@01 ($Snap.combine ($Snap.first $t@16@01) ($Snap.second $t@16@01))))
(assert (= ($Snap.first $t@16@01) $Snap.unit))
; [eval] p0_1 ==> secret >= 0
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 0 | p0_1@8@01 | live]
; [else-branch: 0 | !(p0_1@8@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 0 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] secret >= 0
(pop) ; 3
(push) ; 3
; [else-branch: 0 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not p0_1@8@01) p0_1@8@01))
(assert (=> p0_1@8@01 (>= secret@12@01 0)))
(assert (=
  ($Snap.second $t@16@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@16@01))
    ($Snap.second ($Snap.second $t@16@01)))))
(assert (= ($Snap.first ($Snap.second $t@16@01)) $Snap.unit))
; [eval] p1_1 ==> secret_1 >= 0
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1 | p1_1@9@01 | live]
; [else-branch: 1 | !(p1_1@9@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 1 | p1_1@9@01]
(assert p1_1@9@01)
; [eval] secret_1 >= 0
(pop) ; 3
(push) ; 3
; [else-branch: 1 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not p1_1@9@01) p1_1@9@01))
(assert (=> p1_1@9@01 (>= secret_1@13@01 0)))
(assert (=
  ($Snap.second ($Snap.second $t@16@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@16@01)))
    ($Snap.second ($Snap.second ($Snap.second $t@16@01))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@16@01))) $Snap.unit))
; [eval] p0_1 ==> secret < |a_in|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 2 | p0_1@8@01 | live]
; [else-branch: 2 | !(p0_1@8@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 2 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] secret < |a_in|
; [eval] |a_in|
(pop) ; 3
(push) ; 3
; [else-branch: 2 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=> p0_1@8@01 (< secret@12@01 (Seq_length a_in@10@01))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second $t@16@01)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@16@01))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@16@01)))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@16@01))))
  $Snap.unit))
; [eval] p1_1 ==> secret_1 < |a_in_1|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 3 | p1_1@9@01 | live]
; [else-branch: 3 | !(p1_1@9@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 3 | p1_1@9@01]
(assert p1_1@9@01)
; [eval] secret_1 < |a_in_1|
; [eval] |a_in_1|
(pop) ; 3
(push) ; 3
; [else-branch: 3 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=> p1_1@9@01 (< secret_1@13@01 (Seq_length a_in_1@11@01))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@16@01))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@16@01)))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@16@01))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@16@01)))))
  $Snap.unit))
; [eval] p0_1 ==> p0_1 && p1_1 ==> |a_in| == |a_in_1|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 4 | p0_1@8@01 | live]
; [else-branch: 4 | !(p0_1@8@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 4 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] p0_1 && p1_1 ==> |a_in| == |a_in_1|
; [eval] p0_1 && p1_1
(push) ; 4
; [then-branch: 5 | !(p0_1@8@01) | live]
; [else-branch: 5 | p0_1@8@01 | live]
(push) ; 5
; [then-branch: 5 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 5
(push) ; 5
; [else-branch: 5 | p0_1@8@01]
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or p0_1@8@01 (not p0_1@8@01)))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (and p0_1@8@01 p1_1@9@01))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (and p0_1@8@01 p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 6 | p0_1@8@01 && p1_1@9@01 | live]
; [else-branch: 6 | !(p0_1@8@01 && p1_1@9@01) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 6 | p0_1@8@01 && p1_1@9@01]
(assert (and p0_1@8@01 p1_1@9@01))
; [eval] |a_in| == |a_in_1|
; [eval] |a_in|
; [eval] |a_in_1|
(pop) ; 5
(push) ; 5
; [else-branch: 6 | !(p0_1@8@01 && p1_1@9@01)]
(assert (not (and p0_1@8@01 p1_1@9@01)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (not (and p0_1@8@01 p1_1@9@01)) (and p0_1@8@01 p1_1@9@01)))
(pop) ; 3
(push) ; 3
; [else-branch: 4 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
(assert (=>
  p0_1@8@01
  (and
    p0_1@8@01
    (or p0_1@8@01 (not p0_1@8@01))
    (or (not (and p0_1@8@01 p1_1@9@01)) (and p0_1@8@01 p1_1@9@01)))))
; Joined path conditions
(assert (=>
  (and p0_1@8@01 (and p0_1@8@01 p1_1@9@01))
  (= (Seq_length a_in@10@01) (Seq_length a_in_1@11@01))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@16@01)))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@16@01))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@16@01)))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@16@01))))))
  $Snap.unit))
; [eval] p1_1 ==> true
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 7 | p1_1@9@01 | live]
; [else-branch: 7 | !(p1_1@9@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 7 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 3
(push) ; 3
; [else-branch: 7 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@16@01))))))
  $Snap.unit))
; [eval] (forall i: Int :: { a_in[i] } { a_in_1[i] } (p0_1 ==> i >= 0 && i < |a_in| ==> a_in[i] == 0) && (p1_1 ==> i >= 0 && i < |a_in_1| ==> a_in_1[i] == 0))
(declare-const i@17@01 Int)
(push) ; 2
; [eval] (p0_1 ==> i >= 0 && i < |a_in| ==> a_in[i] == 0) && (p1_1 ==> i >= 0 && i < |a_in_1| ==> a_in_1[i] == 0)
; [eval] p0_1 ==> i >= 0 && i < |a_in| ==> a_in[i] == 0
(push) ; 3
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 8 | p0_1@8@01 | live]
; [else-branch: 8 | !(p0_1@8@01) | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 8 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i >= 0 && i < |a_in| ==> a_in[i] == 0
; [eval] i >= 0 && i < |a_in|
; [eval] i >= 0
(push) ; 5
; [then-branch: 9 | !(i@17@01 >= 0) | live]
; [else-branch: 9 | i@17@01 >= 0 | live]
(push) ; 6
; [then-branch: 9 | !(i@17@01 >= 0)]
(assert (not (>= i@17@01 0)))
(pop) ; 6
(push) ; 6
; [else-branch: 9 | i@17@01 >= 0]
(assert (>= i@17@01 0))
; [eval] i < |a_in|
; [eval] |a_in|
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (or (>= i@17@01 0) (not (>= i@17@01 0))))
(push) ; 5
; [then-branch: 10 | i@17@01 >= 0 && i@17@01 < |a_in@10@01| | live]
; [else-branch: 10 | !(i@17@01 >= 0 && i@17@01 < |a_in@10@01|) | live]
(push) ; 6
; [then-branch: 10 | i@17@01 >= 0 && i@17@01 < |a_in@10@01|]
(assert (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
; [eval] a_in[i] == 0
; [eval] a_in[i]
(pop) ; 6
(push) ; 6
; [else-branch: 10 | !(i@17@01 >= 0 && i@17@01 < |a_in@10@01|)]
(assert (not (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01)))))
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (or
  (not (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
  (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01)))))
(pop) ; 4
(push) ; 4
; [else-branch: 8 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 4
(pop) ; 3
; Joined path conditions
(assert (=>
  p0_1@8@01
  (and
    p0_1@8@01
    (or (>= i@17@01 0) (not (>= i@17@01 0)))
    (or
      (not (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
      (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01)))))))
; Joined path conditions
(push) ; 3
; [then-branch: 11 | !(p0_1@8@01 && i@17@01 >= 0 && i@17@01 < |a_in@10@01| ==> a_in@10@01[i@17@01] == 0) | live]
; [else-branch: 11 | p0_1@8@01 && i@17@01 >= 0 && i@17@01 < |a_in@10@01| ==> a_in@10@01[i@17@01] == 0 | live]
(push) ; 4
; [then-branch: 11 | !(p0_1@8@01 && i@17@01 >= 0 && i@17@01 < |a_in@10@01| ==> a_in@10@01[i@17@01] == 0)]
(assert (not
  (=>
    (and p0_1@8@01 (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
    (= (Seq_index a_in@10@01 i@17@01) 0))))
(pop) ; 4
(push) ; 4
; [else-branch: 11 | p0_1@8@01 && i@17@01 >= 0 && i@17@01 < |a_in@10@01| ==> a_in@10@01[i@17@01] == 0]
(assert (=>
  (and p0_1@8@01 (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
  (= (Seq_index a_in@10@01 i@17@01) 0)))
; [eval] p1_1 ==> i >= 0 && i < |a_in_1| ==> a_in_1[i] == 0
(push) ; 5
(push) ; 6
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [then-branch: 12 | p1_1@9@01 | live]
; [else-branch: 12 | !(p1_1@9@01) | live]
(set-option :rlimit 0)
(push) ; 6
; [then-branch: 12 | p1_1@9@01]
(assert p1_1@9@01)
; [eval] i >= 0 && i < |a_in_1| ==> a_in_1[i] == 0
; [eval] i >= 0 && i < |a_in_1|
; [eval] i >= 0
(push) ; 7
; [then-branch: 13 | !(i@17@01 >= 0) | live]
; [else-branch: 13 | i@17@01 >= 0 | live]
(push) ; 8
; [then-branch: 13 | !(i@17@01 >= 0)]
(assert (not (>= i@17@01 0)))
(pop) ; 8
(push) ; 8
; [else-branch: 13 | i@17@01 >= 0]
(assert (>= i@17@01 0))
; [eval] i < |a_in_1|
; [eval] |a_in_1|
(pop) ; 8
(pop) ; 7
; Joined path conditions
; Joined path conditions
(assert (or (>= i@17@01 0) (not (>= i@17@01 0))))
(push) ; 7
; [then-branch: 14 | i@17@01 >= 0 && i@17@01 < |a_in_1@11@01| | live]
; [else-branch: 14 | !(i@17@01 >= 0 && i@17@01 < |a_in_1@11@01|) | live]
(push) ; 8
; [then-branch: 14 | i@17@01 >= 0 && i@17@01 < |a_in_1@11@01|]
(assert (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in_1@11@01))))
; [eval] a_in_1[i] == 0
; [eval] a_in_1[i]
(pop) ; 8
(push) ; 8
; [else-branch: 14 | !(i@17@01 >= 0 && i@17@01 < |a_in_1@11@01|)]
(assert (not (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in_1@11@01)))))
(pop) ; 8
(pop) ; 7
; Joined path conditions
; Joined path conditions
(assert (or
  (not (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in_1@11@01))))
  (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in_1@11@01)))))
(pop) ; 6
(push) ; 6
; [else-branch: 12 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (=>
  p1_1@9@01
  (and
    p1_1@9@01
    (or (>= i@17@01 0) (not (>= i@17@01 0)))
    (or
      (not (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in_1@11@01))))
      (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in_1@11@01)))))))
; Joined path conditions
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (=>
  (=>
    (and p0_1@8@01 (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
    (= (Seq_index a_in@10@01 i@17@01) 0))
  (and
    (=>
      (and p0_1@8@01 (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
      (= (Seq_index a_in@10@01 i@17@01) 0))
    (=>
      p1_1@9@01
      (and
        p1_1@9@01
        (or (>= i@17@01 0) (not (>= i@17@01 0)))
        (or
          (not (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in_1@11@01))))
          (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in_1@11@01)))))))))
(assert (or
  (=>
    (and p0_1@8@01 (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
    (= (Seq_index a_in@10@01 i@17@01) 0))
  (not
    (=>
      (and p0_1@8@01 (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
      (= (Seq_index a_in@10@01 i@17@01) 0)))))
(pop) ; 2
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@17@01 Int)) (!
  (and
    (=>
      p0_1@8@01
      (and
        p0_1@8@01
        (or (>= i@17@01 0) (not (>= i@17@01 0)))
        (or
          (not (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
          (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))))
    (=>
      (=>
        (and p0_1@8@01 (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
        (= (Seq_index a_in@10@01 i@17@01) 0))
      (and
        (=>
          (and
            p0_1@8@01
            (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
          (= (Seq_index a_in@10@01 i@17@01) 0))
        (=>
          p1_1@9@01
          (and
            p1_1@9@01
            (or (>= i@17@01 0) (not (>= i@17@01 0)))
            (or
              (not (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in_1@11@01))))
              (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in_1@11@01))))))))
    (or
      (=>
        (and p0_1@8@01 (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
        (= (Seq_index a_in@10@01 i@17@01) 0))
      (not
        (=>
          (and
            p0_1@8@01
            (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
          (= (Seq_index a_in@10@01 i@17@01) 0)))))
  :pattern ((Seq_index a_in@10@01 i@17@01))
  :qid |prog./root/evaluation/2_performance/sequences/smith.vpr@3@82@3@229-aux|)))
(assert (forall ((i@17@01 Int)) (!
  (and
    (=>
      p0_1@8@01
      (and
        p0_1@8@01
        (or (>= i@17@01 0) (not (>= i@17@01 0)))
        (or
          (not (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
          (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))))
    (=>
      (=>
        (and p0_1@8@01 (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
        (= (Seq_index a_in@10@01 i@17@01) 0))
      (and
        (=>
          (and
            p0_1@8@01
            (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
          (= (Seq_index a_in@10@01 i@17@01) 0))
        (=>
          p1_1@9@01
          (and
            p1_1@9@01
            (or (>= i@17@01 0) (not (>= i@17@01 0)))
            (or
              (not (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in_1@11@01))))
              (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in_1@11@01))))))))
    (or
      (=>
        (and p0_1@8@01 (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
        (= (Seq_index a_in@10@01 i@17@01) 0))
      (not
        (=>
          (and
            p0_1@8@01
            (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
          (= (Seq_index a_in@10@01 i@17@01) 0)))))
  :pattern ((Seq_index a_in_1@11@01 i@17@01))
  :qid |prog./root/evaluation/2_performance/sequences/smith.vpr@3@82@3@229-aux|)))
(assert (forall ((i@17@01 Int)) (!
  (and
    (=>
      (and p0_1@8@01 (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in@10@01))))
      (= (Seq_index a_in@10@01 i@17@01) 0))
    (=>
      (and p1_1@9@01 (and (>= i@17@01 0) (< i@17@01 (Seq_length a_in_1@11@01))))
      (= (Seq_index a_in_1@11@01 i@17@01) 0)))
  :pattern ((Seq_index a_in@10@01 i@17@01))
  :pattern ((Seq_index a_in_1@11@01 i@17@01))
  :qid |prog./root/evaluation/2_performance/sequences/smith.vpr@3@82@3@229|)))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
(declare-const $t@18@01 $Snap)
(assert (= $t@18@01 ($Snap.combine ($Snap.first $t@18@01) ($Snap.second $t@18@01))))
(assert (= ($Snap.first $t@18@01) $Snap.unit))
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 3
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 15 | p0_1@8@01 | live]
; [else-branch: 15 | !(p0_1@8@01) | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 15 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] p0_1 && p1_1 ==> leak == leak_1
; [eval] p0_1 && p1_1
(push) ; 5
; [then-branch: 16 | !(p0_1@8@01) | live]
; [else-branch: 16 | p0_1@8@01 | live]
(push) ; 6
; [then-branch: 16 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 6
(push) ; 6
; [else-branch: 16 | p0_1@8@01]
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (or p0_1@8@01 (not p0_1@8@01)))
(push) ; 5
(push) ; 6
(set-option :rlimit 16000)
(assert (not (not (and p0_1@8@01 p1_1@9@01))))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
(set-option :rlimit 16000)
(assert (not (and p0_1@8@01 p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [then-branch: 17 | p0_1@8@01 && p1_1@9@01 | live]
; [else-branch: 17 | !(p0_1@8@01 && p1_1@9@01) | live]
(set-option :rlimit 0)
(push) ; 6
; [then-branch: 17 | p0_1@8@01 && p1_1@9@01]
(assert (and p0_1@8@01 p1_1@9@01))
; [eval] leak == leak_1
(pop) ; 6
(push) ; 6
; [else-branch: 17 | !(p0_1@8@01 && p1_1@9@01)]
(assert (not (and p0_1@8@01 p1_1@9@01)))
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (or (not (and p0_1@8@01 p1_1@9@01)) (and p0_1@8@01 p1_1@9@01)))
(pop) ; 4
(push) ; 4
; [else-branch: 15 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (=> (and p0_1@8@01 (and p0_1@8@01 p1_1@9@01)) (= leak@14@01 leak_1@15@01)))
(assert (= ($Snap.second $t@18@01) $Snap.unit))
; [eval] p1_1 ==> true
(push) ; 3
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 18 | p1_1@9@01 | live]
; [else-branch: 18 | !(p1_1@9@01) | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 18 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 4
(push) ; 4
; [else-branch: 18 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(pop) ; 2
(push) ; 2
; [exec]
; var a: Seq[Int]
(declare-const a@19@01 Seq<Int>)
; [exec]
; var i: Int
(declare-const i@20@01 Int)
; [exec]
; var _cond0: Bool
(declare-const _cond0@21@01 Bool)
; [exec]
; var a_1: Seq[Int]
(declare-const a_1@22@01 Seq<Int>)
; [exec]
; var i_1: Int
(declare-const i_1@23@01 Int)
; [exec]
; var _cond0_1: Bool
(declare-const _cond0_1@24@01 Bool)
; [exec]
; var tmp0_1: Int
(declare-const tmp0_1@25@01 Int)
; [exec]
; var tmp1_1: Int
(declare-const tmp1_1@26@01 Int)
; [exec]
; var tmp0_2: Int
(declare-const tmp0_2@27@01 Int)
; [exec]
; var tmp1_2: Int
(declare-const tmp1_2@28@01 Int)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 19 | p0_1@8@01 | live]
; [else-branch: 19 | !(p0_1@8@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 19 | p0_1@8@01]
(assert p0_1@8@01)
; [exec]
; _cond0 := false
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 20 | p1_1@9@01 | live]
; [else-branch: 20 | !(p1_1@9@01) | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 20 | p1_1@9@01]
(assert p1_1@9@01)
; [exec]
; _cond0_1 := false
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 21 | p0_1@8@01 | live]
; [else-branch: 21 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 21 | p0_1@8@01]
; [exec]
; a := a_in
(push) ; 6
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [then-branch: 22 | p1_1@9@01 | live]
; [else-branch: 22 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 6
; [then-branch: 22 | p1_1@9@01]
; [exec]
; a_1 := a_in_1
(push) ; 7
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 23 | p0_1@8@01 | live]
; [else-branch: 23 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 7
; [then-branch: 23 | p0_1@8@01]
; [exec]
; a := a[secret := 1]
; [eval] a[secret := 1]
(push) ; 8
(assert (not (>= secret@12@01 0)))
(check-sat)
; unsat
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
(push) ; 8
(assert (not (< secret@12@01 (Seq_length a_in@10@01))))
(check-sat)
; unsat
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
(declare-const a@29@01 Seq<Int>)
(assert (=
  a@29@01
  (Seq_append
    (Seq_take a_in@10@01 secret@12@01)
    (Seq_append (Seq_singleton 1) (Seq_drop a_in@10@01 (+ secret@12@01 1))))))
(push) ; 8
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
; [then-branch: 24 | p1_1@9@01 | live]
; [else-branch: 24 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 8
; [then-branch: 24 | p1_1@9@01]
; [exec]
; a_1 := a_1[secret_1 := 1]
; [eval] a_1[secret_1 := 1]
(push) ; 9
(assert (not (>= secret_1@13@01 0)))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(push) ; 9
(assert (not (< secret_1@13@01 (Seq_length a_in_1@11@01))))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(declare-const a_1@30@01 Seq<Int>)
(assert (=
  a_1@30@01
  (Seq_append
    (Seq_take a_in_1@11@01 secret_1@13@01)
    (Seq_append (Seq_singleton 1) (Seq_drop a_in_1@11@01 (+ secret_1@13@01 1))))))
; [exec]
; inhale p0_1 && p1_1 ==> secret == secret_1
(declare-const $t@31@01 $Snap)
(assert (= $t@31@01 $Snap.unit))
; [eval] p0_1 && p1_1 ==> secret == secret_1
; [eval] p0_1 && p1_1
(push) ; 9
; [then-branch: 25 | !(p0_1@8@01) | live]
; [else-branch: 25 | p0_1@8@01 | live]
(push) ; 10
; [then-branch: 25 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 10
(push) ; 10
; [else-branch: 25 | p0_1@8@01]
(pop) ; 10
(pop) ; 9
; Joined path conditions
; Joined path conditions
(assert (or p0_1@8@01 (not p0_1@8@01)))
(push) ; 9
(push) ; 10
(set-option :rlimit 16000)
(assert (not (not (and p0_1@8@01 p1_1@9@01))))
(check-sat)
; unknown
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 10
(set-option :rlimit 16000)
(assert (not (and p0_1@8@01 p1_1@9@01)))
(check-sat)
; unsat
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
; [then-branch: 26 | p0_1@8@01 && p1_1@9@01 | live]
; [else-branch: 26 | !(p0_1@8@01 && p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 10
; [then-branch: 26 | p0_1@8@01 && p1_1@9@01]
(assert (and p0_1@8@01 p1_1@9@01))
; [eval] secret == secret_1
(pop) ; 10
(pop) ; 9
; Joined path conditions
(assert (and p0_1@8@01 p1_1@9@01))
(assert (=> (and p0_1@8@01 p1_1@9@01) (= secret@12@01 secret_1@13@01)))
; State saturation: after inhale
(set-option :rlimit 32000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
; [then-branch: 27 | p0_1@8@01 | live]
; [else-branch: 27 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 9
; [then-branch: 27 | p0_1@8@01]
; [exec]
; i := 0
(push) ; 10
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
; [then-branch: 28 | p1_1@9@01 | live]
; [else-branch: 28 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 10
; [then-branch: 28 | p1_1@9@01]
; [exec]
; i_1 := 0
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 29 | p0_1@8@01 | live]
; [else-branch: 29 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 29 | p0_1@8@01]
; [exec]
; leak := 0
(push) ; 12
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 12
; 0.00s
; (get-info :all-statistics)
; [then-branch: 30 | p1_1@9@01 | live]
; [else-branch: 30 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 12
; [then-branch: 30 | p1_1@9@01]
; [exec]
; leak_1 := 0
; [eval] !p0_1
; [then-branch: 31 | !(p0_1@8@01) | dead]
; [else-branch: 31 | p0_1@8@01 | live]
(push) ; 13
; [else-branch: 31 | p0_1@8@01]
(pop) ; 13
; [eval] !!p0_1
; [eval] !p0_1
(push) ; 13
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 13
; 0.00s
; (get-info :all-statistics)
; [then-branch: 32 | p0_1@8@01 | live]
; [else-branch: 32 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 13
; [then-branch: 32 | p0_1@8@01]
; [eval] !p1_1
; [then-branch: 33 | !(p1_1@9@01) | dead]
; [else-branch: 33 | p1_1@9@01 | live]
(push) ; 14
; [else-branch: 33 | p1_1@9@01]
(pop) ; 14
; [eval] !!p1_1
; [eval] !p1_1
(push) ; 14
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 14
; 0.00s
; (get-info :all-statistics)
; [then-branch: 34 | p1_1@9@01 | live]
; [else-branch: 34 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 14
; [then-branch: 34 | p1_1@9@01]
; [eval] !p0_1
; [then-branch: 35 | !(p0_1@8@01) | dead]
; [else-branch: 35 | p0_1@8@01 | live]
(push) ; 15
; [else-branch: 35 | p0_1@8@01]
(pop) ; 15
; [eval] !!p0_1
; [eval] !p0_1
(push) ; 15
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
; [then-branch: 36 | p0_1@8@01 | live]
; [else-branch: 36 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 15
; [then-branch: 36 | p0_1@8@01]
; [eval] !p1_1
; [then-branch: 37 | !(p1_1@9@01) | dead]
; [else-branch: 37 | p1_1@9@01 | live]
(push) ; 16
; [else-branch: 37 | p1_1@9@01]
(pop) ; 16
; [eval] !!p1_1
; [eval] !p1_1
(push) ; 16
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [then-branch: 38 | p1_1@9@01 | live]
; [else-branch: 38 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 16
; [then-branch: 38 | p1_1@9@01]
(declare-const p0_2@32@01 Bool)
(declare-const p1_2@33@01 Bool)
(declare-const pt0_0@34@01 Bool)
(declare-const pt1_0@35@01 Bool)
(declare-const pf0_0@36@01 Bool)
(declare-const pf1_0@37@01 Bool)
(declare-const leak@38@01 Int)
(declare-const leak_1@39@01 Int)
(declare-const i@40@01 Int)
(declare-const i_1@41@01 Int)
(push) ; 17
; Loop head block: Check well-definedness of invariant
(declare-const $t@42@01 $Snap)
(assert (= $t@42@01 ($Snap.combine ($Snap.first $t@42@01) ($Snap.second $t@42@01))))
(assert (= ($Snap.first $t@42@01) $Snap.unit))
; [eval] p0_1 ==> i >= 0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 39 | p0_1@8@01 | live]
; [else-branch: 39 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 39 | p0_1@8@01]
; [eval] i >= 0
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> p0_1@8@01 (>= i@40@01 0)))
(assert (=
  ($Snap.second $t@42@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@42@01))
    ($Snap.second ($Snap.second $t@42@01)))))
(assert (= ($Snap.first ($Snap.second $t@42@01)) $Snap.unit))
; [eval] p1_1 ==> i_1 >= 0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.01s
; (get-info :all-statistics)
; [then-branch: 40 | p1_1@9@01 | live]
; [else-branch: 40 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 40 | p1_1@9@01]
; [eval] i_1 >= 0
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> p1_1@9@01 (>= i_1@41@01 0)))
(assert (=
  ($Snap.second ($Snap.second $t@42@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@42@01)))
    ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@42@01))) $Snap.unit))
; [eval] p0_1 ==> i <= |a|
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 41 | p0_1@8@01 | live]
; [else-branch: 41 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 41 | p0_1@8@01]
; [eval] i <= |a|
; [eval] |a|
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> p0_1@8@01 (<= i@40@01 (Seq_length a@29@01))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second $t@42@01)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@42@01))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@42@01))))
  $Snap.unit))
; [eval] p1_1 ==> i_1 <= |a_1|
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 42 | p1_1@9@01 | live]
; [else-branch: 42 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 42 | p1_1@9@01]
; [eval] i_1 <= |a_1|
; [eval] |a_1|
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> p1_1@9@01 (<= i_1@41@01 (Seq_length a_1@30@01))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))
  $Snap.unit))
; [eval] (forall j: Int ::(p0_1 ==> true) && (p1_1 ==> true))
(declare-const j@43@01 Int)
(push) ; 18
; [eval] (p0_1 ==> true) && (p1_1 ==> true)
; [eval] p0_1 ==> true
(push) ; 19
(push) ; 20
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 20
; 0.01s
; (get-info :all-statistics)
; [then-branch: 43 | p0_1@8@01 | live]
; [else-branch: 43 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 43 | p0_1@8@01]
(pop) ; 20
(pop) ; 19
; Joined path conditions
(push) ; 19
; [then-branch: 44 | False | live]
; [else-branch: 44 | True | live]
(push) ; 20
; [then-branch: 44 | False]
(assert false)
(pop) ; 20
(push) ; 20
; [else-branch: 44 | True]
; [eval] p1_1 ==> true
(push) ; 21
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 45 | p1_1@9@01 | live]
; [else-branch: 45 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 45 | p1_1@9@01]
(pop) ; 22
(pop) ; 21
; Joined path conditions
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(pop) ; 18
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))
  $Snap.unit))
; [eval] p0_1 ==> p0_1 && p1_1 ==> i == i_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 46 | p0_1@8@01 | live]
; [else-branch: 46 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 46 | p0_1@8@01]
; [eval] p0_1 && p1_1 ==> i == i_1
; [eval] p0_1 && p1_1
(push) ; 20
; [then-branch: 47 | !(p0_1@8@01) | live]
; [else-branch: 47 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 47 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 21
(push) ; 21
; [else-branch: 47 | p0_1@8@01]
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(push) ; 20
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not (and p0_1@8@01 p1_1@9@01))))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (and p0_1@8@01 p1_1@9@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 48 | p0_1@8@01 && p1_1@9@01 | live]
; [else-branch: 48 | !(p0_1@8@01 && p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 48 | p0_1@8@01 && p1_1@9@01]
(assert (and p0_1@8@01 p1_1@9@01))
; [eval] i == i_1
(pop) ; 21
(pop) ; 20
; Joined path conditions
(assert (and p0_1@8@01 p1_1@9@01))
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> p0_1@8@01 (and p0_1@8@01 p1_1@9@01)))
(assert p0_1@8@01)
(assert (=> (and p0_1@8@01 (and p0_1@8@01 p1_1@9@01)) (= i@40@01 i_1@41@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))
  $Snap.unit))
; [eval] p1_1 ==> true
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 49 | p1_1@9@01 | live]
; [else-branch: 49 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 49 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p1_1@9@01)
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))
  $Snap.unit))
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 50 | p0_1@8@01 | live]
; [else-branch: 50 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 50 | p0_1@8@01]
; [eval] p0_1 && p1_1 ==> leak == leak_1
; [eval] p0_1 && p1_1
(push) ; 20
; [then-branch: 51 | !(p0_1@8@01) | live]
; [else-branch: 51 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 51 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 21
(push) ; 21
; [else-branch: 51 | p0_1@8@01]
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(push) ; 20
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not (and p0_1@8@01 p1_1@9@01))))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (and p0_1@8@01 p1_1@9@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 52 | p0_1@8@01 && p1_1@9@01 | live]
; [else-branch: 52 | !(p0_1@8@01 && p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 52 | p0_1@8@01 && p1_1@9@01]
(assert (and p0_1@8@01 p1_1@9@01))
; [eval] leak == leak_1
(pop) ; 21
(pop) ; 20
; Joined path conditions
(assert (and p0_1@8@01 p1_1@9@01))
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p0_1@8@01)
(assert (=> (and p0_1@8@01 (and p0_1@8@01 p1_1@9@01)) (= leak@38@01 leak_1@39@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))
  $Snap.unit))
; [eval] p1_1 ==> true
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 53 | p1_1@9@01 | live]
; [else-branch: 53 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 53 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p1_1@9@01)
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))
  $Snap.unit))
; [eval] !p0_1 ==> tmp0_1 == leak
; [eval] !p0_1
(push) ; 18
; [then-branch: 54 | !(p0_1@8@01) | dead]
; [else-branch: 54 | p0_1@8@01 | live]
(push) ; 19
; [else-branch: 54 | p0_1@8@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))))
  $Snap.unit))
; [eval] !p0_1 ==> tmp0_2 == i
; [eval] !p0_1
(push) ; 18
; [then-branch: 55 | !(p0_1@8@01) | dead]
; [else-branch: 55 | p0_1@8@01 | live]
(push) ; 19
; [else-branch: 55 | p0_1@8@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))))
  $Snap.unit))
; [eval] !p1_1 ==> tmp1_2 == i_1
; [eval] !p1_1
(push) ; 18
; [then-branch: 56 | !(p1_1@9@01) | dead]
; [else-branch: 56 | p1_1@9@01 | live]
(push) ; 19
; [else-branch: 56 | p1_1@9@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))))
  $Snap.unit))
; [eval] !p1_1 ==> tmp1_1 == leak_1
; [eval] !p1_1
(push) ; 18
; [then-branch: 57 | !(p1_1@9@01) | dead]
; [else-branch: 57 | p1_1@9@01 | live]
(push) ; 19
; [else-branch: 57 | p1_1@9@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(pop) ; 17
(push) ; 17
; Loop head block: Establish invariant
; [eval] p0_1 ==> i >= 0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 58 | p0_1@8@01 | live]
; [else-branch: 58 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 58 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i >= 0
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p0_1@8@01)
; [eval] p1_1 ==> i_1 >= 0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 59 | p1_1@9@01 | live]
; [else-branch: 59 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 59 | p1_1@9@01]
(assert p1_1@9@01)
; [eval] i_1 >= 0
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p1_1@9@01)
; [eval] p0_1 ==> i <= |a|
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 60 | p0_1@8@01 | live]
; [else-branch: 60 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 60 | p0_1@8@01]
; [eval] i <= |a|
; [eval] |a|
(pop) ; 19
(pop) ; 18
; Joined path conditions
(push) ; 18
(assert (not (=> p0_1@8@01 (<= 0 (Seq_length a@29@01)))))
(check-sat)
; unsat
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
(assert (=> p0_1@8@01 (<= 0 (Seq_length a@29@01))))
; [eval] p1_1 ==> i_1 <= |a_1|
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 61 | p1_1@9@01 | live]
; [else-branch: 61 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 61 | p1_1@9@01]
; [eval] i_1 <= |a_1|
; [eval] |a_1|
(pop) ; 19
(pop) ; 18
; Joined path conditions
(push) ; 18
(assert (not (=> p1_1@9@01 (<= 0 (Seq_length a_1@30@01)))))
(check-sat)
; unsat
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
(assert (=> p1_1@9@01 (<= 0 (Seq_length a_1@30@01))))
; [eval] (forall j: Int ::(p0_1 ==> true) && (p1_1 ==> true))
(declare-const j@44@01 Int)
(push) ; 18
; [eval] (p0_1 ==> true) && (p1_1 ==> true)
; [eval] p0_1 ==> true
(push) ; 19
(push) ; 20
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 62 | p0_1@8@01 | live]
; [else-branch: 62 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 62 | p0_1@8@01]
(pop) ; 20
(pop) ; 19
; Joined path conditions
(push) ; 19
; [then-branch: 63 | False | live]
; [else-branch: 63 | True | live]
(push) ; 20
; [then-branch: 63 | False]
(assert false)
(pop) ; 20
(push) ; 20
; [else-branch: 63 | True]
; [eval] p1_1 ==> true
(push) ; 21
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 64 | p1_1@9@01 | live]
; [else-branch: 64 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 64 | p1_1@9@01]
(pop) ; 22
(pop) ; 21
; Joined path conditions
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(pop) ; 18
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
; [eval] p0_1 ==> p0_1 && p1_1 ==> i == i_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 65 | p0_1@8@01 | live]
; [else-branch: 65 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 65 | p0_1@8@01]
; [eval] p0_1 && p1_1 ==> i == i_1
; [eval] p0_1 && p1_1
(push) ; 20
; [then-branch: 66 | !(p0_1@8@01) | live]
; [else-branch: 66 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 66 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 21
(push) ; 21
; [else-branch: 66 | p0_1@8@01]
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(push) ; 20
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not (and p0_1@8@01 p1_1@9@01))))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (and p0_1@8@01 p1_1@9@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 67 | p0_1@8@01 && p1_1@9@01 | live]
; [else-branch: 67 | !(p0_1@8@01 && p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 67 | p0_1@8@01 && p1_1@9@01]
(assert (and p0_1@8@01 p1_1@9@01))
; [eval] i == i_1
(pop) ; 21
(pop) ; 20
; Joined path conditions
(assert (and p0_1@8@01 p1_1@9@01))
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> p0_1@8@01 (and p0_1@8@01 p1_1@9@01)))
(assert p0_1@8@01)
; [eval] p1_1 ==> true
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 68 | p1_1@9@01 | live]
; [else-branch: 68 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 68 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p1_1@9@01)
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 69 | p0_1@8@01 | live]
; [else-branch: 69 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 69 | p0_1@8@01]
; [eval] p0_1 && p1_1 ==> leak == leak_1
; [eval] p0_1 && p1_1
(push) ; 20
; [then-branch: 70 | !(p0_1@8@01) | live]
; [else-branch: 70 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 70 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 21
(push) ; 21
; [else-branch: 70 | p0_1@8@01]
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(push) ; 20
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not (and p0_1@8@01 p1_1@9@01))))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (and p0_1@8@01 p1_1@9@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 71 | p0_1@8@01 && p1_1@9@01 | live]
; [else-branch: 71 | !(p0_1@8@01 && p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 71 | p0_1@8@01 && p1_1@9@01]
(assert (and p0_1@8@01 p1_1@9@01))
; [eval] leak == leak_1
(pop) ; 21
(pop) ; 20
; Joined path conditions
(assert (and p0_1@8@01 p1_1@9@01))
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p0_1@8@01)
; [eval] p1_1 ==> true
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 72 | p1_1@9@01 | live]
; [else-branch: 72 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 72 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p1_1@9@01)
; [eval] !p0_1 ==> tmp0_1 == leak
; [eval] !p0_1
(push) ; 18
; [then-branch: 73 | !(p0_1@8@01) | dead]
; [else-branch: 73 | p0_1@8@01 | live]
(push) ; 19
; [else-branch: 73 | p0_1@8@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p0_1 ==> tmp0_2 == i
; [eval] !p0_1
(push) ; 18
; [then-branch: 74 | !(p0_1@8@01) | dead]
; [else-branch: 74 | p0_1@8@01 | live]
(push) ; 19
; [else-branch: 74 | p0_1@8@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p1_1 ==> tmp1_2 == i_1
; [eval] !p1_1
(push) ; 18
; [then-branch: 75 | !(p1_1@9@01) | dead]
; [else-branch: 75 | p1_1@9@01 | live]
(push) ; 19
; [else-branch: 75 | p1_1@9@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p1_1 ==> tmp1_1 == leak_1
; [eval] !p1_1
(push) ; 18
; [then-branch: 76 | !(p1_1@9@01) | dead]
; [else-branch: 76 | p1_1@9@01 | live]
(push) ; 19
; [else-branch: 76 | p1_1@9@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; Loop head block: Execute statements of loop head block (in invariant state)
(push) ; 18
(assert (= $t@42@01 ($Snap.combine ($Snap.first $t@42@01) ($Snap.second $t@42@01))))
(assert (= ($Snap.first $t@42@01) $Snap.unit))
(assert (=> p0_1@8@01 (>= i@40@01 0)))
(assert (=
  ($Snap.second $t@42@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@42@01))
    ($Snap.second ($Snap.second $t@42@01)))))
(assert (= ($Snap.first ($Snap.second $t@42@01)) $Snap.unit))
(assert (=> p1_1@9@01 (>= i_1@41@01 0)))
(assert (=
  ($Snap.second ($Snap.second $t@42@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@42@01)))
    ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@42@01))) $Snap.unit))
(assert (=> p0_1@8@01 (<= i@40@01 (Seq_length a@29@01))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second $t@42@01)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@42@01))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@42@01))))
  $Snap.unit))
(assert (=> p1_1@9@01 (<= i_1@41@01 (Seq_length a_1@30@01))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))
  $Snap.unit))
(assert (=> (and p0_1@8@01 (and p0_1@8@01 p1_1@9@01)) (= i@40@01 i_1@41@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))
  $Snap.unit))
(assert (=> (and p0_1@8@01 (and p0_1@8@01 p1_1@9@01)) (= leak@38@01 leak_1@39@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01)))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@42@01))))))))))))
  $Snap.unit))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 16000)
(check-sat)
; unknown
; Loop head block: Check well-definedness of edge conditions
(set-option :rlimit 0)
(push) ; 19
; [eval] p0_1 && i < |a| || p1_1 && i_1 < |a_1|
; [eval] p0_1 && i < |a|
(push) ; 20
; [then-branch: 77 | !(p0_1@8@01) | live]
; [else-branch: 77 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 77 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 21
(push) ; 21
; [else-branch: 77 | p0_1@8@01]
; [eval] i < |a|
; [eval] |a|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(push) ; 20
; [then-branch: 78 | p0_1@8@01 && i@40@01 < |a@29@01| | live]
; [else-branch: 78 | !(p0_1@8@01 && i@40@01 < |a@29@01|) | live]
(push) ; 21
; [then-branch: 78 | p0_1@8@01 && i@40@01 < |a@29@01|]
(assert (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01))))
(pop) ; 21
(push) ; 21
; [else-branch: 78 | !(p0_1@8@01 && i@40@01 < |a@29@01|)]
(assert (not (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01)))))
; [eval] p1_1 && i_1 < |a_1|
(push) ; 22
; [then-branch: 79 | !(p1_1@9@01) | live]
; [else-branch: 79 | p1_1@9@01 | live]
(push) ; 23
; [then-branch: 79 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 23
(push) ; 23
; [else-branch: 79 | p1_1@9@01]
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 23
(pop) ; 22
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01))))
  (and
    (not (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01))))
    (or p1_1@9@01 (not p1_1@9@01)))))
(assert (or
  (not (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01))))
  (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01)))))
(pop) ; 19
(push) ; 19
; [eval] !(p0_1 && i < |a| || p1_1 && i_1 < |a_1|)
; [eval] p0_1 && i < |a| || p1_1 && i_1 < |a_1|
; [eval] p0_1 && i < |a|
(push) ; 20
; [then-branch: 80 | !(p0_1@8@01) | live]
; [else-branch: 80 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 80 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 21
(push) ; 21
; [else-branch: 80 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(push) ; 20
; [then-branch: 81 | p0_1@8@01 && i@40@01 < |a@29@01| | live]
; [else-branch: 81 | !(p0_1@8@01 && i@40@01 < |a@29@01|) | live]
(push) ; 21
; [then-branch: 81 | p0_1@8@01 && i@40@01 < |a@29@01|]
(assert (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01))))
(pop) ; 21
(push) ; 21
; [else-branch: 81 | !(p0_1@8@01 && i@40@01 < |a@29@01|)]
(assert (not (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01)))))
; [eval] p1_1 && i_1 < |a_1|
(push) ; 22
; [then-branch: 82 | !(p1_1@9@01) | live]
; [else-branch: 82 | p1_1@9@01 | live]
(push) ; 23
; [then-branch: 82 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 23
(push) ; 23
; [else-branch: 82 | p1_1@9@01]
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 23
(pop) ; 22
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01))))
  (and
    (not (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01))))
    (or p1_1@9@01 (not p1_1@9@01)))))
(assert (or
  (not (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01))))
  (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01)))))
(pop) ; 19
; Loop head block: Follow loop-internal edges
; [eval] p0_1 && i < |a| || p1_1 && i_1 < |a_1|
; [eval] p0_1 && i < |a|
(push) ; 19
; [then-branch: 83 | !(p0_1@8@01) | live]
; [else-branch: 83 | p0_1@8@01 | live]
(push) ; 20
; [then-branch: 83 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 20
(push) ; 20
; [else-branch: 83 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(push) ; 19
; [then-branch: 84 | p0_1@8@01 && i@40@01 < |a@29@01| | live]
; [else-branch: 84 | !(p0_1@8@01 && i@40@01 < |a@29@01|) | live]
(push) ; 20
; [then-branch: 84 | p0_1@8@01 && i@40@01 < |a@29@01|]
(assert (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01))))
(pop) ; 20
(push) ; 20
; [else-branch: 84 | !(p0_1@8@01 && i@40@01 < |a@29@01|)]
(assert (not (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01)))))
; [eval] p1_1 && i_1 < |a_1|
(push) ; 21
; [then-branch: 85 | !(p1_1@9@01) | live]
; [else-branch: 85 | p1_1@9@01 | live]
(push) ; 22
; [then-branch: 85 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 22
(push) ; 22
; [else-branch: 85 | p1_1@9@01]
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01))))
  (and
    (not (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01))))
    (or p1_1@9@01 (not p1_1@9@01)))))
(assert (or
  (not (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01))))
  (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01)))))
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not
  (or
    (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01)))
    (and p1_1@9@01 (< i_1@41@01 (Seq_length a_1@30@01)))))))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not (or
  (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01)))
  (and p1_1@9@01 (< i_1@41@01 (Seq_length a_1@30@01))))))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 86 | p0_1@8@01 && i@40@01 < |a@29@01| || p1_1@9@01 && i_1@41@01 < |a_1@30@01| | live]
; [else-branch: 86 | !(p0_1@8@01 && i@40@01 < |a@29@01| || p1_1@9@01 && i_1@41@01 < |a_1@30@01|) | live]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 86 | p0_1@8@01 && i@40@01 < |a@29@01| || p1_1@9@01 && i_1@41@01 < |a_1@30@01|]
(assert (or
  (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01)))
  (and p1_1@9@01 (< i_1@41@01 (Seq_length a_1@30@01)))))
; [exec]
; var p0_2: Bool
(declare-const p0_2@45@01 Bool)
; [exec]
; var p1_2: Bool
(declare-const p1_2@46@01 Bool)
; [exec]
; var pt0_0: Bool
(declare-const pt0_0@47@01 Bool)
; [exec]
; var pt1_0: Bool
(declare-const pt1_0@48@01 Bool)
; [exec]
; var pf0_0: Bool
(declare-const pf0_0@49@01 Bool)
; [exec]
; var pf1_0: Bool
(declare-const pf1_0@50@01 Bool)
; [exec]
; p0_2 := p0_1 && i < |a|
; [eval] p0_1 && i < |a|
(push) ; 20
; [then-branch: 87 | !(p0_1@8@01) | live]
; [else-branch: 87 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 87 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 21
(push) ; 21
; [else-branch: 87 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(declare-const p0_2@51@01 Bool)
(assert (= p0_2@51@01 (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01)))))
; [exec]
; p1_2 := p1_1 && i_1 < |a_1|
; [eval] p1_1 && i_1 < |a_1|
(push) ; 20
; [then-branch: 88 | !(p1_1@9@01) | live]
; [else-branch: 88 | p1_1@9@01 | live]
(push) ; 21
; [then-branch: 88 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 21
(push) ; 21
; [else-branch: 88 | p1_1@9@01]
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(declare-const p1_2@52@01 Bool)
(assert (= p1_2@52@01 (and p1_1@9@01 (< i_1@41@01 (Seq_length a_1@30@01)))))
; [exec]
; pt0_0 := p0_2 && a[i] == 1
; [eval] p0_2 && a[i] == 1
(push) ; 20
; [then-branch: 89 | !(p0_2@51@01) | live]
; [else-branch: 89 | p0_2@51@01 | live]
(push) ; 21
; [then-branch: 89 | !(p0_2@51@01)]
(assert (not p0_2@51@01))
(pop) ; 21
(push) ; 21
; [else-branch: 89 | p0_2@51@01]
(assert p0_2@51@01)
; [eval] a[i] == 1
; [eval] a[i]
(push) ; 22
(assert (not (>= i@40@01 0)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(push) ; 22
(assert (not (< i@40@01 (Seq_length a@29@01))))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p0_2@51@01 (not p0_2@51@01)))
(declare-const pt0_0@53@01 Bool)
(assert (= pt0_0@53@01 (and p0_2@51@01 (= (Seq_index a@29@01 i@40@01) 1))))
; [exec]
; pt1_0 := p1_2 && a_1[i_1] == 1
; [eval] p1_2 && a_1[i_1] == 1
(push) ; 20
; [then-branch: 90 | !(p1_2@52@01) | live]
; [else-branch: 90 | p1_2@52@01 | live]
(push) ; 21
; [then-branch: 90 | !(p1_2@52@01)]
(assert (not p1_2@52@01))
(pop) ; 21
(push) ; 21
; [else-branch: 90 | p1_2@52@01]
(assert p1_2@52@01)
; [eval] a_1[i_1] == 1
; [eval] a_1[i_1]
(push) ; 22
(assert (not (>= i_1@41@01 0)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(push) ; 22
(assert (not (< i_1@41@01 (Seq_length a_1@30@01))))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p1_2@52@01 (not p1_2@52@01)))
(declare-const pt1_0@54@01 Bool)
(assert (= pt1_0@54@01 (and p1_2@52@01 (= (Seq_index a_1@30@01 i_1@41@01) 1))))
; [exec]
; pf0_0 := p0_2 && !(a[i] == 1)
; [eval] p0_2 && !(a[i] == 1)
(push) ; 20
; [then-branch: 91 | !(p0_2@51@01) | live]
; [else-branch: 91 | p0_2@51@01 | live]
(push) ; 21
; [then-branch: 91 | !(p0_2@51@01)]
(assert (not p0_2@51@01))
(pop) ; 21
(push) ; 21
; [else-branch: 91 | p0_2@51@01]
(assert p0_2@51@01)
; [eval] !(a[i] == 1)
; [eval] a[i] == 1
; [eval] a[i]
(push) ; 22
(assert (not (>= i@40@01 0)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(push) ; 22
(assert (not (< i@40@01 (Seq_length a@29@01))))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(declare-const pf0_0@55@01 Bool)
(assert (= pf0_0@55@01 (and p0_2@51@01 (not (= (Seq_index a@29@01 i@40@01) 1)))))
; [exec]
; pf1_0 := p1_2 && !(a_1[i_1] == 1)
; [eval] p1_2 && !(a_1[i_1] == 1)
(push) ; 20
; [then-branch: 92 | !(p1_2@52@01) | live]
; [else-branch: 92 | p1_2@52@01 | live]
(push) ; 21
; [then-branch: 92 | !(p1_2@52@01)]
(assert (not p1_2@52@01))
(pop) ; 21
(push) ; 21
; [else-branch: 92 | p1_2@52@01]
(assert p1_2@52@01)
; [eval] !(a_1[i_1] == 1)
; [eval] a_1[i_1] == 1
; [eval] a_1[i_1]
(push) ; 22
(assert (not (>= i_1@41@01 0)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(push) ; 22
(assert (not (< i_1@41@01 (Seq_length a_1@30@01))))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(declare-const pf1_0@56@01 Bool)
(assert (= pf1_0@56@01 (and p1_2@52@01 (not (= (Seq_index a_1@30@01 i_1@41@01) 1)))))
(push) ; 20
(set-option :rlimit 16000)
(assert (not (not pt0_0@53@01)))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 20
(set-option :rlimit 16000)
(assert (not pt0_0@53@01))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 93 | pt0_0@53@01 | live]
; [else-branch: 93 | !(pt0_0@53@01) | live]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 93 | pt0_0@53@01]
(assert pt0_0@53@01)
; [exec]
; leak := i
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt1_0@54@01)))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not pt1_0@54@01))
(check-sat)
; unknown
(pop) ; 21
; 0.01s
; (get-info :all-statistics)
; [then-branch: 94 | pt1_0@54@01 | live]
; [else-branch: 94 | !(pt1_0@54@01) | live]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 94 | pt1_0@54@01]
(assert pt1_0@54@01)
; [exec]
; leak_1 := i_1
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p0_2@51@01)))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 22
(set-option :rlimit 16000)
(assert (not p0_2@51@01))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 95 | p0_2@51@01 | live]
; [else-branch: 95 | !(p0_2@51@01) | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 95 | p0_2@51@01]
(assert p0_2@51@01)
; [exec]
; i := i + 1
; [eval] i + 1
(declare-const i@57@01 Int)
(assert (= i@57@01 (+ i@40@01 1)))
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not p1_2@52@01)))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 23
(set-option :rlimit 16000)
(assert (not p1_2@52@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 96 | p1_2@52@01 | live]
; [else-branch: 96 | !(p1_2@52@01) | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 96 | p1_2@52@01]
(assert p1_2@52@01)
; [exec]
; i_1 := i_1 + 1
; [eval] i_1 + 1
(declare-const i_1@58@01 Int)
(assert (= i_1@58@01 (+ i_1@41@01 1)))
; Loop head block: Re-establish invariant
; [eval] p0_1 ==> i >= 0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 25
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 97 | p0_1@8@01 | live]
; [else-branch: 97 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 97 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i >= 0
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p0_1@8@01)
(push) ; 24
(assert (not (=> p0_1@8@01 (>= i@57@01 0))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p0_1@8@01 (>= i@57@01 0)))
; [eval] p1_1 ==> i_1 >= 0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 98 | p1_1@9@01 | live]
; [else-branch: 98 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 98 | p1_1@9@01]
; [eval] i_1 >= 0
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p1_1@9@01 (>= i_1@58@01 0))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p1_1@9@01 (>= i_1@58@01 0)))
; [eval] p0_1 ==> i <= |a|
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 99 | p0_1@8@01 | live]
; [else-branch: 99 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 99 | p0_1@8@01]
; [eval] i <= |a|
; [eval] |a|
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p0_1@8@01 (<= i@57@01 (Seq_length a@29@01)))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p0_1@8@01 (<= i@57@01 (Seq_length a@29@01))))
; [eval] p1_1 ==> i_1 <= |a_1|
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 100 | p1_1@9@01 | live]
; [else-branch: 100 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 100 | p1_1@9@01]
; [eval] i_1 <= |a_1|
; [eval] |a_1|
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p1_1@9@01 (<= i_1@58@01 (Seq_length a_1@30@01)))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p1_1@9@01 (<= i_1@58@01 (Seq_length a_1@30@01))))
; [eval] (forall j: Int ::(p0_1 ==> true) && (p1_1 ==> true))
(declare-const j@59@01 Int)
(push) ; 24
; [eval] (p0_1 ==> true) && (p1_1 ==> true)
; [eval] p0_1 ==> true
(push) ; 25
(push) ; 26
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 26
; 0.00s
; (get-info :all-statistics)
; [then-branch: 101 | p0_1@8@01 | live]
; [else-branch: 101 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 101 | p0_1@8@01]
(pop) ; 26
(pop) ; 25
; Joined path conditions
(push) ; 25
; [then-branch: 102 | False | live]
; [else-branch: 102 | True | live]
(push) ; 26
; [then-branch: 102 | False]
(assert false)
(pop) ; 26
(push) ; 26
; [else-branch: 102 | True]
; [eval] p1_1 ==> true
(push) ; 27
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 103 | p1_1@9@01 | live]
; [else-branch: 103 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 103 | p1_1@9@01]
(pop) ; 28
(pop) ; 27
; Joined path conditions
(pop) ; 26
(pop) ; 25
; Joined path conditions
; Joined path conditions
(pop) ; 24
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
; [eval] p0_1 ==> p0_1 && p1_1 ==> i == i_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 104 | p0_1@8@01 | live]
; [else-branch: 104 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 104 | p0_1@8@01]
; [eval] p0_1 && p1_1 ==> i == i_1
; [eval] p0_1 && p1_1
(push) ; 26
; [then-branch: 105 | !(p0_1@8@01) | live]
; [else-branch: 105 | p0_1@8@01 | live]
(push) ; 27
; [then-branch: 105 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 27
(push) ; 27
; [else-branch: 105 | p0_1@8@01]
(pop) ; 27
(pop) ; 26
; Joined path conditions
; Joined path conditions
(push) ; 26
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not (and p0_1@8@01 p1_1@9@01))))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 27
(set-option :rlimit 16000)
(assert (not (and p0_1@8@01 p1_1@9@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 106 | p0_1@8@01 && p1_1@9@01 | live]
; [else-branch: 106 | !(p0_1@8@01 && p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 106 | p0_1@8@01 && p1_1@9@01]
(assert (and p0_1@8@01 p1_1@9@01))
; [eval] i == i_1
(pop) ; 27
(pop) ; 26
; Joined path conditions
(assert (and p0_1@8@01 p1_1@9@01))
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p0_1@8@01)
(push) ; 24
(assert (not (=> (and p0_1@8@01 (and p0_1@8@01 p1_1@9@01)) (= i@57@01 i_1@58@01))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> (and p0_1@8@01 (and p0_1@8@01 p1_1@9@01)) (= i@57@01 i_1@58@01)))
; [eval] p1_1 ==> true
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 25
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 107 | p1_1@9@01 | live]
; [else-branch: 107 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 107 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p1_1@9@01)
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 108 | p0_1@8@01 | live]
; [else-branch: 108 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 108 | p0_1@8@01]
; [eval] p0_1 && p1_1 ==> leak == leak_1
; [eval] p0_1 && p1_1
(push) ; 26
; [then-branch: 109 | !(p0_1@8@01) | live]
; [else-branch: 109 | p0_1@8@01 | live]
(push) ; 27
; [then-branch: 109 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 27
(push) ; 27
; [else-branch: 109 | p0_1@8@01]
(pop) ; 27
(pop) ; 26
; Joined path conditions
; Joined path conditions
(push) ; 26
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not (and p0_1@8@01 p1_1@9@01))))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 27
(set-option :rlimit 16000)
(assert (not (and p0_1@8@01 p1_1@9@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 110 | p0_1@8@01 && p1_1@9@01 | live]
; [else-branch: 110 | !(p0_1@8@01 && p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 110 | p0_1@8@01 && p1_1@9@01]
(assert (and p0_1@8@01 p1_1@9@01))
; [eval] leak == leak_1
(pop) ; 27
(pop) ; 26
; Joined path conditions
(assert (and p0_1@8@01 p1_1@9@01))
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p0_1@8@01)
; [eval] p1_1 ==> true
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 25
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 111 | p1_1@9@01 | live]
; [else-branch: 111 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 111 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p1_1@9@01)
; [eval] !p0_1 ==> tmp0_1 == leak
; [eval] !p0_1
(push) ; 24
; [then-branch: 112 | !(p0_1@8@01) | dead]
; [else-branch: 112 | p0_1@8@01 | live]
(push) ; 25
; [else-branch: 112 | p0_1@8@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p0_1 ==> tmp0_2 == i
; [eval] !p0_1
(push) ; 24
; [then-branch: 113 | !(p0_1@8@01) | dead]
; [else-branch: 113 | p0_1@8@01 | live]
(push) ; 25
; [else-branch: 113 | p0_1@8@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p1_1 ==> tmp1_2 == i_1
; [eval] !p1_1
(push) ; 24
; [then-branch: 114 | !(p1_1@9@01) | dead]
; [else-branch: 114 | p1_1@9@01 | live]
(push) ; 25
; [else-branch: 114 | p1_1@9@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p1_1 ==> tmp1_1 == leak_1
; [eval] !p1_1
(push) ; 24
; [then-branch: 115 | !(p1_1@9@01) | dead]
; [else-branch: 115 | p1_1@9@01 | live]
(push) ; 25
; [else-branch: 115 | p1_1@9@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
(pop) ; 23
; [eval] !p1_2
(push) ; 23
(set-option :rlimit 16000)
(assert (not p1_2@52@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 116 | !(p1_2@52@01) | dead]
; [else-branch: 116 | p1_2@52@01 | live]
(set-option :rlimit 0)
(push) ; 23
; [else-branch: 116 | p1_2@52@01]
(assert p1_2@52@01)
(pop) ; 23
(pop) ; 22
; [eval] !p0_2
(push) ; 22
(set-option :rlimit 16000)
(assert (not p0_2@51@01))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 117 | !(p0_2@51@01) | dead]
; [else-branch: 117 | p0_2@51@01 | live]
(set-option :rlimit 0)
(push) ; 22
; [else-branch: 117 | p0_2@51@01]
(assert p0_2@51@01)
(pop) ; 22
(pop) ; 21
(push) ; 21
; [else-branch: 94 | !(pt1_0@54@01)]
(assert (not pt1_0@54@01))
(pop) ; 21
; [eval] !pt1_0
(push) ; 21
(set-option :rlimit 16000)
(assert (not pt1_0@54@01))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt1_0@54@01)))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 118 | !(pt1_0@54@01) | live]
; [else-branch: 118 | pt1_0@54@01 | live]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 118 | !(pt1_0@54@01)]
(assert (not pt1_0@54@01))
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p0_2@51@01)))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 22
(set-option :rlimit 16000)
(assert (not p0_2@51@01))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 119 | p0_2@51@01 | live]
; [else-branch: 119 | !(p0_2@51@01) | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 119 | p0_2@51@01]
(assert p0_2@51@01)
; [exec]
; i := i + 1
; [eval] i + 1
(declare-const i@60@01 Int)
(assert (= i@60@01 (+ i@40@01 1)))
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not p1_2@52@01)))
(check-sat)
; unknown
(pop) ; 23
; 0.01s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 23
(set-option :rlimit 16000)
(assert (not p1_2@52@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 120 | p1_2@52@01 | live]
; [else-branch: 120 | !(p1_2@52@01) | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 120 | p1_2@52@01]
(assert p1_2@52@01)
; [exec]
; i_1 := i_1 + 1
; [eval] i_1 + 1
(declare-const i_1@61@01 Int)
(assert (= i_1@61@01 (+ i_1@41@01 1)))
; Loop head block: Re-establish invariant
; [eval] p0_1 ==> i >= 0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unsat
(pop) ; 25
; 0.01s
; (get-info :all-statistics)
; [then-branch: 121 | p0_1@8@01 | dead]
; [else-branch: 121 | !(p0_1@8@01) | live]
(set-option :rlimit 0)
(push) ; 25
; [else-branch: 121 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert (not p0_1@8@01))
; [eval] p1_1 ==> i_1 >= 0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 122 | p1_1@9@01 | dead]
; [else-branch: 122 | !(p1_1@9@01) | live]
(set-option :rlimit 0)
(push) ; 25
; [else-branch: 122 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert (not p1_1@9@01))
; [eval] p0_1 ==> i <= |a|
(push) ; 24
; [then-branch: 123 | p0_1@8@01 | dead]
; [else-branch: 123 | !(p0_1@8@01) | live]
(push) ; 25
; [else-branch: 123 | !(p0_1@8@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p1_1 ==> i_1 <= |a_1|
(push) ; 24
; [then-branch: 124 | p1_1@9@01 | dead]
; [else-branch: 124 | !(p1_1@9@01) | live]
(push) ; 25
; [else-branch: 124 | !(p1_1@9@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] (forall j: Int ::(p0_1 ==> true) && (p1_1 ==> true))
(declare-const j@62@01 Int)
(push) ; 24
; [eval] (p0_1 ==> true) && (p1_1 ==> true)
; [eval] p0_1 ==> true
(push) ; 25
; [then-branch: 125 | p0_1@8@01 | dead]
; [else-branch: 125 | !(p0_1@8@01) | live]
(push) ; 26
; [else-branch: 125 | !(p0_1@8@01)]
(pop) ; 26
(pop) ; 25
; Joined path conditions
(push) ; 25
; [then-branch: 126 | False | live]
; [else-branch: 126 | True | live]
(push) ; 26
; [then-branch: 126 | False]
(assert false)
(pop) ; 26
(push) ; 26
; [else-branch: 126 | True]
; [eval] p1_1 ==> true
(push) ; 27
; [then-branch: 127 | p1_1@9@01 | dead]
; [else-branch: 127 | !(p1_1@9@01) | live]
(push) ; 28
; [else-branch: 127 | !(p1_1@9@01)]
(pop) ; 28
(pop) ; 27
; Joined path conditions
(pop) ; 26
(pop) ; 25
; Joined path conditions
; Joined path conditions
(pop) ; 24
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
; [eval] p0_1 ==> p0_1 && p1_1 ==> i == i_1
(push) ; 24
; [then-branch: 128 | p0_1@8@01 | dead]
; [else-branch: 128 | !(p0_1@8@01) | live]
(push) ; 25
; [else-branch: 128 | !(p0_1@8@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 24
; [then-branch: 129 | p1_1@9@01 | dead]
; [else-branch: 129 | !(p1_1@9@01) | live]
(push) ; 25
; [else-branch: 129 | !(p1_1@9@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 24
; [then-branch: 130 | p0_1@8@01 | dead]
; [else-branch: 130 | !(p0_1@8@01) | live]
(push) ; 25
; [else-branch: 130 | !(p0_1@8@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 24
; [then-branch: 131 | p1_1@9@01 | dead]
; [else-branch: 131 | !(p1_1@9@01) | live]
(push) ; 25
; [else-branch: 131 | !(p1_1@9@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p0_1 ==> tmp0_1 == leak
; [eval] !p0_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 132 | !(p0_1@8@01) | dead]
; [else-branch: 132 | p0_1@8@01 | live]
(set-option :rlimit 0)
(push) ; 25
; [else-branch: 132 | p0_1@8@01]
(assert p0_1@8@01)
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p0_1@8@01)
; [eval] !p0_1 ==> tmp0_2 == i
; [eval] !p0_1
(push) ; 24
; [then-branch: 133 | !(p0_1@8@01) | dead]
; [else-branch: 133 | p0_1@8@01 | live]
(push) ; 25
; [else-branch: 133 | p0_1@8@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p1_1 ==> tmp1_2 == i_1
; [eval] !p1_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 134 | !(p1_1@9@01) | dead]
; [else-branch: 134 | p1_1@9@01 | live]
(set-option :rlimit 0)
(push) ; 25
; [else-branch: 134 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p1_1@9@01)
; [eval] !p1_1 ==> tmp1_1 == leak_1
; [eval] !p1_1
(push) ; 24
; [then-branch: 135 | !(p1_1@9@01) | dead]
; [else-branch: 135 | p1_1@9@01 | live]
(push) ; 25
; [else-branch: 135 | p1_1@9@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
(pop) ; 23
; [eval] !p1_2
(push) ; 23
(set-option :rlimit 16000)
(assert (not p1_2@52@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 136 | !(p1_2@52@01) | dead]
; [else-branch: 136 | p1_2@52@01 | live]
(set-option :rlimit 0)
(push) ; 23
; [else-branch: 136 | p1_2@52@01]
(assert p1_2@52@01)
(pop) ; 23
(pop) ; 22
; [eval] !p0_2
(push) ; 22
(set-option :rlimit 16000)
(assert (not p0_2@51@01))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 137 | !(p0_2@51@01) | dead]
; [else-branch: 137 | p0_2@51@01 | live]
(set-option :rlimit 0)
(push) ; 22
; [else-branch: 137 | p0_2@51@01]
(assert p0_2@51@01)
(pop) ; 22
(pop) ; 21
(push) ; 21
; [else-branch: 118 | pt1_0@54@01]
(assert pt1_0@54@01)
(pop) ; 21
(pop) ; 20
(push) ; 20
; [else-branch: 93 | !(pt0_0@53@01)]
(assert (not pt0_0@53@01))
(pop) ; 20
; [eval] !pt0_0
(push) ; 20
(set-option :rlimit 16000)
(assert (not pt0_0@53@01))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 20
(set-option :rlimit 16000)
(assert (not (not pt0_0@53@01)))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 138 | !(pt0_0@53@01) | live]
; [else-branch: 138 | pt0_0@53@01 | live]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 138 | !(pt0_0@53@01)]
(assert (not pt0_0@53@01))
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt1_0@54@01)))
(check-sat)
; unknown
(pop) ; 21
; 0.01s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not pt1_0@54@01))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 139 | pt1_0@54@01 | live]
; [else-branch: 139 | !(pt1_0@54@01) | live]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 139 | pt1_0@54@01]
(assert pt1_0@54@01)
; [exec]
; leak_1 := i_1
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p0_2@51@01)))
(check-sat)
; unknown
(pop) ; 22
; 0.01s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 22
(set-option :rlimit 16000)
(assert (not p0_2@51@01))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 140 | p0_2@51@01 | live]
; [else-branch: 140 | !(p0_2@51@01) | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 140 | p0_2@51@01]
(assert p0_2@51@01)
; [exec]
; i := i + 1
; [eval] i + 1
(declare-const i@63@01 Int)
(assert (= i@63@01 (+ i@40@01 1)))
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not p1_2@52@01)))
(check-sat)
; unknown
(pop) ; 23
; 0.01s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 23
(set-option :rlimit 16000)
(assert (not p1_2@52@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 141 | p1_2@52@01 | live]
; [else-branch: 141 | !(p1_2@52@01) | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 141 | p1_2@52@01]
(assert p1_2@52@01)
; [exec]
; i_1 := i_1 + 1
; [eval] i_1 + 1
(declare-const i_1@64@01 Int)
(assert (= i_1@64@01 (+ i_1@41@01 1)))
; Loop head block: Re-establish invariant
; [eval] p0_1 ==> i >= 0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 25
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 142 | p0_1@8@01 | live]
; [else-branch: 142 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 142 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i >= 0
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p0_1@8@01)
(push) ; 24
(assert (not (=> p0_1@8@01 (>= i@63@01 0))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p0_1@8@01 (>= i@63@01 0)))
; [eval] p1_1 ==> i_1 >= 0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 25
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 143 | p1_1@9@01 | live]
; [else-branch: 143 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 143 | p1_1@9@01]
(assert p1_1@9@01)
; [eval] i_1 >= 0
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p1_1@9@01)
(push) ; 24
(assert (not (=> p1_1@9@01 (>= i_1@64@01 0))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p1_1@9@01 (>= i_1@64@01 0)))
; [eval] p0_1 ==> i <= |a|
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 144 | p0_1@8@01 | live]
; [else-branch: 144 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 144 | p0_1@8@01]
; [eval] i <= |a|
; [eval] |a|
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p0_1@8@01 (<= i@63@01 (Seq_length a@29@01)))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p0_1@8@01 (<= i@63@01 (Seq_length a@29@01))))
; [eval] p1_1 ==> i_1 <= |a_1|
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.01s
; (get-info :all-statistics)
; [then-branch: 145 | p1_1@9@01 | live]
; [else-branch: 145 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 145 | p1_1@9@01]
; [eval] i_1 <= |a_1|
; [eval] |a_1|
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p1_1@9@01 (<= i_1@64@01 (Seq_length a_1@30@01)))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p1_1@9@01 (<= i_1@64@01 (Seq_length a_1@30@01))))
; [eval] (forall j: Int ::(p0_1 ==> true) && (p1_1 ==> true))
(declare-const j@65@01 Int)
(push) ; 24
; [eval] (p0_1 ==> true) && (p1_1 ==> true)
; [eval] p0_1 ==> true
(push) ; 25
(push) ; 26
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 26
; 0.00s
; (get-info :all-statistics)
; [then-branch: 146 | p0_1@8@01 | live]
; [else-branch: 146 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 146 | p0_1@8@01]
(pop) ; 26
(pop) ; 25
; Joined path conditions
(push) ; 25
; [then-branch: 147 | False | live]
; [else-branch: 147 | True | live]
(push) ; 26
; [then-branch: 147 | False]
(assert false)
(pop) ; 26
(push) ; 26
; [else-branch: 147 | True]
; [eval] p1_1 ==> true
(push) ; 27
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 28
; 0.01s
; (get-info :all-statistics)
; [then-branch: 148 | p1_1@9@01 | live]
; [else-branch: 148 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 148 | p1_1@9@01]
(pop) ; 28
(pop) ; 27
; Joined path conditions
(pop) ; 26
(pop) ; 25
; Joined path conditions
; Joined path conditions
(pop) ; 24
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
; [eval] p0_1 ==> p0_1 && p1_1 ==> i == i_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 149 | p0_1@8@01 | live]
; [else-branch: 149 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 149 | p0_1@8@01]
; [eval] p0_1 && p1_1 ==> i == i_1
; [eval] p0_1 && p1_1
(push) ; 26
; [then-branch: 150 | !(p0_1@8@01) | live]
; [else-branch: 150 | p0_1@8@01 | live]
(push) ; 27
; [then-branch: 150 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 27
(push) ; 27
; [else-branch: 150 | p0_1@8@01]
(pop) ; 27
(pop) ; 26
; Joined path conditions
; Joined path conditions
(push) ; 26
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not (and p0_1@8@01 p1_1@9@01))))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 151 | p0_1@8@01 && p1_1@9@01 | dead]
; [else-branch: 151 | !(p0_1@8@01 && p1_1@9@01) | live]
(set-option :rlimit 0)
(push) ; 27
; [else-branch: 151 | !(p0_1@8@01 && p1_1@9@01)]
(assert (not (and p0_1@8@01 p1_1@9@01)))
(pop) ; 27
(pop) ; 26
; Joined path conditions
(assert (not (and p0_1@8@01 p1_1@9@01)))
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert (=> p0_1@8@01 (not (and p0_1@8@01 p1_1@9@01))))
; [eval] p1_1 ==> true
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 152 | p1_1@9@01 | dead]
; [else-branch: 152 | !(p1_1@9@01) | live]
(set-option :rlimit 0)
(push) ; 25
; [else-branch: 152 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert (not p1_1@9@01))
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 153 | p0_1@8@01 | dead]
; [else-branch: 153 | !(p0_1@8@01) | live]
(set-option :rlimit 0)
(push) ; 25
; [else-branch: 153 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert (not p0_1@8@01))
; [eval] p1_1 ==> true
(push) ; 24
; [then-branch: 154 | p1_1@9@01 | dead]
; [else-branch: 154 | !(p1_1@9@01) | live]
(push) ; 25
; [else-branch: 154 | !(p1_1@9@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p0_1 ==> tmp0_1 == leak
; [eval] !p0_1
(push) ; 24
; [then-branch: 155 | !(p0_1@8@01) | dead]
; [else-branch: 155 | p0_1@8@01 | live]
(push) ; 25
; [else-branch: 155 | p0_1@8@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p0_1 ==> tmp0_2 == i
; [eval] !p0_1
(push) ; 24
; [then-branch: 156 | !(p0_1@8@01) | dead]
; [else-branch: 156 | p0_1@8@01 | live]
(push) ; 25
; [else-branch: 156 | p0_1@8@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p1_1 ==> tmp1_2 == i_1
; [eval] !p1_1
(push) ; 24
; [then-branch: 157 | !(p1_1@9@01) | dead]
; [else-branch: 157 | p1_1@9@01 | live]
(push) ; 25
; [else-branch: 157 | p1_1@9@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p1_1 ==> tmp1_1 == leak_1
; [eval] !p1_1
(push) ; 24
; [then-branch: 158 | !(p1_1@9@01) | dead]
; [else-branch: 158 | p1_1@9@01 | live]
(push) ; 25
; [else-branch: 158 | p1_1@9@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
(pop) ; 23
; [eval] !p1_2
(push) ; 23
(set-option :rlimit 16000)
(assert (not p1_2@52@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 159 | !(p1_2@52@01) | dead]
; [else-branch: 159 | p1_2@52@01 | live]
(set-option :rlimit 0)
(push) ; 23
; [else-branch: 159 | p1_2@52@01]
(assert p1_2@52@01)
(pop) ; 23
(pop) ; 22
; [eval] !p0_2
(push) ; 22
(set-option :rlimit 16000)
(assert (not p0_2@51@01))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 160 | !(p0_2@51@01) | dead]
; [else-branch: 160 | p0_2@51@01 | live]
(set-option :rlimit 0)
(push) ; 22
; [else-branch: 160 | p0_2@51@01]
(assert p0_2@51@01)
(pop) ; 22
(pop) ; 21
(push) ; 21
; [else-branch: 139 | !(pt1_0@54@01)]
(assert (not pt1_0@54@01))
(pop) ; 21
; [eval] !pt1_0
(push) ; 21
(set-option :rlimit 16000)
(assert (not pt1_0@54@01))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt1_0@54@01)))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 161 | !(pt1_0@54@01) | live]
; [else-branch: 161 | pt1_0@54@01 | live]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 161 | !(pt1_0@54@01)]
(assert (not pt1_0@54@01))
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p0_2@51@01)))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 22
(set-option :rlimit 16000)
(assert (not p0_2@51@01))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 162 | p0_2@51@01 | live]
; [else-branch: 162 | !(p0_2@51@01) | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 162 | p0_2@51@01]
(assert p0_2@51@01)
; [exec]
; i := i + 1
; [eval] i + 1
(declare-const i@66@01 Int)
(assert (= i@66@01 (+ i@40@01 1)))
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not p1_2@52@01)))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 23
(set-option :rlimit 16000)
(assert (not p1_2@52@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 163 | p1_2@52@01 | live]
; [else-branch: 163 | !(p1_2@52@01) | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 163 | p1_2@52@01]
(assert p1_2@52@01)
; [exec]
; i_1 := i_1 + 1
; [eval] i_1 + 1
(declare-const i_1@67@01 Int)
(assert (= i_1@67@01 (+ i_1@41@01 1)))
; Loop head block: Re-establish invariant
; [eval] p0_1 ==> i >= 0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 25
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 164 | p0_1@8@01 | live]
; [else-branch: 164 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 164 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i >= 0
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p0_1@8@01)
(push) ; 24
(assert (not (=> p0_1@8@01 (>= i@66@01 0))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p0_1@8@01 (>= i@66@01 0)))
; [eval] p1_1 ==> i_1 >= 0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 25
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 165 | p1_1@9@01 | live]
; [else-branch: 165 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 165 | p1_1@9@01]
(assert p1_1@9@01)
; [eval] i_1 >= 0
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p1_1@9@01)
(push) ; 24
(assert (not (=> p1_1@9@01 (>= i_1@67@01 0))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p1_1@9@01 (>= i_1@67@01 0)))
; [eval] p0_1 ==> i <= |a|
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.01s
; (get-info :all-statistics)
; [then-branch: 166 | p0_1@8@01 | live]
; [else-branch: 166 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 166 | p0_1@8@01]
; [eval] i <= |a|
; [eval] |a|
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p0_1@8@01 (<= i@66@01 (Seq_length a@29@01)))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p0_1@8@01 (<= i@66@01 (Seq_length a@29@01))))
; [eval] p1_1 ==> i_1 <= |a_1|
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 167 | p1_1@9@01 | live]
; [else-branch: 167 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 167 | p1_1@9@01]
; [eval] i_1 <= |a_1|
; [eval] |a_1|
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p1_1@9@01 (<= i_1@67@01 (Seq_length a_1@30@01)))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p1_1@9@01 (<= i_1@67@01 (Seq_length a_1@30@01))))
; [eval] (forall j: Int ::(p0_1 ==> true) && (p1_1 ==> true))
(declare-const j@68@01 Int)
(push) ; 24
; [eval] (p0_1 ==> true) && (p1_1 ==> true)
; [eval] p0_1 ==> true
(push) ; 25
(push) ; 26
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 26
; 0.00s
; (get-info :all-statistics)
; [then-branch: 168 | p0_1@8@01 | live]
; [else-branch: 168 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 168 | p0_1@8@01]
(pop) ; 26
(pop) ; 25
; Joined path conditions
(push) ; 25
; [then-branch: 169 | False | live]
; [else-branch: 169 | True | live]
(push) ; 26
; [then-branch: 169 | False]
(assert false)
(pop) ; 26
(push) ; 26
; [else-branch: 169 | True]
; [eval] p1_1 ==> true
(push) ; 27
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 170 | p1_1@9@01 | live]
; [else-branch: 170 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 170 | p1_1@9@01]
(pop) ; 28
(pop) ; 27
; Joined path conditions
(pop) ; 26
(pop) ; 25
; Joined path conditions
; Joined path conditions
(pop) ; 24
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
; [eval] p0_1 ==> p0_1 && p1_1 ==> i == i_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 171 | p0_1@8@01 | live]
; [else-branch: 171 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 171 | p0_1@8@01]
; [eval] p0_1 && p1_1 ==> i == i_1
; [eval] p0_1 && p1_1
(push) ; 26
; [then-branch: 172 | !(p0_1@8@01) | live]
; [else-branch: 172 | p0_1@8@01 | live]
(push) ; 27
; [then-branch: 172 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 27
(push) ; 27
; [else-branch: 172 | p0_1@8@01]
(pop) ; 27
(pop) ; 26
; Joined path conditions
; Joined path conditions
(push) ; 26
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not (and p0_1@8@01 p1_1@9@01))))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 27
(set-option :rlimit 16000)
(assert (not (and p0_1@8@01 p1_1@9@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 173 | p0_1@8@01 && p1_1@9@01 | live]
; [else-branch: 173 | !(p0_1@8@01 && p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 173 | p0_1@8@01 && p1_1@9@01]
(assert (and p0_1@8@01 p1_1@9@01))
; [eval] i == i_1
(pop) ; 27
(pop) ; 26
; Joined path conditions
(assert (and p0_1@8@01 p1_1@9@01))
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p0_1@8@01)
(push) ; 24
(assert (not (=> (and p0_1@8@01 (and p0_1@8@01 p1_1@9@01)) (= i@66@01 i_1@67@01))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> (and p0_1@8@01 (and p0_1@8@01 p1_1@9@01)) (= i@66@01 i_1@67@01)))
; [eval] p1_1 ==> true
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 25
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 174 | p1_1@9@01 | live]
; [else-branch: 174 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 174 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p1_1@9@01)
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 175 | p0_1@8@01 | live]
; [else-branch: 175 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 175 | p0_1@8@01]
; [eval] p0_1 && p1_1 ==> leak == leak_1
; [eval] p0_1 && p1_1
(push) ; 26
; [then-branch: 176 | !(p0_1@8@01) | live]
; [else-branch: 176 | p0_1@8@01 | live]
(push) ; 27
; [then-branch: 176 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 27
(push) ; 27
; [else-branch: 176 | p0_1@8@01]
(pop) ; 27
(pop) ; 26
; Joined path conditions
; Joined path conditions
(push) ; 26
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not (and p0_1@8@01 p1_1@9@01))))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 27
(set-option :rlimit 16000)
(assert (not (and p0_1@8@01 p1_1@9@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 177 | p0_1@8@01 && p1_1@9@01 | live]
; [else-branch: 177 | !(p0_1@8@01 && p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 177 | p0_1@8@01 && p1_1@9@01]
(assert (and p0_1@8@01 p1_1@9@01))
; [eval] leak == leak_1
(pop) ; 27
(pop) ; 26
; Joined path conditions
(assert (and p0_1@8@01 p1_1@9@01))
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p0_1@8@01)
; [eval] p1_1 ==> true
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 25
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 178 | p1_1@9@01 | live]
; [else-branch: 178 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 178 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p1_1@9@01)
; [eval] !p0_1 ==> tmp0_1 == leak
; [eval] !p0_1
(push) ; 24
; [then-branch: 179 | !(p0_1@8@01) | dead]
; [else-branch: 179 | p0_1@8@01 | live]
(push) ; 25
; [else-branch: 179 | p0_1@8@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p0_1 ==> tmp0_2 == i
; [eval] !p0_1
(push) ; 24
; [then-branch: 180 | !(p0_1@8@01) | dead]
; [else-branch: 180 | p0_1@8@01 | live]
(push) ; 25
; [else-branch: 180 | p0_1@8@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p1_1 ==> tmp1_2 == i_1
; [eval] !p1_1
(push) ; 24
; [then-branch: 181 | !(p1_1@9@01) | dead]
; [else-branch: 181 | p1_1@9@01 | live]
(push) ; 25
; [else-branch: 181 | p1_1@9@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p1_1 ==> tmp1_1 == leak_1
; [eval] !p1_1
(push) ; 24
; [then-branch: 182 | !(p1_1@9@01) | dead]
; [else-branch: 182 | p1_1@9@01 | live]
(push) ; 25
; [else-branch: 182 | p1_1@9@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
(pop) ; 23
; [eval] !p1_2
(push) ; 23
(set-option :rlimit 16000)
(assert (not p1_2@52@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 183 | !(p1_2@52@01) | dead]
; [else-branch: 183 | p1_2@52@01 | live]
(set-option :rlimit 0)
(push) ; 23
; [else-branch: 183 | p1_2@52@01]
(assert p1_2@52@01)
(pop) ; 23
(pop) ; 22
; [eval] !p0_2
(push) ; 22
(set-option :rlimit 16000)
(assert (not p0_2@51@01))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 184 | !(p0_2@51@01) | dead]
; [else-branch: 184 | p0_2@51@01 | live]
(set-option :rlimit 0)
(push) ; 22
; [else-branch: 184 | p0_2@51@01]
(assert p0_2@51@01)
(pop) ; 22
(pop) ; 21
(push) ; 21
; [else-branch: 161 | pt1_0@54@01]
(assert pt1_0@54@01)
(pop) ; 21
(pop) ; 20
(push) ; 20
; [else-branch: 138 | pt0_0@53@01]
(assert pt0_0@53@01)
(pop) ; 20
(pop) ; 19
(push) ; 19
; [else-branch: 86 | !(p0_1@8@01 && i@40@01 < |a@29@01| || p1_1@9@01 && i_1@41@01 < |a_1@30@01|)]
(assert (not
  (or
    (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01)))
    (and p1_1@9@01 (< i_1@41@01 (Seq_length a_1@30@01))))))
(pop) ; 19
; [eval] !(p0_1 && i < |a| || p1_1 && i_1 < |a_1|)
; [eval] p0_1 && i < |a| || p1_1 && i_1 < |a_1|
; [eval] p0_1 && i < |a|
(push) ; 19
; [then-branch: 185 | !(p0_1@8@01) | live]
; [else-branch: 185 | p0_1@8@01 | live]
(push) ; 20
; [then-branch: 185 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 20
(push) ; 20
; [else-branch: 185 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(push) ; 19
; [then-branch: 186 | p0_1@8@01 && i@40@01 < |a@29@01| | live]
; [else-branch: 186 | !(p0_1@8@01 && i@40@01 < |a@29@01|) | live]
(push) ; 20
; [then-branch: 186 | p0_1@8@01 && i@40@01 < |a@29@01|]
(assert (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01))))
(pop) ; 20
(push) ; 20
; [else-branch: 186 | !(p0_1@8@01 && i@40@01 < |a@29@01|)]
(assert (not (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01)))))
; [eval] p1_1 && i_1 < |a_1|
(push) ; 21
; [then-branch: 187 | !(p1_1@9@01) | live]
; [else-branch: 187 | p1_1@9@01 | live]
(push) ; 22
; [then-branch: 187 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 22
(push) ; 22
; [else-branch: 187 | p1_1@9@01]
(assert p1_1@9@01)
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(push) ; 19
(set-option :rlimit 16000)
(assert (not (or
  (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01)))
  (and p1_1@9@01 (< i_1@41@01 (Seq_length a_1@30@01))))))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not
  (or
    (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01)))
    (and p1_1@9@01 (< i_1@41@01 (Seq_length a_1@30@01)))))))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 188 | !(p0_1@8@01 && i@40@01 < |a@29@01| || p1_1@9@01 && i_1@41@01 < |a_1@30@01|) | live]
; [else-branch: 188 | p0_1@8@01 && i@40@01 < |a@29@01| || p1_1@9@01 && i_1@41@01 < |a_1@30@01| | live]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 188 | !(p0_1@8@01 && i@40@01 < |a@29@01| || p1_1@9@01 && i_1@41@01 < |a_1@30@01|)]
(assert (not
  (or
    (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01)))
    (and p1_1@9@01 (< i_1@41@01 (Seq_length a_1@30@01))))))
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 20
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 189 | p0_1@8@01 | live]
; [else-branch: 189 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 189 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] p0_1 && p1_1 ==> leak == leak_1
; [eval] p0_1 && p1_1
(push) ; 22
; [then-branch: 190 | !(p0_1@8@01) | live]
; [else-branch: 190 | p0_1@8@01 | live]
(push) ; 23
; [then-branch: 190 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 23
(push) ; 23
; [else-branch: 190 | p0_1@8@01]
(pop) ; 23
(pop) ; 22
; Joined path conditions
; Joined path conditions
(push) ; 22
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not (and p0_1@8@01 p1_1@9@01))))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 23
(set-option :rlimit 16000)
(assert (not (and p0_1@8@01 p1_1@9@01)))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 191 | p0_1@8@01 && p1_1@9@01 | live]
; [else-branch: 191 | !(p0_1@8@01 && p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 191 | p0_1@8@01 && p1_1@9@01]
(assert (and p0_1@8@01 p1_1@9@01))
; [eval] leak == leak_1
(pop) ; 23
(pop) ; 22
; Joined path conditions
(assert (and p0_1@8@01 p1_1@9@01))
(pop) ; 21
(pop) ; 20
; Joined path conditions
(assert p0_1@8@01)
; [eval] p1_1 ==> true
(push) ; 20
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 192 | p1_1@9@01 | live]
; [else-branch: 192 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 192 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 21
(pop) ; 20
; Joined path conditions
(assert p1_1@9@01)
(pop) ; 19
(push) ; 19
; [else-branch: 188 | p0_1@8@01 && i@40@01 < |a@29@01| || p1_1@9@01 && i_1@41@01 < |a_1@30@01|]
(assert (or
  (and p0_1@8@01 (< i@40@01 (Seq_length a@29@01)))
  (and p1_1@9@01 (< i_1@41@01 (Seq_length a_1@30@01)))))
(pop) ; 19
(pop) ; 18
(pop) ; 17
(pop) ; 16
(pop) ; 15
(pop) ; 14
(pop) ; 13
(pop) ; 12
; [eval] !p1_1
(push) ; 12
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unsat
(pop) ; 12
; 0.00s
; (get-info :all-statistics)
; [then-branch: 193 | !(p1_1@9@01) | dead]
; [else-branch: 193 | p1_1@9@01 | live]
(set-option :rlimit 0)
(push) ; 12
; [else-branch: 193 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 12
(pop) ; 11
; [eval] !p0_1
(push) ; 11
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 194 | !(p0_1@8@01) | dead]
; [else-branch: 194 | p0_1@8@01 | live]
(set-option :rlimit 0)
(push) ; 11
; [else-branch: 194 | p0_1@8@01]
(assert p0_1@8@01)
(pop) ; 11
(pop) ; 10
; [eval] !p1_1
(push) ; 10
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unsat
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
; [then-branch: 195 | !(p1_1@9@01) | dead]
; [else-branch: 195 | p1_1@9@01 | live]
(set-option :rlimit 0)
(push) ; 10
; [else-branch: 195 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 10
(pop) ; 9
; [eval] !p0_1
(push) ; 9
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
; [then-branch: 196 | !(p0_1@8@01) | dead]
; [else-branch: 196 | p0_1@8@01 | live]
(set-option :rlimit 0)
(push) ; 9
; [else-branch: 196 | p0_1@8@01]
(assert p0_1@8@01)
(pop) ; 9
(pop) ; 8
; [eval] !p1_1
(push) ; 8
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unsat
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
; [then-branch: 197 | !(p1_1@9@01) | dead]
; [else-branch: 197 | p1_1@9@01 | live]
(set-option :rlimit 0)
(push) ; 8
; [else-branch: 197 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 8
(pop) ; 7
; [eval] !p0_1
(push) ; 7
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 198 | !(p0_1@8@01) | dead]
; [else-branch: 198 | p0_1@8@01 | live]
(set-option :rlimit 0)
(push) ; 7
; [else-branch: 198 | p0_1@8@01]
(assert p0_1@8@01)
(pop) ; 7
(pop) ; 6
; [eval] !p1_1
(push) ; 6
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [then-branch: 199 | !(p1_1@9@01) | dead]
; [else-branch: 199 | p1_1@9@01 | live]
(set-option :rlimit 0)
(push) ; 6
; [else-branch: 199 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 6
(pop) ; 5
; [eval] !p0_1
(push) ; 5
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 200 | !(p0_1@8@01) | dead]
; [else-branch: 200 | p0_1@8@01 | live]
(set-option :rlimit 0)
(push) ; 5
; [else-branch: 200 | p0_1@8@01]
(assert p0_1@8@01)
(pop) ; 5
(pop) ; 4
(push) ; 4
; [else-branch: 20 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 4
; [eval] !p1_1
(push) ; 4
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 201 | !(p1_1@9@01) | live]
; [else-branch: 201 | p1_1@9@01 | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 201 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 202 | p0_1@8@01 | live]
; [else-branch: 202 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 202 | p0_1@8@01]
(assert p0_1@8@01)
; [exec]
; a := a_in
; [then-branch: 203 | p1_1@9@01 | dead]
; [else-branch: 203 | !(p1_1@9@01) | live]
(push) ; 6
; [else-branch: 203 | !(p1_1@9@01)]
(pop) ; 6
; [eval] !p1_1
(push) ; 6
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [then-branch: 204 | !(p1_1@9@01) | live]
; [else-branch: 204 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 6
; [then-branch: 204 | !(p1_1@9@01)]
(push) ; 7
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 205 | p0_1@8@01 | live]
; [else-branch: 205 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 7
; [then-branch: 205 | p0_1@8@01]
; [exec]
; a := a[secret := 1]
; [eval] a[secret := 1]
(push) ; 8
(assert (not (>= secret@12@01 0)))
(check-sat)
; unsat
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
(push) ; 8
(assert (not (< secret@12@01 (Seq_length a_in@10@01))))
(check-sat)
; unsat
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
(declare-const a@69@01 Seq<Int>)
(assert (=
  a@69@01
  (Seq_append
    (Seq_take a_in@10@01 secret@12@01)
    (Seq_append (Seq_singleton 1) (Seq_drop a_in@10@01 (+ secret@12@01 1))))))
; [then-branch: 206 | p1_1@9@01 | dead]
; [else-branch: 206 | !(p1_1@9@01) | live]
(push) ; 8
; [else-branch: 206 | !(p1_1@9@01)]
(pop) ; 8
; [eval] !p1_1
(push) ; 8
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
; [then-branch: 207 | !(p1_1@9@01) | live]
; [else-branch: 207 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 8
; [then-branch: 207 | !(p1_1@9@01)]
; [exec]
; inhale p0_1 && p1_1 ==> secret == secret_1
(declare-const $t@70@01 $Snap)
(assert (= $t@70@01 $Snap.unit))
; [eval] p0_1 && p1_1 ==> secret == secret_1
; [eval] p0_1 && p1_1
(push) ; 9
; [then-branch: 208 | !(p0_1@8@01) | live]
; [else-branch: 208 | p0_1@8@01 | live]
(push) ; 10
; [then-branch: 208 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 10
(push) ; 10
; [else-branch: 208 | p0_1@8@01]
(pop) ; 10
(pop) ; 9
; Joined path conditions
; Joined path conditions
(assert (or p0_1@8@01 (not p0_1@8@01)))
(push) ; 9
(push) ; 10
(set-option :rlimit 16000)
(assert (not (not (and p0_1@8@01 p1_1@9@01))))
(check-sat)
; unsat
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
; [then-branch: 209 | p0_1@8@01 && p1_1@9@01 | dead]
; [else-branch: 209 | !(p0_1@8@01 && p1_1@9@01) | live]
(set-option :rlimit 0)
(push) ; 10
; [else-branch: 209 | !(p0_1@8@01 && p1_1@9@01)]
(assert (not (and p0_1@8@01 p1_1@9@01)))
(pop) ; 10
(pop) ; 9
; Joined path conditions
(assert (not (and p0_1@8@01 p1_1@9@01)))
; State saturation: after inhale
(set-option :rlimit 32000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
; [then-branch: 210 | p0_1@8@01 | live]
; [else-branch: 210 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 9
; [then-branch: 210 | p0_1@8@01]
; [exec]
; i := 0
; [then-branch: 211 | p1_1@9@01 | dead]
; [else-branch: 211 | !(p1_1@9@01) | live]
(push) ; 10
; [else-branch: 211 | !(p1_1@9@01)]
(pop) ; 10
; [eval] !p1_1
(push) ; 10
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
; [then-branch: 212 | !(p1_1@9@01) | live]
; [else-branch: 212 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 10
; [then-branch: 212 | !(p1_1@9@01)]
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 213 | p0_1@8@01 | live]
; [else-branch: 213 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 213 | p0_1@8@01]
; [exec]
; leak := 0
; [then-branch: 214 | p1_1@9@01 | dead]
; [else-branch: 214 | !(p1_1@9@01) | live]
(push) ; 12
; [else-branch: 214 | !(p1_1@9@01)]
(pop) ; 12
; [eval] !p1_1
(push) ; 12
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 12
; 0.00s
; (get-info :all-statistics)
; [then-branch: 215 | !(p1_1@9@01) | live]
; [else-branch: 215 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 12
; [then-branch: 215 | !(p1_1@9@01)]
; [eval] !p0_1
; [then-branch: 216 | !(p0_1@8@01) | dead]
; [else-branch: 216 | p0_1@8@01 | live]
(push) ; 13
; [else-branch: 216 | p0_1@8@01]
(pop) ; 13
; [eval] !!p0_1
; [eval] !p0_1
(push) ; 13
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 13
; 0.00s
; (get-info :all-statistics)
; [then-branch: 217 | p0_1@8@01 | live]
; [else-branch: 217 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 13
; [then-branch: 217 | p0_1@8@01]
; [eval] !p1_1
(push) ; 14
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 14
; 0.00s
; (get-info :all-statistics)
; [then-branch: 218 | !(p1_1@9@01) | live]
; [else-branch: 218 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 14
; [then-branch: 218 | !(p1_1@9@01)]
; [exec]
; tmp1_1 := leak_1
; [eval] !p0_1
; [then-branch: 219 | !(p0_1@8@01) | dead]
; [else-branch: 219 | p0_1@8@01 | live]
(push) ; 15
; [else-branch: 219 | p0_1@8@01]
(pop) ; 15
; [eval] !!p0_1
; [eval] !p0_1
(push) ; 15
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
; [then-branch: 220 | p0_1@8@01 | live]
; [else-branch: 220 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 15
; [then-branch: 220 | p0_1@8@01]
; [eval] !p1_1
(push) ; 16
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [then-branch: 221 | !(p1_1@9@01) | live]
; [else-branch: 221 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 16
; [then-branch: 221 | !(p1_1@9@01)]
; [exec]
; tmp1_2 := i_1
(declare-const p0_2@71@01 Bool)
(declare-const p1_2@72@01 Bool)
(declare-const pt0_0@73@01 Bool)
(declare-const pt1_0@74@01 Bool)
(declare-const pf0_0@75@01 Bool)
(declare-const pf1_0@76@01 Bool)
(declare-const leak@77@01 Int)
(declare-const leak_1@78@01 Int)
(declare-const i@79@01 Int)
(declare-const i_1@80@01 Int)
(push) ; 17
; Loop head block: Check well-definedness of invariant
(declare-const $t@81@01 $Snap)
(assert (= $t@81@01 ($Snap.combine ($Snap.first $t@81@01) ($Snap.second $t@81@01))))
(assert (= ($Snap.first $t@81@01) $Snap.unit))
; [eval] p0_1 ==> i >= 0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 222 | p0_1@8@01 | live]
; [else-branch: 222 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 222 | p0_1@8@01]
; [eval] i >= 0
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> p0_1@8@01 (>= i@79@01 0)))
(assert (=
  ($Snap.second $t@81@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@81@01))
    ($Snap.second ($Snap.second $t@81@01)))))
(assert (= ($Snap.first ($Snap.second $t@81@01)) $Snap.unit))
; [eval] p1_1 ==> i_1 >= 0
(push) ; 18
; [then-branch: 223 | p1_1@9@01 | dead]
; [else-branch: 223 | !(p1_1@9@01) | live]
(push) ; 19
; [else-branch: 223 | !(p1_1@9@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second $t@81@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@81@01)))
    ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@81@01))) $Snap.unit))
; [eval] p0_1 ==> i <= |a|
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 224 | p0_1@8@01 | live]
; [else-branch: 224 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 224 | p0_1@8@01]
; [eval] i <= |a|
; [eval] |a|
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> p0_1@8@01 (<= i@79@01 (Seq_length a@69@01))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second $t@81@01)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@81@01))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@81@01))))
  $Snap.unit))
; [eval] p1_1 ==> i_1 <= |a_1|
(push) ; 18
; [then-branch: 225 | p1_1@9@01 | dead]
; [else-branch: 225 | !(p1_1@9@01) | live]
(push) ; 19
; [else-branch: 225 | !(p1_1@9@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))
  $Snap.unit))
; [eval] (forall j: Int ::(p0_1 ==> true) && (p1_1 ==> true))
(declare-const j@82@01 Int)
(push) ; 18
; [eval] (p0_1 ==> true) && (p1_1 ==> true)
; [eval] p0_1 ==> true
(push) ; 19
(push) ; 20
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 226 | p0_1@8@01 | live]
; [else-branch: 226 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 226 | p0_1@8@01]
(pop) ; 20
(pop) ; 19
; Joined path conditions
(push) ; 19
; [then-branch: 227 | False | live]
; [else-branch: 227 | True | live]
(push) ; 20
; [then-branch: 227 | False]
(assert false)
(pop) ; 20
(push) ; 20
; [else-branch: 227 | True]
; [eval] p1_1 ==> true
(push) ; 21
; [then-branch: 228 | p1_1@9@01 | dead]
; [else-branch: 228 | !(p1_1@9@01) | live]
(push) ; 22
; [else-branch: 228 | !(p1_1@9@01)]
(pop) ; 22
(pop) ; 21
; Joined path conditions
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(pop) ; 18
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))
  $Snap.unit))
; [eval] p0_1 ==> p0_1 && p1_1 ==> i == i_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 229 | p0_1@8@01 | live]
; [else-branch: 229 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 229 | p0_1@8@01]
; [eval] p0_1 && p1_1 ==> i == i_1
; [eval] p0_1 && p1_1
(push) ; 20
; [then-branch: 230 | !(p0_1@8@01) | live]
; [else-branch: 230 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 230 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 21
(push) ; 21
; [else-branch: 230 | p0_1@8@01]
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(push) ; 20
; [then-branch: 231 | p0_1@8@01 && p1_1@9@01 | dead]
; [else-branch: 231 | !(p0_1@8@01 && p1_1@9@01) | live]
(push) ; 21
; [else-branch: 231 | !(p0_1@8@01 && p1_1@9@01)]
(pop) ; 21
(pop) ; 20
; Joined path conditions
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))
  $Snap.unit))
; [eval] p1_1 ==> true
(push) ; 18
; [then-branch: 232 | p1_1@9@01 | dead]
; [else-branch: 232 | !(p1_1@9@01) | live]
(push) ; 19
; [else-branch: 232 | !(p1_1@9@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))
  $Snap.unit))
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 233 | p0_1@8@01 | live]
; [else-branch: 233 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 233 | p0_1@8@01]
; [eval] p0_1 && p1_1 ==> leak == leak_1
; [eval] p0_1 && p1_1
(push) ; 20
; [then-branch: 234 | !(p0_1@8@01) | live]
; [else-branch: 234 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 234 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 21
(push) ; 21
; [else-branch: 234 | p0_1@8@01]
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(push) ; 20
; [then-branch: 235 | p0_1@8@01 && p1_1@9@01 | dead]
; [else-branch: 235 | !(p0_1@8@01 && p1_1@9@01) | live]
(push) ; 21
; [else-branch: 235 | !(p0_1@8@01 && p1_1@9@01)]
(pop) ; 21
(pop) ; 20
; Joined path conditions
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))
  $Snap.unit))
; [eval] p1_1 ==> true
(push) ; 18
; [then-branch: 236 | p1_1@9@01 | dead]
; [else-branch: 236 | !(p1_1@9@01) | live]
(push) ; 19
; [else-branch: 236 | !(p1_1@9@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))
  $Snap.unit))
; [eval] !p0_1 ==> tmp0_1 == leak
; [eval] !p0_1
(push) ; 18
; [then-branch: 237 | !(p0_1@8@01) | dead]
; [else-branch: 237 | p0_1@8@01 | live]
(push) ; 19
; [else-branch: 237 | p0_1@8@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))))
  $Snap.unit))
; [eval] !p0_1 ==> tmp0_2 == i
; [eval] !p0_1
(push) ; 18
; [then-branch: 238 | !(p0_1@8@01) | dead]
; [else-branch: 238 | p0_1@8@01 | live]
(push) ; 19
; [else-branch: 238 | p0_1@8@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))))
  $Snap.unit))
; [eval] !p1_1 ==> tmp1_2 == i_1
; [eval] !p1_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 239 | !(p1_1@9@01) | live]
; [else-branch: 239 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 239 | !(p1_1@9@01)]
; [eval] tmp1_2 == i_1
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> (not p1_1@9@01) (= i_1@23@01 i_1@80@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))))
  $Snap.unit))
; [eval] !p1_1 ==> tmp1_1 == leak_1
; [eval] !p1_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 240 | !(p1_1@9@01) | live]
; [else-branch: 240 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 240 | !(p1_1@9@01)]
; [eval] tmp1_1 == leak_1
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> (not p1_1@9@01) (= leak_1@15@01 leak_1@78@01)))
(pop) ; 17
(push) ; 17
; Loop head block: Establish invariant
; [eval] p0_1 ==> i >= 0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 241 | p0_1@8@01 | live]
; [else-branch: 241 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 241 | p0_1@8@01]
; [eval] i >= 0
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] p1_1 ==> i_1 >= 0
(push) ; 18
; [then-branch: 242 | p1_1@9@01 | dead]
; [else-branch: 242 | !(p1_1@9@01) | live]
(push) ; 19
; [else-branch: 242 | !(p1_1@9@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] p0_1 ==> i <= |a|
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 243 | p0_1@8@01 | live]
; [else-branch: 243 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 243 | p0_1@8@01]
; [eval] i <= |a|
; [eval] |a|
(pop) ; 19
(pop) ; 18
; Joined path conditions
(push) ; 18
(assert (not (=> p0_1@8@01 (<= 0 (Seq_length a@69@01)))))
(check-sat)
; unsat
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
(assert (=> p0_1@8@01 (<= 0 (Seq_length a@69@01))))
; [eval] p1_1 ==> i_1 <= |a_1|
(push) ; 18
; [then-branch: 244 | p1_1@9@01 | dead]
; [else-branch: 244 | !(p1_1@9@01) | live]
(push) ; 19
; [else-branch: 244 | !(p1_1@9@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] (forall j: Int ::(p0_1 ==> true) && (p1_1 ==> true))
(declare-const j@83@01 Int)
(push) ; 18
; [eval] (p0_1 ==> true) && (p1_1 ==> true)
; [eval] p0_1 ==> true
(push) ; 19
(push) ; 20
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 245 | p0_1@8@01 | live]
; [else-branch: 245 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 245 | p0_1@8@01]
(pop) ; 20
(pop) ; 19
; Joined path conditions
(push) ; 19
; [then-branch: 246 | False | live]
; [else-branch: 246 | True | live]
(push) ; 20
; [then-branch: 246 | False]
(assert false)
(pop) ; 20
(push) ; 20
; [else-branch: 246 | True]
; [eval] p1_1 ==> true
(push) ; 21
; [then-branch: 247 | p1_1@9@01 | dead]
; [else-branch: 247 | !(p1_1@9@01) | live]
(push) ; 22
; [else-branch: 247 | !(p1_1@9@01)]
(pop) ; 22
(pop) ; 21
; Joined path conditions
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(pop) ; 18
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
; [eval] p0_1 ==> p0_1 && p1_1 ==> i == i_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 248 | p0_1@8@01 | live]
; [else-branch: 248 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 248 | p0_1@8@01]
; [eval] p0_1 && p1_1 ==> i == i_1
; [eval] p0_1 && p1_1
(push) ; 20
; [then-branch: 249 | !(p0_1@8@01) | live]
; [else-branch: 249 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 249 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 21
(push) ; 21
; [else-branch: 249 | p0_1@8@01]
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(push) ; 20
; [then-branch: 250 | p0_1@8@01 && p1_1@9@01 | dead]
; [else-branch: 250 | !(p0_1@8@01 && p1_1@9@01) | live]
(push) ; 21
; [else-branch: 250 | !(p0_1@8@01 && p1_1@9@01)]
(pop) ; 21
(pop) ; 20
; Joined path conditions
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 18
; [then-branch: 251 | p1_1@9@01 | dead]
; [else-branch: 251 | !(p1_1@9@01) | live]
(push) ; 19
; [else-branch: 251 | !(p1_1@9@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 252 | p0_1@8@01 | live]
; [else-branch: 252 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 252 | p0_1@8@01]
; [eval] p0_1 && p1_1 ==> leak == leak_1
; [eval] p0_1 && p1_1
(push) ; 20
; [then-branch: 253 | !(p0_1@8@01) | live]
; [else-branch: 253 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 253 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 21
(push) ; 21
; [else-branch: 253 | p0_1@8@01]
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(push) ; 20
; [then-branch: 254 | p0_1@8@01 && p1_1@9@01 | dead]
; [else-branch: 254 | !(p0_1@8@01 && p1_1@9@01) | live]
(push) ; 21
; [else-branch: 254 | !(p0_1@8@01 && p1_1@9@01)]
(pop) ; 21
(pop) ; 20
; Joined path conditions
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 18
; [then-branch: 255 | p1_1@9@01 | dead]
; [else-branch: 255 | !(p1_1@9@01) | live]
(push) ; 19
; [else-branch: 255 | !(p1_1@9@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p0_1 ==> tmp0_1 == leak
; [eval] !p0_1
(push) ; 18
; [then-branch: 256 | !(p0_1@8@01) | dead]
; [else-branch: 256 | p0_1@8@01 | live]
(push) ; 19
; [else-branch: 256 | p0_1@8@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p0_1 ==> tmp0_2 == i
; [eval] !p0_1
(push) ; 18
; [then-branch: 257 | !(p0_1@8@01) | dead]
; [else-branch: 257 | p0_1@8@01 | live]
(push) ; 19
; [else-branch: 257 | p0_1@8@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p1_1 ==> tmp1_2 == i_1
; [eval] !p1_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 258 | !(p1_1@9@01) | live]
; [else-branch: 258 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 258 | !(p1_1@9@01)]
; [eval] tmp1_2 == i_1
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p1_1 ==> tmp1_1 == leak_1
; [eval] !p1_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 259 | !(p1_1@9@01) | live]
; [else-branch: 259 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 259 | !(p1_1@9@01)]
; [eval] tmp1_1 == leak_1
(pop) ; 19
(pop) ; 18
; Joined path conditions
; Loop head block: Execute statements of loop head block (in invariant state)
(push) ; 18
(assert (= $t@81@01 ($Snap.combine ($Snap.first $t@81@01) ($Snap.second $t@81@01))))
(assert (= ($Snap.first $t@81@01) $Snap.unit))
(assert (=> p0_1@8@01 (>= i@79@01 0)))
(assert (=
  ($Snap.second $t@81@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@81@01))
    ($Snap.second ($Snap.second $t@81@01)))))
(assert (= ($Snap.first ($Snap.second $t@81@01)) $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second $t@81@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@81@01)))
    ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@81@01))) $Snap.unit))
(assert (=> p0_1@8@01 (<= i@79@01 (Seq_length a@69@01))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second $t@81@01)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@81@01))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@81@01))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01)))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))))
  $Snap.unit))
(assert (=> (not p1_1@9@01) (= i_1@23@01 i_1@80@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@81@01))))))))))))
  $Snap.unit))
(assert (=> (not p1_1@9@01) (= leak_1@15@01 leak_1@78@01)))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 16000)
(check-sat)
; unknown
; Loop head block: Check well-definedness of edge conditions
(set-option :rlimit 0)
(push) ; 19
; [eval] p0_1 && i < |a| || p1_1 && i_1 < |a_1|
; [eval] p0_1 && i < |a|
(push) ; 20
; [then-branch: 260 | !(p0_1@8@01) | live]
; [else-branch: 260 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 260 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 21
(push) ; 21
; [else-branch: 260 | p0_1@8@01]
; [eval] i < |a|
; [eval] |a|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(push) ; 20
; [then-branch: 261 | p0_1@8@01 && i@79@01 < |a@69@01| | live]
; [else-branch: 261 | !(p0_1@8@01 && i@79@01 < |a@69@01|) | live]
(push) ; 21
; [then-branch: 261 | p0_1@8@01 && i@79@01 < |a@69@01|]
(assert (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01))))
(pop) ; 21
(push) ; 21
; [else-branch: 261 | !(p0_1@8@01 && i@79@01 < |a@69@01|)]
(assert (not (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01)))))
; [eval] p1_1 && i_1 < |a_1|
(push) ; 22
; [then-branch: 262 | !(p1_1@9@01) | live]
; [else-branch: 262 | p1_1@9@01 | live]
(push) ; 23
; [then-branch: 262 | !(p1_1@9@01)]
(pop) ; 23
(push) ; 23
; [else-branch: 262 | p1_1@9@01]
(assert p1_1@9@01)
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 23
(pop) ; 22
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01))))
  (and
    (not (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01))))
    (or p1_1@9@01 (not p1_1@9@01)))))
(assert (or
  (not (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01))))
  (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01)))))
(pop) ; 19
(push) ; 19
; [eval] !(p0_1 && i < |a| || p1_1 && i_1 < |a_1|)
; [eval] p0_1 && i < |a| || p1_1 && i_1 < |a_1|
; [eval] p0_1 && i < |a|
(push) ; 20
; [then-branch: 263 | !(p0_1@8@01) | live]
; [else-branch: 263 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 263 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 21
(push) ; 21
; [else-branch: 263 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(push) ; 20
; [then-branch: 264 | p0_1@8@01 && i@79@01 < |a@69@01| | live]
; [else-branch: 264 | !(p0_1@8@01 && i@79@01 < |a@69@01|) | live]
(push) ; 21
; [then-branch: 264 | p0_1@8@01 && i@79@01 < |a@69@01|]
(assert (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01))))
(pop) ; 21
(push) ; 21
; [else-branch: 264 | !(p0_1@8@01 && i@79@01 < |a@69@01|)]
(assert (not (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01)))))
; [eval] p1_1 && i_1 < |a_1|
(push) ; 22
; [then-branch: 265 | !(p1_1@9@01) | live]
; [else-branch: 265 | p1_1@9@01 | live]
(push) ; 23
; [then-branch: 265 | !(p1_1@9@01)]
(pop) ; 23
(push) ; 23
; [else-branch: 265 | p1_1@9@01]
(assert p1_1@9@01)
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 23
(pop) ; 22
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01))))
  (and
    (not (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01))))
    (or p1_1@9@01 (not p1_1@9@01)))))
(assert (or
  (not (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01))))
  (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01)))))
(pop) ; 19
; Loop head block: Follow loop-internal edges
; [eval] p0_1 && i < |a| || p1_1 && i_1 < |a_1|
; [eval] p0_1 && i < |a|
(push) ; 19
; [then-branch: 266 | !(p0_1@8@01) | live]
; [else-branch: 266 | p0_1@8@01 | live]
(push) ; 20
; [then-branch: 266 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 20
(push) ; 20
; [else-branch: 266 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(push) ; 19
; [then-branch: 267 | p0_1@8@01 && i@79@01 < |a@69@01| | live]
; [else-branch: 267 | !(p0_1@8@01 && i@79@01 < |a@69@01|) | live]
(push) ; 20
; [then-branch: 267 | p0_1@8@01 && i@79@01 < |a@69@01|]
(assert (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01))))
(pop) ; 20
(push) ; 20
; [else-branch: 267 | !(p0_1@8@01 && i@79@01 < |a@69@01|)]
(assert (not (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01)))))
; [eval] p1_1 && i_1 < |a_1|
(push) ; 21
; [then-branch: 268 | !(p1_1@9@01) | live]
; [else-branch: 268 | p1_1@9@01 | live]
(push) ; 22
; [then-branch: 268 | !(p1_1@9@01)]
(pop) ; 22
(push) ; 22
; [else-branch: 268 | p1_1@9@01]
(assert p1_1@9@01)
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01))))
  (and
    (not (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01))))
    (or p1_1@9@01 (not p1_1@9@01)))))
(assert (or
  (not (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01))))
  (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01)))))
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not
  (or
    (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01)))
    (and p1_1@9@01 (< i_1@80@01 (Seq_length a_1@22@01)))))))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not (or
  (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01)))
  (and p1_1@9@01 (< i_1@80@01 (Seq_length a_1@22@01))))))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 269 | p0_1@8@01 && i@79@01 < |a@69@01| || p1_1@9@01 && i_1@80@01 < |a_1@22@01| | live]
; [else-branch: 269 | !(p0_1@8@01 && i@79@01 < |a@69@01| || p1_1@9@01 && i_1@80@01 < |a_1@22@01|) | live]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 269 | p0_1@8@01 && i@79@01 < |a@69@01| || p1_1@9@01 && i_1@80@01 < |a_1@22@01|]
(assert (or
  (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01)))
  (and p1_1@9@01 (< i_1@80@01 (Seq_length a_1@22@01)))))
; [exec]
; var p0_2: Bool
(declare-const p0_2@84@01 Bool)
; [exec]
; var p1_2: Bool
(declare-const p1_2@85@01 Bool)
; [exec]
; var pt0_0: Bool
(declare-const pt0_0@86@01 Bool)
; [exec]
; var pt1_0: Bool
(declare-const pt1_0@87@01 Bool)
; [exec]
; var pf0_0: Bool
(declare-const pf0_0@88@01 Bool)
; [exec]
; var pf1_0: Bool
(declare-const pf1_0@89@01 Bool)
; [exec]
; p0_2 := p0_1 && i < |a|
; [eval] p0_1 && i < |a|
(push) ; 20
; [then-branch: 270 | !(p0_1@8@01) | live]
; [else-branch: 270 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 270 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 21
(push) ; 21
; [else-branch: 270 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(declare-const p0_2@90@01 Bool)
(assert (= p0_2@90@01 (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01)))))
; [exec]
; p1_2 := p1_1 && i_1 < |a_1|
; [eval] p1_1 && i_1 < |a_1|
(push) ; 20
; [then-branch: 271 | !(p1_1@9@01) | live]
; [else-branch: 271 | p1_1@9@01 | live]
(push) ; 21
; [then-branch: 271 | !(p1_1@9@01)]
(pop) ; 21
(push) ; 21
; [else-branch: 271 | p1_1@9@01]
(assert p1_1@9@01)
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(declare-const p1_2@91@01 Bool)
(assert (= p1_2@91@01 (and p1_1@9@01 (< i_1@80@01 (Seq_length a_1@22@01)))))
; [exec]
; pt0_0 := p0_2 && a[i] == 1
; [eval] p0_2 && a[i] == 1
(push) ; 20
; [then-branch: 272 | !(p0_2@90@01) | live]
; [else-branch: 272 | p0_2@90@01 | live]
(push) ; 21
; [then-branch: 272 | !(p0_2@90@01)]
(assert (not p0_2@90@01))
(pop) ; 21
(push) ; 21
; [else-branch: 272 | p0_2@90@01]
(assert p0_2@90@01)
; [eval] a[i] == 1
; [eval] a[i]
(push) ; 22
(assert (not (>= i@79@01 0)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(push) ; 22
(assert (not (< i@79@01 (Seq_length a@69@01))))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p0_2@90@01 (not p0_2@90@01)))
(declare-const pt0_0@92@01 Bool)
(assert (= pt0_0@92@01 (and p0_2@90@01 (= (Seq_index a@69@01 i@79@01) 1))))
; [exec]
; pt1_0 := p1_2 && a_1[i_1] == 1
; [eval] p1_2 && a_1[i_1] == 1
(push) ; 20
; [then-branch: 273 | !(p1_2@91@01) | live]
; [else-branch: 273 | p1_2@91@01 | live]
(push) ; 21
; [then-branch: 273 | !(p1_2@91@01)]
(assert (not p1_2@91@01))
(pop) ; 21
(push) ; 21
; [else-branch: 273 | p1_2@91@01]
(assert p1_2@91@01)
; [eval] a_1[i_1] == 1
; [eval] a_1[i_1]
(push) ; 22
(assert (not (>= i_1@80@01 0)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(push) ; 22
(assert (not (< i_1@80@01 (Seq_length a_1@22@01))))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p1_2@91@01 (not p1_2@91@01)))
(declare-const pt1_0@93@01 Bool)
(assert (= pt1_0@93@01 (and p1_2@91@01 (= (Seq_index a_1@22@01 i_1@80@01) 1))))
; [exec]
; pf0_0 := p0_2 && !(a[i] == 1)
; [eval] p0_2 && !(a[i] == 1)
(push) ; 20
; [then-branch: 274 | !(p0_2@90@01) | live]
; [else-branch: 274 | p0_2@90@01 | live]
(push) ; 21
; [then-branch: 274 | !(p0_2@90@01)]
(assert (not p0_2@90@01))
(pop) ; 21
(push) ; 21
; [else-branch: 274 | p0_2@90@01]
(assert p0_2@90@01)
; [eval] !(a[i] == 1)
; [eval] a[i] == 1
; [eval] a[i]
(push) ; 22
(assert (not (>= i@79@01 0)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(push) ; 22
(assert (not (< i@79@01 (Seq_length a@69@01))))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(declare-const pf0_0@94@01 Bool)
(assert (= pf0_0@94@01 (and p0_2@90@01 (not (= (Seq_index a@69@01 i@79@01) 1)))))
; [exec]
; pf1_0 := p1_2 && !(a_1[i_1] == 1)
; [eval] p1_2 && !(a_1[i_1] == 1)
(push) ; 20
; [then-branch: 275 | !(p1_2@91@01) | live]
; [else-branch: 275 | p1_2@91@01 | live]
(push) ; 21
; [then-branch: 275 | !(p1_2@91@01)]
(assert (not p1_2@91@01))
(pop) ; 21
(push) ; 21
; [else-branch: 275 | p1_2@91@01]
(assert p1_2@91@01)
; [eval] !(a_1[i_1] == 1)
; [eval] a_1[i_1] == 1
; [eval] a_1[i_1]
(push) ; 22
(assert (not (>= i_1@80@01 0)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(push) ; 22
(assert (not (< i_1@80@01 (Seq_length a_1@22@01))))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(declare-const pf1_0@95@01 Bool)
(assert (= pf1_0@95@01 (and p1_2@91@01 (not (= (Seq_index a_1@22@01 i_1@80@01) 1)))))
(push) ; 20
(set-option :rlimit 16000)
(assert (not (not pt0_0@92@01)))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 20
(set-option :rlimit 16000)
(assert (not pt0_0@92@01))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 276 | pt0_0@92@01 | live]
; [else-branch: 276 | !(pt0_0@92@01) | live]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 276 | pt0_0@92@01]
(assert pt0_0@92@01)
; [exec]
; leak := i
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt1_0@93@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 277 | pt1_0@93@01 | dead]
; [else-branch: 277 | !(pt1_0@93@01) | live]
(set-option :rlimit 0)
(push) ; 21
; [else-branch: 277 | !(pt1_0@93@01)]
(assert (not pt1_0@93@01))
(pop) ; 21
; [eval] !pt1_0
(push) ; 21
(set-option :rlimit 16000)
(assert (not pt1_0@93@01))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt1_0@93@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 278 | !(pt1_0@93@01) | live]
; [else-branch: 278 | pt1_0@93@01 | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 278 | !(pt1_0@93@01)]
(assert (not pt1_0@93@01))
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p0_2@90@01)))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 22
(set-option :rlimit 16000)
(assert (not p0_2@90@01))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 279 | p0_2@90@01 | live]
; [else-branch: 279 | !(p0_2@90@01) | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 279 | p0_2@90@01]
(assert p0_2@90@01)
; [exec]
; i := i + 1
; [eval] i + 1
(declare-const i@96@01 Int)
(assert (= i@96@01 (+ i@79@01 1)))
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not p1_2@91@01)))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 280 | p1_2@91@01 | dead]
; [else-branch: 280 | !(p1_2@91@01) | live]
(set-option :rlimit 0)
(push) ; 23
; [else-branch: 280 | !(p1_2@91@01)]
(assert (not p1_2@91@01))
(pop) ; 23
; [eval] !p1_2
(push) ; 23
(set-option :rlimit 16000)
(assert (not p1_2@91@01))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not p1_2@91@01)))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 281 | !(p1_2@91@01) | live]
; [else-branch: 281 | p1_2@91@01 | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 281 | !(p1_2@91@01)]
(assert (not p1_2@91@01))
; Loop head block: Re-establish invariant
; [eval] p0_1 ==> i >= 0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 25
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 282 | p0_1@8@01 | live]
; [else-branch: 282 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 282 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i >= 0
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p0_1@8@01)
(push) ; 24
(assert (not (=> p0_1@8@01 (>= i@96@01 0))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p0_1@8@01 (>= i@96@01 0)))
; [eval] p1_1 ==> i_1 >= 0
(push) ; 24
; [then-branch: 283 | p1_1@9@01 | dead]
; [else-branch: 283 | !(p1_1@9@01) | live]
(push) ; 25
; [else-branch: 283 | !(p1_1@9@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p0_1 ==> i <= |a|
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 284 | p0_1@8@01 | live]
; [else-branch: 284 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 284 | p0_1@8@01]
; [eval] i <= |a|
; [eval] |a|
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p0_1@8@01 (<= i@96@01 (Seq_length a@69@01)))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p0_1@8@01 (<= i@96@01 (Seq_length a@69@01))))
; [eval] p1_1 ==> i_1 <= |a_1|
(push) ; 24
; [then-branch: 285 | p1_1@9@01 | dead]
; [else-branch: 285 | !(p1_1@9@01) | live]
(push) ; 25
; [else-branch: 285 | !(p1_1@9@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] (forall j: Int ::(p0_1 ==> true) && (p1_1 ==> true))
(declare-const j@97@01 Int)
(push) ; 24
; [eval] (p0_1 ==> true) && (p1_1 ==> true)
; [eval] p0_1 ==> true
(push) ; 25
(push) ; 26
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 26
; 0.00s
; (get-info :all-statistics)
; [then-branch: 286 | p0_1@8@01 | live]
; [else-branch: 286 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 286 | p0_1@8@01]
(pop) ; 26
(pop) ; 25
; Joined path conditions
(push) ; 25
; [then-branch: 287 | False | live]
; [else-branch: 287 | True | live]
(push) ; 26
; [then-branch: 287 | False]
(assert false)
(pop) ; 26
(push) ; 26
; [else-branch: 287 | True]
; [eval] p1_1 ==> true
(push) ; 27
; [then-branch: 288 | p1_1@9@01 | dead]
; [else-branch: 288 | !(p1_1@9@01) | live]
(push) ; 28
; [else-branch: 288 | !(p1_1@9@01)]
(pop) ; 28
(pop) ; 27
; Joined path conditions
(pop) ; 26
(pop) ; 25
; Joined path conditions
; Joined path conditions
(pop) ; 24
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
; [eval] p0_1 ==> p0_1 && p1_1 ==> i == i_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 289 | p0_1@8@01 | live]
; [else-branch: 289 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 289 | p0_1@8@01]
; [eval] p0_1 && p1_1 ==> i == i_1
; [eval] p0_1 && p1_1
(push) ; 26
; [then-branch: 290 | !(p0_1@8@01) | live]
; [else-branch: 290 | p0_1@8@01 | live]
(push) ; 27
; [then-branch: 290 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 27
(push) ; 27
; [else-branch: 290 | p0_1@8@01]
(pop) ; 27
(pop) ; 26
; Joined path conditions
; Joined path conditions
(push) ; 26
; [then-branch: 291 | p0_1@8@01 && p1_1@9@01 | dead]
; [else-branch: 291 | !(p0_1@8@01 && p1_1@9@01) | live]
(push) ; 27
; [else-branch: 291 | !(p0_1@8@01 && p1_1@9@01)]
(pop) ; 27
(pop) ; 26
; Joined path conditions
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 24
; [then-branch: 292 | p1_1@9@01 | dead]
; [else-branch: 292 | !(p1_1@9@01) | live]
(push) ; 25
; [else-branch: 292 | !(p1_1@9@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 293 | p0_1@8@01 | live]
; [else-branch: 293 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 293 | p0_1@8@01]
; [eval] p0_1 && p1_1 ==> leak == leak_1
; [eval] p0_1 && p1_1
(push) ; 26
; [then-branch: 294 | !(p0_1@8@01) | live]
; [else-branch: 294 | p0_1@8@01 | live]
(push) ; 27
; [then-branch: 294 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 27
(push) ; 27
; [else-branch: 294 | p0_1@8@01]
(pop) ; 27
(pop) ; 26
; Joined path conditions
; Joined path conditions
(push) ; 26
; [then-branch: 295 | p0_1@8@01 && p1_1@9@01 | dead]
; [else-branch: 295 | !(p0_1@8@01 && p1_1@9@01) | live]
(push) ; 27
; [else-branch: 295 | !(p0_1@8@01 && p1_1@9@01)]
(pop) ; 27
(pop) ; 26
; Joined path conditions
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 24
; [then-branch: 296 | p1_1@9@01 | dead]
; [else-branch: 296 | !(p1_1@9@01) | live]
(push) ; 25
; [else-branch: 296 | !(p1_1@9@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p0_1 ==> tmp0_1 == leak
; [eval] !p0_1
(push) ; 24
; [then-branch: 297 | !(p0_1@8@01) | dead]
; [else-branch: 297 | p0_1@8@01 | live]
(push) ; 25
; [else-branch: 297 | p0_1@8@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p0_1 ==> tmp0_2 == i
; [eval] !p0_1
(push) ; 24
; [then-branch: 298 | !(p0_1@8@01) | dead]
; [else-branch: 298 | p0_1@8@01 | live]
(push) ; 25
; [else-branch: 298 | p0_1@8@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p1_1 ==> tmp1_2 == i_1
; [eval] !p1_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 299 | !(p1_1@9@01) | live]
; [else-branch: 299 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 299 | !(p1_1@9@01)]
; [eval] tmp1_2 == i_1
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p1_1 ==> tmp1_1 == leak_1
; [eval] !p1_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 300 | !(p1_1@9@01) | live]
; [else-branch: 300 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 300 | !(p1_1@9@01)]
; [eval] tmp1_1 == leak_1
(pop) ; 25
(pop) ; 24
; Joined path conditions
(pop) ; 23
(pop) ; 22
; [eval] !p0_2
(push) ; 22
(set-option :rlimit 16000)
(assert (not p0_2@90@01))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 301 | !(p0_2@90@01) | dead]
; [else-branch: 301 | p0_2@90@01 | live]
(set-option :rlimit 0)
(push) ; 22
; [else-branch: 301 | p0_2@90@01]
(assert p0_2@90@01)
(pop) ; 22
(pop) ; 21
(pop) ; 20
(push) ; 20
; [else-branch: 276 | !(pt0_0@92@01)]
(assert (not pt0_0@92@01))
(pop) ; 20
; [eval] !pt0_0
(push) ; 20
(set-option :rlimit 16000)
(assert (not pt0_0@92@01))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 20
(set-option :rlimit 16000)
(assert (not (not pt0_0@92@01)))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 302 | !(pt0_0@92@01) | live]
; [else-branch: 302 | pt0_0@92@01 | live]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 302 | !(pt0_0@92@01)]
(assert (not pt0_0@92@01))
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt1_0@93@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 303 | pt1_0@93@01 | dead]
; [else-branch: 303 | !(pt1_0@93@01) | live]
(set-option :rlimit 0)
(push) ; 21
; [else-branch: 303 | !(pt1_0@93@01)]
(assert (not pt1_0@93@01))
(pop) ; 21
; [eval] !pt1_0
(push) ; 21
(set-option :rlimit 16000)
(assert (not pt1_0@93@01))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt1_0@93@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 304 | !(pt1_0@93@01) | live]
; [else-branch: 304 | pt1_0@93@01 | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 304 | !(pt1_0@93@01)]
(assert (not pt1_0@93@01))
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p0_2@90@01)))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 22
(set-option :rlimit 16000)
(assert (not p0_2@90@01))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 305 | p0_2@90@01 | live]
; [else-branch: 305 | !(p0_2@90@01) | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 305 | p0_2@90@01]
(assert p0_2@90@01)
; [exec]
; i := i + 1
; [eval] i + 1
(declare-const i@98@01 Int)
(assert (= i@98@01 (+ i@79@01 1)))
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not p1_2@91@01)))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 306 | p1_2@91@01 | dead]
; [else-branch: 306 | !(p1_2@91@01) | live]
(set-option :rlimit 0)
(push) ; 23
; [else-branch: 306 | !(p1_2@91@01)]
(assert (not p1_2@91@01))
(pop) ; 23
; [eval] !p1_2
(push) ; 23
(set-option :rlimit 16000)
(assert (not p1_2@91@01))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not p1_2@91@01)))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 307 | !(p1_2@91@01) | live]
; [else-branch: 307 | p1_2@91@01 | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 307 | !(p1_2@91@01)]
(assert (not p1_2@91@01))
; Loop head block: Re-establish invariant
; [eval] p0_1 ==> i >= 0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 25
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 308 | p0_1@8@01 | live]
; [else-branch: 308 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 308 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i >= 0
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p0_1@8@01)
(push) ; 24
(assert (not (=> p0_1@8@01 (>= i@98@01 0))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p0_1@8@01 (>= i@98@01 0)))
; [eval] p1_1 ==> i_1 >= 0
(push) ; 24
; [then-branch: 309 | p1_1@9@01 | dead]
; [else-branch: 309 | !(p1_1@9@01) | live]
(push) ; 25
; [else-branch: 309 | !(p1_1@9@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p0_1 ==> i <= |a|
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 310 | p0_1@8@01 | live]
; [else-branch: 310 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 310 | p0_1@8@01]
; [eval] i <= |a|
; [eval] |a|
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p0_1@8@01 (<= i@98@01 (Seq_length a@69@01)))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p0_1@8@01 (<= i@98@01 (Seq_length a@69@01))))
; [eval] p1_1 ==> i_1 <= |a_1|
(push) ; 24
; [then-branch: 311 | p1_1@9@01 | dead]
; [else-branch: 311 | !(p1_1@9@01) | live]
(push) ; 25
; [else-branch: 311 | !(p1_1@9@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] (forall j: Int ::(p0_1 ==> true) && (p1_1 ==> true))
(declare-const j@99@01 Int)
(push) ; 24
; [eval] (p0_1 ==> true) && (p1_1 ==> true)
; [eval] p0_1 ==> true
(push) ; 25
(push) ; 26
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 26
; 0.00s
; (get-info :all-statistics)
; [then-branch: 312 | p0_1@8@01 | live]
; [else-branch: 312 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 312 | p0_1@8@01]
(pop) ; 26
(pop) ; 25
; Joined path conditions
(push) ; 25
; [then-branch: 313 | False | live]
; [else-branch: 313 | True | live]
(push) ; 26
; [then-branch: 313 | False]
(assert false)
(pop) ; 26
(push) ; 26
; [else-branch: 313 | True]
; [eval] p1_1 ==> true
(push) ; 27
; [then-branch: 314 | p1_1@9@01 | dead]
; [else-branch: 314 | !(p1_1@9@01) | live]
(push) ; 28
; [else-branch: 314 | !(p1_1@9@01)]
(pop) ; 28
(pop) ; 27
; Joined path conditions
(pop) ; 26
(pop) ; 25
; Joined path conditions
; Joined path conditions
(pop) ; 24
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
; [eval] p0_1 ==> p0_1 && p1_1 ==> i == i_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 315 | p0_1@8@01 | live]
; [else-branch: 315 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 315 | p0_1@8@01]
; [eval] p0_1 && p1_1 ==> i == i_1
; [eval] p0_1 && p1_1
(push) ; 26
; [then-branch: 316 | !(p0_1@8@01) | live]
; [else-branch: 316 | p0_1@8@01 | live]
(push) ; 27
; [then-branch: 316 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 27
(push) ; 27
; [else-branch: 316 | p0_1@8@01]
(pop) ; 27
(pop) ; 26
; Joined path conditions
; Joined path conditions
(push) ; 26
; [then-branch: 317 | p0_1@8@01 && p1_1@9@01 | dead]
; [else-branch: 317 | !(p0_1@8@01 && p1_1@9@01) | live]
(push) ; 27
; [else-branch: 317 | !(p0_1@8@01 && p1_1@9@01)]
(pop) ; 27
(pop) ; 26
; Joined path conditions
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 24
; [then-branch: 318 | p1_1@9@01 | dead]
; [else-branch: 318 | !(p1_1@9@01) | live]
(push) ; 25
; [else-branch: 318 | !(p1_1@9@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 319 | p0_1@8@01 | live]
; [else-branch: 319 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 319 | p0_1@8@01]
; [eval] p0_1 && p1_1 ==> leak == leak_1
; [eval] p0_1 && p1_1
(push) ; 26
; [then-branch: 320 | !(p0_1@8@01) | live]
; [else-branch: 320 | p0_1@8@01 | live]
(push) ; 27
; [then-branch: 320 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 27
(push) ; 27
; [else-branch: 320 | p0_1@8@01]
(pop) ; 27
(pop) ; 26
; Joined path conditions
; Joined path conditions
(push) ; 26
; [then-branch: 321 | p0_1@8@01 && p1_1@9@01 | dead]
; [else-branch: 321 | !(p0_1@8@01 && p1_1@9@01) | live]
(push) ; 27
; [else-branch: 321 | !(p0_1@8@01 && p1_1@9@01)]
(pop) ; 27
(pop) ; 26
; Joined path conditions
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 24
; [then-branch: 322 | p1_1@9@01 | dead]
; [else-branch: 322 | !(p1_1@9@01) | live]
(push) ; 25
; [else-branch: 322 | !(p1_1@9@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p0_1 ==> tmp0_1 == leak
; [eval] !p0_1
(push) ; 24
; [then-branch: 323 | !(p0_1@8@01) | dead]
; [else-branch: 323 | p0_1@8@01 | live]
(push) ; 25
; [else-branch: 323 | p0_1@8@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p0_1 ==> tmp0_2 == i
; [eval] !p0_1
(push) ; 24
; [then-branch: 324 | !(p0_1@8@01) | dead]
; [else-branch: 324 | p0_1@8@01 | live]
(push) ; 25
; [else-branch: 324 | p0_1@8@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p1_1 ==> tmp1_2 == i_1
; [eval] !p1_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 325 | !(p1_1@9@01) | live]
; [else-branch: 325 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 325 | !(p1_1@9@01)]
; [eval] tmp1_2 == i_1
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p1_1 ==> tmp1_1 == leak_1
; [eval] !p1_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 326 | !(p1_1@9@01) | live]
; [else-branch: 326 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 326 | !(p1_1@9@01)]
; [eval] tmp1_1 == leak_1
(pop) ; 25
(pop) ; 24
; Joined path conditions
(pop) ; 23
(pop) ; 22
; [eval] !p0_2
(push) ; 22
(set-option :rlimit 16000)
(assert (not p0_2@90@01))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 327 | !(p0_2@90@01) | dead]
; [else-branch: 327 | p0_2@90@01 | live]
(set-option :rlimit 0)
(push) ; 22
; [else-branch: 327 | p0_2@90@01]
(assert p0_2@90@01)
(pop) ; 22
(pop) ; 21
(pop) ; 20
(push) ; 20
; [else-branch: 302 | pt0_0@92@01]
(assert pt0_0@92@01)
(pop) ; 20
(pop) ; 19
(push) ; 19
; [else-branch: 269 | !(p0_1@8@01 && i@79@01 < |a@69@01| || p1_1@9@01 && i_1@80@01 < |a_1@22@01|)]
(assert (not
  (or
    (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01)))
    (and p1_1@9@01 (< i_1@80@01 (Seq_length a_1@22@01))))))
(pop) ; 19
; [eval] !(p0_1 && i < |a| || p1_1 && i_1 < |a_1|)
; [eval] p0_1 && i < |a| || p1_1 && i_1 < |a_1|
; [eval] p0_1 && i < |a|
(push) ; 19
; [then-branch: 328 | !(p0_1@8@01) | live]
; [else-branch: 328 | p0_1@8@01 | live]
(push) ; 20
; [then-branch: 328 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 20
(push) ; 20
; [else-branch: 328 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(push) ; 19
; [then-branch: 329 | p0_1@8@01 && i@79@01 < |a@69@01| | live]
; [else-branch: 329 | !(p0_1@8@01 && i@79@01 < |a@69@01|) | live]
(push) ; 20
; [then-branch: 329 | p0_1@8@01 && i@79@01 < |a@69@01|]
(assert (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01))))
(pop) ; 20
(push) ; 20
; [else-branch: 329 | !(p0_1@8@01 && i@79@01 < |a@69@01|)]
(assert (not (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01)))))
; [eval] p1_1 && i_1 < |a_1|
(push) ; 21
; [then-branch: 330 | !(p1_1@9@01) | live]
; [else-branch: 330 | p1_1@9@01 | live]
(push) ; 22
; [then-branch: 330 | !(p1_1@9@01)]
(pop) ; 22
(push) ; 22
; [else-branch: 330 | p1_1@9@01]
(assert p1_1@9@01)
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(push) ; 19
(set-option :rlimit 16000)
(assert (not (or
  (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01)))
  (and p1_1@9@01 (< i_1@80@01 (Seq_length a_1@22@01))))))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not
  (or
    (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01)))
    (and p1_1@9@01 (< i_1@80@01 (Seq_length a_1@22@01)))))))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 331 | !(p0_1@8@01 && i@79@01 < |a@69@01| || p1_1@9@01 && i_1@80@01 < |a_1@22@01|) | live]
; [else-branch: 331 | p0_1@8@01 && i@79@01 < |a@69@01| || p1_1@9@01 && i_1@80@01 < |a_1@22@01| | live]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 331 | !(p0_1@8@01 && i@79@01 < |a@69@01| || p1_1@9@01 && i_1@80@01 < |a_1@22@01|)]
(assert (not
  (or
    (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01)))
    (and p1_1@9@01 (< i_1@80@01 (Seq_length a_1@22@01))))))
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 20
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 332 | p0_1@8@01 | live]
; [else-branch: 332 | !(p0_1@8@01) | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 332 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] p0_1 && p1_1 ==> leak == leak_1
; [eval] p0_1 && p1_1
(push) ; 22
; [then-branch: 333 | !(p0_1@8@01) | live]
; [else-branch: 333 | p0_1@8@01 | live]
(push) ; 23
; [then-branch: 333 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 23
(push) ; 23
; [else-branch: 333 | p0_1@8@01]
(pop) ; 23
(pop) ; 22
; Joined path conditions
; Joined path conditions
(push) ; 22
; [then-branch: 334 | p0_1@8@01 && p1_1@9@01 | dead]
; [else-branch: 334 | !(p0_1@8@01 && p1_1@9@01) | live]
(push) ; 23
; [else-branch: 334 | !(p0_1@8@01 && p1_1@9@01)]
(pop) ; 23
(pop) ; 22
; Joined path conditions
(pop) ; 21
(pop) ; 20
; Joined path conditions
(assert p0_1@8@01)
; [eval] p1_1 ==> true
(push) ; 20
; [then-branch: 335 | p1_1@9@01 | dead]
; [else-branch: 335 | !(p1_1@9@01) | live]
(push) ; 21
; [else-branch: 335 | !(p1_1@9@01)]
(pop) ; 21
(pop) ; 20
; Joined path conditions
(pop) ; 19
(push) ; 19
; [else-branch: 331 | p0_1@8@01 && i@79@01 < |a@69@01| || p1_1@9@01 && i_1@80@01 < |a_1@22@01|]
(assert (or
  (and p0_1@8@01 (< i@79@01 (Seq_length a@69@01)))
  (and p1_1@9@01 (< i_1@80@01 (Seq_length a_1@22@01)))))
(pop) ; 19
(pop) ; 18
(pop) ; 17
(pop) ; 16
; [eval] !!p1_1
; [eval] !p1_1
; [then-branch: 336 | p1_1@9@01 | dead]
; [else-branch: 336 | !(p1_1@9@01) | live]
(push) ; 16
; [else-branch: 336 | !(p1_1@9@01)]
(pop) ; 16
(pop) ; 15
(pop) ; 14
; [eval] !!p1_1
; [eval] !p1_1
; [then-branch: 337 | p1_1@9@01 | dead]
; [else-branch: 337 | !(p1_1@9@01) | live]
(push) ; 14
; [else-branch: 337 | !(p1_1@9@01)]
(pop) ; 14
(pop) ; 13
(pop) ; 12
(pop) ; 11
; [eval] !p0_1
(push) ; 11
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 338 | !(p0_1@8@01) | dead]
; [else-branch: 338 | p0_1@8@01 | live]
(set-option :rlimit 0)
(push) ; 11
; [else-branch: 338 | p0_1@8@01]
(assert p0_1@8@01)
(pop) ; 11
(pop) ; 10
(pop) ; 9
; [eval] !p0_1
(push) ; 9
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
; [then-branch: 339 | !(p0_1@8@01) | dead]
; [else-branch: 339 | p0_1@8@01 | live]
(set-option :rlimit 0)
(push) ; 9
; [else-branch: 339 | p0_1@8@01]
(assert p0_1@8@01)
(pop) ; 9
(pop) ; 8
(pop) ; 7
; [eval] !p0_1
(push) ; 7
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 340 | !(p0_1@8@01) | dead]
; [else-branch: 340 | p0_1@8@01 | live]
(set-option :rlimit 0)
(push) ; 7
; [else-branch: 340 | p0_1@8@01]
(assert p0_1@8@01)
(pop) ; 7
(pop) ; 6
(pop) ; 5
; [eval] !p0_1
(push) ; 5
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 341 | !(p0_1@8@01) | dead]
; [else-branch: 341 | p0_1@8@01 | live]
(set-option :rlimit 0)
(push) ; 5
; [else-branch: 341 | p0_1@8@01]
(assert p0_1@8@01)
(pop) ; 5
(pop) ; 4
(push) ; 4
; [else-branch: 201 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 4
(pop) ; 3
(push) ; 3
; [else-branch: 19 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(pop) ; 3
; [eval] !p0_1
(push) ; 3
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p0_1@8@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 342 | !(p0_1@8@01) | live]
; [else-branch: 342 | p0_1@8@01 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 342 | !(p0_1@8@01)]
(assert (not p0_1@8@01))
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 343 | p1_1@9@01 | live]
; [else-branch: 343 | !(p1_1@9@01) | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 343 | p1_1@9@01]
(assert p1_1@9@01)
; [exec]
; _cond0_1 := false
; [then-branch: 344 | p0_1@8@01 | dead]
; [else-branch: 344 | !(p0_1@8@01) | live]
(push) ; 5
; [else-branch: 344 | !(p0_1@8@01)]
(pop) ; 5
; [eval] !p0_1
(push) ; 5
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 345 | !(p0_1@8@01) | live]
; [else-branch: 345 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 345 | !(p0_1@8@01)]
(push) ; 6
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [then-branch: 346 | p1_1@9@01 | live]
; [else-branch: 346 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 6
; [then-branch: 346 | p1_1@9@01]
; [exec]
; a_1 := a_in_1
; [then-branch: 347 | p0_1@8@01 | dead]
; [else-branch: 347 | !(p0_1@8@01) | live]
(push) ; 7
; [else-branch: 347 | !(p0_1@8@01)]
(pop) ; 7
; [eval] !p0_1
(push) ; 7
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 348 | !(p0_1@8@01) | live]
; [else-branch: 348 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 7
; [then-branch: 348 | !(p0_1@8@01)]
(push) ; 8
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
; [then-branch: 349 | p1_1@9@01 | live]
; [else-branch: 349 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 8
; [then-branch: 349 | p1_1@9@01]
; [exec]
; a_1 := a_1[secret_1 := 1]
; [eval] a_1[secret_1 := 1]
(push) ; 9
(assert (not (>= secret_1@13@01 0)))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(push) ; 9
(assert (not (< secret_1@13@01 (Seq_length a_in_1@11@01))))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(declare-const a_1@100@01 Seq<Int>)
(assert (=
  a_1@100@01
  (Seq_append
    (Seq_take a_in_1@11@01 secret_1@13@01)
    (Seq_append (Seq_singleton 1) (Seq_drop a_in_1@11@01 (+ secret_1@13@01 1))))))
; [exec]
; inhale p0_1 && p1_1 ==> secret == secret_1
(declare-const $t@101@01 $Snap)
(assert (= $t@101@01 $Snap.unit))
; [eval] p0_1 && p1_1 ==> secret == secret_1
; [eval] p0_1 && p1_1
(push) ; 9
; [then-branch: 350 | !(p0_1@8@01) | live]
; [else-branch: 350 | p0_1@8@01 | live]
(push) ; 10
; [then-branch: 350 | !(p0_1@8@01)]
(pop) ; 10
(push) ; 10
; [else-branch: 350 | p0_1@8@01]
(assert p0_1@8@01)
(pop) ; 10
(pop) ; 9
; Joined path conditions
; Joined path conditions
(assert (or p0_1@8@01 (not p0_1@8@01)))
(push) ; 9
(push) ; 10
(set-option :rlimit 16000)
(assert (not (not (and p0_1@8@01 p1_1@9@01))))
(check-sat)
; unsat
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
; [then-branch: 351 | p0_1@8@01 && p1_1@9@01 | dead]
; [else-branch: 351 | !(p0_1@8@01 && p1_1@9@01) | live]
(set-option :rlimit 0)
(push) ; 10
; [else-branch: 351 | !(p0_1@8@01 && p1_1@9@01)]
(assert (not (and p0_1@8@01 p1_1@9@01)))
(pop) ; 10
(pop) ; 9
; Joined path conditions
(assert (not (and p0_1@8@01 p1_1@9@01)))
; State saturation: after inhale
(set-option :rlimit 32000)
(check-sat)
; unknown
; [then-branch: 352 | p0_1@8@01 | dead]
; [else-branch: 352 | !(p0_1@8@01) | live]
(set-option :rlimit 0)
(push) ; 9
; [else-branch: 352 | !(p0_1@8@01)]
(pop) ; 9
; [eval] !p0_1
(push) ; 9
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
; [then-branch: 353 | !(p0_1@8@01) | live]
; [else-branch: 353 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 9
; [then-branch: 353 | !(p0_1@8@01)]
(push) ; 10
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
; [then-branch: 354 | p1_1@9@01 | live]
; [else-branch: 354 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 10
; [then-branch: 354 | p1_1@9@01]
; [exec]
; i_1 := 0
; [then-branch: 355 | p0_1@8@01 | dead]
; [else-branch: 355 | !(p0_1@8@01) | live]
(push) ; 11
; [else-branch: 355 | !(p0_1@8@01)]
(pop) ; 11
; [eval] !p0_1
(push) ; 11
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 356 | !(p0_1@8@01) | live]
; [else-branch: 356 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 356 | !(p0_1@8@01)]
(push) ; 12
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 12
; 0.00s
; (get-info :all-statistics)
; [then-branch: 357 | p1_1@9@01 | live]
; [else-branch: 357 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 12
; [then-branch: 357 | p1_1@9@01]
; [exec]
; leak_1 := 0
; [eval] !p0_1
(push) ; 13
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 13
; 0.00s
; (get-info :all-statistics)
; [then-branch: 358 | !(p0_1@8@01) | live]
; [else-branch: 358 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 13
; [then-branch: 358 | !(p0_1@8@01)]
; [exec]
; tmp0_1 := leak
; [eval] !p1_1
; [then-branch: 359 | !(p1_1@9@01) | dead]
; [else-branch: 359 | p1_1@9@01 | live]
(push) ; 14
; [else-branch: 359 | p1_1@9@01]
(pop) ; 14
; [eval] !!p1_1
; [eval] !p1_1
(push) ; 14
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 14
; 0.00s
; (get-info :all-statistics)
; [then-branch: 360 | p1_1@9@01 | live]
; [else-branch: 360 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 14
; [then-branch: 360 | p1_1@9@01]
; [eval] !p0_1
(push) ; 15
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
; [then-branch: 361 | !(p0_1@8@01) | live]
; [else-branch: 361 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 15
; [then-branch: 361 | !(p0_1@8@01)]
; [exec]
; tmp0_2 := i
; [eval] !p1_1
; [then-branch: 362 | !(p1_1@9@01) | dead]
; [else-branch: 362 | p1_1@9@01 | live]
(push) ; 16
; [else-branch: 362 | p1_1@9@01]
(pop) ; 16
; [eval] !!p1_1
; [eval] !p1_1
(push) ; 16
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [then-branch: 363 | p1_1@9@01 | live]
; [else-branch: 363 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 16
; [then-branch: 363 | p1_1@9@01]
(declare-const p0_2@102@01 Bool)
(declare-const p1_2@103@01 Bool)
(declare-const pt0_0@104@01 Bool)
(declare-const pt1_0@105@01 Bool)
(declare-const pf0_0@106@01 Bool)
(declare-const pf1_0@107@01 Bool)
(declare-const leak@108@01 Int)
(declare-const leak_1@109@01 Int)
(declare-const i@110@01 Int)
(declare-const i_1@111@01 Int)
(push) ; 17
; Loop head block: Check well-definedness of invariant
(declare-const $t@112@01 $Snap)
(assert (= $t@112@01 ($Snap.combine ($Snap.first $t@112@01) ($Snap.second $t@112@01))))
(assert (= ($Snap.first $t@112@01) $Snap.unit))
; [eval] p0_1 ==> i >= 0
(push) ; 18
; [then-branch: 364 | p0_1@8@01 | dead]
; [else-branch: 364 | !(p0_1@8@01) | live]
(push) ; 19
; [else-branch: 364 | !(p0_1@8@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second $t@112@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@112@01))
    ($Snap.second ($Snap.second $t@112@01)))))
(assert (= ($Snap.first ($Snap.second $t@112@01)) $Snap.unit))
; [eval] p1_1 ==> i_1 >= 0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 365 | p1_1@9@01 | live]
; [else-branch: 365 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 365 | p1_1@9@01]
; [eval] i_1 >= 0
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> p1_1@9@01 (>= i_1@111@01 0)))
(assert (=
  ($Snap.second ($Snap.second $t@112@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@112@01)))
    ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@112@01))) $Snap.unit))
; [eval] p0_1 ==> i <= |a|
(push) ; 18
; [then-branch: 366 | p0_1@8@01 | dead]
; [else-branch: 366 | !(p0_1@8@01) | live]
(push) ; 19
; [else-branch: 366 | !(p0_1@8@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second $t@112@01)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@112@01))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@112@01))))
  $Snap.unit))
; [eval] p1_1 ==> i_1 <= |a_1|
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 367 | p1_1@9@01 | live]
; [else-branch: 367 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 367 | p1_1@9@01]
; [eval] i_1 <= |a_1|
; [eval] |a_1|
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> p1_1@9@01 (<= i_1@111@01 (Seq_length a_1@100@01))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))
  $Snap.unit))
; [eval] (forall j: Int ::(p0_1 ==> true) && (p1_1 ==> true))
(declare-const j@113@01 Int)
(push) ; 18
; [eval] (p0_1 ==> true) && (p1_1 ==> true)
; [eval] p0_1 ==> true
(push) ; 19
; [then-branch: 368 | p0_1@8@01 | dead]
; [else-branch: 368 | !(p0_1@8@01) | live]
(push) ; 20
; [else-branch: 368 | !(p0_1@8@01)]
(pop) ; 20
(pop) ; 19
; Joined path conditions
(push) ; 19
; [then-branch: 369 | False | live]
; [else-branch: 369 | True | live]
(push) ; 20
; [then-branch: 369 | False]
(assert false)
(pop) ; 20
(push) ; 20
; [else-branch: 369 | True]
; [eval] p1_1 ==> true
(push) ; 21
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 370 | p1_1@9@01 | live]
; [else-branch: 370 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 370 | p1_1@9@01]
(pop) ; 22
(pop) ; 21
; Joined path conditions
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(pop) ; 18
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))
  $Snap.unit))
; [eval] p0_1 ==> p0_1 && p1_1 ==> i == i_1
(push) ; 18
; [then-branch: 371 | p0_1@8@01 | dead]
; [else-branch: 371 | !(p0_1@8@01) | live]
(push) ; 19
; [else-branch: 371 | !(p0_1@8@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))
  $Snap.unit))
; [eval] p1_1 ==> true
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 372 | p1_1@9@01 | live]
; [else-branch: 372 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 372 | p1_1@9@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))
  $Snap.unit))
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 18
; [then-branch: 373 | p0_1@8@01 | dead]
; [else-branch: 373 | !(p0_1@8@01) | live]
(push) ; 19
; [else-branch: 373 | !(p0_1@8@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))
  $Snap.unit))
; [eval] p1_1 ==> true
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 374 | p1_1@9@01 | live]
; [else-branch: 374 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 374 | p1_1@9@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))
  $Snap.unit))
; [eval] !p0_1 ==> tmp0_1 == leak
; [eval] !p0_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 375 | !(p0_1@8@01) | live]
; [else-branch: 375 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 375 | !(p0_1@8@01)]
; [eval] tmp0_1 == leak
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> (not p0_1@8@01) (= leak@14@01 leak@108@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))))
  $Snap.unit))
; [eval] !p0_1 ==> tmp0_2 == i
; [eval] !p0_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 376 | !(p0_1@8@01) | live]
; [else-branch: 376 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 376 | !(p0_1@8@01)]
; [eval] tmp0_2 == i
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> (not p0_1@8@01) (= i@20@01 i@110@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))))
  $Snap.unit))
; [eval] !p1_1 ==> tmp1_2 == i_1
; [eval] !p1_1
(push) ; 18
; [then-branch: 377 | !(p1_1@9@01) | dead]
; [else-branch: 377 | p1_1@9@01 | live]
(push) ; 19
; [else-branch: 377 | p1_1@9@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))))
  $Snap.unit))
; [eval] !p1_1 ==> tmp1_1 == leak_1
; [eval] !p1_1
(push) ; 18
; [then-branch: 378 | !(p1_1@9@01) | dead]
; [else-branch: 378 | p1_1@9@01 | live]
(push) ; 19
; [else-branch: 378 | p1_1@9@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(pop) ; 17
(push) ; 17
; Loop head block: Establish invariant
; [eval] p0_1 ==> i >= 0
(push) ; 18
; [then-branch: 379 | p0_1@8@01 | dead]
; [else-branch: 379 | !(p0_1@8@01) | live]
(push) ; 19
; [else-branch: 379 | !(p0_1@8@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] p1_1 ==> i_1 >= 0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 380 | p1_1@9@01 | live]
; [else-branch: 380 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 380 | p1_1@9@01]
; [eval] i_1 >= 0
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] p0_1 ==> i <= |a|
(push) ; 18
; [then-branch: 381 | p0_1@8@01 | dead]
; [else-branch: 381 | !(p0_1@8@01) | live]
(push) ; 19
; [else-branch: 381 | !(p0_1@8@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] p1_1 ==> i_1 <= |a_1|
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 382 | p1_1@9@01 | live]
; [else-branch: 382 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 382 | p1_1@9@01]
; [eval] i_1 <= |a_1|
; [eval] |a_1|
(pop) ; 19
(pop) ; 18
; Joined path conditions
(push) ; 18
(assert (not (=> p1_1@9@01 (<= 0 (Seq_length a_1@100@01)))))
(check-sat)
; unsat
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
(assert (=> p1_1@9@01 (<= 0 (Seq_length a_1@100@01))))
; [eval] (forall j: Int ::(p0_1 ==> true) && (p1_1 ==> true))
(declare-const j@114@01 Int)
(push) ; 18
; [eval] (p0_1 ==> true) && (p1_1 ==> true)
; [eval] p0_1 ==> true
(push) ; 19
; [then-branch: 383 | p0_1@8@01 | dead]
; [else-branch: 383 | !(p0_1@8@01) | live]
(push) ; 20
; [else-branch: 383 | !(p0_1@8@01)]
(pop) ; 20
(pop) ; 19
; Joined path conditions
(push) ; 19
; [then-branch: 384 | False | live]
; [else-branch: 384 | True | live]
(push) ; 20
; [then-branch: 384 | False]
(assert false)
(pop) ; 20
(push) ; 20
; [else-branch: 384 | True]
; [eval] p1_1 ==> true
(push) ; 21
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 385 | p1_1@9@01 | live]
; [else-branch: 385 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 385 | p1_1@9@01]
(pop) ; 22
(pop) ; 21
; Joined path conditions
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(pop) ; 18
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
; [eval] p0_1 ==> p0_1 && p1_1 ==> i == i_1
(push) ; 18
; [then-branch: 386 | p0_1@8@01 | dead]
; [else-branch: 386 | !(p0_1@8@01) | live]
(push) ; 19
; [else-branch: 386 | !(p0_1@8@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 387 | p1_1@9@01 | live]
; [else-branch: 387 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 387 | p1_1@9@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 18
; [then-branch: 388 | p0_1@8@01 | dead]
; [else-branch: 388 | !(p0_1@8@01) | live]
(push) ; 19
; [else-branch: 388 | !(p0_1@8@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 389 | p1_1@9@01 | live]
; [else-branch: 389 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 389 | p1_1@9@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p0_1 ==> tmp0_1 == leak
; [eval] !p0_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 390 | !(p0_1@8@01) | live]
; [else-branch: 390 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 390 | !(p0_1@8@01)]
; [eval] tmp0_1 == leak
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p0_1 ==> tmp0_2 == i
; [eval] !p0_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 391 | !(p0_1@8@01) | live]
; [else-branch: 391 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 391 | !(p0_1@8@01)]
; [eval] tmp0_2 == i
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p1_1 ==> tmp1_2 == i_1
; [eval] !p1_1
(push) ; 18
; [then-branch: 392 | !(p1_1@9@01) | dead]
; [else-branch: 392 | p1_1@9@01 | live]
(push) ; 19
; [else-branch: 392 | p1_1@9@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p1_1 ==> tmp1_1 == leak_1
; [eval] !p1_1
(push) ; 18
; [then-branch: 393 | !(p1_1@9@01) | dead]
; [else-branch: 393 | p1_1@9@01 | live]
(push) ; 19
; [else-branch: 393 | p1_1@9@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; Loop head block: Execute statements of loop head block (in invariant state)
(push) ; 18
(assert (= $t@112@01 ($Snap.combine ($Snap.first $t@112@01) ($Snap.second $t@112@01))))
(assert (= ($Snap.first $t@112@01) $Snap.unit))
(assert (=
  ($Snap.second $t@112@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@112@01))
    ($Snap.second ($Snap.second $t@112@01)))))
(assert (= ($Snap.first ($Snap.second $t@112@01)) $Snap.unit))
(assert (=> p1_1@9@01 (>= i_1@111@01 0)))
(assert (=
  ($Snap.second ($Snap.second $t@112@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@112@01)))
    ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@112@01))) $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second $t@112@01)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@112@01))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@112@01))))
  $Snap.unit))
(assert (=> p1_1@9@01 (<= i_1@111@01 (Seq_length a_1@100@01))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))
  $Snap.unit))
(assert (=> (not p0_1@8@01) (= leak@14@01 leak@108@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))))
  $Snap.unit))
(assert (=> (not p0_1@8@01) (= i@20@01 i@110@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01)))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@112@01))))))))))))
  $Snap.unit))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 16000)
(check-sat)
; unknown
; Loop head block: Check well-definedness of edge conditions
(set-option :rlimit 0)
(push) ; 19
; [eval] p0_1 && i < |a| || p1_1 && i_1 < |a_1|
; [eval] p0_1 && i < |a|
(push) ; 20
; [then-branch: 394 | !(p0_1@8@01) | live]
; [else-branch: 394 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 394 | !(p0_1@8@01)]
(pop) ; 21
(push) ; 21
; [else-branch: 394 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(push) ; 20
; [then-branch: 395 | p0_1@8@01 && i@110@01 < |a@19@01| | live]
; [else-branch: 395 | !(p0_1@8@01 && i@110@01 < |a@19@01|) | live]
(push) ; 21
; [then-branch: 395 | p0_1@8@01 && i@110@01 < |a@19@01|]
(assert (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01))))
(pop) ; 21
(push) ; 21
; [else-branch: 395 | !(p0_1@8@01 && i@110@01 < |a@19@01|)]
(assert (not (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01)))))
; [eval] p1_1 && i_1 < |a_1|
(push) ; 22
; [then-branch: 396 | !(p1_1@9@01) | live]
; [else-branch: 396 | p1_1@9@01 | live]
(push) ; 23
; [then-branch: 396 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 23
(push) ; 23
; [else-branch: 396 | p1_1@9@01]
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 23
(pop) ; 22
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01))))
  (and
    (not (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01))))
    (or p1_1@9@01 (not p1_1@9@01)))))
(assert (or
  (not (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01))))
  (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01)))))
(pop) ; 19
(push) ; 19
; [eval] !(p0_1 && i < |a| || p1_1 && i_1 < |a_1|)
; [eval] p0_1 && i < |a| || p1_1 && i_1 < |a_1|
; [eval] p0_1 && i < |a|
(push) ; 20
; [then-branch: 397 | !(p0_1@8@01) | live]
; [else-branch: 397 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 397 | !(p0_1@8@01)]
(pop) ; 21
(push) ; 21
; [else-branch: 397 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(push) ; 20
; [then-branch: 398 | p0_1@8@01 && i@110@01 < |a@19@01| | live]
; [else-branch: 398 | !(p0_1@8@01 && i@110@01 < |a@19@01|) | live]
(push) ; 21
; [then-branch: 398 | p0_1@8@01 && i@110@01 < |a@19@01|]
(assert (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01))))
(pop) ; 21
(push) ; 21
; [else-branch: 398 | !(p0_1@8@01 && i@110@01 < |a@19@01|)]
(assert (not (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01)))))
; [eval] p1_1 && i_1 < |a_1|
(push) ; 22
; [then-branch: 399 | !(p1_1@9@01) | live]
; [else-branch: 399 | p1_1@9@01 | live]
(push) ; 23
; [then-branch: 399 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 23
(push) ; 23
; [else-branch: 399 | p1_1@9@01]
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 23
(pop) ; 22
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01))))
  (and
    (not (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01))))
    (or p1_1@9@01 (not p1_1@9@01)))))
(assert (or
  (not (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01))))
  (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01)))))
(pop) ; 19
; Loop head block: Follow loop-internal edges
; [eval] p0_1 && i < |a| || p1_1 && i_1 < |a_1|
; [eval] p0_1 && i < |a|
(push) ; 19
; [then-branch: 400 | !(p0_1@8@01) | live]
; [else-branch: 400 | p0_1@8@01 | live]
(push) ; 20
; [then-branch: 400 | !(p0_1@8@01)]
(pop) ; 20
(push) ; 20
; [else-branch: 400 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(push) ; 19
; [then-branch: 401 | p0_1@8@01 && i@110@01 < |a@19@01| | live]
; [else-branch: 401 | !(p0_1@8@01 && i@110@01 < |a@19@01|) | live]
(push) ; 20
; [then-branch: 401 | p0_1@8@01 && i@110@01 < |a@19@01|]
(assert (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01))))
(pop) ; 20
(push) ; 20
; [else-branch: 401 | !(p0_1@8@01 && i@110@01 < |a@19@01|)]
(assert (not (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01)))))
; [eval] p1_1 && i_1 < |a_1|
(push) ; 21
; [then-branch: 402 | !(p1_1@9@01) | live]
; [else-branch: 402 | p1_1@9@01 | live]
(push) ; 22
; [then-branch: 402 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 22
(push) ; 22
; [else-branch: 402 | p1_1@9@01]
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01))))
  (and
    (not (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01))))
    (or p1_1@9@01 (not p1_1@9@01)))))
(assert (or
  (not (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01))))
  (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01)))))
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not
  (or
    (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01)))
    (and p1_1@9@01 (< i_1@111@01 (Seq_length a_1@100@01)))))))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not (or
  (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01)))
  (and p1_1@9@01 (< i_1@111@01 (Seq_length a_1@100@01))))))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 403 | p0_1@8@01 && i@110@01 < |a@19@01| || p1_1@9@01 && i_1@111@01 < |a_1@100@01| | live]
; [else-branch: 403 | !(p0_1@8@01 && i@110@01 < |a@19@01| || p1_1@9@01 && i_1@111@01 < |a_1@100@01|) | live]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 403 | p0_1@8@01 && i@110@01 < |a@19@01| || p1_1@9@01 && i_1@111@01 < |a_1@100@01|]
(assert (or
  (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01)))
  (and p1_1@9@01 (< i_1@111@01 (Seq_length a_1@100@01)))))
; [exec]
; var p0_2: Bool
(declare-const p0_2@115@01 Bool)
; [exec]
; var p1_2: Bool
(declare-const p1_2@116@01 Bool)
; [exec]
; var pt0_0: Bool
(declare-const pt0_0@117@01 Bool)
; [exec]
; var pt1_0: Bool
(declare-const pt1_0@118@01 Bool)
; [exec]
; var pf0_0: Bool
(declare-const pf0_0@119@01 Bool)
; [exec]
; var pf1_0: Bool
(declare-const pf1_0@120@01 Bool)
; [exec]
; p0_2 := p0_1 && i < |a|
; [eval] p0_1 && i < |a|
(push) ; 20
; [then-branch: 404 | !(p0_1@8@01) | live]
; [else-branch: 404 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 404 | !(p0_1@8@01)]
(pop) ; 21
(push) ; 21
; [else-branch: 404 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(declare-const p0_2@121@01 Bool)
(assert (= p0_2@121@01 (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01)))))
; [exec]
; p1_2 := p1_1 && i_1 < |a_1|
; [eval] p1_1 && i_1 < |a_1|
(push) ; 20
; [then-branch: 405 | !(p1_1@9@01) | live]
; [else-branch: 405 | p1_1@9@01 | live]
(push) ; 21
; [then-branch: 405 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 21
(push) ; 21
; [else-branch: 405 | p1_1@9@01]
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(declare-const p1_2@122@01 Bool)
(assert (= p1_2@122@01 (and p1_1@9@01 (< i_1@111@01 (Seq_length a_1@100@01)))))
; [exec]
; pt0_0 := p0_2 && a[i] == 1
; [eval] p0_2 && a[i] == 1
(push) ; 20
; [then-branch: 406 | !(p0_2@121@01) | live]
; [else-branch: 406 | p0_2@121@01 | live]
(push) ; 21
; [then-branch: 406 | !(p0_2@121@01)]
(assert (not p0_2@121@01))
(pop) ; 21
(push) ; 21
; [else-branch: 406 | p0_2@121@01]
(assert p0_2@121@01)
; [eval] a[i] == 1
; [eval] a[i]
(push) ; 22
(assert (not (>= i@110@01 0)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(push) ; 22
(assert (not (< i@110@01 (Seq_length a@19@01))))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p0_2@121@01 (not p0_2@121@01)))
(declare-const pt0_0@123@01 Bool)
(assert (= pt0_0@123@01 (and p0_2@121@01 (= (Seq_index a@19@01 i@110@01) 1))))
; [exec]
; pt1_0 := p1_2 && a_1[i_1] == 1
; [eval] p1_2 && a_1[i_1] == 1
(push) ; 20
; [then-branch: 407 | !(p1_2@122@01) | live]
; [else-branch: 407 | p1_2@122@01 | live]
(push) ; 21
; [then-branch: 407 | !(p1_2@122@01)]
(assert (not p1_2@122@01))
(pop) ; 21
(push) ; 21
; [else-branch: 407 | p1_2@122@01]
(assert p1_2@122@01)
; [eval] a_1[i_1] == 1
; [eval] a_1[i_1]
(push) ; 22
(assert (not (>= i_1@111@01 0)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(push) ; 22
(assert (not (< i_1@111@01 (Seq_length a_1@100@01))))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p1_2@122@01 (not p1_2@122@01)))
(declare-const pt1_0@124@01 Bool)
(assert (= pt1_0@124@01 (and p1_2@122@01 (= (Seq_index a_1@100@01 i_1@111@01) 1))))
; [exec]
; pf0_0 := p0_2 && !(a[i] == 1)
; [eval] p0_2 && !(a[i] == 1)
(push) ; 20
; [then-branch: 408 | !(p0_2@121@01) | live]
; [else-branch: 408 | p0_2@121@01 | live]
(push) ; 21
; [then-branch: 408 | !(p0_2@121@01)]
(assert (not p0_2@121@01))
(pop) ; 21
(push) ; 21
; [else-branch: 408 | p0_2@121@01]
(assert p0_2@121@01)
; [eval] !(a[i] == 1)
; [eval] a[i] == 1
; [eval] a[i]
(push) ; 22
(assert (not (>= i@110@01 0)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(push) ; 22
(assert (not (< i@110@01 (Seq_length a@19@01))))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(declare-const pf0_0@125@01 Bool)
(assert (= pf0_0@125@01 (and p0_2@121@01 (not (= (Seq_index a@19@01 i@110@01) 1)))))
; [exec]
; pf1_0 := p1_2 && !(a_1[i_1] == 1)
; [eval] p1_2 && !(a_1[i_1] == 1)
(push) ; 20
; [then-branch: 409 | !(p1_2@122@01) | live]
; [else-branch: 409 | p1_2@122@01 | live]
(push) ; 21
; [then-branch: 409 | !(p1_2@122@01)]
(assert (not p1_2@122@01))
(pop) ; 21
(push) ; 21
; [else-branch: 409 | p1_2@122@01]
(assert p1_2@122@01)
; [eval] !(a_1[i_1] == 1)
; [eval] a_1[i_1] == 1
; [eval] a_1[i_1]
(push) ; 22
(assert (not (>= i_1@111@01 0)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(push) ; 22
(assert (not (< i_1@111@01 (Seq_length a_1@100@01))))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(declare-const pf1_0@126@01 Bool)
(assert (= pf1_0@126@01 (and p1_2@122@01 (not (= (Seq_index a_1@100@01 i_1@111@01) 1)))))
(push) ; 20
(set-option :rlimit 16000)
(assert (not (not pt0_0@123@01)))
(check-sat)
; unsat
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 410 | pt0_0@123@01 | dead]
; [else-branch: 410 | !(pt0_0@123@01) | live]
(set-option :rlimit 0)
(push) ; 20
; [else-branch: 410 | !(pt0_0@123@01)]
(assert (not pt0_0@123@01))
(pop) ; 20
; [eval] !pt0_0
(push) ; 20
(set-option :rlimit 16000)
(assert (not pt0_0@123@01))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 20
(set-option :rlimit 16000)
(assert (not (not pt0_0@123@01)))
(check-sat)
; unsat
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 411 | !(pt0_0@123@01) | live]
; [else-branch: 411 | pt0_0@123@01 | dead]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 411 | !(pt0_0@123@01)]
(assert (not pt0_0@123@01))
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt1_0@124@01)))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not pt1_0@124@01))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 412 | pt1_0@124@01 | live]
; [else-branch: 412 | !(pt1_0@124@01) | live]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 412 | pt1_0@124@01]
(assert pt1_0@124@01)
; [exec]
; leak_1 := i_1
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p0_2@121@01)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 413 | p0_2@121@01 | dead]
; [else-branch: 413 | !(p0_2@121@01) | live]
(set-option :rlimit 0)
(push) ; 22
; [else-branch: 413 | !(p0_2@121@01)]
(assert (not p0_2@121@01))
(pop) ; 22
; [eval] !p0_2
(push) ; 22
(set-option :rlimit 16000)
(assert (not p0_2@121@01))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p0_2@121@01)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 414 | !(p0_2@121@01) | live]
; [else-branch: 414 | p0_2@121@01 | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 414 | !(p0_2@121@01)]
(assert (not p0_2@121@01))
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not p1_2@122@01)))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 23
(set-option :rlimit 16000)
(assert (not p1_2@122@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 415 | p1_2@122@01 | live]
; [else-branch: 415 | !(p1_2@122@01) | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 415 | p1_2@122@01]
(assert p1_2@122@01)
; [exec]
; i_1 := i_1 + 1
; [eval] i_1 + 1
(declare-const i_1@127@01 Int)
(assert (= i_1@127@01 (+ i_1@111@01 1)))
; Loop head block: Re-establish invariant
; [eval] p0_1 ==> i >= 0
(push) ; 24
; [then-branch: 416 | p0_1@8@01 | dead]
; [else-branch: 416 | !(p0_1@8@01) | live]
(push) ; 25
; [else-branch: 416 | !(p0_1@8@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p1_1 ==> i_1 >= 0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 417 | p1_1@9@01 | live]
; [else-branch: 417 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 417 | p1_1@9@01]
; [eval] i_1 >= 0
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p1_1@9@01 (>= i_1@127@01 0))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p1_1@9@01 (>= i_1@127@01 0)))
; [eval] p0_1 ==> i <= |a|
(push) ; 24
; [then-branch: 418 | p0_1@8@01 | dead]
; [else-branch: 418 | !(p0_1@8@01) | live]
(push) ; 25
; [else-branch: 418 | !(p0_1@8@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p1_1 ==> i_1 <= |a_1|
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 419 | p1_1@9@01 | live]
; [else-branch: 419 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 419 | p1_1@9@01]
; [eval] i_1 <= |a_1|
; [eval] |a_1|
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p1_1@9@01 (<= i_1@127@01 (Seq_length a_1@100@01)))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p1_1@9@01 (<= i_1@127@01 (Seq_length a_1@100@01))))
; [eval] (forall j: Int ::(p0_1 ==> true) && (p1_1 ==> true))
(declare-const j@128@01 Int)
(push) ; 24
; [eval] (p0_1 ==> true) && (p1_1 ==> true)
; [eval] p0_1 ==> true
(push) ; 25
; [then-branch: 420 | p0_1@8@01 | dead]
; [else-branch: 420 | !(p0_1@8@01) | live]
(push) ; 26
; [else-branch: 420 | !(p0_1@8@01)]
(pop) ; 26
(pop) ; 25
; Joined path conditions
(push) ; 25
; [then-branch: 421 | False | live]
; [else-branch: 421 | True | live]
(push) ; 26
; [then-branch: 421 | False]
(assert false)
(pop) ; 26
(push) ; 26
; [else-branch: 421 | True]
; [eval] p1_1 ==> true
(push) ; 27
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 422 | p1_1@9@01 | live]
; [else-branch: 422 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 422 | p1_1@9@01]
(pop) ; 28
(pop) ; 27
; Joined path conditions
(pop) ; 26
(pop) ; 25
; Joined path conditions
; Joined path conditions
(pop) ; 24
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
; [eval] p0_1 ==> p0_1 && p1_1 ==> i == i_1
(push) ; 24
; [then-branch: 423 | p0_1@8@01 | dead]
; [else-branch: 423 | !(p0_1@8@01) | live]
(push) ; 25
; [else-branch: 423 | !(p0_1@8@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 424 | p1_1@9@01 | live]
; [else-branch: 424 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 424 | p1_1@9@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 24
; [then-branch: 425 | p0_1@8@01 | dead]
; [else-branch: 425 | !(p0_1@8@01) | live]
(push) ; 25
; [else-branch: 425 | !(p0_1@8@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 426 | p1_1@9@01 | live]
; [else-branch: 426 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 426 | p1_1@9@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p0_1 ==> tmp0_1 == leak
; [eval] !p0_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 427 | !(p0_1@8@01) | live]
; [else-branch: 427 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 427 | !(p0_1@8@01)]
; [eval] tmp0_1 == leak
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p0_1 ==> tmp0_2 == i
; [eval] !p0_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 428 | !(p0_1@8@01) | live]
; [else-branch: 428 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 428 | !(p0_1@8@01)]
; [eval] tmp0_2 == i
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p1_1 ==> tmp1_2 == i_1
; [eval] !p1_1
(push) ; 24
; [then-branch: 429 | !(p1_1@9@01) | dead]
; [else-branch: 429 | p1_1@9@01 | live]
(push) ; 25
; [else-branch: 429 | p1_1@9@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p1_1 ==> tmp1_1 == leak_1
; [eval] !p1_1
(push) ; 24
; [then-branch: 430 | !(p1_1@9@01) | dead]
; [else-branch: 430 | p1_1@9@01 | live]
(push) ; 25
; [else-branch: 430 | p1_1@9@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
(pop) ; 23
; [eval] !p1_2
(push) ; 23
(set-option :rlimit 16000)
(assert (not p1_2@122@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 431 | !(p1_2@122@01) | dead]
; [else-branch: 431 | p1_2@122@01 | live]
(set-option :rlimit 0)
(push) ; 23
; [else-branch: 431 | p1_2@122@01]
(assert p1_2@122@01)
(pop) ; 23
(pop) ; 22
(pop) ; 21
(push) ; 21
; [else-branch: 412 | !(pt1_0@124@01)]
(assert (not pt1_0@124@01))
(pop) ; 21
; [eval] !pt1_0
(push) ; 21
(set-option :rlimit 16000)
(assert (not pt1_0@124@01))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt1_0@124@01)))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 432 | !(pt1_0@124@01) | live]
; [else-branch: 432 | pt1_0@124@01 | live]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 432 | !(pt1_0@124@01)]
(assert (not pt1_0@124@01))
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p0_2@121@01)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 433 | p0_2@121@01 | dead]
; [else-branch: 433 | !(p0_2@121@01) | live]
(set-option :rlimit 0)
(push) ; 22
; [else-branch: 433 | !(p0_2@121@01)]
(assert (not p0_2@121@01))
(pop) ; 22
; [eval] !p0_2
(push) ; 22
(set-option :rlimit 16000)
(assert (not p0_2@121@01))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p0_2@121@01)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 434 | !(p0_2@121@01) | live]
; [else-branch: 434 | p0_2@121@01 | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 434 | !(p0_2@121@01)]
(assert (not p0_2@121@01))
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not p1_2@122@01)))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 23
(set-option :rlimit 16000)
(assert (not p1_2@122@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 435 | p1_2@122@01 | live]
; [else-branch: 435 | !(p1_2@122@01) | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 435 | p1_2@122@01]
(assert p1_2@122@01)
; [exec]
; i_1 := i_1 + 1
; [eval] i_1 + 1
(declare-const i_1@129@01 Int)
(assert (= i_1@129@01 (+ i_1@111@01 1)))
; Loop head block: Re-establish invariant
; [eval] p0_1 ==> i >= 0
(push) ; 24
; [then-branch: 436 | p0_1@8@01 | dead]
; [else-branch: 436 | !(p0_1@8@01) | live]
(push) ; 25
; [else-branch: 436 | !(p0_1@8@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p1_1 ==> i_1 >= 0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 437 | p1_1@9@01 | live]
; [else-branch: 437 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 437 | p1_1@9@01]
; [eval] i_1 >= 0
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p1_1@9@01 (>= i_1@129@01 0))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p1_1@9@01 (>= i_1@129@01 0)))
; [eval] p0_1 ==> i <= |a|
(push) ; 24
; [then-branch: 438 | p0_1@8@01 | dead]
; [else-branch: 438 | !(p0_1@8@01) | live]
(push) ; 25
; [else-branch: 438 | !(p0_1@8@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p1_1 ==> i_1 <= |a_1|
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.01s
; (get-info :all-statistics)
; [then-branch: 439 | p1_1@9@01 | live]
; [else-branch: 439 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 439 | p1_1@9@01]
; [eval] i_1 <= |a_1|
; [eval] |a_1|
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p1_1@9@01 (<= i_1@129@01 (Seq_length a_1@100@01)))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p1_1@9@01 (<= i_1@129@01 (Seq_length a_1@100@01))))
; [eval] (forall j: Int ::(p0_1 ==> true) && (p1_1 ==> true))
(declare-const j@130@01 Int)
(push) ; 24
; [eval] (p0_1 ==> true) && (p1_1 ==> true)
; [eval] p0_1 ==> true
(push) ; 25
; [then-branch: 440 | p0_1@8@01 | dead]
; [else-branch: 440 | !(p0_1@8@01) | live]
(push) ; 26
; [else-branch: 440 | !(p0_1@8@01)]
(pop) ; 26
(pop) ; 25
; Joined path conditions
(push) ; 25
; [then-branch: 441 | False | live]
; [else-branch: 441 | True | live]
(push) ; 26
; [then-branch: 441 | False]
(assert false)
(pop) ; 26
(push) ; 26
; [else-branch: 441 | True]
; [eval] p1_1 ==> true
(push) ; 27
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 442 | p1_1@9@01 | live]
; [else-branch: 442 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 442 | p1_1@9@01]
(pop) ; 28
(pop) ; 27
; Joined path conditions
(pop) ; 26
(pop) ; 25
; Joined path conditions
; Joined path conditions
(pop) ; 24
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
; [eval] p0_1 ==> p0_1 && p1_1 ==> i == i_1
(push) ; 24
; [then-branch: 443 | p0_1@8@01 | dead]
; [else-branch: 443 | !(p0_1@8@01) | live]
(push) ; 25
; [else-branch: 443 | !(p0_1@8@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 444 | p1_1@9@01 | live]
; [else-branch: 444 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 444 | p1_1@9@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 24
; [then-branch: 445 | p0_1@8@01 | dead]
; [else-branch: 445 | !(p0_1@8@01) | live]
(push) ; 25
; [else-branch: 445 | !(p0_1@8@01)]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 446 | p1_1@9@01 | live]
; [else-branch: 446 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 446 | p1_1@9@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p0_1 ==> tmp0_1 == leak
; [eval] !p0_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 447 | !(p0_1@8@01) | live]
; [else-branch: 447 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 447 | !(p0_1@8@01)]
; [eval] tmp0_1 == leak
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p0_1 ==> tmp0_2 == i
; [eval] !p0_1
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 448 | !(p0_1@8@01) | live]
; [else-branch: 448 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 448 | !(p0_1@8@01)]
; [eval] tmp0_2 == i
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p1_1 ==> tmp1_2 == i_1
; [eval] !p1_1
(push) ; 24
; [then-branch: 449 | !(p1_1@9@01) | dead]
; [else-branch: 449 | p1_1@9@01 | live]
(push) ; 25
; [else-branch: 449 | p1_1@9@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p1_1 ==> tmp1_1 == leak_1
; [eval] !p1_1
(push) ; 24
; [then-branch: 450 | !(p1_1@9@01) | dead]
; [else-branch: 450 | p1_1@9@01 | live]
(push) ; 25
; [else-branch: 450 | p1_1@9@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
(pop) ; 23
; [eval] !p1_2
(push) ; 23
(set-option :rlimit 16000)
(assert (not p1_2@122@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 451 | !(p1_2@122@01) | dead]
; [else-branch: 451 | p1_2@122@01 | live]
(set-option :rlimit 0)
(push) ; 23
; [else-branch: 451 | p1_2@122@01]
(assert p1_2@122@01)
(pop) ; 23
(pop) ; 22
(pop) ; 21
(push) ; 21
; [else-branch: 432 | pt1_0@124@01]
(assert pt1_0@124@01)
(pop) ; 21
(pop) ; 20
(pop) ; 19
(push) ; 19
; [else-branch: 403 | !(p0_1@8@01 && i@110@01 < |a@19@01| || p1_1@9@01 && i_1@111@01 < |a_1@100@01|)]
(assert (not
  (or
    (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01)))
    (and p1_1@9@01 (< i_1@111@01 (Seq_length a_1@100@01))))))
(pop) ; 19
; [eval] !(p0_1 && i < |a| || p1_1 && i_1 < |a_1|)
; [eval] p0_1 && i < |a| || p1_1 && i_1 < |a_1|
; [eval] p0_1 && i < |a|
(push) ; 19
; [then-branch: 452 | !(p0_1@8@01) | live]
; [else-branch: 452 | p0_1@8@01 | live]
(push) ; 20
; [then-branch: 452 | !(p0_1@8@01)]
(pop) ; 20
(push) ; 20
; [else-branch: 452 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(push) ; 19
; [then-branch: 453 | p0_1@8@01 && i@110@01 < |a@19@01| | live]
; [else-branch: 453 | !(p0_1@8@01 && i@110@01 < |a@19@01|) | live]
(push) ; 20
; [then-branch: 453 | p0_1@8@01 && i@110@01 < |a@19@01|]
(assert (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01))))
(pop) ; 20
(push) ; 20
; [else-branch: 453 | !(p0_1@8@01 && i@110@01 < |a@19@01|)]
(assert (not (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01)))))
; [eval] p1_1 && i_1 < |a_1|
(push) ; 21
; [then-branch: 454 | !(p1_1@9@01) | live]
; [else-branch: 454 | p1_1@9@01 | live]
(push) ; 22
; [then-branch: 454 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 22
(push) ; 22
; [else-branch: 454 | p1_1@9@01]
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(push) ; 19
(set-option :rlimit 16000)
(assert (not (or
  (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01)))
  (and p1_1@9@01 (< i_1@111@01 (Seq_length a_1@100@01))))))
(check-sat)
; unknown
(pop) ; 19
; 0.01s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not
  (or
    (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01)))
    (and p1_1@9@01 (< i_1@111@01 (Seq_length a_1@100@01)))))))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 455 | !(p0_1@8@01 && i@110@01 < |a@19@01| || p1_1@9@01 && i_1@111@01 < |a_1@100@01|) | live]
; [else-branch: 455 | p0_1@8@01 && i@110@01 < |a@19@01| || p1_1@9@01 && i_1@111@01 < |a_1@100@01| | live]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 455 | !(p0_1@8@01 && i@110@01 < |a@19@01| || p1_1@9@01 && i_1@111@01 < |a_1@100@01|)]
(assert (not
  (or
    (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01)))
    (and p1_1@9@01 (< i_1@111@01 (Seq_length a_1@100@01))))))
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 20
; [then-branch: 456 | p0_1@8@01 | dead]
; [else-branch: 456 | !(p0_1@8@01) | live]
(push) ; 21
; [else-branch: 456 | !(p0_1@8@01)]
(pop) ; 21
(pop) ; 20
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 20
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 457 | p1_1@9@01 | live]
; [else-branch: 457 | !(p1_1@9@01) | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 457 | p1_1@9@01]
(pop) ; 21
(pop) ; 20
; Joined path conditions
(pop) ; 19
(push) ; 19
; [else-branch: 455 | p0_1@8@01 && i@110@01 < |a@19@01| || p1_1@9@01 && i_1@111@01 < |a_1@100@01|]
(assert (or
  (and p0_1@8@01 (< i@110@01 (Seq_length a@19@01)))
  (and p1_1@9@01 (< i_1@111@01 (Seq_length a_1@100@01)))))
(pop) ; 19
(pop) ; 18
(pop) ; 17
(pop) ; 16
(pop) ; 15
; [eval] !!p0_1
; [eval] !p0_1
; [then-branch: 458 | p0_1@8@01 | dead]
; [else-branch: 458 | !(p0_1@8@01) | live]
(push) ; 15
; [else-branch: 458 | !(p0_1@8@01)]
(pop) ; 15
(pop) ; 14
(pop) ; 13
; [eval] !!p0_1
; [eval] !p0_1
; [then-branch: 459 | p0_1@8@01 | dead]
; [else-branch: 459 | !(p0_1@8@01) | live]
(push) ; 13
; [else-branch: 459 | !(p0_1@8@01)]
(pop) ; 13
(pop) ; 12
; [eval] !p1_1
; [then-branch: 460 | !(p1_1@9@01) | dead]
; [else-branch: 460 | p1_1@9@01 | live]
(push) ; 12
; [else-branch: 460 | p1_1@9@01]
(pop) ; 12
(pop) ; 11
(pop) ; 10
; [eval] !p1_1
; [then-branch: 461 | !(p1_1@9@01) | dead]
; [else-branch: 461 | p1_1@9@01 | live]
(push) ; 10
; [else-branch: 461 | p1_1@9@01]
(pop) ; 10
(pop) ; 9
(pop) ; 8
; [eval] !p1_1
; [then-branch: 462 | !(p1_1@9@01) | dead]
; [else-branch: 462 | p1_1@9@01 | live]
(push) ; 8
; [else-branch: 462 | p1_1@9@01]
(pop) ; 8
(pop) ; 7
(pop) ; 6
; [eval] !p1_1
; [then-branch: 463 | !(p1_1@9@01) | dead]
; [else-branch: 463 | p1_1@9@01 | live]
(push) ; 6
; [else-branch: 463 | p1_1@9@01]
(pop) ; 6
(pop) ; 5
(pop) ; 4
(push) ; 4
; [else-branch: 343 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
(pop) ; 4
; [eval] !p1_1
(push) ; 4
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not p1_1@9@01)))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 464 | !(p1_1@9@01) | live]
; [else-branch: 464 | p1_1@9@01 | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 464 | !(p1_1@9@01)]
(assert (not p1_1@9@01))
; [then-branch: 465 | p0_1@8@01 | dead]
; [else-branch: 465 | !(p0_1@8@01) | live]
(push) ; 5
; [else-branch: 465 | !(p0_1@8@01)]
(pop) ; 5
; [eval] !p0_1
(push) ; 5
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 466 | !(p0_1@8@01) | live]
; [else-branch: 466 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 466 | !(p0_1@8@01)]
; [then-branch: 467 | p1_1@9@01 | dead]
; [else-branch: 467 | !(p1_1@9@01) | live]
(push) ; 6
; [else-branch: 467 | !(p1_1@9@01)]
(pop) ; 6
; [eval] !p1_1
(push) ; 6
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [then-branch: 468 | !(p1_1@9@01) | live]
; [else-branch: 468 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 6
; [then-branch: 468 | !(p1_1@9@01)]
; [then-branch: 469 | p0_1@8@01 | dead]
; [else-branch: 469 | !(p0_1@8@01) | live]
(push) ; 7
; [else-branch: 469 | !(p0_1@8@01)]
(pop) ; 7
; [eval] !p0_1
(push) ; 7
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 470 | !(p0_1@8@01) | live]
; [else-branch: 470 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 7
; [then-branch: 470 | !(p0_1@8@01)]
; [then-branch: 471 | p1_1@9@01 | dead]
; [else-branch: 471 | !(p1_1@9@01) | live]
(push) ; 8
; [else-branch: 471 | !(p1_1@9@01)]
(pop) ; 8
; [eval] !p1_1
(push) ; 8
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
; [then-branch: 472 | !(p1_1@9@01) | live]
; [else-branch: 472 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 8
; [then-branch: 472 | !(p1_1@9@01)]
; [exec]
; inhale p0_1 && p1_1 ==> secret == secret_1
(declare-const $t@131@01 $Snap)
(assert (= $t@131@01 $Snap.unit))
; [eval] p0_1 && p1_1 ==> secret == secret_1
; [eval] p0_1 && p1_1
(push) ; 9
; [then-branch: 473 | !(p0_1@8@01) | live]
; [else-branch: 473 | p0_1@8@01 | live]
(push) ; 10
; [then-branch: 473 | !(p0_1@8@01)]
(pop) ; 10
(push) ; 10
; [else-branch: 473 | p0_1@8@01]
(assert p0_1@8@01)
(pop) ; 10
(pop) ; 9
; Joined path conditions
; Joined path conditions
(assert (or p0_1@8@01 (not p0_1@8@01)))
(push) ; 9
(push) ; 10
(set-option :rlimit 16000)
(assert (not (not (and p0_1@8@01 p1_1@9@01))))
(check-sat)
; unsat
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
; [then-branch: 474 | p0_1@8@01 && p1_1@9@01 | dead]
; [else-branch: 474 | !(p0_1@8@01 && p1_1@9@01) | live]
(set-option :rlimit 0)
(push) ; 10
; [else-branch: 474 | !(p0_1@8@01 && p1_1@9@01)]
(assert (not (and p0_1@8@01 p1_1@9@01)))
(pop) ; 10
(pop) ; 9
; Joined path conditions
(assert (not (and p0_1@8@01 p1_1@9@01)))
; State saturation: after inhale
(set-option :rlimit 32000)
(check-sat)
; unknown
; [then-branch: 475 | p0_1@8@01 | dead]
; [else-branch: 475 | !(p0_1@8@01) | live]
(set-option :rlimit 0)
(push) ; 9
; [else-branch: 475 | !(p0_1@8@01)]
(pop) ; 9
; [eval] !p0_1
(push) ; 9
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
; [then-branch: 476 | !(p0_1@8@01) | live]
; [else-branch: 476 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 9
; [then-branch: 476 | !(p0_1@8@01)]
; [then-branch: 477 | p1_1@9@01 | dead]
; [else-branch: 477 | !(p1_1@9@01) | live]
(push) ; 10
; [else-branch: 477 | !(p1_1@9@01)]
(pop) ; 10
; [eval] !p1_1
(push) ; 10
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
; [then-branch: 478 | !(p1_1@9@01) | live]
; [else-branch: 478 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 10
; [then-branch: 478 | !(p1_1@9@01)]
; [then-branch: 479 | p0_1@8@01 | dead]
; [else-branch: 479 | !(p0_1@8@01) | live]
(push) ; 11
; [else-branch: 479 | !(p0_1@8@01)]
(pop) ; 11
; [eval] !p0_1
(push) ; 11
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 480 | !(p0_1@8@01) | live]
; [else-branch: 480 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 480 | !(p0_1@8@01)]
; [then-branch: 481 | p1_1@9@01 | dead]
; [else-branch: 481 | !(p1_1@9@01) | live]
(push) ; 12
; [else-branch: 481 | !(p1_1@9@01)]
(pop) ; 12
; [eval] !p1_1
(push) ; 12
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 12
; 0.00s
; (get-info :all-statistics)
; [then-branch: 482 | !(p1_1@9@01) | live]
; [else-branch: 482 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 12
; [then-branch: 482 | !(p1_1@9@01)]
; [eval] !p0_1
(push) ; 13
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 13
; 0.00s
; (get-info :all-statistics)
; [then-branch: 483 | !(p0_1@8@01) | live]
; [else-branch: 483 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 13
; [then-branch: 483 | !(p0_1@8@01)]
; [exec]
; tmp0_1 := leak
; [eval] !p1_1
(push) ; 14
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 14
; 0.00s
; (get-info :all-statistics)
; [then-branch: 484 | !(p1_1@9@01) | live]
; [else-branch: 484 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 14
; [then-branch: 484 | !(p1_1@9@01)]
; [exec]
; tmp1_1 := leak_1
; [eval] !p0_1
(push) ; 15
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
; [then-branch: 485 | !(p0_1@8@01) | live]
; [else-branch: 485 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 15
; [then-branch: 485 | !(p0_1@8@01)]
; [exec]
; tmp0_2 := i
; [eval] !p1_1
(push) ; 16
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [then-branch: 486 | !(p1_1@9@01) | live]
; [else-branch: 486 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 16
; [then-branch: 486 | !(p1_1@9@01)]
; [exec]
; tmp1_2 := i_1
(declare-const p0_2@132@01 Bool)
(declare-const p1_2@133@01 Bool)
(declare-const pt0_0@134@01 Bool)
(declare-const pt1_0@135@01 Bool)
(declare-const pf0_0@136@01 Bool)
(declare-const pf1_0@137@01 Bool)
(declare-const leak@138@01 Int)
(declare-const leak_1@139@01 Int)
(declare-const i@140@01 Int)
(declare-const i_1@141@01 Int)
(push) ; 17
; Loop head block: Check well-definedness of invariant
(declare-const $t@142@01 $Snap)
(assert (= $t@142@01 ($Snap.combine ($Snap.first $t@142@01) ($Snap.second $t@142@01))))
(assert (= ($Snap.first $t@142@01) $Snap.unit))
; [eval] p0_1 ==> i >= 0
(push) ; 18
; [then-branch: 487 | p0_1@8@01 | dead]
; [else-branch: 487 | !(p0_1@8@01) | live]
(push) ; 19
; [else-branch: 487 | !(p0_1@8@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second $t@142@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@142@01))
    ($Snap.second ($Snap.second $t@142@01)))))
(assert (= ($Snap.first ($Snap.second $t@142@01)) $Snap.unit))
; [eval] p1_1 ==> i_1 >= 0
(push) ; 18
; [then-branch: 488 | p1_1@9@01 | dead]
; [else-branch: 488 | !(p1_1@9@01) | live]
(push) ; 19
; [else-branch: 488 | !(p1_1@9@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second $t@142@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@142@01)))
    ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@142@01))) $Snap.unit))
; [eval] p0_1 ==> i <= |a|
(push) ; 18
; [then-branch: 489 | p0_1@8@01 | dead]
; [else-branch: 489 | !(p0_1@8@01) | live]
(push) ; 19
; [else-branch: 489 | !(p0_1@8@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second $t@142@01)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@142@01))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@142@01))))
  $Snap.unit))
; [eval] p1_1 ==> i_1 <= |a_1|
(push) ; 18
; [then-branch: 490 | p1_1@9@01 | dead]
; [else-branch: 490 | !(p1_1@9@01) | live]
(push) ; 19
; [else-branch: 490 | !(p1_1@9@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))
  $Snap.unit))
; [eval] (forall j: Int ::(p0_1 ==> true) && (p1_1 ==> true))
(declare-const j@143@01 Int)
(push) ; 18
; [eval] (p0_1 ==> true) && (p1_1 ==> true)
; [eval] p0_1 ==> true
(push) ; 19
; [then-branch: 491 | p0_1@8@01 | dead]
; [else-branch: 491 | !(p0_1@8@01) | live]
(push) ; 20
; [else-branch: 491 | !(p0_1@8@01)]
(pop) ; 20
(pop) ; 19
; Joined path conditions
(push) ; 19
; [then-branch: 492 | False | live]
; [else-branch: 492 | True | live]
(push) ; 20
; [then-branch: 492 | False]
(assert false)
(pop) ; 20
(push) ; 20
; [else-branch: 492 | True]
; [eval] p1_1 ==> true
(push) ; 21
; [then-branch: 493 | p1_1@9@01 | dead]
; [else-branch: 493 | !(p1_1@9@01) | live]
(push) ; 22
; [else-branch: 493 | !(p1_1@9@01)]
(pop) ; 22
(pop) ; 21
; Joined path conditions
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(pop) ; 18
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))
  $Snap.unit))
; [eval] p0_1 ==> p0_1 && p1_1 ==> i == i_1
(push) ; 18
; [then-branch: 494 | p0_1@8@01 | dead]
; [else-branch: 494 | !(p0_1@8@01) | live]
(push) ; 19
; [else-branch: 494 | !(p0_1@8@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))
  $Snap.unit))
; [eval] p1_1 ==> true
(push) ; 18
; [then-branch: 495 | p1_1@9@01 | dead]
; [else-branch: 495 | !(p1_1@9@01) | live]
(push) ; 19
; [else-branch: 495 | !(p1_1@9@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))
  $Snap.unit))
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 18
; [then-branch: 496 | p0_1@8@01 | dead]
; [else-branch: 496 | !(p0_1@8@01) | live]
(push) ; 19
; [else-branch: 496 | !(p0_1@8@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))
  $Snap.unit))
; [eval] p1_1 ==> true
(push) ; 18
; [then-branch: 497 | p1_1@9@01 | dead]
; [else-branch: 497 | !(p1_1@9@01) | live]
(push) ; 19
; [else-branch: 497 | !(p1_1@9@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))
  $Snap.unit))
; [eval] !p0_1 ==> tmp0_1 == leak
; [eval] !p0_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 498 | !(p0_1@8@01) | live]
; [else-branch: 498 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 498 | !(p0_1@8@01)]
; [eval] tmp0_1 == leak
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> (not p0_1@8@01) (= leak@14@01 leak@138@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))))
  $Snap.unit))
; [eval] !p0_1 ==> tmp0_2 == i
; [eval] !p0_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 499 | !(p0_1@8@01) | live]
; [else-branch: 499 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 499 | !(p0_1@8@01)]
; [eval] tmp0_2 == i
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> (not p0_1@8@01) (= i@20@01 i@140@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))))
  $Snap.unit))
; [eval] !p1_1 ==> tmp1_2 == i_1
; [eval] !p1_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 500 | !(p1_1@9@01) | live]
; [else-branch: 500 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 500 | !(p1_1@9@01)]
; [eval] tmp1_2 == i_1
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> (not p1_1@9@01) (= i_1@23@01 i_1@141@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))))
  $Snap.unit))
; [eval] !p1_1 ==> tmp1_1 == leak_1
; [eval] !p1_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 501 | !(p1_1@9@01) | live]
; [else-branch: 501 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 501 | !(p1_1@9@01)]
; [eval] tmp1_1 == leak_1
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> (not p1_1@9@01) (= leak_1@15@01 leak_1@139@01)))
(pop) ; 17
(push) ; 17
; Loop head block: Establish invariant
; [eval] p0_1 ==> i >= 0
(push) ; 18
; [then-branch: 502 | p0_1@8@01 | dead]
; [else-branch: 502 | !(p0_1@8@01) | live]
(push) ; 19
; [else-branch: 502 | !(p0_1@8@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] p1_1 ==> i_1 >= 0
(push) ; 18
; [then-branch: 503 | p1_1@9@01 | dead]
; [else-branch: 503 | !(p1_1@9@01) | live]
(push) ; 19
; [else-branch: 503 | !(p1_1@9@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] p0_1 ==> i <= |a|
(push) ; 18
; [then-branch: 504 | p0_1@8@01 | dead]
; [else-branch: 504 | !(p0_1@8@01) | live]
(push) ; 19
; [else-branch: 504 | !(p0_1@8@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] p1_1 ==> i_1 <= |a_1|
(push) ; 18
; [then-branch: 505 | p1_1@9@01 | dead]
; [else-branch: 505 | !(p1_1@9@01) | live]
(push) ; 19
; [else-branch: 505 | !(p1_1@9@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] (forall j: Int ::(p0_1 ==> true) && (p1_1 ==> true))
(declare-const j@144@01 Int)
(push) ; 18
; [eval] (p0_1 ==> true) && (p1_1 ==> true)
; [eval] p0_1 ==> true
(push) ; 19
; [then-branch: 506 | p0_1@8@01 | dead]
; [else-branch: 506 | !(p0_1@8@01) | live]
(push) ; 20
; [else-branch: 506 | !(p0_1@8@01)]
(pop) ; 20
(pop) ; 19
; Joined path conditions
(push) ; 19
; [then-branch: 507 | False | live]
; [else-branch: 507 | True | live]
(push) ; 20
; [then-branch: 507 | False]
(assert false)
(pop) ; 20
(push) ; 20
; [else-branch: 507 | True]
; [eval] p1_1 ==> true
(push) ; 21
; [then-branch: 508 | p1_1@9@01 | dead]
; [else-branch: 508 | !(p1_1@9@01) | live]
(push) ; 22
; [else-branch: 508 | !(p1_1@9@01)]
(pop) ; 22
(pop) ; 21
; Joined path conditions
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(pop) ; 18
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
; [eval] p0_1 ==> p0_1 && p1_1 ==> i == i_1
(push) ; 18
; [then-branch: 509 | p0_1@8@01 | dead]
; [else-branch: 509 | !(p0_1@8@01) | live]
(push) ; 19
; [else-branch: 509 | !(p0_1@8@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 18
; [then-branch: 510 | p1_1@9@01 | dead]
; [else-branch: 510 | !(p1_1@9@01) | live]
(push) ; 19
; [else-branch: 510 | !(p1_1@9@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 18
; [then-branch: 511 | p0_1@8@01 | dead]
; [else-branch: 511 | !(p0_1@8@01) | live]
(push) ; 19
; [else-branch: 511 | !(p0_1@8@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 18
; [then-branch: 512 | p1_1@9@01 | dead]
; [else-branch: 512 | !(p1_1@9@01) | live]
(push) ; 19
; [else-branch: 512 | !(p1_1@9@01)]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p0_1 ==> tmp0_1 == leak
; [eval] !p0_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 513 | !(p0_1@8@01) | live]
; [else-branch: 513 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 513 | !(p0_1@8@01)]
; [eval] tmp0_1 == leak
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p0_1 ==> tmp0_2 == i
; [eval] !p0_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not p0_1@8@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 514 | !(p0_1@8@01) | live]
; [else-branch: 514 | p0_1@8@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 514 | !(p0_1@8@01)]
; [eval] tmp0_2 == i
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p1_1 ==> tmp1_2 == i_1
; [eval] !p1_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 515 | !(p1_1@9@01) | live]
; [else-branch: 515 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 515 | !(p1_1@9@01)]
; [eval] tmp1_2 == i_1
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p1_1 ==> tmp1_1 == leak_1
; [eval] !p1_1
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1_1@9@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 516 | !(p1_1@9@01) | live]
; [else-branch: 516 | p1_1@9@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 516 | !(p1_1@9@01)]
; [eval] tmp1_1 == leak_1
(pop) ; 19
(pop) ; 18
; Joined path conditions
; Loop head block: Execute statements of loop head block (in invariant state)
(push) ; 18
(assert (= $t@142@01 ($Snap.combine ($Snap.first $t@142@01) ($Snap.second $t@142@01))))
(assert (= ($Snap.first $t@142@01) $Snap.unit))
(assert (=
  ($Snap.second $t@142@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@142@01))
    ($Snap.second ($Snap.second $t@142@01)))))
(assert (= ($Snap.first ($Snap.second $t@142@01)) $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second $t@142@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@142@01)))
    ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@142@01))) $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second $t@142@01)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@142@01))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@142@01))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))
  $Snap.unit))
(assert (=> (not p0_1@8@01) (= leak@14@01 leak@138@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))))
  $Snap.unit))
(assert (=> (not p0_1@8@01) (= i@20@01 i@140@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01)))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))))
  $Snap.unit))
(assert (=> (not p1_1@9@01) (= i_1@23@01 i_1@141@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@142@01))))))))))))
  $Snap.unit))
(assert (=> (not p1_1@9@01) (= leak_1@15@01 leak_1@139@01)))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 16000)
(check-sat)
; unknown
; Loop head block: Check well-definedness of edge conditions
(set-option :rlimit 0)
(push) ; 19
; [eval] p0_1 && i < |a| || p1_1 && i_1 < |a_1|
; [eval] p0_1 && i < |a|
(push) ; 20
; [then-branch: 517 | !(p0_1@8@01) | live]
; [else-branch: 517 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 517 | !(p0_1@8@01)]
(pop) ; 21
(push) ; 21
; [else-branch: 517 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(push) ; 20
; [then-branch: 518 | p0_1@8@01 && i@140@01 < |a@19@01| | live]
; [else-branch: 518 | !(p0_1@8@01 && i@140@01 < |a@19@01|) | live]
(push) ; 21
; [then-branch: 518 | p0_1@8@01 && i@140@01 < |a@19@01|]
(assert (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01))))
(pop) ; 21
(push) ; 21
; [else-branch: 518 | !(p0_1@8@01 && i@140@01 < |a@19@01|)]
(assert (not (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01)))))
; [eval] p1_1 && i_1 < |a_1|
(push) ; 22
; [then-branch: 519 | !(p1_1@9@01) | live]
; [else-branch: 519 | p1_1@9@01 | live]
(push) ; 23
; [then-branch: 519 | !(p1_1@9@01)]
(pop) ; 23
(push) ; 23
; [else-branch: 519 | p1_1@9@01]
(assert p1_1@9@01)
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 23
(pop) ; 22
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01))))
  (and
    (not (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01))))
    (or p1_1@9@01 (not p1_1@9@01)))))
(assert (or
  (not (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01))))
  (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01)))))
(pop) ; 19
(push) ; 19
; [eval] !(p0_1 && i < |a| || p1_1 && i_1 < |a_1|)
; [eval] p0_1 && i < |a| || p1_1 && i_1 < |a_1|
; [eval] p0_1 && i < |a|
(push) ; 20
; [then-branch: 520 | !(p0_1@8@01) | live]
; [else-branch: 520 | p0_1@8@01 | live]
(push) ; 21
; [then-branch: 520 | !(p0_1@8@01)]
(pop) ; 21
(push) ; 21
; [else-branch: 520 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(push) ; 20
; [then-branch: 521 | p0_1@8@01 && i@140@01 < |a@19@01| | live]
; [else-branch: 521 | !(p0_1@8@01 && i@140@01 < |a@19@01|) | live]
(push) ; 21
; [then-branch: 521 | p0_1@8@01 && i@140@01 < |a@19@01|]
(assert (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01))))
(pop) ; 21
(push) ; 21
; [else-branch: 521 | !(p0_1@8@01 && i@140@01 < |a@19@01|)]
(assert (not (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01)))))
; [eval] p1_1 && i_1 < |a_1|
(push) ; 22
; [then-branch: 522 | !(p1_1@9@01) | live]
; [else-branch: 522 | p1_1@9@01 | live]
(push) ; 23
; [then-branch: 522 | !(p1_1@9@01)]
(pop) ; 23
(push) ; 23
; [else-branch: 522 | p1_1@9@01]
(assert p1_1@9@01)
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 23
(pop) ; 22
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01))))
  (and
    (not (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01))))
    (or p1_1@9@01 (not p1_1@9@01)))))
(assert (or
  (not (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01))))
  (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01)))))
(pop) ; 19
; Loop head block: Follow loop-internal edges
; [eval] p0_1 && i < |a| || p1_1 && i_1 < |a_1|
; [eval] p0_1 && i < |a|
(push) ; 19
; [then-branch: 523 | !(p0_1@8@01) | live]
; [else-branch: 523 | p0_1@8@01 | live]
(push) ; 20
; [then-branch: 523 | !(p0_1@8@01)]
(pop) ; 20
(push) ; 20
; [else-branch: 523 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(push) ; 19
; [then-branch: 524 | p0_1@8@01 && i@140@01 < |a@19@01| | live]
; [else-branch: 524 | !(p0_1@8@01 && i@140@01 < |a@19@01|) | live]
(push) ; 20
; [then-branch: 524 | p0_1@8@01 && i@140@01 < |a@19@01|]
(assert (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01))))
(pop) ; 20
(push) ; 20
; [else-branch: 524 | !(p0_1@8@01 && i@140@01 < |a@19@01|)]
(assert (not (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01)))))
; [eval] p1_1 && i_1 < |a_1|
(push) ; 21
; [then-branch: 525 | !(p1_1@9@01) | live]
; [else-branch: 525 | p1_1@9@01 | live]
(push) ; 22
; [then-branch: 525 | !(p1_1@9@01)]
(pop) ; 22
(push) ; 22
; [else-branch: 525 | p1_1@9@01]
(assert p1_1@9@01)
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01))))
  (and
    (not (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01))))
    (or p1_1@9@01 (not p1_1@9@01)))))
(assert (or
  (not (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01))))
  (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01)))))
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not
  (or
    (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01)))
    (and p1_1@9@01 (< i_1@141@01 (Seq_length a_1@22@01)))))))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 526 | p0_1@8@01 && i@140@01 < |a@19@01| || p1_1@9@01 && i_1@141@01 < |a_1@22@01| | dead]
; [else-branch: 526 | !(p0_1@8@01 && i@140@01 < |a@19@01| || p1_1@9@01 && i_1@141@01 < |a_1@22@01|) | live]
(set-option :rlimit 0)
(push) ; 19
; [else-branch: 526 | !(p0_1@8@01 && i@140@01 < |a@19@01| || p1_1@9@01 && i_1@141@01 < |a_1@22@01|)]
(assert (not
  (or
    (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01)))
    (and p1_1@9@01 (< i_1@141@01 (Seq_length a_1@22@01))))))
(pop) ; 19
; [eval] !(p0_1 && i < |a| || p1_1 && i_1 < |a_1|)
; [eval] p0_1 && i < |a| || p1_1 && i_1 < |a_1|
; [eval] p0_1 && i < |a|
(push) ; 19
; [then-branch: 527 | !(p0_1@8@01) | live]
; [else-branch: 527 | p0_1@8@01 | live]
(push) ; 20
; [then-branch: 527 | !(p0_1@8@01)]
(pop) ; 20
(push) ; 20
; [else-branch: 527 | p0_1@8@01]
(assert p0_1@8@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(push) ; 19
; [then-branch: 528 | p0_1@8@01 && i@140@01 < |a@19@01| | live]
; [else-branch: 528 | !(p0_1@8@01 && i@140@01 < |a@19@01|) | live]
(push) ; 20
; [then-branch: 528 | p0_1@8@01 && i@140@01 < |a@19@01|]
(assert (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01))))
(pop) ; 20
(push) ; 20
; [else-branch: 528 | !(p0_1@8@01 && i@140@01 < |a@19@01|)]
(assert (not (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01)))))
; [eval] p1_1 && i_1 < |a_1|
(push) ; 21
; [then-branch: 529 | !(p1_1@9@01) | live]
; [else-branch: 529 | p1_1@9@01 | live]
(push) ; 22
; [then-branch: 529 | !(p1_1@9@01)]
(pop) ; 22
(push) ; 22
; [else-branch: 529 | p1_1@9@01]
(assert p1_1@9@01)
; [eval] i_1 < |a_1|
; [eval] |a_1|
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (or p1_1@9@01 (not p1_1@9@01)))
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(push) ; 19
(set-option :rlimit 16000)
(assert (not (or
  (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01)))
  (and p1_1@9@01 (< i_1@141@01 (Seq_length a_1@22@01))))))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not
  (or
    (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01)))
    (and p1_1@9@01 (< i_1@141@01 (Seq_length a_1@22@01)))))))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 530 | !(p0_1@8@01 && i@140@01 < |a@19@01| || p1_1@9@01 && i_1@141@01 < |a_1@22@01|) | live]
; [else-branch: 530 | p0_1@8@01 && i@140@01 < |a@19@01| || p1_1@9@01 && i_1@141@01 < |a_1@22@01| | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 530 | !(p0_1@8@01 && i@140@01 < |a@19@01| || p1_1@9@01 && i_1@141@01 < |a_1@22@01|)]
(assert (not
  (or
    (and p0_1@8@01 (< i@140@01 (Seq_length a@19@01)))
    (and p1_1@9@01 (< i_1@141@01 (Seq_length a_1@22@01))))))
; [eval] p0_1 ==> p0_1 && p1_1 ==> leak == leak_1
(push) ; 20
; [then-branch: 531 | p0_1@8@01 | dead]
; [else-branch: 531 | !(p0_1@8@01) | live]
(push) ; 21
; [else-branch: 531 | !(p0_1@8@01)]
(pop) ; 21
(pop) ; 20
; Joined path conditions
; [eval] p1_1 ==> true
(push) ; 20
; [then-branch: 532 | p1_1@9@01 | dead]
; [else-branch: 532 | !(p1_1@9@01) | live]
(push) ; 21
; [else-branch: 532 | !(p1_1@9@01)]
(pop) ; 21
(pop) ; 20
; Joined path conditions
(pop) ; 19
(pop) ; 18
(pop) ; 17
(pop) ; 16
; [eval] !!p1_1
; [eval] !p1_1
; [then-branch: 533 | p1_1@9@01 | dead]
; [else-branch: 533 | !(p1_1@9@01) | live]
(push) ; 16
; [else-branch: 533 | !(p1_1@9@01)]
(pop) ; 16
(pop) ; 15
; [eval] !!p0_1
; [eval] !p0_1
; [then-branch: 534 | p0_1@8@01 | dead]
; [else-branch: 534 | !(p0_1@8@01) | live]
(push) ; 15
; [else-branch: 534 | !(p0_1@8@01)]
(pop) ; 15
(pop) ; 14
; [eval] !!p1_1
; [eval] !p1_1
; [then-branch: 535 | p1_1@9@01 | dead]
; [else-branch: 535 | !(p1_1@9@01) | live]
(push) ; 14
; [else-branch: 535 | !(p1_1@9@01)]
(pop) ; 14
(pop) ; 13
; [eval] !!p0_1
; [eval] !p0_1
; [then-branch: 536 | p0_1@8@01 | dead]
; [else-branch: 536 | !(p0_1@8@01) | live]
(push) ; 13
; [else-branch: 536 | !(p0_1@8@01)]
(pop) ; 13
(pop) ; 12
(pop) ; 11
(pop) ; 10
(pop) ; 9
(pop) ; 8
(pop) ; 7
(pop) ; 6
(pop) ; 5
(pop) ; 4
(push) ; 4
; [else-branch: 464 | p1_1@9@01]
(assert p1_1@9@01)
(pop) ; 4
(pop) ; 3
(push) ; 3
; [else-branch: 342 | p0_1@8@01]
(assert p0_1@8@01)
(pop) ; 3
(pop) ; 2
(pop) ; 1
; ---------- main ----------
(declare-const p0@145@01 Bool)
(declare-const p1@146@01 Bool)
(declare-const a_in@147@01 Seq<Int>)
(declare-const a_in_0@148@01 Seq<Int>)
(declare-const secret@149@01 Int)
(declare-const secret_0@150@01 Int)
(declare-const leak@151@01 Int)
(declare-const leak_0@152@01 Int)
(declare-const p0@153@01 Bool)
(declare-const p1@154@01 Bool)
(declare-const a_in@155@01 Seq<Int>)
(declare-const a_in_0@156@01 Seq<Int>)
(declare-const secret@157@01 Int)
(declare-const secret_0@158@01 Int)
(declare-const leak@159@01 Int)
(declare-const leak_0@160@01 Int)
(push) ; 1
(declare-const $t@161@01 $Snap)
(assert (= $t@161@01 ($Snap.combine ($Snap.first $t@161@01) ($Snap.second $t@161@01))))
(assert (= ($Snap.first $t@161@01) $Snap.unit))
; [eval] p0 ==> secret >= 0
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p0@153@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 537 | p0@153@01 | live]
; [else-branch: 537 | !(p0@153@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 537 | p0@153@01]
(assert p0@153@01)
; [eval] secret >= 0
(pop) ; 3
(push) ; 3
; [else-branch: 537 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not p0@153@01) p0@153@01))
(assert (=> p0@153@01 (>= secret@157@01 0)))
(assert (=
  ($Snap.second $t@161@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@161@01))
    ($Snap.second ($Snap.second $t@161@01)))))
(assert (= ($Snap.first ($Snap.second $t@161@01)) $Snap.unit))
; [eval] p1 ==> secret_0 >= 0
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p1@154@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 538 | p1@154@01 | live]
; [else-branch: 538 | !(p1@154@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 538 | p1@154@01]
(assert p1@154@01)
; [eval] secret_0 >= 0
(pop) ; 3
(push) ; 3
; [else-branch: 538 | !(p1@154@01)]
(assert (not p1@154@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not p1@154@01) p1@154@01))
(assert (=> p1@154@01 (>= secret_0@158@01 0)))
(assert (=
  ($Snap.second ($Snap.second $t@161@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@161@01)))
    ($Snap.second ($Snap.second ($Snap.second $t@161@01))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@161@01))) $Snap.unit))
; [eval] p0 ==> secret < |a_in|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p0@153@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 539 | p0@153@01 | live]
; [else-branch: 539 | !(p0@153@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 539 | p0@153@01]
(assert p0@153@01)
; [eval] secret < |a_in|
; [eval] |a_in|
(pop) ; 3
(push) ; 3
; [else-branch: 539 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=> p0@153@01 (< secret@157@01 (Seq_length a_in@155@01))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second $t@161@01)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@161@01))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@161@01)))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@161@01))))
  $Snap.unit))
; [eval] p1 ==> secret_0 < |a_in_0|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p1@154@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 540 | p1@154@01 | live]
; [else-branch: 540 | !(p1@154@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 540 | p1@154@01]
(assert p1@154@01)
; [eval] secret_0 < |a_in_0|
; [eval] |a_in_0|
(pop) ; 3
(push) ; 3
; [else-branch: 540 | !(p1@154@01)]
(assert (not p1@154@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=> p1@154@01 (< secret_0@158@01 (Seq_length a_in_0@156@01))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@161@01))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@161@01)))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@161@01))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@161@01)))))
  $Snap.unit))
; [eval] p0 ==> p0 && p1 ==> a_in == a_in_0
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p0@153@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 541 | p0@153@01 | live]
; [else-branch: 541 | !(p0@153@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 541 | p0@153@01]
(assert p0@153@01)
; [eval] p0 && p1 ==> a_in == a_in_0
; [eval] p0 && p1
(push) ; 4
; [then-branch: 542 | !(p0@153@01) | live]
; [else-branch: 542 | p0@153@01 | live]
(push) ; 5
; [then-branch: 542 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 5
(push) ; 5
; [else-branch: 542 | p0@153@01]
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or p0@153@01 (not p0@153@01)))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (and p0@153@01 p1@154@01))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (and p0@153@01 p1@154@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 543 | p0@153@01 && p1@154@01 | live]
; [else-branch: 543 | !(p0@153@01 && p1@154@01) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 543 | p0@153@01 && p1@154@01]
(assert (and p0@153@01 p1@154@01))
; [eval] a_in == a_in_0
(pop) ; 5
(push) ; 5
; [else-branch: 543 | !(p0@153@01 && p1@154@01)]
(assert (not (and p0@153@01 p1@154@01)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (not (and p0@153@01 p1@154@01)) (and p0@153@01 p1@154@01)))
(pop) ; 3
(push) ; 3
; [else-branch: 541 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
(assert (=>
  p0@153@01
  (and
    p0@153@01
    (or p0@153@01 (not p0@153@01))
    (or (not (and p0@153@01 p1@154@01)) (and p0@153@01 p1@154@01)))))
; Joined path conditions
(assert (=>
  (and p0@153@01 (and p0@153@01 p1@154@01))
  (Seq_equal a_in@155@01 a_in_0@156@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@161@01)))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@161@01))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@161@01)))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@161@01))))))
  $Snap.unit))
; [eval] p1 ==> true
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p1@154@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 544 | p1@154@01 | live]
; [else-branch: 544 | !(p1@154@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 544 | p1@154@01]
(assert p1@154@01)
(pop) ; 3
(push) ; 3
; [else-branch: 544 | !(p1@154@01)]
(assert (not p1@154@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@161@01))))))
  $Snap.unit))
; [eval] (forall i: Int :: { a_in[i] } { a_in_0[i] } (p0 ==> i >= 0 && i < |a_in| ==> a_in[i] == 0) && (p1 ==> i >= 0 && i < |a_in_0| ==> a_in_0[i] == 0))
(declare-const i@162@01 Int)
(push) ; 2
; [eval] (p0 ==> i >= 0 && i < |a_in| ==> a_in[i] == 0) && (p1 ==> i >= 0 && i < |a_in_0| ==> a_in_0[i] == 0)
; [eval] p0 ==> i >= 0 && i < |a_in| ==> a_in[i] == 0
(push) ; 3
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not p0@153@01))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 545 | p0@153@01 | live]
; [else-branch: 545 | !(p0@153@01) | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 545 | p0@153@01]
(assert p0@153@01)
; [eval] i >= 0 && i < |a_in| ==> a_in[i] == 0
; [eval] i >= 0 && i < |a_in|
; [eval] i >= 0
(push) ; 5
; [then-branch: 546 | !(i@162@01 >= 0) | live]
; [else-branch: 546 | i@162@01 >= 0 | live]
(push) ; 6
; [then-branch: 546 | !(i@162@01 >= 0)]
(assert (not (>= i@162@01 0)))
(pop) ; 6
(push) ; 6
; [else-branch: 546 | i@162@01 >= 0]
(assert (>= i@162@01 0))
; [eval] i < |a_in|
; [eval] |a_in|
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (or (>= i@162@01 0) (not (>= i@162@01 0))))
(push) ; 5
; [then-branch: 547 | i@162@01 >= 0 && i@162@01 < |a_in@155@01| | live]
; [else-branch: 547 | !(i@162@01 >= 0 && i@162@01 < |a_in@155@01|) | live]
(push) ; 6
; [then-branch: 547 | i@162@01 >= 0 && i@162@01 < |a_in@155@01|]
(assert (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
; [eval] a_in[i] == 0
; [eval] a_in[i]
(pop) ; 6
(push) ; 6
; [else-branch: 547 | !(i@162@01 >= 0 && i@162@01 < |a_in@155@01|)]
(assert (not (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01)))))
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (or
  (not (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
  (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01)))))
(pop) ; 4
(push) ; 4
; [else-branch: 545 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 4
(pop) ; 3
; Joined path conditions
(assert (=>
  p0@153@01
  (and
    p0@153@01
    (or (>= i@162@01 0) (not (>= i@162@01 0)))
    (or
      (not (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
      (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01)))))))
; Joined path conditions
(push) ; 3
; [then-branch: 548 | !(p0@153@01 && i@162@01 >= 0 && i@162@01 < |a_in@155@01| ==> a_in@155@01[i@162@01] == 0) | live]
; [else-branch: 548 | p0@153@01 && i@162@01 >= 0 && i@162@01 < |a_in@155@01| ==> a_in@155@01[i@162@01] == 0 | live]
(push) ; 4
; [then-branch: 548 | !(p0@153@01 && i@162@01 >= 0 && i@162@01 < |a_in@155@01| ==> a_in@155@01[i@162@01] == 0)]
(assert (not
  (=>
    (and p0@153@01 (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
    (= (Seq_index a_in@155@01 i@162@01) 0))))
(pop) ; 4
(push) ; 4
; [else-branch: 548 | p0@153@01 && i@162@01 >= 0 && i@162@01 < |a_in@155@01| ==> a_in@155@01[i@162@01] == 0]
(assert (=>
  (and p0@153@01 (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
  (= (Seq_index a_in@155@01 i@162@01) 0)))
; [eval] p1 ==> i >= 0 && i < |a_in_0| ==> a_in_0[i] == 0
(push) ; 5
(push) ; 6
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
(set-option :rlimit 16000)
(assert (not p1@154@01))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [then-branch: 549 | p1@154@01 | live]
; [else-branch: 549 | !(p1@154@01) | live]
(set-option :rlimit 0)
(push) ; 6
; [then-branch: 549 | p1@154@01]
(assert p1@154@01)
; [eval] i >= 0 && i < |a_in_0| ==> a_in_0[i] == 0
; [eval] i >= 0 && i < |a_in_0|
; [eval] i >= 0
(push) ; 7
; [then-branch: 550 | !(i@162@01 >= 0) | live]
; [else-branch: 550 | i@162@01 >= 0 | live]
(push) ; 8
; [then-branch: 550 | !(i@162@01 >= 0)]
(assert (not (>= i@162@01 0)))
(pop) ; 8
(push) ; 8
; [else-branch: 550 | i@162@01 >= 0]
(assert (>= i@162@01 0))
; [eval] i < |a_in_0|
; [eval] |a_in_0|
(pop) ; 8
(pop) ; 7
; Joined path conditions
; Joined path conditions
(assert (or (>= i@162@01 0) (not (>= i@162@01 0))))
(push) ; 7
; [then-branch: 551 | i@162@01 >= 0 && i@162@01 < |a_in_0@156@01| | live]
; [else-branch: 551 | !(i@162@01 >= 0 && i@162@01 < |a_in_0@156@01|) | live]
(push) ; 8
; [then-branch: 551 | i@162@01 >= 0 && i@162@01 < |a_in_0@156@01|]
(assert (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in_0@156@01))))
; [eval] a_in_0[i] == 0
; [eval] a_in_0[i]
(pop) ; 8
(push) ; 8
; [else-branch: 551 | !(i@162@01 >= 0 && i@162@01 < |a_in_0@156@01|)]
(assert (not (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in_0@156@01)))))
(pop) ; 8
(pop) ; 7
; Joined path conditions
; Joined path conditions
(assert (or
  (not (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in_0@156@01))))
  (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in_0@156@01)))))
(pop) ; 6
(push) ; 6
; [else-branch: 549 | !(p1@154@01)]
(assert (not p1@154@01))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (=>
  p1@154@01
  (and
    p1@154@01
    (or (>= i@162@01 0) (not (>= i@162@01 0)))
    (or
      (not (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in_0@156@01))))
      (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in_0@156@01)))))))
; Joined path conditions
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (=>
  (=>
    (and p0@153@01 (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
    (= (Seq_index a_in@155@01 i@162@01) 0))
  (and
    (=>
      (and p0@153@01 (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
      (= (Seq_index a_in@155@01 i@162@01) 0))
    (=>
      p1@154@01
      (and
        p1@154@01
        (or (>= i@162@01 0) (not (>= i@162@01 0)))
        (or
          (not (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in_0@156@01))))
          (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in_0@156@01)))))))))
(assert (or
  (=>
    (and p0@153@01 (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
    (= (Seq_index a_in@155@01 i@162@01) 0))
  (not
    (=>
      (and p0@153@01 (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
      (= (Seq_index a_in@155@01 i@162@01) 0)))))
(pop) ; 2
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@162@01 Int)) (!
  (and
    (=>
      p0@153@01
      (and
        p0@153@01
        (or (>= i@162@01 0) (not (>= i@162@01 0)))
        (or
          (not (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
          (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))))
    (=>
      (=>
        (and
          p0@153@01
          (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
        (= (Seq_index a_in@155@01 i@162@01) 0))
      (and
        (=>
          (and
            p0@153@01
            (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
          (= (Seq_index a_in@155@01 i@162@01) 0))
        (=>
          p1@154@01
          (and
            p1@154@01
            (or (>= i@162@01 0) (not (>= i@162@01 0)))
            (or
              (not (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in_0@156@01))))
              (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in_0@156@01))))))))
    (or
      (=>
        (and
          p0@153@01
          (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
        (= (Seq_index a_in@155@01 i@162@01) 0))
      (not
        (=>
          (and
            p0@153@01
            (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
          (= (Seq_index a_in@155@01 i@162@01) 0)))))
  :pattern ((Seq_index a_in@155@01 i@162@01))
  :qid |prog./root/evaluation/2_performance/sequences/smith.vpr@97@70@97@213-aux|)))
(assert (forall ((i@162@01 Int)) (!
  (and
    (=>
      p0@153@01
      (and
        p0@153@01
        (or (>= i@162@01 0) (not (>= i@162@01 0)))
        (or
          (not (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
          (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))))
    (=>
      (=>
        (and
          p0@153@01
          (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
        (= (Seq_index a_in@155@01 i@162@01) 0))
      (and
        (=>
          (and
            p0@153@01
            (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
          (= (Seq_index a_in@155@01 i@162@01) 0))
        (=>
          p1@154@01
          (and
            p1@154@01
            (or (>= i@162@01 0) (not (>= i@162@01 0)))
            (or
              (not (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in_0@156@01))))
              (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in_0@156@01))))))))
    (or
      (=>
        (and
          p0@153@01
          (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
        (= (Seq_index a_in@155@01 i@162@01) 0))
      (not
        (=>
          (and
            p0@153@01
            (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
          (= (Seq_index a_in@155@01 i@162@01) 0)))))
  :pattern ((Seq_index a_in_0@156@01 i@162@01))
  :qid |prog./root/evaluation/2_performance/sequences/smith.vpr@97@70@97@213-aux|)))
(assert (forall ((i@162@01 Int)) (!
  (and
    (=>
      (and p0@153@01 (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in@155@01))))
      (= (Seq_index a_in@155@01 i@162@01) 0))
    (=>
      (and
        p1@154@01
        (and (>= i@162@01 0) (< i@162@01 (Seq_length a_in_0@156@01))))
      (= (Seq_index a_in_0@156@01 i@162@01) 0)))
  :pattern ((Seq_index a_in@155@01 i@162@01))
  :pattern ((Seq_index a_in_0@156@01 i@162@01))
  :qid |prog./root/evaluation/2_performance/sequences/smith.vpr@97@70@97@213|)))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
(declare-const $t@163@01 $Snap)
(assert (= $t@163@01 ($Snap.combine ($Snap.first $t@163@01) ($Snap.second $t@163@01))))
(assert (= ($Snap.first $t@163@01) $Snap.unit))
; [eval] p0 ==> p0 && p1 ==> leak == leak_0
(push) ; 3
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not p0@153@01))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 552 | p0@153@01 | live]
; [else-branch: 552 | !(p0@153@01) | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 552 | p0@153@01]
(assert p0@153@01)
; [eval] p0 && p1 ==> leak == leak_0
; [eval] p0 && p1
(push) ; 5
; [then-branch: 553 | !(p0@153@01) | live]
; [else-branch: 553 | p0@153@01 | live]
(push) ; 6
; [then-branch: 553 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 6
(push) ; 6
; [else-branch: 553 | p0@153@01]
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (or p0@153@01 (not p0@153@01)))
(push) ; 5
(push) ; 6
(set-option :rlimit 16000)
(assert (not (not (and p0@153@01 p1@154@01))))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
(set-option :rlimit 16000)
(assert (not (and p0@153@01 p1@154@01)))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [then-branch: 554 | p0@153@01 && p1@154@01 | live]
; [else-branch: 554 | !(p0@153@01 && p1@154@01) | live]
(set-option :rlimit 0)
(push) ; 6
; [then-branch: 554 | p0@153@01 && p1@154@01]
(assert (and p0@153@01 p1@154@01))
; [eval] leak == leak_0
(pop) ; 6
(push) ; 6
; [else-branch: 554 | !(p0@153@01 && p1@154@01)]
(assert (not (and p0@153@01 p1@154@01)))
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (or (not (and p0@153@01 p1@154@01)) (and p0@153@01 p1@154@01)))
(pop) ; 4
(push) ; 4
; [else-branch: 552 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (=> (and p0@153@01 (and p0@153@01 p1@154@01)) (= leak@159@01 leak_0@160@01)))
(assert (= ($Snap.second $t@163@01) $Snap.unit))
; [eval] p1 ==> true
(push) ; 3
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not p1@154@01))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 555 | p1@154@01 | live]
; [else-branch: 555 | !(p1@154@01) | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 555 | p1@154@01]
(assert p1@154@01)
(pop) ; 4
(push) ; 4
; [else-branch: 555 | !(p1@154@01)]
(assert (not p1@154@01))
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(pop) ; 2
(push) ; 2
; [exec]
; var a: Seq[Int]
(declare-const a@164@01 Seq<Int>)
; [exec]
; var i: Int
(declare-const i@165@01 Int)
; [exec]
; var _cond0: Bool
(declare-const _cond0@166@01 Bool)
; [exec]
; var a_0: Seq[Int]
(declare-const a_0@167@01 Seq<Int>)
; [exec]
; var i_0: Int
(declare-const i_0@168@01 Int)
; [exec]
; var _cond0_0: Bool
(declare-const _cond0_0@169@01 Bool)
; [exec]
; var tmp0: Int
(declare-const tmp0@170@01 Int)
; [exec]
; var tmp1: Int
(declare-const tmp1@171@01 Int)
; [exec]
; var tmp0_0: Int
(declare-const tmp0_0@172@01 Int)
; [exec]
; var tmp1_0: Int
(declare-const tmp1_0@173@01 Int)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p0@153@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 556 | p0@153@01 | live]
; [else-branch: 556 | !(p0@153@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 556 | p0@153@01]
(assert p0@153@01)
; [exec]
; _cond0 := false
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not p1@154@01))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 557 | p1@154@01 | live]
; [else-branch: 557 | !(p1@154@01) | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 557 | p1@154@01]
(assert p1@154@01)
; [exec]
; _cond0_0 := false
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 558 | p0@153@01 | live]
; [else-branch: 558 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 558 | p0@153@01]
; [exec]
; a := a_in
(push) ; 6
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [then-branch: 559 | p1@154@01 | live]
; [else-branch: 559 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 6
; [then-branch: 559 | p1@154@01]
; [exec]
; a_0 := a_in_0
(push) ; 7
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 560 | p0@153@01 | live]
; [else-branch: 560 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 7
; [then-branch: 560 | p0@153@01]
; [exec]
; a := a[secret := 1]
; [eval] a[secret := 1]
(push) ; 8
(assert (not (>= secret@157@01 0)))
(check-sat)
; unsat
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
(push) ; 8
(assert (not (< secret@157@01 (Seq_length a_in@155@01))))
(check-sat)
; unsat
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
(declare-const a@174@01 Seq<Int>)
(assert (=
  a@174@01
  (Seq_append
    (Seq_take a_in@155@01 secret@157@01)
    (Seq_append (Seq_singleton 1) (Seq_drop a_in@155@01 (+ secret@157@01 1))))))
(push) ; 8
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
; [then-branch: 561 | p1@154@01 | live]
; [else-branch: 561 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 8
; [then-branch: 561 | p1@154@01]
; [exec]
; a_0 := a_0[secret_0 := 1]
; [eval] a_0[secret_0 := 1]
(push) ; 9
(assert (not (>= secret_0@158@01 0)))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(push) ; 9
(assert (not (< secret_0@158@01 (Seq_length a_in_0@156@01))))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(declare-const a_0@175@01 Seq<Int>)
(assert (=
  a_0@175@01
  (Seq_append
    (Seq_take a_in_0@156@01 secret_0@158@01)
    (Seq_append (Seq_singleton 1) (Seq_drop a_in_0@156@01 (+ secret_0@158@01 1))))))
(push) ; 9
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
; [then-branch: 562 | p0@153@01 | live]
; [else-branch: 562 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 9
; [then-branch: 562 | p0@153@01]
; [exec]
; i := 0
(push) ; 10
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
; [then-branch: 563 | p1@154@01 | live]
; [else-branch: 563 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 10
; [then-branch: 563 | p1@154@01]
; [exec]
; i_0 := 0
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 564 | p0@153@01 | live]
; [else-branch: 564 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 564 | p0@153@01]
; [exec]
; leak := 0
(push) ; 12
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 12
; 0.00s
; (get-info :all-statistics)
; [then-branch: 565 | p1@154@01 | live]
; [else-branch: 565 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 12
; [then-branch: 565 | p1@154@01]
; [exec]
; leak_0 := 0
; [eval] !p0
; [then-branch: 566 | !(p0@153@01) | dead]
; [else-branch: 566 | p0@153@01 | live]
(push) ; 13
; [else-branch: 566 | p0@153@01]
(pop) ; 13
; [eval] !!p0
; [eval] !p0
(push) ; 13
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 13
; 0.00s
; (get-info :all-statistics)
; [then-branch: 567 | p0@153@01 | live]
; [else-branch: 567 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 13
; [then-branch: 567 | p0@153@01]
; [eval] !p1
; [then-branch: 568 | !(p1@154@01) | dead]
; [else-branch: 568 | p1@154@01 | live]
(push) ; 14
; [else-branch: 568 | p1@154@01]
(pop) ; 14
; [eval] !!p1
; [eval] !p1
(push) ; 14
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 14
; 0.00s
; (get-info :all-statistics)
; [then-branch: 569 | p1@154@01 | live]
; [else-branch: 569 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 14
; [then-branch: 569 | p1@154@01]
; [eval] !p0
; [then-branch: 570 | !(p0@153@01) | dead]
; [else-branch: 570 | p0@153@01 | live]
(push) ; 15
; [else-branch: 570 | p0@153@01]
(pop) ; 15
; [eval] !!p0
; [eval] !p0
(push) ; 15
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
; [then-branch: 571 | p0@153@01 | live]
; [else-branch: 571 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 15
; [then-branch: 571 | p0@153@01]
; [eval] !p1
; [then-branch: 572 | !(p1@154@01) | dead]
; [else-branch: 572 | p1@154@01 | live]
(push) ; 16
; [else-branch: 572 | p1@154@01]
(pop) ; 16
; [eval] !!p1
; [eval] !p1
(push) ; 16
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [then-branch: 573 | p1@154@01 | live]
; [else-branch: 573 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 16
; [then-branch: 573 | p1@154@01]
(declare-const p0_0@176@01 Bool)
(declare-const p1_0@177@01 Bool)
(declare-const pt0@178@01 Bool)
(declare-const pt1@179@01 Bool)
(declare-const pf0@180@01 Bool)
(declare-const pf1@181@01 Bool)
(declare-const leak@182@01 Int)
(declare-const leak_0@183@01 Int)
(declare-const i@184@01 Int)
(declare-const i_0@185@01 Int)
(push) ; 17
; Loop head block: Check well-definedness of invariant
(declare-const $t@186@01 $Snap)
(assert (= $t@186@01 ($Snap.combine ($Snap.first $t@186@01) ($Snap.second $t@186@01))))
(assert (= ($Snap.first $t@186@01) $Snap.unit))
; [eval] p0 ==> i >= 0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 574 | p0@153@01 | live]
; [else-branch: 574 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 574 | p0@153@01]
; [eval] i >= 0
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> p0@153@01 (>= i@184@01 0)))
(assert (=
  ($Snap.second $t@186@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@186@01))
    ($Snap.second ($Snap.second $t@186@01)))))
(assert (= ($Snap.first ($Snap.second $t@186@01)) $Snap.unit))
; [eval] p1 ==> i_0 >= 0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 575 | p1@154@01 | live]
; [else-branch: 575 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 575 | p1@154@01]
; [eval] i_0 >= 0
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> p1@154@01 (>= i_0@185@01 0)))
(assert (=
  ($Snap.second ($Snap.second $t@186@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@186@01)))
    ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@186@01))) $Snap.unit))
; [eval] p0 ==> i <= |a|
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 576 | p0@153@01 | live]
; [else-branch: 576 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 576 | p0@153@01]
; [eval] i <= |a|
; [eval] |a|
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> p0@153@01 (<= i@184@01 (Seq_length a@174@01))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second $t@186@01)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@186@01))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@186@01))))
  $Snap.unit))
; [eval] p1 ==> i_0 <= |a_0|
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 577 | p1@154@01 | live]
; [else-branch: 577 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 577 | p1@154@01]
; [eval] i_0 <= |a_0|
; [eval] |a_0|
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> p1@154@01 (<= i_0@185@01 (Seq_length a_0@175@01))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))
  $Snap.unit))
; [eval] (forall j: Int ::(p0 ==> true) && (p1 ==> true))
(declare-const j@187@01 Int)
(push) ; 18
; [eval] (p0 ==> true) && (p1 ==> true)
; [eval] p0 ==> true
(push) ; 19
(push) ; 20
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 578 | p0@153@01 | live]
; [else-branch: 578 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 578 | p0@153@01]
(pop) ; 20
(pop) ; 19
; Joined path conditions
(push) ; 19
; [then-branch: 579 | False | live]
; [else-branch: 579 | True | live]
(push) ; 20
; [then-branch: 579 | False]
(assert false)
(pop) ; 20
(push) ; 20
; [else-branch: 579 | True]
; [eval] p1 ==> true
(push) ; 21
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 580 | p1@154@01 | live]
; [else-branch: 580 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 580 | p1@154@01]
(pop) ; 22
(pop) ; 21
; Joined path conditions
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(pop) ; 18
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))
  $Snap.unit))
; [eval] p0 ==> p0 && p1 ==> leak == leak_0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 581 | p0@153@01 | live]
; [else-branch: 581 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 581 | p0@153@01]
; [eval] p0 && p1 ==> leak == leak_0
; [eval] p0 && p1
(push) ; 20
; [then-branch: 582 | !(p0@153@01) | live]
; [else-branch: 582 | p0@153@01 | live]
(push) ; 21
; [then-branch: 582 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 21
(push) ; 21
; [else-branch: 582 | p0@153@01]
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p0@153@01 (not p0@153@01)))
(push) ; 20
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not (and p0@153@01 p1@154@01))))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (and p0@153@01 p1@154@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 583 | p0@153@01 && p1@154@01 | live]
; [else-branch: 583 | !(p0@153@01 && p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 583 | p0@153@01 && p1@154@01]
(assert (and p0@153@01 p1@154@01))
; [eval] leak == leak_0
(pop) ; 21
(pop) ; 20
; Joined path conditions
(assert (and p0@153@01 p1@154@01))
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> p0@153@01 (and (or p0@153@01 (not p0@153@01)) p0@153@01 p1@154@01)))
(assert p0@153@01)
(assert (=> (and p0@153@01 (and p0@153@01 p1@154@01)) (= leak@182@01 leak_0@183@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))
  $Snap.unit))
; [eval] p1 ==> true
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1@154@01))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 584 | p1@154@01 | live]
; [else-branch: 584 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 584 | p1@154@01]
(assert p1@154@01)
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p1@154@01)
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))
  $Snap.unit))
; [eval] p0 ==> p0 && p1 ==> i == i_0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 585 | p0@153@01 | live]
; [else-branch: 585 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 585 | p0@153@01]
; [eval] p0 && p1 ==> i == i_0
; [eval] p0 && p1
(push) ; 20
; [then-branch: 586 | !(p0@153@01) | live]
; [else-branch: 586 | p0@153@01 | live]
(push) ; 21
; [then-branch: 586 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 21
(push) ; 21
; [else-branch: 586 | p0@153@01]
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p0@153@01 (not p0@153@01)))
(push) ; 20
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not (and p0@153@01 p1@154@01))))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (and p0@153@01 p1@154@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 587 | p0@153@01 && p1@154@01 | live]
; [else-branch: 587 | !(p0@153@01 && p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 587 | p0@153@01 && p1@154@01]
(assert (and p0@153@01 p1@154@01))
; [eval] i == i_0
(pop) ; 21
(pop) ; 20
; Joined path conditions
(assert (and p0@153@01 p1@154@01))
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p0@153@01)
(assert (=> (and p0@153@01 (and p0@153@01 p1@154@01)) (= i@184@01 i_0@185@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))
  $Snap.unit))
; [eval] p1 ==> true
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1@154@01))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 588 | p1@154@01 | live]
; [else-branch: 588 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 588 | p1@154@01]
(assert p1@154@01)
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p1@154@01)
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))
  $Snap.unit))
; [eval] !p0 ==> tmp0_0 == i
; [eval] !p0
(push) ; 18
; [then-branch: 589 | !(p0@153@01) | dead]
; [else-branch: 589 | p0@153@01 | live]
(push) ; 19
; [else-branch: 589 | p0@153@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))))
  $Snap.unit))
; [eval] !p0 ==> tmp0 == leak
; [eval] !p0
(push) ; 18
; [then-branch: 590 | !(p0@153@01) | dead]
; [else-branch: 590 | p0@153@01 | live]
(push) ; 19
; [else-branch: 590 | p0@153@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))))
  $Snap.unit))
; [eval] !p1 ==> tmp1 == leak_0
; [eval] !p1
(push) ; 18
; [then-branch: 591 | !(p1@154@01) | dead]
; [else-branch: 591 | p1@154@01 | live]
(push) ; 19
; [else-branch: 591 | p1@154@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))))
  $Snap.unit))
; [eval] !p1 ==> tmp1_0 == i_0
; [eval] !p1
(push) ; 18
; [then-branch: 592 | !(p1@154@01) | dead]
; [else-branch: 592 | p1@154@01 | live]
(push) ; 19
; [else-branch: 592 | p1@154@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(pop) ; 17
(push) ; 17
; Loop head block: Establish invariant
; [eval] p0 ==> i >= 0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not p0@153@01))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 593 | p0@153@01 | live]
; [else-branch: 593 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 593 | p0@153@01]
(assert p0@153@01)
; [eval] i >= 0
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p0@153@01)
; [eval] p1 ==> i_0 >= 0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1@154@01))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 594 | p1@154@01 | live]
; [else-branch: 594 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 594 | p1@154@01]
(assert p1@154@01)
; [eval] i_0 >= 0
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p1@154@01)
; [eval] p0 ==> i <= |a|
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 595 | p0@153@01 | live]
; [else-branch: 595 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 595 | p0@153@01]
; [eval] i <= |a|
; [eval] |a|
(pop) ; 19
(pop) ; 18
; Joined path conditions
(push) ; 18
(assert (not (=> p0@153@01 (<= 0 (Seq_length a@174@01)))))
(check-sat)
; unsat
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
(assert (=> p0@153@01 (<= 0 (Seq_length a@174@01))))
; [eval] p1 ==> i_0 <= |a_0|
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 596 | p1@154@01 | live]
; [else-branch: 596 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 596 | p1@154@01]
; [eval] i_0 <= |a_0|
; [eval] |a_0|
(pop) ; 19
(pop) ; 18
; Joined path conditions
(push) ; 18
(assert (not (=> p1@154@01 (<= 0 (Seq_length a_0@175@01)))))
(check-sat)
; unsat
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
(assert (=> p1@154@01 (<= 0 (Seq_length a_0@175@01))))
; [eval] (forall j: Int ::(p0 ==> true) && (p1 ==> true))
(declare-const j@188@01 Int)
(push) ; 18
; [eval] (p0 ==> true) && (p1 ==> true)
; [eval] p0 ==> true
(push) ; 19
(push) ; 20
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 597 | p0@153@01 | live]
; [else-branch: 597 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 597 | p0@153@01]
(pop) ; 20
(pop) ; 19
; Joined path conditions
(push) ; 19
; [then-branch: 598 | False | live]
; [else-branch: 598 | True | live]
(push) ; 20
; [then-branch: 598 | False]
(assert false)
(pop) ; 20
(push) ; 20
; [else-branch: 598 | True]
; [eval] p1 ==> true
(push) ; 21
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 599 | p1@154@01 | live]
; [else-branch: 599 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 599 | p1@154@01]
(pop) ; 22
(pop) ; 21
; Joined path conditions
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(pop) ; 18
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
; [eval] p0 ==> p0 && p1 ==> leak == leak_0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 600 | p0@153@01 | live]
; [else-branch: 600 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 600 | p0@153@01]
; [eval] p0 && p1 ==> leak == leak_0
; [eval] p0 && p1
(push) ; 20
; [then-branch: 601 | !(p0@153@01) | live]
; [else-branch: 601 | p0@153@01 | live]
(push) ; 21
; [then-branch: 601 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 21
(push) ; 21
; [else-branch: 601 | p0@153@01]
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p0@153@01 (not p0@153@01)))
(push) ; 20
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not (and p0@153@01 p1@154@01))))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (and p0@153@01 p1@154@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 602 | p0@153@01 && p1@154@01 | live]
; [else-branch: 602 | !(p0@153@01 && p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 602 | p0@153@01 && p1@154@01]
(assert (and p0@153@01 p1@154@01))
; [eval] leak == leak_0
(pop) ; 21
(pop) ; 20
; Joined path conditions
(assert (and p0@153@01 p1@154@01))
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> p0@153@01 (and (or p0@153@01 (not p0@153@01)) p0@153@01 p1@154@01)))
(assert p0@153@01)
; [eval] p1 ==> true
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1@154@01))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 603 | p1@154@01 | live]
; [else-branch: 603 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 603 | p1@154@01]
(assert p1@154@01)
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p1@154@01)
; [eval] p0 ==> p0 && p1 ==> i == i_0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 604 | p0@153@01 | live]
; [else-branch: 604 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 604 | p0@153@01]
; [eval] p0 && p1 ==> i == i_0
; [eval] p0 && p1
(push) ; 20
; [then-branch: 605 | !(p0@153@01) | live]
; [else-branch: 605 | p0@153@01 | live]
(push) ; 21
; [then-branch: 605 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 21
(push) ; 21
; [else-branch: 605 | p0@153@01]
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p0@153@01 (not p0@153@01)))
(push) ; 20
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not (and p0@153@01 p1@154@01))))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (and p0@153@01 p1@154@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 606 | p0@153@01 && p1@154@01 | live]
; [else-branch: 606 | !(p0@153@01 && p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 606 | p0@153@01 && p1@154@01]
(assert (and p0@153@01 p1@154@01))
; [eval] i == i_0
(pop) ; 21
(pop) ; 20
; Joined path conditions
(assert (and p0@153@01 p1@154@01))
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p0@153@01)
; [eval] p1 ==> true
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1@154@01))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 607 | p1@154@01 | live]
; [else-branch: 607 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 607 | p1@154@01]
(assert p1@154@01)
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p1@154@01)
; [eval] !p0 ==> tmp0_0 == i
; [eval] !p0
(push) ; 18
; [then-branch: 608 | !(p0@153@01) | dead]
; [else-branch: 608 | p0@153@01 | live]
(push) ; 19
; [else-branch: 608 | p0@153@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p0 ==> tmp0 == leak
; [eval] !p0
(push) ; 18
; [then-branch: 609 | !(p0@153@01) | dead]
; [else-branch: 609 | p0@153@01 | live]
(push) ; 19
; [else-branch: 609 | p0@153@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p1 ==> tmp1 == leak_0
; [eval] !p1
(push) ; 18
; [then-branch: 610 | !(p1@154@01) | dead]
; [else-branch: 610 | p1@154@01 | live]
(push) ; 19
; [else-branch: 610 | p1@154@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p1 ==> tmp1_0 == i_0
; [eval] !p1
(push) ; 18
; [then-branch: 611 | !(p1@154@01) | dead]
; [else-branch: 611 | p1@154@01 | live]
(push) ; 19
; [else-branch: 611 | p1@154@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; Loop head block: Execute statements of loop head block (in invariant state)
(push) ; 18
(assert (= $t@186@01 ($Snap.combine ($Snap.first $t@186@01) ($Snap.second $t@186@01))))
(assert (= ($Snap.first $t@186@01) $Snap.unit))
(assert (=> p0@153@01 (>= i@184@01 0)))
(assert (=
  ($Snap.second $t@186@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@186@01))
    ($Snap.second ($Snap.second $t@186@01)))))
(assert (= ($Snap.first ($Snap.second $t@186@01)) $Snap.unit))
(assert (=> p1@154@01 (>= i_0@185@01 0)))
(assert (=
  ($Snap.second ($Snap.second $t@186@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@186@01)))
    ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@186@01))) $Snap.unit))
(assert (=> p0@153@01 (<= i@184@01 (Seq_length a@174@01))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second $t@186@01)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@186@01))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@186@01))))
  $Snap.unit))
(assert (=> p1@154@01 (<= i_0@185@01 (Seq_length a_0@175@01))))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))
  $Snap.unit))
(assert (=> (and p0@153@01 (and p0@153@01 p1@154@01)) (= leak@182@01 leak_0@183@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))
  $Snap.unit))
(assert (=> (and p0@153@01 (and p0@153@01 p1@154@01)) (= i@184@01 i_0@185@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01)))))))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@186@01))))))))))))
  $Snap.unit))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 16000)
(check-sat)
; unknown
; Loop head block: Check well-definedness of edge conditions
(set-option :rlimit 0)
(push) ; 19
; [eval] p0 && i < |a| || p1 && i_0 < |a_0|
; [eval] p0 && i < |a|
(push) ; 20
; [then-branch: 612 | !(p0@153@01) | live]
; [else-branch: 612 | p0@153@01 | live]
(push) ; 21
; [then-branch: 612 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 21
(push) ; 21
; [else-branch: 612 | p0@153@01]
; [eval] i < |a|
; [eval] |a|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p0@153@01 (not p0@153@01)))
(push) ; 20
; [then-branch: 613 | p0@153@01 && i@184@01 < |a@174@01| | live]
; [else-branch: 613 | !(p0@153@01 && i@184@01 < |a@174@01|) | live]
(push) ; 21
; [then-branch: 613 | p0@153@01 && i@184@01 < |a@174@01|]
(assert (and p0@153@01 (< i@184@01 (Seq_length a@174@01))))
(pop) ; 21
(push) ; 21
; [else-branch: 613 | !(p0@153@01 && i@184@01 < |a@174@01|)]
(assert (not (and p0@153@01 (< i@184@01 (Seq_length a@174@01)))))
; [eval] p1 && i_0 < |a_0|
(push) ; 22
; [then-branch: 614 | !(p1@154@01) | live]
; [else-branch: 614 | p1@154@01 | live]
(push) ; 23
; [then-branch: 614 | !(p1@154@01)]
(assert (not p1@154@01))
(pop) ; 23
(push) ; 23
; [else-branch: 614 | p1@154@01]
; [eval] i_0 < |a_0|
; [eval] |a_0|
(pop) ; 23
(pop) ; 22
; Joined path conditions
; Joined path conditions
(assert (or p1@154@01 (not p1@154@01)))
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0@153@01 (< i@184@01 (Seq_length a@174@01))))
  (and
    (not (and p0@153@01 (< i@184@01 (Seq_length a@174@01))))
    (or p1@154@01 (not p1@154@01)))))
(assert (or
  (not (and p0@153@01 (< i@184@01 (Seq_length a@174@01))))
  (and p0@153@01 (< i@184@01 (Seq_length a@174@01)))))
(pop) ; 19
(push) ; 19
; [eval] !(p0 && i < |a| || p1 && i_0 < |a_0|)
; [eval] p0 && i < |a| || p1 && i_0 < |a_0|
; [eval] p0 && i < |a|
(push) ; 20
; [then-branch: 615 | !(p0@153@01) | live]
; [else-branch: 615 | p0@153@01 | live]
(push) ; 21
; [then-branch: 615 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 21
(push) ; 21
; [else-branch: 615 | p0@153@01]
(assert p0@153@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p0@153@01 (not p0@153@01)))
(push) ; 20
; [then-branch: 616 | p0@153@01 && i@184@01 < |a@174@01| | live]
; [else-branch: 616 | !(p0@153@01 && i@184@01 < |a@174@01|) | live]
(push) ; 21
; [then-branch: 616 | p0@153@01 && i@184@01 < |a@174@01|]
(assert (and p0@153@01 (< i@184@01 (Seq_length a@174@01))))
(pop) ; 21
(push) ; 21
; [else-branch: 616 | !(p0@153@01 && i@184@01 < |a@174@01|)]
(assert (not (and p0@153@01 (< i@184@01 (Seq_length a@174@01)))))
; [eval] p1 && i_0 < |a_0|
(push) ; 22
; [then-branch: 617 | !(p1@154@01) | live]
; [else-branch: 617 | p1@154@01 | live]
(push) ; 23
; [then-branch: 617 | !(p1@154@01)]
(assert (not p1@154@01))
(pop) ; 23
(push) ; 23
; [else-branch: 617 | p1@154@01]
; [eval] i_0 < |a_0|
; [eval] |a_0|
(pop) ; 23
(pop) ; 22
; Joined path conditions
; Joined path conditions
(assert (or p1@154@01 (not p1@154@01)))
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0@153@01 (< i@184@01 (Seq_length a@174@01))))
  (and
    (not (and p0@153@01 (< i@184@01 (Seq_length a@174@01))))
    (or p1@154@01 (not p1@154@01)))))
(assert (or
  (not (and p0@153@01 (< i@184@01 (Seq_length a@174@01))))
  (and p0@153@01 (< i@184@01 (Seq_length a@174@01)))))
(pop) ; 19
; Loop head block: Follow loop-internal edges
; [eval] p0 && i < |a| || p1 && i_0 < |a_0|
; [eval] p0 && i < |a|
(push) ; 19
; [then-branch: 618 | !(p0@153@01) | live]
; [else-branch: 618 | p0@153@01 | live]
(push) ; 20
; [then-branch: 618 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 20
(push) ; 20
; [else-branch: 618 | p0@153@01]
(assert p0@153@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(assert (or p0@153@01 (not p0@153@01)))
(push) ; 19
; [then-branch: 619 | p0@153@01 && i@184@01 < |a@174@01| | live]
; [else-branch: 619 | !(p0@153@01 && i@184@01 < |a@174@01|) | live]
(push) ; 20
; [then-branch: 619 | p0@153@01 && i@184@01 < |a@174@01|]
(assert (and p0@153@01 (< i@184@01 (Seq_length a@174@01))))
(pop) ; 20
(push) ; 20
; [else-branch: 619 | !(p0@153@01 && i@184@01 < |a@174@01|)]
(assert (not (and p0@153@01 (< i@184@01 (Seq_length a@174@01)))))
; [eval] p1 && i_0 < |a_0|
(push) ; 21
; [then-branch: 620 | !(p1@154@01) | live]
; [else-branch: 620 | p1@154@01 | live]
(push) ; 22
; [then-branch: 620 | !(p1@154@01)]
(assert (not p1@154@01))
(pop) ; 22
(push) ; 22
; [else-branch: 620 | p1@154@01]
; [eval] i_0 < |a_0|
; [eval] |a_0|
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (or p1@154@01 (not p1@154@01)))
(pop) ; 20
(pop) ; 19
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0@153@01 (< i@184@01 (Seq_length a@174@01))))
  (and
    (not (and p0@153@01 (< i@184@01 (Seq_length a@174@01))))
    (or p1@154@01 (not p1@154@01)))))
(assert (or
  (not (and p0@153@01 (< i@184@01 (Seq_length a@174@01))))
  (and p0@153@01 (< i@184@01 (Seq_length a@174@01)))))
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not
  (or
    (and p0@153@01 (< i@184@01 (Seq_length a@174@01)))
    (and p1@154@01 (< i_0@185@01 (Seq_length a_0@175@01)))))))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not (or
  (and p0@153@01 (< i@184@01 (Seq_length a@174@01)))
  (and p1@154@01 (< i_0@185@01 (Seq_length a_0@175@01))))))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 621 | p0@153@01 && i@184@01 < |a@174@01| || p1@154@01 && i_0@185@01 < |a_0@175@01| | live]
; [else-branch: 621 | !(p0@153@01 && i@184@01 < |a@174@01| || p1@154@01 && i_0@185@01 < |a_0@175@01|) | live]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 621 | p0@153@01 && i@184@01 < |a@174@01| || p1@154@01 && i_0@185@01 < |a_0@175@01|]
(assert (or
  (and p0@153@01 (< i@184@01 (Seq_length a@174@01)))
  (and p1@154@01 (< i_0@185@01 (Seq_length a_0@175@01)))))
; [exec]
; var p0_0: Bool
(declare-const p0_0@189@01 Bool)
; [exec]
; var p1_0: Bool
(declare-const p1_0@190@01 Bool)
; [exec]
; var pt0: Bool
(declare-const pt0@191@01 Bool)
; [exec]
; var pt1: Bool
(declare-const pt1@192@01 Bool)
; [exec]
; var pf0: Bool
(declare-const pf0@193@01 Bool)
; [exec]
; var pf1: Bool
(declare-const pf1@194@01 Bool)
; [exec]
; p0_0 := p0 && i < |a|
; [eval] p0 && i < |a|
(push) ; 20
; [then-branch: 622 | !(p0@153@01) | live]
; [else-branch: 622 | p0@153@01 | live]
(push) ; 21
; [then-branch: 622 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 21
(push) ; 21
; [else-branch: 622 | p0@153@01]
(assert p0@153@01)
; [eval] i < |a|
; [eval] |a|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(declare-const p0_0@195@01 Bool)
(assert (= p0_0@195@01 (and p0@153@01 (< i@184@01 (Seq_length a@174@01)))))
; [exec]
; p1_0 := p1 && i_0 < |a_0|
; [eval] p1 && i_0 < |a_0|
(push) ; 20
; [then-branch: 623 | !(p1@154@01) | live]
; [else-branch: 623 | p1@154@01 | live]
(push) ; 21
; [then-branch: 623 | !(p1@154@01)]
(assert (not p1@154@01))
(pop) ; 21
(push) ; 21
; [else-branch: 623 | p1@154@01]
; [eval] i_0 < |a_0|
; [eval] |a_0|
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p1@154@01 (not p1@154@01)))
(declare-const p1_0@196@01 Bool)
(assert (= p1_0@196@01 (and p1@154@01 (< i_0@185@01 (Seq_length a_0@175@01)))))
; [exec]
; pt0 := p0_0 && a[i] == 1
; [eval] p0_0 && a[i] == 1
(push) ; 20
; [then-branch: 624 | !(p0_0@195@01) | live]
; [else-branch: 624 | p0_0@195@01 | live]
(push) ; 21
; [then-branch: 624 | !(p0_0@195@01)]
(assert (not p0_0@195@01))
(pop) ; 21
(push) ; 21
; [else-branch: 624 | p0_0@195@01]
(assert p0_0@195@01)
; [eval] a[i] == 1
; [eval] a[i]
(push) ; 22
(assert (not (>= i@184@01 0)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(push) ; 22
(assert (not (< i@184@01 (Seq_length a@174@01))))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p0_0@195@01 (not p0_0@195@01)))
(declare-const pt0@197@01 Bool)
(assert (= pt0@197@01 (and p0_0@195@01 (= (Seq_index a@174@01 i@184@01) 1))))
; [exec]
; pt1 := p1_0 && a_0[i_0] == 1
; [eval] p1_0 && a_0[i_0] == 1
(push) ; 20
; [then-branch: 625 | !(p1_0@196@01) | live]
; [else-branch: 625 | p1_0@196@01 | live]
(push) ; 21
; [then-branch: 625 | !(p1_0@196@01)]
(assert (not p1_0@196@01))
(pop) ; 21
(push) ; 21
; [else-branch: 625 | p1_0@196@01]
(assert p1_0@196@01)
; [eval] a_0[i_0] == 1
; [eval] a_0[i_0]
(push) ; 22
(assert (not (>= i_0@185@01 0)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(push) ; 22
(assert (not (< i_0@185@01 (Seq_length a_0@175@01))))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(assert (or p1_0@196@01 (not p1_0@196@01)))
(declare-const pt1@198@01 Bool)
(assert (= pt1@198@01 (and p1_0@196@01 (= (Seq_index a_0@175@01 i_0@185@01) 1))))
; [exec]
; pf0 := p0_0 && !(a[i] == 1)
; [eval] p0_0 && !(a[i] == 1)
(push) ; 20
; [then-branch: 626 | !(p0_0@195@01) | live]
; [else-branch: 626 | p0_0@195@01 | live]
(push) ; 21
; [then-branch: 626 | !(p0_0@195@01)]
(assert (not p0_0@195@01))
(pop) ; 21
(push) ; 21
; [else-branch: 626 | p0_0@195@01]
(assert p0_0@195@01)
; [eval] !(a[i] == 1)
; [eval] a[i] == 1
; [eval] a[i]
(push) ; 22
(assert (not (>= i@184@01 0)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(push) ; 22
(assert (not (< i@184@01 (Seq_length a@174@01))))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(declare-const pf0@199@01 Bool)
(assert (= pf0@199@01 (and p0_0@195@01 (not (= (Seq_index a@174@01 i@184@01) 1)))))
; [exec]
; pf1 := p1_0 && !(a_0[i_0] == 1)
; [eval] p1_0 && !(a_0[i_0] == 1)
(push) ; 20
; [then-branch: 627 | !(p1_0@196@01) | live]
; [else-branch: 627 | p1_0@196@01 | live]
(push) ; 21
; [then-branch: 627 | !(p1_0@196@01)]
(assert (not p1_0@196@01))
(pop) ; 21
(push) ; 21
; [else-branch: 627 | p1_0@196@01]
(assert p1_0@196@01)
; [eval] !(a_0[i_0] == 1)
; [eval] a_0[i_0] == 1
; [eval] a_0[i_0]
(push) ; 22
(assert (not (>= i_0@185@01 0)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(push) ; 22
(assert (not (< i_0@185@01 (Seq_length a_0@175@01))))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(declare-const pf1@200@01 Bool)
(assert (= pf1@200@01 (and p1_0@196@01 (not (= (Seq_index a_0@175@01 i_0@185@01) 1)))))
(push) ; 20
(set-option :rlimit 16000)
(assert (not (not pt0@197@01)))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 20
(set-option :rlimit 16000)
(assert (not pt0@197@01))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 628 | pt0@197@01 | live]
; [else-branch: 628 | !(pt0@197@01) | live]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 628 | pt0@197@01]
(assert pt0@197@01)
; [exec]
; leak := i
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt1@198@01)))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not pt1@198@01))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 629 | pt1@198@01 | live]
; [else-branch: 629 | !(pt1@198@01) | live]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 629 | pt1@198@01]
(assert pt1@198@01)
; [exec]
; leak_0 := i_0
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p0_0@195@01)))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 22
(set-option :rlimit 16000)
(assert (not p0_0@195@01))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 630 | p0_0@195@01 | live]
; [else-branch: 630 | !(p0_0@195@01) | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 630 | p0_0@195@01]
(assert p0_0@195@01)
; [exec]
; i := i + 1
; [eval] i + 1
(declare-const i@201@01 Int)
(assert (= i@201@01 (+ i@184@01 1)))
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not p1_0@196@01)))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 23
(set-option :rlimit 16000)
(assert (not p1_0@196@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 631 | p1_0@196@01 | live]
; [else-branch: 631 | !(p1_0@196@01) | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 631 | p1_0@196@01]
(assert p1_0@196@01)
; [exec]
; i_0 := i_0 + 1
; [eval] i_0 + 1
(declare-const i_0@202@01 Int)
(assert (= i_0@202@01 (+ i_0@185@01 1)))
; Loop head block: Re-establish invariant
; [eval] p0 ==> i >= 0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 25
(set-option :rlimit 16000)
(assert (not p0@153@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 632 | p0@153@01 | live]
; [else-branch: 632 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 632 | p0@153@01]
(assert p0@153@01)
; [eval] i >= 0
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p0@153@01)
(push) ; 24
(assert (not (=> p0@153@01 (>= i@201@01 0))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p0@153@01 (>= i@201@01 0)))
; [eval] p1 ==> i_0 >= 0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 633 | p1@154@01 | live]
; [else-branch: 633 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 633 | p1@154@01]
; [eval] i_0 >= 0
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p1@154@01 (>= i_0@202@01 0))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p1@154@01 (>= i_0@202@01 0)))
; [eval] p0 ==> i <= |a|
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 634 | p0@153@01 | live]
; [else-branch: 634 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 634 | p0@153@01]
; [eval] i <= |a|
; [eval] |a|
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p0@153@01 (<= i@201@01 (Seq_length a@174@01)))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p0@153@01 (<= i@201@01 (Seq_length a@174@01))))
; [eval] p1 ==> i_0 <= |a_0|
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 635 | p1@154@01 | live]
; [else-branch: 635 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 635 | p1@154@01]
; [eval] i_0 <= |a_0|
; [eval] |a_0|
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p1@154@01 (<= i_0@202@01 (Seq_length a_0@175@01)))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p1@154@01 (<= i_0@202@01 (Seq_length a_0@175@01))))
; [eval] (forall j: Int ::(p0 ==> true) && (p1 ==> true))
(declare-const j@203@01 Int)
(push) ; 24
; [eval] (p0 ==> true) && (p1 ==> true)
; [eval] p0 ==> true
(push) ; 25
(push) ; 26
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 26
; 0.00s
; (get-info :all-statistics)
; [then-branch: 636 | p0@153@01 | live]
; [else-branch: 636 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 636 | p0@153@01]
(pop) ; 26
(pop) ; 25
; Joined path conditions
(push) ; 25
; [then-branch: 637 | False | live]
; [else-branch: 637 | True | live]
(push) ; 26
; [then-branch: 637 | False]
(assert false)
(pop) ; 26
(push) ; 26
; [else-branch: 637 | True]
; [eval] p1 ==> true
(push) ; 27
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 638 | p1@154@01 | live]
; [else-branch: 638 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 638 | p1@154@01]
(pop) ; 28
(pop) ; 27
; Joined path conditions
(pop) ; 26
(pop) ; 25
; Joined path conditions
; Joined path conditions
(pop) ; 24
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
; [eval] p0 ==> p0 && p1 ==> leak == leak_0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 639 | p0@153@01 | live]
; [else-branch: 639 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 639 | p0@153@01]
; [eval] p0 && p1 ==> leak == leak_0
; [eval] p0 && p1
(push) ; 26
; [then-branch: 640 | !(p0@153@01) | live]
; [else-branch: 640 | p0@153@01 | live]
(push) ; 27
; [then-branch: 640 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 27
(push) ; 27
; [else-branch: 640 | p0@153@01]
(pop) ; 27
(pop) ; 26
; Joined path conditions
; Joined path conditions
(push) ; 26
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not (and p0@153@01 p1@154@01))))
(check-sat)
; unknown
(pop) ; 27
; 0.01s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 27
(set-option :rlimit 16000)
(assert (not (and p0@153@01 p1@154@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 641 | p0@153@01 && p1@154@01 | live]
; [else-branch: 641 | !(p0@153@01 && p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 641 | p0@153@01 && p1@154@01]
(assert (and p0@153@01 p1@154@01))
; [eval] leak == leak_0
(pop) ; 27
(pop) ; 26
; Joined path conditions
(assert (and p0@153@01 p1@154@01))
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert (=> p0@153@01 (and p0@153@01 p1@154@01)))
(assert p0@153@01)
; [eval] p1 ==> true
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 25
(set-option :rlimit 16000)
(assert (not p1@154@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 642 | p1@154@01 | live]
; [else-branch: 642 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 642 | p1@154@01]
(assert p1@154@01)
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p1@154@01)
; [eval] p0 ==> p0 && p1 ==> i == i_0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.01s
; (get-info :all-statistics)
; [then-branch: 643 | p0@153@01 | live]
; [else-branch: 643 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 643 | p0@153@01]
; [eval] p0 && p1 ==> i == i_0
; [eval] p0 && p1
(push) ; 26
; [then-branch: 644 | !(p0@153@01) | live]
; [else-branch: 644 | p0@153@01 | live]
(push) ; 27
; [then-branch: 644 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 27
(push) ; 27
; [else-branch: 644 | p0@153@01]
(pop) ; 27
(pop) ; 26
; Joined path conditions
; Joined path conditions
(push) ; 26
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not (and p0@153@01 p1@154@01))))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 27
(set-option :rlimit 16000)
(assert (not (and p0@153@01 p1@154@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 645 | p0@153@01 && p1@154@01 | live]
; [else-branch: 645 | !(p0@153@01 && p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 645 | p0@153@01 && p1@154@01]
(assert (and p0@153@01 p1@154@01))
; [eval] i == i_0
(pop) ; 27
(pop) ; 26
; Joined path conditions
(assert (and p0@153@01 p1@154@01))
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p0@153@01)
(push) ; 24
(assert (not (=> (and p0@153@01 (and p0@153@01 p1@154@01)) (= i@201@01 i_0@202@01))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> (and p0@153@01 (and p0@153@01 p1@154@01)) (= i@201@01 i_0@202@01)))
; [eval] p1 ==> true
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 25
(set-option :rlimit 16000)
(assert (not p1@154@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 646 | p1@154@01 | live]
; [else-branch: 646 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 646 | p1@154@01]
(assert p1@154@01)
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p1@154@01)
; [eval] !p0 ==> tmp0_0 == i
; [eval] !p0
(push) ; 24
; [then-branch: 647 | !(p0@153@01) | dead]
; [else-branch: 647 | p0@153@01 | live]
(push) ; 25
; [else-branch: 647 | p0@153@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p0 ==> tmp0 == leak
; [eval] !p0
(push) ; 24
; [then-branch: 648 | !(p0@153@01) | dead]
; [else-branch: 648 | p0@153@01 | live]
(push) ; 25
; [else-branch: 648 | p0@153@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p1 ==> tmp1 == leak_0
; [eval] !p1
(push) ; 24
; [then-branch: 649 | !(p1@154@01) | dead]
; [else-branch: 649 | p1@154@01 | live]
(push) ; 25
; [else-branch: 649 | p1@154@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
; [eval] !p1 ==> tmp1_0 == i_0
; [eval] !p1
(push) ; 24
; [then-branch: 650 | !(p1@154@01) | dead]
; [else-branch: 650 | p1@154@01 | live]
(push) ; 25
; [else-branch: 650 | p1@154@01]
(pop) ; 25
(pop) ; 24
; Joined path conditions
(pop) ; 23
; [eval] !p1_0
(push) ; 23
(set-option :rlimit 16000)
(assert (not p1_0@196@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 651 | !(p1_0@196@01) | dead]
; [else-branch: 651 | p1_0@196@01 | live]
(set-option :rlimit 0)
(push) ; 23
; [else-branch: 651 | p1_0@196@01]
(assert p1_0@196@01)
(pop) ; 23
(pop) ; 22
; [eval] !p0_0
(push) ; 22
(set-option :rlimit 16000)
(assert (not p0_0@195@01))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 652 | !(p0_0@195@01) | dead]
; [else-branch: 652 | p0_0@195@01 | live]
(set-option :rlimit 0)
(push) ; 22
; [else-branch: 652 | p0_0@195@01]
(assert p0_0@195@01)
(pop) ; 22
(pop) ; 21
(push) ; 21
; [else-branch: 629 | !(pt1@198@01)]
(assert (not pt1@198@01))
(pop) ; 21
; [eval] !pt1
(push) ; 21
(set-option :rlimit 16000)
(assert (not pt1@198@01))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt1@198@01)))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 653 | !(pt1@198@01) | live]
; [else-branch: 653 | pt1@198@01 | live]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 653 | !(pt1@198@01)]
(assert (not pt1@198@01))
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not p0_0@195@01)))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 22
(set-option :rlimit 16000)
(assert (not p0_0@195@01))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 654 | p0_0@195@01 | live]
; [else-branch: 654 | !(p0_0@195@01) | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 654 | p0_0@195@01]
(assert p0_0@195@01)
; [exec]
; i := i + 1
; [eval] i + 1
(declare-const i@204@01 Int)
(assert (= i@204@01 (+ i@184@01 1)))
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not p1_0@196@01)))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 23
(set-option :rlimit 16000)
(assert (not p1_0@196@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 655 | p1_0@196@01 | live]
; [else-branch: 655 | !(p1_0@196@01) | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 655 | p1_0@196@01]
(assert p1_0@196@01)
; [exec]
; i_0 := i_0 + 1
; [eval] i_0 + 1
(declare-const i_0@205@01 Int)
(assert (= i_0@205@01 (+ i_0@185@01 1)))
; Loop head block: Re-establish invariant
; [eval] p0 ==> i >= 0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 25
(set-option :rlimit 16000)
(assert (not p0@153@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 656 | p0@153@01 | live]
; [else-branch: 656 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 656 | p0@153@01]
(assert p0@153@01)
; [eval] i >= 0
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p0@153@01)
(push) ; 24
(assert (not (=> p0@153@01 (>= i@204@01 0))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p0@153@01 (>= i@204@01 0)))
; [eval] p1 ==> i_0 >= 0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 25
(set-option :rlimit 16000)
(assert (not p1@154@01))
(check-sat)
; unsat
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 657 | p1@154@01 | live]
; [else-branch: 657 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 657 | p1@154@01]
(assert p1@154@01)
; [eval] i_0 >= 0
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p1@154@01)
(push) ; 24
(assert (not (=> p1@154@01 (>= i_0@205@01 0))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p1@154@01 (>= i_0@205@01 0)))
; [eval] p0 ==> i <= |a|
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 658 | p0@153@01 | live]
; [else-branch: 658 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 658 | p0@153@01]
; [eval] i <= |a|
; [eval] |a|
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p0@153@01 (<= i@204@01 (Seq_length a@174@01)))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p0@153@01 (<= i@204@01 (Seq_length a@174@01))))
; [eval] p1 ==> i_0 <= |a_0|
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 659 | p1@154@01 | live]
; [else-branch: 659 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 659 | p1@154@01]
; [eval] i_0 <= |a_0|
; [eval] |a_0|
(pop) ; 25
(pop) ; 24
; Joined path conditions
(push) ; 24
(assert (not (=> p1@154@01 (<= i_0@205@01 (Seq_length a_0@175@01)))))
(check-sat)
; unsat
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(assert (=> p1@154@01 (<= i_0@205@01 (Seq_length a_0@175@01))))
; [eval] (forall j: Int ::(p0 ==> true) && (p1 ==> true))
(declare-const j@206@01 Int)
(push) ; 24
; [eval] (p0 ==> true) && (p1 ==> true)
; [eval] p0 ==> true
(push) ; 25
(push) ; 26
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 26
; 0.00s
; (get-info :all-statistics)
; [then-branch: 660 | p0@153@01 | live]
; [else-branch: 660 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 660 | p0@153@01]
(pop) ; 26
(pop) ; 25
; Joined path conditions
(push) ; 25
; [then-branch: 661 | False | live]
; [else-branch: 661 | True | live]
(push) ; 26
; [then-branch: 661 | False]
(assert false)
(pop) ; 26
(push) ; 26
; [else-branch: 661 | True]
; [eval] p1 ==> true
(push) ; 27
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not p1@154@01)))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 662 | p1@154@01 | live]
; [else-branch: 662 | !(p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 662 | p1@154@01]
(pop) ; 28
(pop) ; 27
; Joined path conditions
(pop) ; 26
(pop) ; 25
; Joined path conditions
; Joined path conditions
(pop) ; 24
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
; [eval] p0 ==> p0 && p1 ==> leak == leak_0
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 663 | p0@153@01 | live]
; [else-branch: 663 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 663 | p0@153@01]
; [eval] p0 && p1 ==> leak == leak_0
; [eval] p0 && p1
(push) ; 26
; [then-branch: 664 | !(p0@153@01) | live]
; [else-branch: 664 | p0@153@01 | live]
(push) ; 27
; [then-branch: 664 | !(p0@153@01)]
(assert (not p0@153@01))
(pop) ; 27
(push) ; 27
; [else-branch: 664 | p0@153@01]
(pop) ; 27
(pop) ; 26
; Joined path conditions
; Joined path conditions
(push) ; 26
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not (and p0@153@01 p1@154@01))))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 27
(set-option :rlimit 16000)
(assert (not (and p0@153@01 p1@154@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 665 | p0@153@01 && p1@154@01 | live]
; [else-branch: 665 | !(p0@153@01 && p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 665 | p0@153@01 && p1@154@01]
(assert (and p0@153@01 p1@154@01))
; [eval] leak == leak_0
(pop) ; 27
(pop) ; 26
; Joined path conditions
(assert (and p0@153@01 p1@154@01))
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert (=> p0@153@01 (and p0@153@01 p1@154@01)))
(assert p0@153@01)
(push) ; 24
(assert (not (=> (and p0@153@01 (and p0@153@01 p1@154@01)) (= i@184@01 leak_0@183@01))))
(check-sat)
; unknown
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] p0 ==> p0 && p1 ==> leak == leak_0
(set-option :rlimit 0)
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 666 | p0@153@01 | live]
; [else-branch: 666 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 666 | p0@153@01]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] p0 && p1 ==> leak == leak_0
; [eval] p0 && p1
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 667 | !(p0@153@01) | live]
; [else-branch: 667 | p0@153@01 | live]
(push) ; 27
; [then-branch: 667 | !(p0@153@01)]
(assert (not p0@153@01))
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unsat
(pop) ; 27
(set-option :rlimit 0)
(push) ; 27
; [else-branch: 667 | p0@153@01]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
(pop) ; 27
(pop) ; 26
; Joined path conditions
; Joined path conditions
(set-option :rlimit 0)
(push) ; 26
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not (and p0@153@01 p1@154@01))))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 27
(set-option :rlimit 16000)
(assert (not (and p0@153@01 p1@154@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 668 | p0@153@01 && p1@154@01 | live]
; [else-branch: 668 | !(p0@153@01 && p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 668 | p0@153@01 && p1@154@01]
(assert (and p0@153@01 p1@154@01))
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] leak == leak_0
(pop) ; 27
(pop) ; 26
; Joined path conditions
(assert (and p0@153@01 p1@154@01))
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p0@153@01)
(set-option :rlimit 0)
(push) ; 24
(assert (not (=> (and p0@153@01 (and p0@153@01 p1@154@01)) (= i@184@01 leak_0@183@01))))
(check-sat)
; unknown
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] p0 ==> p0 && p1 ==> leak == leak_0
(set-option :rlimit 0)
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 669 | p0@153@01 | live]
; [else-branch: 669 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 669 | p0@153@01]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] p0 && p1 ==> leak == leak_0
; [eval] p0 && p1
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 670 | !(p0@153@01) | live]
; [else-branch: 670 | p0@153@01 | live]
(push) ; 27
; [then-branch: 670 | !(p0@153@01)]
(assert (not p0@153@01))
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unsat
(pop) ; 27
(set-option :rlimit 0)
(push) ; 27
; [else-branch: 670 | p0@153@01]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
(pop) ; 27
(pop) ; 26
; Joined path conditions
; Joined path conditions
(set-option :rlimit 0)
(push) ; 26
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not (and p0@153@01 p1@154@01))))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 27
(set-option :rlimit 16000)
(assert (not (and p0@153@01 p1@154@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 671 | p0@153@01 && p1@154@01 | live]
; [else-branch: 671 | !(p0@153@01 && p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 671 | p0@153@01 && p1@154@01]
(assert (and p0@153@01 p1@154@01))
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] leak == leak_0
(pop) ; 27
(pop) ; 26
; Joined path conditions
(assert (and p0@153@01 p1@154@01))
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p0@153@01)
(set-option :rlimit 0)
(push) ; 24
(assert (not (=> (and p0@153@01 (and p0@153@01 p1@154@01)) (= i@184@01 leak_0@183@01))))
(check-sat)
; unknown
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] p0 ==> p0 && p1 ==> leak == leak_0
(set-option :rlimit 0)
(push) ; 24
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not p0@153@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 672 | p0@153@01 | live]
; [else-branch: 672 | !(p0@153@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 672 | p0@153@01]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] p0 && p1 ==> leak == leak_0
; [eval] p0 && p1
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 673 | !(p0@153@01) | live]
; [else-branch: 673 | p0@153@01 | live]
(push) ; 27
; [then-branch: 673 | !(p0@153@01)]
(assert (not p0@153@01))
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unsat
(pop) ; 27
(set-option :rlimit 0)
(push) ; 27
; [else-branch: 673 | p0@153@01]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
(pop) ; 27
(pop) ; 26
; Joined path conditions
; Joined path conditions
(set-option :rlimit 0)
(push) ; 26
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not (and p0@153@01 p1@154@01))))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 27
(set-option :rlimit 16000)
(assert (not (and p0@153@01 p1@154@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 674 | p0@153@01 && p1@154@01 | live]
; [else-branch: 674 | !(p0@153@01 && p1@154@01) | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 674 | p0@153@01 && p1@154@01]
(assert (and p0@153@01 p1@154@01))
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] leak == leak_0
(pop) ; 27
(pop) ; 26
; Joined path conditions
(assert (and p0@153@01 p1@154@01))
(pop) ; 25
(pop) ; 24
; Joined path conditions
(assert p0@153@01)
(set-option :rlimit 0)
(push) ; 24
(assert (not (=> (and p0@153@01 (and p0@153@01 p1@154@01)) (= i@184@01 leak_0@183@01))))
(check-sat)
; unknown
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
(pop) ; 23
(pop) ; 22
(pop) ; 21
(pop) ; 20
(pop) ; 19
(pop) ; 18
(pop) ; 17
(pop) ; 16
(pop) ; 15
(pop) ; 14
(pop) ; 13
(pop) ; 12
(pop) ; 11
(pop) ; 10
(pop) ; 9
(pop) ; 8
(pop) ; 7
(pop) ; 6
(pop) ; 5
(pop) ; 4
(pop) ; 3
(pop) ; 2
(pop) ; 1
