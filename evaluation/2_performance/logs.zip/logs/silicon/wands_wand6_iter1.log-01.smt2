(get-info :version)
; (:version "4.8.7")
; Started: 2025-12-05 16:52:14
; Silicon.version: 1.1-SNAPSHOT (95328487@(detached))
; Input file: ./wands/wand6.vpr
; Verifier id: 00
; ------------------------------------------------------------
; Begin preamble
; ////////// Static preamble
; 
; ; /z3config.smt2
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :smt.qi.max_multi_patterns 1000)
; 
; ; /preamble.smt2
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(define-fun $Perm.min ((p1 $Perm) (p2 $Perm)) Real
    (ite (<= p1 p2) p1 p2))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
; ////////// Sorts
(declare-sort $MWSF 0)
; ////////// Sort wrappers
; Declaring additional sort wrappers
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.$MWSFTo$Snap ($MWSF) $Snap)
(declare-fun $SortWrappers.$SnapTo$MWSF ($Snap) $MWSF)
(assert (forall ((x $MWSF)) (!
    (= x ($SortWrappers.$SnapTo$MWSF($SortWrappers.$MWSFTo$Snap x)))
    :pattern (($SortWrappers.$MWSFTo$Snap x))
    :qid |$Snap.$SnapTo$MWSFTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$MWSFTo$Snap($SortWrappers.$SnapTo$MWSF x)))
    :pattern (($SortWrappers.$SnapTo$MWSF x))
    :qid |$Snap.$MWSFTo$SnapTo$MWSF|
    )))
; ////////// Symbols
(declare-fun MWSF_apply ($MWSF $Snap) $Snap)
; Declaring symbols related to program functions (from program analysis)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
; Declaring predicate trigger functions
(declare-fun p%trigger ($Snap $Ref) Bool)
; ////////// Uniqueness assumptions from domains
; ////////// Axioms
; End preamble
; ------------------------------------------------------------
; State saturation: after preamble
(set-option :rlimit 160000)
(check-sat)
; unknown
; ------------------------------------------------------------
; Begin function- and predicate-related preamble
; Declaring symbols related to program functions (from verification)
; Declaring symbols related to program functions (from verification)
; End function- and predicate-related preamble
; ------------------------------------------------------------
; ---------- foo ----------
(declare-const y@0@01 $Ref)
(declare-const x0@1@01 $Ref)
(declare-const x1@2@01 $Ref)
(declare-const y@3@01 $Ref)
(declare-const x0@4@01 $Ref)
(declare-const x1@5@01 $Ref)
(set-option :rlimit 0)
(push) ; 1
(declare-const $t@6@01 $Snap)
(assert (= $t@6@01 ($Snap.combine ($Snap.first $t@6@01) ($Snap.second $t@6@01))))
(assert (not (= x0@4@01 $Ref.null)))
(assert (=
  ($Snap.second $t@6@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@6@01))
    ($Snap.second ($Snap.second $t@6@01)))))
(assert (=
  ($Snap.second ($Snap.second $t@6@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@6@01)))
    ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@6@01))) $Snap.unit))
; [eval] x0.f == 0
(assert (= ($SortWrappers.$SnapToInt ($Snap.first $t@6@01)) 0))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second $t@6@01)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@6@01))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01)))))))
(push) ; 2
(set-option :rlimit 16000)
(assert (not (= x0@4@01 x1@5@01)))
(check-sat)
; unknown
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (not (= x1@5@01 $Ref.null)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01)))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))))
(set-option :rlimit 0)
(push) ; 2
(set-option :rlimit 16000)
(assert (not (= x0@4@01 x1@5@01)))
(check-sat)
; unknown
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01)))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01)))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))
  $Snap.unit))
; [eval] x1.f == 1
(assert (=
  ($SortWrappers.$SnapToInt ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@6@01)))))
  1))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))
  $Snap.unit))
; [eval] y == x0 || y == x1
; [eval] y == x0
(set-option :rlimit 0)
(push) ; 2
; [then-branch: 0 | y@3@01 == x0@4@01 | live]
; [else-branch: 0 | y@3@01 != x0@4@01 | live]
(push) ; 3
; [then-branch: 0 | y@3@01 == x0@4@01]
(assert (= y@3@01 x0@4@01))
(pop) ; 3
(push) ; 3
; [else-branch: 0 | y@3@01 != x0@4@01]
(assert (not (= y@3@01 x0@4@01)))
; [eval] y == x1
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= y@3@01 x0@4@01)) (= y@3@01 x0@4@01)))
(assert (or (= y@3@01 x0@4@01) (= y@3@01 x1@5@01)))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
(pop) ; 2
(push) ; 2
; [exec]
; package acc(x0.g, write) --* acc(p(x0), write) {
;   fold acc(p(x0), write)
; }
(push) ; 3
(declare-const $t@7@01 $Snap)
; [exec]
; fold acc(p(x0), write)
(push) ; 4
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(check-sat)
; unknown
(check-sat)
; unknown
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(check-sat)
; unknown
(check-sat)
; unknown
(assert (p%trigger ($Snap.combine ($Snap.first $t@6@01) $t@7@01) x0@4@01))
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(check-sat)
; unknown
; Create MagicWandSnapFunction for wand acc(x0.g, write) --* acc(p(x0), write)
(declare-const mwsf@8@01 $MWSF)
(assert (forall (($t@7@01 $Snap)) (!
  (=
    (MWSF_apply mwsf@8@01 $t@7@01)
    ($Snap.combine ($Snap.first $t@6@01) $t@7@01))
  :pattern ((MWSF_apply mwsf@8@01 $t@7@01))
  :qid |quant-u-0|)))
(pop) ; 3
(set-option :rlimit 0)
(push) ; 3
(assert (forall (($t@7@01 $Snap)) (!
  (=
    (MWSF_apply mwsf@8@01 $t@7@01)
    ($Snap.combine ($Snap.first $t@6@01) $t@7@01))
  :pattern ((MWSF_apply mwsf@8@01 $t@7@01))
  :qid |quant-u-1|)))
(assert true)
; [exec]
; package acc(x1.g, write) --* acc(p(x1), write) {
;   fold acc(p(x1), write)
; }
(push) ; 4
(declare-const $t@9@01 $Snap)
; [exec]
; fold acc(p(x1), write)
(push) ; 5
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(check-sat)
; unknown
(check-sat)
; unknown
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(check-sat)
; unknown
(check-sat)
; unknown
(assert (p%trigger ($Snap.combine
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@6@01))))
  $t@9@01) x1@5@01))
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(check-sat)
; unknown
; Create MagicWandSnapFunction for wand acc(x1.g, write) --* acc(p(x1), write)
(declare-const mwsf@10@01 $MWSF)
(assert (forall (($t@9@01 $Snap)) (!
  (=
    (MWSF_apply mwsf@10@01 $t@9@01)
    ($Snap.combine
      ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@6@01))))
      $t@9@01))
  :pattern ((MWSF_apply mwsf@10@01 $t@9@01))
  :qid |quant-u-2|)))
(pop) ; 4
(set-option :rlimit 0)
(push) ; 4
(assert (forall (($t@9@01 $Snap)) (!
  (=
    (MWSF_apply mwsf@10@01 $t@9@01)
    ($Snap.combine
      ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@6@01))))
      $t@9@01))
  :pattern ((MWSF_apply mwsf@10@01 $t@9@01))
  :qid |quant-u-3|)))
(assert true)
; [exec]
; quasihavoc acc(x0.g, write) --* acc(p(x0), write)
(declare-const mwsf@11@01 $MWSF)
(declare-const mwsf@12@01 $MWSF)
; [exec]
; quasihavoc acc(x1.g, write) --* acc(p(x1), write)
(declare-const mwsf@13@01 $MWSF)
(declare-const mwsf@14@01 $MWSF)
; [exec]
; apply acc(x0.g, write) --* acc(p(x0), write)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [exec]
; apply acc(x1.g, write) --* acc(p(x1), write)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x0@4@01 x1@5@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.01s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x1@5@01 x0@4@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (=
    (MWSF_apply (ite (= x0@4@01 x1@5@01) mwsf@13@01 mwsf@12@01) ($Snap.first ($Snap.second $t@6@01)))
    (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))))))
(check-sat)
; unknown
(pop) ; 5
; 0.01s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (=
    (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))
    (MWSF_apply (ite (= x0@4@01 x1@5@01) mwsf@13@01 mwsf@12@01) ($Snap.first ($Snap.second $t@6@01)))))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [exec]
; unfold acc(p(x0), write)
(assert (=
  (MWSF_apply (ite (= x0@4@01 x1@5@01) mwsf@13@01 mwsf@12@01) ($Snap.first ($Snap.second $t@6@01)))
  ($Snap.combine
    ($Snap.first (MWSF_apply (ite (= x0@4@01 x1@5@01) mwsf@13@01 mwsf@12@01) ($Snap.first ($Snap.second $t@6@01))))
    ($Snap.second (MWSF_apply (ite (= x0@4@01 x1@5@01) mwsf@13@01 mwsf@12@01) ($Snap.first ($Snap.second $t@6@01)))))))
; State saturation: after unfold
(set-option :rlimit 64000)
(check-sat)
; unknown
(assert (p%trigger (MWSF_apply (ite (= x0@4@01 x1@5@01) mwsf@13@01 mwsf@12@01) ($Snap.first ($Snap.second $t@6@01))) x0@4@01))
; [exec]
; unfold acc(p(x1), write)
(assert (=
  (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))
  ($Snap.combine
    ($Snap.first (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01)))))))
    ($Snap.second (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))))))
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x0@4@01 x1@5@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x0@4@01 x1@5@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; State saturation: after unfold
(set-option :rlimit 64000)
(check-sat)
; unknown
(assert (p%trigger (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01)))))) x1@5@01))
; [exec]
; assert acc(y.f, write)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x1@5@01 y@3@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x0@4@01 y@3@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(check-sat)
; unknown
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x1@5@01 x0@4@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x1@5@01 x0@4@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (=
    ($SortWrappers.$SnapToInt ($Snap.second (MWSF_apply (ite
      (= x0@4@01 x1@5@01)
      mwsf@13@01
      mwsf@12@01) ($Snap.first ($Snap.second $t@6@01)))))
    ($SortWrappers.$SnapToInt ($Snap.second (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))))))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (=
    ($SortWrappers.$SnapToInt ($Snap.second (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))))
    ($SortWrappers.$SnapToInt ($Snap.second (MWSF_apply (ite
      (= x0@4@01 x1@5@01)
      mwsf@13@01
      mwsf@12@01) ($Snap.first ($Snap.second $t@6@01)))))))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (=
    ($SortWrappers.$SnapToInt ($Snap.first (MWSF_apply (ite
      (= x0@4@01 x1@5@01)
      mwsf@13@01
      mwsf@12@01) ($Snap.first ($Snap.second $t@6@01)))))
    ($SortWrappers.$SnapToInt ($Snap.first (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))))))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (=
    ($SortWrappers.$SnapToInt ($Snap.first (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))))
    ($SortWrappers.$SnapToInt ($Snap.first (MWSF_apply (ite
      (= x0@4@01 x1@5@01)
      mwsf@13@01
      mwsf@12@01) ($Snap.first ($Snap.second $t@6@01)))))))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (and (not (= x0@4@01 x1@5@01)) (not (= x1@5@01 x0@4@01))))
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x0@4@01 y@3@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x1@5@01 y@3@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(check-sat)
; unknown
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x1@5@01 x0@4@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x1@5@01 x0@4@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (=
    ($SortWrappers.$SnapToInt ($Snap.second (MWSF_apply (ite
      (= x0@4@01 x1@5@01)
      mwsf@13@01
      mwsf@12@01) ($Snap.first ($Snap.second $t@6@01)))))
    ($SortWrappers.$SnapToInt ($Snap.second (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))))))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (=
    ($SortWrappers.$SnapToInt ($Snap.second (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))))
    ($SortWrappers.$SnapToInt ($Snap.second (MWSF_apply (ite
      (= x0@4@01 x1@5@01)
      mwsf@13@01
      mwsf@12@01) ($Snap.first ($Snap.second $t@6@01)))))))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (=
    ($SortWrappers.$SnapToInt ($Snap.first (MWSF_apply (ite
      (= x0@4@01 x1@5@01)
      mwsf@13@01
      mwsf@12@01) ($Snap.first ($Snap.second $t@6@01)))))
    ($SortWrappers.$SnapToInt ($Snap.first (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))))))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (=
    ($SortWrappers.$SnapToInt ($Snap.first (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))))
    ($SortWrappers.$SnapToInt ($Snap.first (MWSF_apply (ite
      (= x0@4@01 x1@5@01)
      mwsf@13@01
      mwsf@12@01) ($Snap.first ($Snap.second $t@6@01)))))))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (and (not (= x0@4@01 x1@5@01)) (not (= x1@5@01 x0@4@01))))
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x0@4@01 y@3@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x1@5@01 y@3@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(check-sat)
; unknown
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x0@4@01 x1@5@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x0@4@01 x1@5@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (=
    ($SortWrappers.$SnapToInt ($Snap.second (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))))
    ($SortWrappers.$SnapToInt ($Snap.second (MWSF_apply (ite
      (= x0@4@01 x1@5@01)
      mwsf@13@01
      mwsf@12@01) ($Snap.first ($Snap.second $t@6@01)))))))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (=
    ($SortWrappers.$SnapToInt ($Snap.second (MWSF_apply (ite
      (= x0@4@01 x1@5@01)
      mwsf@13@01
      mwsf@12@01) ($Snap.first ($Snap.second $t@6@01)))))
    ($SortWrappers.$SnapToInt ($Snap.second (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))))))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (=
    ($SortWrappers.$SnapToInt ($Snap.first (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))))
    ($SortWrappers.$SnapToInt ($Snap.first (MWSF_apply (ite
      (= x0@4@01 x1@5@01)
      mwsf@13@01
      mwsf@12@01) ($Snap.first ($Snap.second $t@6@01)))))))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (=
    ($SortWrappers.$SnapToInt ($Snap.first (MWSF_apply (ite
      (= x0@4@01 x1@5@01)
      mwsf@13@01
      mwsf@12@01) ($Snap.first ($Snap.second $t@6@01)))))
    ($SortWrappers.$SnapToInt ($Snap.first (MWSF_apply mwsf@14@01 ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@6@01))))))))))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (and (not (= x1@5@01 x0@4@01)) (not (= x0@4@01 x1@5@01))))
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x1@5@01 y@3@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= x0@4@01 y@3@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(check-sat)
; unknown
(pop) ; 4
(pop) ; 3
(pop) ; 2
(pop) ; 1
