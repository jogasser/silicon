(get-info :version)
; (:version "4.8.7")
; Started: 2025-12-05 12:16:13
; Silicon.version: 1.1-SNAPSHOT (95328487@(detached))
; Input file: ./functions/binary_tree_algorithms.vpr
; Verifier id: 00
; ------------------------------------------------------------
; Begin preamble
; ////////// Static preamble
; 
; ; /z3config.smt2
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :smt.qi.max_multi_patterns 1000)
; 
; ; /preamble.smt2
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(define-fun $Perm.min ((p1 $Perm) (p2 $Perm)) Real
    (ite (<= p1 p2) p1 p2))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
; ////////// Sorts
(declare-sort Tree 0)
; ////////// Sort wrappers
; Declaring additional sort wrappers
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.TreeTo$Snap (Tree) $Snap)
(declare-fun $SortWrappers.$SnapToTree ($Snap) Tree)
(assert (forall ((x Tree)) (!
    (= x ($SortWrappers.$SnapToTree($SortWrappers.TreeTo$Snap x)))
    :pattern (($SortWrappers.TreeTo$Snap x))
    :qid |$Snap.$SnapToTreeTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.TreeTo$Snap($SortWrappers.$SnapToTree x)))
    :pattern (($SortWrappers.$SnapToTree x))
    :qid |$Snap.TreeTo$SnapToTree|
    )))
; ////////// Symbols
(declare-const Leaf<Tree> Tree)
(declare-fun Node<Tree> (Tree Int Tree) Tree)
(declare-fun get_Tree_left<Tree> (Tree) Tree)
(declare-fun get_Tree_value<Int> (Tree) Int)
(declare-fun get_Tree_right<Tree> (Tree) Tree)
(declare-fun Tree_tag<Int> (Tree) Int)
; Declaring symbols related to program functions (from program analysis)
(declare-fun max_f ($Snap Int Int) Int)
(declare-fun max_f%limited ($Snap Int Int) Int)
(declare-fun max_f%stateless (Int Int) Bool)
(declare-fun max_f%precondition ($Snap Int Int) Bool)
(declare-fun tree_height ($Snap Tree) Int)
(declare-fun tree_height%limited ($Snap Tree) Int)
(declare-fun tree_height%stateless (Tree) Bool)
(declare-fun tree_height%precondition ($Snap Tree) Bool)
(declare-fun abs_ ($Snap Int) Int)
(declare-fun abs%limited ($Snap Int) Int)
(declare-fun abs%stateless (Int) Bool)
(declare-fun abs%precondition ($Snap Int) Bool)
(declare-fun min_f ($Snap Int Int) Int)
(declare-fun min_f%limited ($Snap Int Int) Int)
(declare-fun min_f%stateless (Int Int) Bool)
(declare-fun min_f%precondition ($Snap Int Int) Bool)
(declare-fun is_bst_helper ($Snap Tree Int Int) Bool)
(declare-fun is_bst_helper%limited ($Snap Tree Int Int) Bool)
(declare-fun is_bst_helper%stateless (Tree Int Int) Bool)
(declare-fun is_bst_helper%precondition ($Snap Tree Int Int) Bool)
(declare-fun is_balanced ($Snap Tree) Bool)
(declare-fun is_balanced%limited ($Snap Tree) Bool)
(declare-fun is_balanced%stateless (Tree) Bool)
(declare-fun is_balanced%precondition ($Snap Tree) Bool)
(declare-fun tree_min ($Snap Tree) Int)
(declare-fun tree_min%limited ($Snap Tree) Int)
(declare-fun tree_min%stateless (Tree) Bool)
(declare-fun tree_min%precondition ($Snap Tree) Bool)
(declare-fun count_leaves ($Snap Tree) Int)
(declare-fun count_leaves%limited ($Snap Tree) Int)
(declare-fun count_leaves%stateless (Tree) Bool)
(declare-fun count_leaves%precondition ($Snap Tree) Bool)
(declare-fun tree_contains ($Snap Tree Int) Bool)
(declare-fun tree_contains%limited ($Snap Tree Int) Bool)
(declare-fun tree_contains%stateless (Tree Int) Bool)
(declare-fun tree_contains%precondition ($Snap Tree Int) Bool)
(declare-fun tree_sum ($Snap Tree) Int)
(declare-fun tree_sum%limited ($Snap Tree) Int)
(declare-fun tree_sum%stateless (Tree) Bool)
(declare-fun tree_sum%precondition ($Snap Tree) Bool)
(declare-fun tree_max ($Snap Tree) Int)
(declare-fun tree_max%limited ($Snap Tree) Int)
(declare-fun tree_max%stateless (Tree) Bool)
(declare-fun tree_max%precondition ($Snap Tree) Bool)
(declare-fun tree_size ($Snap Tree) Int)
(declare-fun tree_size%limited ($Snap Tree) Int)
(declare-fun tree_size%stateless (Tree) Bool)
(declare-fun tree_size%precondition ($Snap Tree) Bool)
(declare-fun is_bst ($Snap Tree) Bool)
(declare-fun is_bst%limited ($Snap Tree) Bool)
(declare-fun is_bst%stateless (Tree) Bool)
(declare-fun is_bst%precondition ($Snap Tree) Bool)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
; Declaring predicate trigger functions
; ////////// Uniqueness assumptions from domains
; ////////// Axioms
(assert (forall ((left Tree) (value Int) (right Tree)) (!
  (= left (get_Tree_left<Tree> (Node<Tree> left value right)))
  :pattern ((Node<Tree> left value right))
  )))
(assert (forall ((left Tree) (value Int) (right Tree)) (!
  (= value (get_Tree_value<Int> (Node<Tree> left value right)))
  :pattern ((Node<Tree> left value right))
  )))
(assert (forall ((left Tree) (value Int) (right Tree)) (!
  (= right (get_Tree_right<Tree> (Node<Tree> left value right)))
  :pattern ((Node<Tree> left value right))
  )))
(assert (= (Tree_tag<Int> (as Leaf<Tree>  Tree)) 0))
(assert (forall ((left Tree) (value Int) (right Tree)) (!
  (= (Tree_tag<Int> (Node<Tree> left value right)) 1)
  :pattern ((Node<Tree> left value right))
  )))
(assert (forall ((t Tree)) (!
  (or
    (= t (as Leaf<Tree>  Tree))
    (=
      t
      (Node<Tree> (get_Tree_left<Tree> t) (get_Tree_value<Int> t) (get_Tree_right<Tree> t))))
  :pattern ((Tree_tag<Int> t))
  :pattern ((get_Tree_left<Tree> t))
  :pattern ((get_Tree_value<Int> t))
  :pattern ((get_Tree_right<Tree> t))
  )))
; End preamble
; ------------------------------------------------------------
; State saturation: after preamble
(set-option :rlimit 160000)
(check-sat)
; unknown
; ---------- FUNCTION max_f----------
(declare-fun a@0@00 () Int)
(declare-fun b@1@00 () Int)
(declare-fun result@2@00 () Int)
; ----- Well-definedness of specifications -----
(set-option :rlimit 0)
(push) ; 1
(declare-const $t@31@00 $Snap)
(assert (= $t@31@00 ($Snap.combine ($Snap.first $t@31@00) ($Snap.second $t@31@00))))
(assert (= ($Snap.first $t@31@00) $Snap.unit))
; [eval] result >= a
(assert (>= result@2@00 a@0@00))
(assert (=
  ($Snap.second $t@31@00)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@31@00))
    ($Snap.second ($Snap.second $t@31@00)))))
(assert (= ($Snap.first ($Snap.second $t@31@00)) $Snap.unit))
; [eval] result >= b
(assert (>= result@2@00 b@1@00))
(assert (= ($Snap.second ($Snap.second $t@31@00)) $Snap.unit))
; [eval] result == a || result == b
; [eval] result == a
(push) ; 2
; [then-branch: 0 | result@2@00 == a@0@00 | live]
; [else-branch: 0 | result@2@00 != a@0@00 | live]
(push) ; 3
; [then-branch: 0 | result@2@00 == a@0@00]
(assert (= result@2@00 a@0@00))
(pop) ; 3
(push) ; 3
; [else-branch: 0 | result@2@00 != a@0@00]
(assert (not (= result@2@00 a@0@00)))
; [eval] result == b
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= result@2@00 a@0@00)) (= result@2@00 a@0@00)))
(assert (or (= result@2@00 a@0@00) (= result@2@00 b@1@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (= (max_f%limited s@$ a@0@00 b@1@00) (max_f s@$ a@0@00 b@1@00))
  :pattern ((max_f s@$ a@0@00 b@1@00))
  :qid |quant-u-0|)))
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (max_f%stateless a@0@00 b@1@00)
  :pattern ((max_f%limited s@$ a@0@00 b@1@00))
  :qid |quant-u-1|)))
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (let ((result@2@00 (max_f%limited s@$ a@0@00 b@1@00))) (=>
    (max_f%precondition s@$ a@0@00 b@1@00)
    (and
      (and (>= result@2@00 a@0@00) (>= result@2@00 b@1@00))
      (or (= result@2@00 a@0@00) (= result@2@00 b@1@00)))))
  :pattern ((max_f%limited s@$ a@0@00 b@1@00))
  :qid |quant-u-26|)))
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (let ((result@2@00 (max_f%limited s@$ a@0@00 b@1@00))) true)
  :pattern ((max_f%limited s@$ a@0@00 b@1@00))
  :qid |quant-u-27|)))
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (let ((result@2@00 (max_f%limited s@$ a@0@00 b@1@00))) true)
  :pattern ((max_f%limited s@$ a@0@00 b@1@00))
  :qid |quant-u-28|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (a > b ? a : b)
; [eval] a > b
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (> a@0@00 b@1@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (> a@0@00 b@1@00)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1 | a@0@00 > b@1@00 | live]
; [else-branch: 1 | !(a@0@00 > b@1@00) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 1 | a@0@00 > b@1@00]
(assert (> a@0@00 b@1@00))
(pop) ; 3
(push) ; 3
; [else-branch: 1 | !(a@0@00 > b@1@00)]
(assert (not (> a@0@00 b@1@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (> a@0@00 b@1@00)) (> a@0@00 b@1@00)))
(assert (= result@2@00 (ite (> a@0@00 b@1@00) a@0@00 b@1@00)))
; [eval] result >= a
(push) ; 2
(assert (not (>= result@2@00 a@0@00)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@2@00 a@0@00))
; [eval] result >= b
(push) ; 2
(assert (not (>= result@2@00 b@1@00)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@2@00 b@1@00))
; [eval] result == a || result == b
; [eval] result == a
(push) ; 2
; [then-branch: 2 | result@2@00 == a@0@00 | live]
; [else-branch: 2 | result@2@00 != a@0@00 | live]
(push) ; 3
; [then-branch: 2 | result@2@00 == a@0@00]
(assert (= result@2@00 a@0@00))
(pop) ; 3
(push) ; 3
; [else-branch: 2 | result@2@00 != a@0@00]
(assert (not (= result@2@00 a@0@00)))
; [eval] result == b
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= result@2@00 a@0@00)) (= result@2@00 a@0@00)))
(push) ; 2
(assert (not (or (= result@2@00 a@0@00) (= result@2@00 b@1@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (or (= result@2@00 a@0@00) (= result@2@00 b@1@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (=>
    (max_f%precondition s@$ a@0@00 b@1@00)
    (= (max_f s@$ a@0@00 b@1@00) (ite (> a@0@00 b@1@00) a@0@00 b@1@00)))
  :pattern ((max_f s@$ a@0@00 b@1@00))
  :qid |quant-u-29|)))
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  true
  :pattern ((max_f s@$ a@0@00 b@1@00))
  :qid |quant-u-30|)))
; ---------- FUNCTION tree_height----------
(declare-fun t@3@00 () Tree)
(declare-fun result@4@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@32@00 $Snap)
(assert (= $t@32@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@4@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@3@00 Tree)) (!
  (= (tree_height%limited s@$ t@3@00) (tree_height s@$ t@3@00))
  :pattern ((tree_height s@$ t@3@00))
  :qid |quant-u-2|)))
(assert (forall ((s@$ $Snap) (t@3@00 Tree)) (!
  (tree_height%stateless t@3@00)
  :pattern ((tree_height%limited s@$ t@3@00))
  :qid |quant-u-3|)))
(assert (forall ((s@$ $Snap) (t@3@00 Tree)) (!
  (let ((result@4@00 (tree_height%limited s@$ t@3@00))) (=>
    (tree_height%precondition s@$ t@3@00)
    (>= result@4@00 0)))
  :pattern ((tree_height%limited s@$ t@3@00))
  :qid |quant-u-31|)))
(assert (forall ((s@$ $Snap) (t@3@00 Tree)) (!
  (let ((result@4@00 (tree_height%limited s@$ t@3@00))) true)
  :pattern ((tree_height%limited s@$ t@3@00))
  :qid |quant-u-32|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (Tree_tag(t) == 0 ? 0 : 1 + max_f(tree_height(get_Tree_left(t)), tree_height(get_Tree_right(t))))
; [eval] Tree_tag(t) == 0
; [eval] Tree_tag(t)
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Tree_tag<Int> t@3@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Tree_tag<Int> t@3@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 3 | Tree_tag[Int](t@3@00) == 0 | live]
; [else-branch: 3 | Tree_tag[Int](t@3@00) != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 3 | Tree_tag[Int](t@3@00) == 0]
(assert (= (Tree_tag<Int> t@3@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 3 | Tree_tag[Int](t@3@00) != 0]
(assert (not (= (Tree_tag<Int> t@3@00) 0)))
; [eval] 1 + max_f(tree_height(get_Tree_left(t)), tree_height(get_Tree_right(t)))
; [eval] max_f(tree_height(get_Tree_left(t)), tree_height(get_Tree_right(t)))
; [eval] tree_height(get_Tree_left(t))
; [eval] get_Tree_left(t)
(push) ; 4
(assert (tree_height%precondition $Snap.unit (get_Tree_left<Tree> t@3@00)))
(pop) ; 4
; Joined path conditions
(assert (tree_height%precondition $Snap.unit (get_Tree_left<Tree> t@3@00)))
; [eval] tree_height(get_Tree_right(t))
; [eval] get_Tree_right(t)
(push) ; 4
(assert (tree_height%precondition $Snap.unit (get_Tree_right<Tree> t@3@00)))
(pop) ; 4
; Joined path conditions
(assert (tree_height%precondition $Snap.unit (get_Tree_right<Tree> t@3@00)))
(push) ; 4
(assert (max_f%precondition $Snap.unit (tree_height $Snap.unit (get_Tree_left<Tree> t@3@00)) (tree_height $Snap.unit (get_Tree_right<Tree> t@3@00))))
(pop) ; 4
; Joined path conditions
(assert (max_f%precondition $Snap.unit (tree_height $Snap.unit (get_Tree_left<Tree> t@3@00)) (tree_height $Snap.unit (get_Tree_right<Tree> t@3@00))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Tree_tag<Int> t@3@00) 0))
  (and
    (not (= (Tree_tag<Int> t@3@00) 0))
    (tree_height%precondition $Snap.unit (get_Tree_left<Tree> t@3@00))
    (tree_height%precondition $Snap.unit (get_Tree_right<Tree> t@3@00))
    (max_f%precondition $Snap.unit (tree_height $Snap.unit (get_Tree_left<Tree> t@3@00)) (tree_height $Snap.unit (get_Tree_right<Tree> t@3@00))))))
(assert (or (not (= (Tree_tag<Int> t@3@00) 0)) (= (Tree_tag<Int> t@3@00) 0)))
(assert (=
  result@4@00
  (ite
    (= (Tree_tag<Int> t@3@00) 0)
    0
    (+
      1
      (max_f $Snap.unit (tree_height $Snap.unit (get_Tree_left<Tree> t@3@00)) (tree_height $Snap.unit (get_Tree_right<Tree> t@3@00)))))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@4@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@4@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@3@00 Tree)) (!
  (=>
    (tree_height%precondition s@$ t@3@00)
    (=
      (tree_height s@$ t@3@00)
      (ite
        (= (Tree_tag<Int> t@3@00) 0)
        0
        (+
          1
          (max_f $Snap.unit (tree_height%limited $Snap.unit (get_Tree_left<Tree> t@3@00)) (tree_height%limited $Snap.unit (get_Tree_right<Tree> t@3@00)))))))
  :pattern ((tree_height s@$ t@3@00))
  :qid |quant-u-33|)))
(assert (forall ((s@$ $Snap) (t@3@00 Tree)) (!
  (=>
    (tree_height%precondition s@$ t@3@00)
    (ite
      (= (Tree_tag<Int> t@3@00) 0)
      true
      (and
        (tree_height%precondition $Snap.unit (get_Tree_left<Tree> t@3@00))
        (tree_height%precondition $Snap.unit (get_Tree_right<Tree> t@3@00))
        (max_f%precondition $Snap.unit (tree_height%limited $Snap.unit (get_Tree_left<Tree> t@3@00)) (tree_height%limited $Snap.unit (get_Tree_right<Tree> t@3@00))))))
  :pattern ((tree_height s@$ t@3@00))
  :qid |quant-u-34|)))
; ---------- FUNCTION abs----------
(declare-fun x@5@00 () Int)
(declare-fun result@6@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@33@00 $Snap)
(assert (= $t@33@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@6@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (x@5@00 Int)) (!
  (= (abs%limited s@$ x@5@00) (abs_ s@$ x@5@00))
  :pattern ((abs_ s@$ x@5@00))
  :qid |quant-u-4|)))
(assert (forall ((s@$ $Snap) (x@5@00 Int)) (!
  (abs%stateless x@5@00)
  :pattern ((abs%limited s@$ x@5@00))
  :qid |quant-u-5|)))
(assert (forall ((s@$ $Snap) (x@5@00 Int)) (!
  (let ((result@6@00 (abs%limited s@$ x@5@00))) (=>
    (abs%precondition s@$ x@5@00)
    (>= result@6@00 0)))
  :pattern ((abs%limited s@$ x@5@00))
  :qid |quant-u-35|)))
(assert (forall ((s@$ $Snap) (x@5@00 Int)) (!
  (let ((result@6@00 (abs%limited s@$ x@5@00))) true)
  :pattern ((abs%limited s@$ x@5@00))
  :qid |quant-u-36|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (x >= 0 ? x : -x)
; [eval] x >= 0
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= x@5@00 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= x@5@00 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 4 | x@5@00 >= 0 | live]
; [else-branch: 4 | !(x@5@00 >= 0) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 4 | x@5@00 >= 0]
(assert (>= x@5@00 0))
(pop) ; 3
(push) ; 3
; [else-branch: 4 | !(x@5@00 >= 0)]
(assert (not (>= x@5@00 0)))
; [eval] -x
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (>= x@5@00 0)) (>= x@5@00 0)))
(assert (= result@6@00 (ite (>= x@5@00 0) x@5@00 (- 0 x@5@00))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@6@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@6@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (x@5@00 Int)) (!
  (=>
    (abs%precondition s@$ x@5@00)
    (= (abs_ s@$ x@5@00) (ite (>= x@5@00 0) x@5@00 (- 0 x@5@00))))
  :pattern ((abs_ s@$ x@5@00))
  :qid |quant-u-37|)))
(assert (forall ((s@$ $Snap) (x@5@00 Int)) (!
  true
  :pattern ((abs_ s@$ x@5@00))
  :qid |quant-u-38|)))
; ---------- FUNCTION min_f----------
(declare-fun a@7@00 () Int)
(declare-fun b@8@00 () Int)
(declare-fun result@9@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@34@00 $Snap)
(assert (= $t@34@00 ($Snap.combine ($Snap.first $t@34@00) ($Snap.second $t@34@00))))
(assert (= ($Snap.first $t@34@00) $Snap.unit))
; [eval] result <= a
(assert (<= result@9@00 a@7@00))
(assert (=
  ($Snap.second $t@34@00)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@34@00))
    ($Snap.second ($Snap.second $t@34@00)))))
(assert (= ($Snap.first ($Snap.second $t@34@00)) $Snap.unit))
; [eval] result <= b
(assert (<= result@9@00 b@8@00))
(assert (= ($Snap.second ($Snap.second $t@34@00)) $Snap.unit))
; [eval] result == a || result == b
; [eval] result == a
(push) ; 2
; [then-branch: 5 | result@9@00 == a@7@00 | live]
; [else-branch: 5 | result@9@00 != a@7@00 | live]
(push) ; 3
; [then-branch: 5 | result@9@00 == a@7@00]
(assert (= result@9@00 a@7@00))
(pop) ; 3
(push) ; 3
; [else-branch: 5 | result@9@00 != a@7@00]
(assert (not (= result@9@00 a@7@00)))
; [eval] result == b
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= result@9@00 a@7@00)) (= result@9@00 a@7@00)))
(assert (or (= result@9@00 a@7@00) (= result@9@00 b@8@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (a@7@00 Int) (b@8@00 Int)) (!
  (= (min_f%limited s@$ a@7@00 b@8@00) (min_f s@$ a@7@00 b@8@00))
  :pattern ((min_f s@$ a@7@00 b@8@00))
  :qid |quant-u-6|)))
(assert (forall ((s@$ $Snap) (a@7@00 Int) (b@8@00 Int)) (!
  (min_f%stateless a@7@00 b@8@00)
  :pattern ((min_f%limited s@$ a@7@00 b@8@00))
  :qid |quant-u-7|)))
(assert (forall ((s@$ $Snap) (a@7@00 Int) (b@8@00 Int)) (!
  (let ((result@9@00 (min_f%limited s@$ a@7@00 b@8@00))) (=>
    (min_f%precondition s@$ a@7@00 b@8@00)
    (and
      (and (<= result@9@00 a@7@00) (<= result@9@00 b@8@00))
      (or (= result@9@00 a@7@00) (= result@9@00 b@8@00)))))
  :pattern ((min_f%limited s@$ a@7@00 b@8@00))
  :qid |quant-u-39|)))
(assert (forall ((s@$ $Snap) (a@7@00 Int) (b@8@00 Int)) (!
  (let ((result@9@00 (min_f%limited s@$ a@7@00 b@8@00))) true)
  :pattern ((min_f%limited s@$ a@7@00 b@8@00))
  :qid |quant-u-40|)))
(assert (forall ((s@$ $Snap) (a@7@00 Int) (b@8@00 Int)) (!
  (let ((result@9@00 (min_f%limited s@$ a@7@00 b@8@00))) true)
  :pattern ((min_f%limited s@$ a@7@00 b@8@00))
  :qid |quant-u-41|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (a < b ? a : b)
; [eval] a < b
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (< a@7@00 b@8@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (< a@7@00 b@8@00)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 6 | a@7@00 < b@8@00 | live]
; [else-branch: 6 | !(a@7@00 < b@8@00) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 6 | a@7@00 < b@8@00]
(assert (< a@7@00 b@8@00))
(pop) ; 3
(push) ; 3
; [else-branch: 6 | !(a@7@00 < b@8@00)]
(assert (not (< a@7@00 b@8@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (< a@7@00 b@8@00)) (< a@7@00 b@8@00)))
(assert (= result@9@00 (ite (< a@7@00 b@8@00) a@7@00 b@8@00)))
; [eval] result <= a
(push) ; 2
(assert (not (<= result@9@00 a@7@00)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (<= result@9@00 a@7@00))
; [eval] result <= b
(push) ; 2
(assert (not (<= result@9@00 b@8@00)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (<= result@9@00 b@8@00))
; [eval] result == a || result == b
; [eval] result == a
(push) ; 2
; [then-branch: 7 | result@9@00 == a@7@00 | live]
; [else-branch: 7 | result@9@00 != a@7@00 | live]
(push) ; 3
; [then-branch: 7 | result@9@00 == a@7@00]
(assert (= result@9@00 a@7@00))
(pop) ; 3
(push) ; 3
; [else-branch: 7 | result@9@00 != a@7@00]
(assert (not (= result@9@00 a@7@00)))
; [eval] result == b
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= result@9@00 a@7@00)) (= result@9@00 a@7@00)))
(push) ; 2
(assert (not (or (= result@9@00 a@7@00) (= result@9@00 b@8@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (or (= result@9@00 a@7@00) (= result@9@00 b@8@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (a@7@00 Int) (b@8@00 Int)) (!
  (=>
    (min_f%precondition s@$ a@7@00 b@8@00)
    (= (min_f s@$ a@7@00 b@8@00) (ite (< a@7@00 b@8@00) a@7@00 b@8@00)))
  :pattern ((min_f s@$ a@7@00 b@8@00))
  :qid |quant-u-42|)))
(assert (forall ((s@$ $Snap) (a@7@00 Int) (b@8@00 Int)) (!
  true
  :pattern ((min_f s@$ a@7@00 b@8@00))
  :qid |quant-u-43|)))
; ---------- FUNCTION is_bst_helper----------
(declare-fun t@10@00 () Tree)
(declare-fun min@11@00 () Int)
(declare-fun max@12@00 () Int)
(declare-fun result@13@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@10@00 Tree) (min@11@00 Int) (max@12@00 Int)) (!
  (=
    (is_bst_helper%limited s@$ t@10@00 min@11@00 max@12@00)
    (is_bst_helper s@$ t@10@00 min@11@00 max@12@00))
  :pattern ((is_bst_helper s@$ t@10@00 min@11@00 max@12@00))
  :qid |quant-u-8|)))
(assert (forall ((s@$ $Snap) (t@10@00 Tree) (min@11@00 Int) (max@12@00 Int)) (!
  (is_bst_helper%stateless t@10@00 min@11@00 max@12@00)
  :pattern ((is_bst_helper%limited s@$ t@10@00 min@11@00 max@12@00))
  :qid |quant-u-9|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (Tree_tag(t) == 0 ? true : get_Tree_value(t) > min && (get_Tree_value(t) < max && (is_bst_helper(get_Tree_left(t), min, get_Tree_value(t)) && is_bst_helper(get_Tree_right(t), get_Tree_value(t), max))))
; [eval] Tree_tag(t) == 0
; [eval] Tree_tag(t)
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Tree_tag<Int> t@10@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Tree_tag<Int> t@10@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 8 | Tree_tag[Int](t@10@00) == 0 | live]
; [else-branch: 8 | Tree_tag[Int](t@10@00) != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 8 | Tree_tag[Int](t@10@00) == 0]
(assert (= (Tree_tag<Int> t@10@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 8 | Tree_tag[Int](t@10@00) != 0]
(assert (not (= (Tree_tag<Int> t@10@00) 0)))
; [eval] get_Tree_value(t) > min && (get_Tree_value(t) < max && (is_bst_helper(get_Tree_left(t), min, get_Tree_value(t)) && is_bst_helper(get_Tree_right(t), get_Tree_value(t), max)))
; [eval] get_Tree_value(t) > min
; [eval] get_Tree_value(t)
(push) ; 4
; [then-branch: 9 | !(get_Tree_value[Int](t@10@00) > min@11@00) | live]
; [else-branch: 9 | get_Tree_value[Int](t@10@00) > min@11@00 | live]
(push) ; 5
; [then-branch: 9 | !(get_Tree_value[Int](t@10@00) > min@11@00)]
(assert (not (> (get_Tree_value<Int> t@10@00) min@11@00)))
(pop) ; 5
(push) ; 5
; [else-branch: 9 | get_Tree_value[Int](t@10@00) > min@11@00]
(assert (> (get_Tree_value<Int> t@10@00) min@11@00))
; [eval] get_Tree_value(t) < max
; [eval] get_Tree_value(t)
(push) ; 6
; [then-branch: 10 | !(get_Tree_value[Int](t@10@00) < max@12@00) | live]
; [else-branch: 10 | get_Tree_value[Int](t@10@00) < max@12@00 | live]
(push) ; 7
; [then-branch: 10 | !(get_Tree_value[Int](t@10@00) < max@12@00)]
(assert (not (< (get_Tree_value<Int> t@10@00) max@12@00)))
(pop) ; 7
(push) ; 7
; [else-branch: 10 | get_Tree_value[Int](t@10@00) < max@12@00]
(assert (< (get_Tree_value<Int> t@10@00) max@12@00))
; [eval] is_bst_helper(get_Tree_left(t), min, get_Tree_value(t))
; [eval] get_Tree_left(t)
; [eval] get_Tree_value(t)
(push) ; 8
(assert (is_bst_helper%precondition $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00)))
(pop) ; 8
; Joined path conditions
(assert (is_bst_helper%precondition $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00)))
(push) ; 8
; [then-branch: 11 | !(is_bst_helper(_, get_Tree_left[Tree](t@10@00), min@11@00, get_Tree_value[Int](t@10@00))) | live]
; [else-branch: 11 | is_bst_helper(_, get_Tree_left[Tree](t@10@00), min@11@00, get_Tree_value[Int](t@10@00)) | live]
(push) ; 9
; [then-branch: 11 | !(is_bst_helper(_, get_Tree_left[Tree](t@10@00), min@11@00, get_Tree_value[Int](t@10@00)))]
(assert (not
  (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))))
(pop) ; 9
(push) ; 9
; [else-branch: 11 | is_bst_helper(_, get_Tree_left[Tree](t@10@00), min@11@00, get_Tree_value[Int](t@10@00))]
(assert (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00)))
; [eval] is_bst_helper(get_Tree_right(t), get_Tree_value(t), max)
; [eval] get_Tree_right(t)
; [eval] get_Tree_value(t)
(push) ; 10
(assert (is_bst_helper%precondition $Snap.unit (get_Tree_right<Tree> t@10@00) (get_Tree_value<Int> t@10@00) max@12@00))
(pop) ; 10
; Joined path conditions
(assert (is_bst_helper%precondition $Snap.unit (get_Tree_right<Tree> t@10@00) (get_Tree_value<Int> t@10@00) max@12@00))
(pop) ; 9
(pop) ; 8
; Joined path conditions
; Joined path conditions
(assert (=>
  (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
  (and
    (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
    (is_bst_helper%precondition $Snap.unit (get_Tree_right<Tree> t@10@00) (get_Tree_value<Int> t@10@00) max@12@00))))
(assert (or
  (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
  (not
    (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00)))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=>
  (< (get_Tree_value<Int> t@10@00) max@12@00)
  (and
    (< (get_Tree_value<Int> t@10@00) max@12@00)
    (is_bst_helper%precondition $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
    (=>
      (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
      (and
        (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
        (is_bst_helper%precondition $Snap.unit (get_Tree_right<Tree> t@10@00) (get_Tree_value<Int> t@10@00) max@12@00)))
    (or
      (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
      (not
        (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00)))))))
(assert (or
  (< (get_Tree_value<Int> t@10@00) max@12@00)
  (not (< (get_Tree_value<Int> t@10@00) max@12@00))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (> (get_Tree_value<Int> t@10@00) min@11@00)
  (and
    (> (get_Tree_value<Int> t@10@00) min@11@00)
    (=>
      (< (get_Tree_value<Int> t@10@00) max@12@00)
      (and
        (< (get_Tree_value<Int> t@10@00) max@12@00)
        (is_bst_helper%precondition $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
        (=>
          (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
          (and
            (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
            (is_bst_helper%precondition $Snap.unit (get_Tree_right<Tree> t@10@00) (get_Tree_value<Int> t@10@00) max@12@00)))
        (or
          (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
          (not
            (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))))))
    (or
      (< (get_Tree_value<Int> t@10@00) max@12@00)
      (not (< (get_Tree_value<Int> t@10@00) max@12@00))))))
(assert (or
  (> (get_Tree_value<Int> t@10@00) min@11@00)
  (not (> (get_Tree_value<Int> t@10@00) min@11@00))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Tree_tag<Int> t@10@00) 0))
  (and
    (not (= (Tree_tag<Int> t@10@00) 0))
    (=>
      (> (get_Tree_value<Int> t@10@00) min@11@00)
      (and
        (> (get_Tree_value<Int> t@10@00) min@11@00)
        (=>
          (< (get_Tree_value<Int> t@10@00) max@12@00)
          (and
            (< (get_Tree_value<Int> t@10@00) max@12@00)
            (is_bst_helper%precondition $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
            (=>
              (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
              (and
                (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
                (is_bst_helper%precondition $Snap.unit (get_Tree_right<Tree> t@10@00) (get_Tree_value<Int> t@10@00) max@12@00)))
            (or
              (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
              (not
                (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))))))
        (or
          (< (get_Tree_value<Int> t@10@00) max@12@00)
          (not (< (get_Tree_value<Int> t@10@00) max@12@00)))))
    (or
      (> (get_Tree_value<Int> t@10@00) min@11@00)
      (not (> (get_Tree_value<Int> t@10@00) min@11@00))))))
(assert (or (not (= (Tree_tag<Int> t@10@00) 0)) (= (Tree_tag<Int> t@10@00) 0)))
(assert (=
  result@13@00
  (ite
    (= (Tree_tag<Int> t@10@00) 0)
    true
    (and
      (> (get_Tree_value<Int> t@10@00) min@11@00)
      (and
        (< (get_Tree_value<Int> t@10@00) max@12@00)
        (and
          (is_bst_helper $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
          (is_bst_helper $Snap.unit (get_Tree_right<Tree> t@10@00) (get_Tree_value<Int> t@10@00) max@12@00)))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@10@00 Tree) (min@11@00 Int) (max@12@00 Int)) (!
  (=>
    (is_bst_helper%precondition s@$ t@10@00 min@11@00 max@12@00)
    (=
      (is_bst_helper s@$ t@10@00 min@11@00 max@12@00)
      (ite
        (= (Tree_tag<Int> t@10@00) 0)
        true
        (and
          (> (get_Tree_value<Int> t@10@00) min@11@00)
          (and
            (< (get_Tree_value<Int> t@10@00) max@12@00)
            (and
              (is_bst_helper%limited $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
              (is_bst_helper%limited $Snap.unit (get_Tree_right<Tree> t@10@00) (get_Tree_value<Int> t@10@00) max@12@00)))))))
  :pattern ((is_bst_helper s@$ t@10@00 min@11@00 max@12@00))
  :qid |quant-u-44|)))
(assert (forall ((s@$ $Snap) (t@10@00 Tree) (min@11@00 Int) (max@12@00 Int)) (!
  (=>
    (is_bst_helper%precondition s@$ t@10@00 min@11@00 max@12@00)
    (ite
      (= (Tree_tag<Int> t@10@00) 0)
      true
      (=>
        (and
          (> (get_Tree_value<Int> t@10@00) min@11@00)
          (< (get_Tree_value<Int> t@10@00) max@12@00))
        (and
          (is_bst_helper%precondition $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
          (=>
            (is_bst_helper%limited $Snap.unit (get_Tree_left<Tree> t@10@00) min@11@00 (get_Tree_value<Int> t@10@00))
            (is_bst_helper%precondition $Snap.unit (get_Tree_right<Tree> t@10@00) (get_Tree_value<Int> t@10@00) max@12@00))))))
  :pattern ((is_bst_helper s@$ t@10@00 min@11@00 max@12@00))
  :qid |quant-u-45|)))
; ---------- FUNCTION is_balanced----------
(declare-fun t@14@00 () Tree)
(declare-fun result@15@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@14@00 Tree)) (!
  (= (is_balanced%limited s@$ t@14@00) (is_balanced s@$ t@14@00))
  :pattern ((is_balanced s@$ t@14@00))
  :qid |quant-u-10|)))
(assert (forall ((s@$ $Snap) (t@14@00 Tree)) (!
  (is_balanced%stateless t@14@00)
  :pattern ((is_balanced%limited s@$ t@14@00))
  :qid |quant-u-11|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (Tree_tag(t) == 0 ? true : is_balanced(get_Tree_left(t)) && (is_balanced(get_Tree_right(t)) && abs(tree_height(get_Tree_left(t)) - tree_height(get_Tree_right(t))) <= 1))
; [eval] Tree_tag(t) == 0
; [eval] Tree_tag(t)
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Tree_tag<Int> t@14@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Tree_tag<Int> t@14@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 12 | Tree_tag[Int](t@14@00) == 0 | live]
; [else-branch: 12 | Tree_tag[Int](t@14@00) != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 12 | Tree_tag[Int](t@14@00) == 0]
(assert (= (Tree_tag<Int> t@14@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 12 | Tree_tag[Int](t@14@00) != 0]
(assert (not (= (Tree_tag<Int> t@14@00) 0)))
; [eval] is_balanced(get_Tree_left(t)) && (is_balanced(get_Tree_right(t)) && abs(tree_height(get_Tree_left(t)) - tree_height(get_Tree_right(t))) <= 1)
; [eval] is_balanced(get_Tree_left(t))
; [eval] get_Tree_left(t)
(push) ; 4
(assert (is_balanced%precondition $Snap.unit (get_Tree_left<Tree> t@14@00)))
(pop) ; 4
; Joined path conditions
(assert (is_balanced%precondition $Snap.unit (get_Tree_left<Tree> t@14@00)))
(push) ; 4
; [then-branch: 13 | !(is_balanced(_, get_Tree_left[Tree](t@14@00))) | live]
; [else-branch: 13 | is_balanced(_, get_Tree_left[Tree](t@14@00)) | live]
(push) ; 5
; [then-branch: 13 | !(is_balanced(_, get_Tree_left[Tree](t@14@00)))]
(assert (not (is_balanced $Snap.unit (get_Tree_left<Tree> t@14@00))))
(pop) ; 5
(push) ; 5
; [else-branch: 13 | is_balanced(_, get_Tree_left[Tree](t@14@00))]
(assert (is_balanced $Snap.unit (get_Tree_left<Tree> t@14@00)))
; [eval] is_balanced(get_Tree_right(t))
; [eval] get_Tree_right(t)
(push) ; 6
(assert (is_balanced%precondition $Snap.unit (get_Tree_right<Tree> t@14@00)))
(pop) ; 6
; Joined path conditions
(assert (is_balanced%precondition $Snap.unit (get_Tree_right<Tree> t@14@00)))
(push) ; 6
; [then-branch: 14 | !(is_balanced(_, get_Tree_right[Tree](t@14@00))) | live]
; [else-branch: 14 | is_balanced(_, get_Tree_right[Tree](t@14@00)) | live]
(push) ; 7
; [then-branch: 14 | !(is_balanced(_, get_Tree_right[Tree](t@14@00)))]
(assert (not (is_balanced $Snap.unit (get_Tree_right<Tree> t@14@00))))
(pop) ; 7
(push) ; 7
; [else-branch: 14 | is_balanced(_, get_Tree_right[Tree](t@14@00))]
(assert (is_balanced $Snap.unit (get_Tree_right<Tree> t@14@00)))
; [eval] abs(tree_height(get_Tree_left(t)) - tree_height(get_Tree_right(t))) <= 1
; [eval] abs(tree_height(get_Tree_left(t)) - tree_height(get_Tree_right(t)))
; [eval] tree_height(get_Tree_left(t)) - tree_height(get_Tree_right(t))
; [eval] tree_height(get_Tree_left(t))
; [eval] get_Tree_left(t)
(push) ; 8
(assert (tree_height%precondition $Snap.unit (get_Tree_left<Tree> t@14@00)))
(pop) ; 8
; Joined path conditions
(assert (tree_height%precondition $Snap.unit (get_Tree_left<Tree> t@14@00)))
; [eval] tree_height(get_Tree_right(t))
; [eval] get_Tree_right(t)
(push) ; 8
(assert (tree_height%precondition $Snap.unit (get_Tree_right<Tree> t@14@00)))
(pop) ; 8
; Joined path conditions
(assert (tree_height%precondition $Snap.unit (get_Tree_right<Tree> t@14@00)))
(push) ; 8
(assert (abs%precondition $Snap.unit (-
  (tree_height $Snap.unit (get_Tree_left<Tree> t@14@00))
  (tree_height $Snap.unit (get_Tree_right<Tree> t@14@00)))))
(pop) ; 8
; Joined path conditions
(assert (abs%precondition $Snap.unit (-
  (tree_height $Snap.unit (get_Tree_left<Tree> t@14@00))
  (tree_height $Snap.unit (get_Tree_right<Tree> t@14@00)))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=>
  (is_balanced $Snap.unit (get_Tree_right<Tree> t@14@00))
  (and
    (is_balanced $Snap.unit (get_Tree_right<Tree> t@14@00))
    (tree_height%precondition $Snap.unit (get_Tree_left<Tree> t@14@00))
    (tree_height%precondition $Snap.unit (get_Tree_right<Tree> t@14@00))
    (abs%precondition $Snap.unit (-
      (tree_height $Snap.unit (get_Tree_left<Tree> t@14@00))
      (tree_height $Snap.unit (get_Tree_right<Tree> t@14@00)))))))
(assert (or
  (is_balanced $Snap.unit (get_Tree_right<Tree> t@14@00))
  (not (is_balanced $Snap.unit (get_Tree_right<Tree> t@14@00)))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (is_balanced $Snap.unit (get_Tree_left<Tree> t@14@00))
  (and
    (is_balanced $Snap.unit (get_Tree_left<Tree> t@14@00))
    (is_balanced%precondition $Snap.unit (get_Tree_right<Tree> t@14@00))
    (=>
      (is_balanced $Snap.unit (get_Tree_right<Tree> t@14@00))
      (and
        (is_balanced $Snap.unit (get_Tree_right<Tree> t@14@00))
        (tree_height%precondition $Snap.unit (get_Tree_left<Tree> t@14@00))
        (tree_height%precondition $Snap.unit (get_Tree_right<Tree> t@14@00))
        (abs%precondition $Snap.unit (-
          (tree_height $Snap.unit (get_Tree_left<Tree> t@14@00))
          (tree_height $Snap.unit (get_Tree_right<Tree> t@14@00))))))
    (or
      (is_balanced $Snap.unit (get_Tree_right<Tree> t@14@00))
      (not (is_balanced $Snap.unit (get_Tree_right<Tree> t@14@00)))))))
(assert (or
  (is_balanced $Snap.unit (get_Tree_left<Tree> t@14@00))
  (not (is_balanced $Snap.unit (get_Tree_left<Tree> t@14@00)))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Tree_tag<Int> t@14@00) 0))
  (and
    (not (= (Tree_tag<Int> t@14@00) 0))
    (is_balanced%precondition $Snap.unit (get_Tree_left<Tree> t@14@00))
    (=>
      (is_balanced $Snap.unit (get_Tree_left<Tree> t@14@00))
      (and
        (is_balanced $Snap.unit (get_Tree_left<Tree> t@14@00))
        (is_balanced%precondition $Snap.unit (get_Tree_right<Tree> t@14@00))
        (=>
          (is_balanced $Snap.unit (get_Tree_right<Tree> t@14@00))
          (and
            (is_balanced $Snap.unit (get_Tree_right<Tree> t@14@00))
            (tree_height%precondition $Snap.unit (get_Tree_left<Tree> t@14@00))
            (tree_height%precondition $Snap.unit (get_Tree_right<Tree> t@14@00))
            (abs%precondition $Snap.unit (-
              (tree_height $Snap.unit (get_Tree_left<Tree> t@14@00))
              (tree_height $Snap.unit (get_Tree_right<Tree> t@14@00))))))
        (or
          (is_balanced $Snap.unit (get_Tree_right<Tree> t@14@00))
          (not (is_balanced $Snap.unit (get_Tree_right<Tree> t@14@00))))))
    (or
      (is_balanced $Snap.unit (get_Tree_left<Tree> t@14@00))
      (not (is_balanced $Snap.unit (get_Tree_left<Tree> t@14@00)))))))
(assert (or (not (= (Tree_tag<Int> t@14@00) 0)) (= (Tree_tag<Int> t@14@00) 0)))
(assert (=
  result@15@00
  (ite
    (= (Tree_tag<Int> t@14@00) 0)
    true
    (and
      (is_balanced $Snap.unit (get_Tree_left<Tree> t@14@00))
      (and
        (is_balanced $Snap.unit (get_Tree_right<Tree> t@14@00))
        (<=
          (abs_ $Snap.unit (-
            (tree_height $Snap.unit (get_Tree_left<Tree> t@14@00))
            (tree_height $Snap.unit (get_Tree_right<Tree> t@14@00))))
          1))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@14@00 Tree)) (!
  (=>
    (is_balanced%precondition s@$ t@14@00)
    (=
      (is_balanced s@$ t@14@00)
      (ite
        (= (Tree_tag<Int> t@14@00) 0)
        true
        (and
          (is_balanced%limited $Snap.unit (get_Tree_left<Tree> t@14@00))
          (and
            (is_balanced%limited $Snap.unit (get_Tree_right<Tree> t@14@00))
            (<=
              (abs_ $Snap.unit (-
                (tree_height $Snap.unit (get_Tree_left<Tree> t@14@00))
                (tree_height $Snap.unit (get_Tree_right<Tree> t@14@00))))
              1))))))
  :pattern ((is_balanced s@$ t@14@00))
  :qid |quant-u-46|)))
(assert (forall ((s@$ $Snap) (t@14@00 Tree)) (!
  (=>
    (is_balanced%precondition s@$ t@14@00)
    (ite
      (= (Tree_tag<Int> t@14@00) 0)
      true
      (and
        (is_balanced%precondition $Snap.unit (get_Tree_left<Tree> t@14@00))
        (=>
          (is_balanced%limited $Snap.unit (get_Tree_left<Tree> t@14@00))
          (and
            (is_balanced%precondition $Snap.unit (get_Tree_right<Tree> t@14@00))
            (=>
              (is_balanced%limited $Snap.unit (get_Tree_right<Tree> t@14@00))
              (and
                (and
                  (tree_height%precondition $Snap.unit (get_Tree_left<Tree> t@14@00))
                  (tree_height%precondition $Snap.unit (get_Tree_right<Tree> t@14@00)))
                (abs%precondition $Snap.unit (-
                  (tree_height $Snap.unit (get_Tree_left<Tree> t@14@00))
                  (tree_height $Snap.unit (get_Tree_right<Tree> t@14@00)))))))))))
  :pattern ((is_balanced s@$ t@14@00))
  :qid |quant-u-47|)))
; ---------- FUNCTION tree_min----------
(declare-fun t@16@00 () Tree)
(declare-fun result@17@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] Tree_tag(t) == 1
; [eval] Tree_tag(t)
(assert (= (Tree_tag<Int> t@16@00) 1))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@16@00 Tree)) (!
  (= (tree_min%limited s@$ t@16@00) (tree_min s@$ t@16@00))
  :pattern ((tree_min s@$ t@16@00))
  :qid |quant-u-12|)))
(assert (forall ((s@$ $Snap) (t@16@00 Tree)) (!
  (tree_min%stateless t@16@00)
  :pattern ((tree_min%limited s@$ t@16@00))
  :qid |quant-u-13|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (= (Tree_tag<Int> t@16@00) 1))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (Tree_tag(t) == 1 ? (Tree_tag(get_Tree_left(t)) == 0 && Tree_tag(get_Tree_right(t)) == 0 ? get_Tree_value(t) : (Tree_tag(get_Tree_left(t)) == 0 ? min_f(get_Tree_value(t), tree_min(get_Tree_right(t))) : (Tree_tag(get_Tree_right(t)) == 0 ? min_f(get_Tree_value(t), tree_min(get_Tree_left(t))) : min_f(get_Tree_value(t), min_f(tree_min(get_Tree_left(t)), tree_min(get_Tree_right(t))))))) : 0)
; [eval] Tree_tag(t) == 1
; [eval] Tree_tag(t)
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Tree_tag<Int> t@16@00) 1))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 15 | Tree_tag[Int](t@16@00) == 1 | live]
; [else-branch: 15 | Tree_tag[Int](t@16@00) != 1 | dead]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 15 | Tree_tag[Int](t@16@00) == 1]
; [eval] (Tree_tag(get_Tree_left(t)) == 0 && Tree_tag(get_Tree_right(t)) == 0 ? get_Tree_value(t) : (Tree_tag(get_Tree_left(t)) == 0 ? min_f(get_Tree_value(t), tree_min(get_Tree_right(t))) : (Tree_tag(get_Tree_right(t)) == 0 ? min_f(get_Tree_value(t), tree_min(get_Tree_left(t))) : min_f(get_Tree_value(t), min_f(tree_min(get_Tree_left(t)), tree_min(get_Tree_right(t)))))))
; [eval] Tree_tag(get_Tree_left(t)) == 0 && Tree_tag(get_Tree_right(t)) == 0
; [eval] Tree_tag(get_Tree_left(t)) == 0
; [eval] Tree_tag(get_Tree_left(t))
; [eval] get_Tree_left(t)
(push) ; 4
; [then-branch: 16 | Tree_tag[Int](get_Tree_left[Tree](t@16@00)) != 0 | live]
; [else-branch: 16 | Tree_tag[Int](get_Tree_left[Tree](t@16@00)) == 0 | live]
(push) ; 5
; [then-branch: 16 | Tree_tag[Int](get_Tree_left[Tree](t@16@00)) != 0]
(assert (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)))
(pop) ; 5
(push) ; 5
; [else-branch: 16 | Tree_tag[Int](get_Tree_left[Tree](t@16@00)) == 0]
(assert (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0))
; [eval] Tree_tag(get_Tree_right(t)) == 0
; [eval] Tree_tag(get_Tree_right(t))
; [eval] get_Tree_right(t)
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or
  (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
  (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0))))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (and
    (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
    (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (and
  (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
  (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 17 | Tree_tag[Int](get_Tree_left[Tree](t@16@00)) == 0 && Tree_tag[Int](get_Tree_right[Tree](t@16@00)) == 0 | live]
; [else-branch: 17 | !(Tree_tag[Int](get_Tree_left[Tree](t@16@00)) == 0 && Tree_tag[Int](get_Tree_right[Tree](t@16@00)) == 0) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 17 | Tree_tag[Int](get_Tree_left[Tree](t@16@00)) == 0 && Tree_tag[Int](get_Tree_right[Tree](t@16@00)) == 0]
(assert (and
  (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
  (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)))
; [eval] get_Tree_value(t)
(pop) ; 5
(push) ; 5
; [else-branch: 17 | !(Tree_tag[Int](get_Tree_left[Tree](t@16@00)) == 0 && Tree_tag[Int](get_Tree_right[Tree](t@16@00)) == 0)]
(assert (not
  (and
    (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
    (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))))
; [eval] (Tree_tag(get_Tree_left(t)) == 0 ? min_f(get_Tree_value(t), tree_min(get_Tree_right(t))) : (Tree_tag(get_Tree_right(t)) == 0 ? min_f(get_Tree_value(t), tree_min(get_Tree_left(t))) : min_f(get_Tree_value(t), min_f(tree_min(get_Tree_left(t)), tree_min(get_Tree_right(t))))))
; [eval] Tree_tag(get_Tree_left(t)) == 0
; [eval] Tree_tag(get_Tree_left(t))
; [eval] get_Tree_left(t)
(push) ; 6
(push) ; 7
(set-option :rlimit 16000)
(assert (not (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 16000)
(assert (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 18 | Tree_tag[Int](get_Tree_left[Tree](t@16@00)) == 0 | live]
; [else-branch: 18 | Tree_tag[Int](get_Tree_left[Tree](t@16@00)) != 0 | live]
(set-option :rlimit 0)
(push) ; 7
; [then-branch: 18 | Tree_tag[Int](get_Tree_left[Tree](t@16@00)) == 0]
(assert (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0))
; [eval] min_f(get_Tree_value(t), tree_min(get_Tree_right(t)))
; [eval] get_Tree_value(t)
; [eval] tree_min(get_Tree_right(t))
; [eval] get_Tree_right(t)
(push) ; 8
; [eval] Tree_tag(t) == 1
; [eval] Tree_tag(t)
(push) ; 9
(assert (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 1)))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(assert (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 1))
(assert (tree_min%precondition $Snap.unit (get_Tree_right<Tree> t@16@00)))
(pop) ; 8
; Joined path conditions
(assert (and
  (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 1)
  (tree_min%precondition $Snap.unit (get_Tree_right<Tree> t@16@00))))
(push) ; 8
(assert (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00))))
(pop) ; 8
; Joined path conditions
(assert (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00))))
(pop) ; 7
(push) ; 7
; [else-branch: 18 | Tree_tag[Int](get_Tree_left[Tree](t@16@00)) != 0]
(assert (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)))
; [eval] (Tree_tag(get_Tree_right(t)) == 0 ? min_f(get_Tree_value(t), tree_min(get_Tree_left(t))) : min_f(get_Tree_value(t), min_f(tree_min(get_Tree_left(t)), tree_min(get_Tree_right(t)))))
; [eval] Tree_tag(get_Tree_right(t)) == 0
; [eval] Tree_tag(get_Tree_right(t))
; [eval] get_Tree_right(t)
(push) ; 8
(push) ; 9
(set-option :rlimit 16000)
(assert (not (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))))
(check-sat)
; unknown
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 16000)
(assert (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)))
(check-sat)
; unknown
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
; [then-branch: 19 | Tree_tag[Int](get_Tree_right[Tree](t@16@00)) == 0 | live]
; [else-branch: 19 | Tree_tag[Int](get_Tree_right[Tree](t@16@00)) != 0 | live]
(set-option :rlimit 0)
(push) ; 9
; [then-branch: 19 | Tree_tag[Int](get_Tree_right[Tree](t@16@00)) == 0]
(assert (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))
; [eval] min_f(get_Tree_value(t), tree_min(get_Tree_left(t)))
; [eval] get_Tree_value(t)
; [eval] tree_min(get_Tree_left(t))
; [eval] get_Tree_left(t)
(push) ; 10
; [eval] Tree_tag(t) == 1
; [eval] Tree_tag(t)
(push) ; 11
(assert (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 1)))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
(assert (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 1))
(assert (tree_min%precondition $Snap.unit (get_Tree_left<Tree> t@16@00)))
(pop) ; 10
; Joined path conditions
(assert (and
  (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 1)
  (tree_min%precondition $Snap.unit (get_Tree_left<Tree> t@16@00))))
(push) ; 10
(assert (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00))))
(pop) ; 10
; Joined path conditions
(assert (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00))))
(pop) ; 9
(push) ; 9
; [else-branch: 19 | Tree_tag[Int](get_Tree_right[Tree](t@16@00)) != 0]
(assert (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)))
; [eval] min_f(get_Tree_value(t), min_f(tree_min(get_Tree_left(t)), tree_min(get_Tree_right(t))))
; [eval] get_Tree_value(t)
; [eval] min_f(tree_min(get_Tree_left(t)), tree_min(get_Tree_right(t)))
; [eval] tree_min(get_Tree_left(t))
; [eval] get_Tree_left(t)
(push) ; 10
; [eval] Tree_tag(t) == 1
; [eval] Tree_tag(t)
(push) ; 11
(assert (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 1)))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
(assert (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 1))
(assert (tree_min%precondition $Snap.unit (get_Tree_left<Tree> t@16@00)))
(pop) ; 10
; Joined path conditions
(assert (and
  (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 1)
  (tree_min%precondition $Snap.unit (get_Tree_left<Tree> t@16@00))))
; [eval] tree_min(get_Tree_right(t))
; [eval] get_Tree_right(t)
(push) ; 10
; [eval] Tree_tag(t) == 1
; [eval] Tree_tag(t)
(push) ; 11
(assert (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 1)))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
(assert (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 1))
(assert (tree_min%precondition $Snap.unit (get_Tree_right<Tree> t@16@00)))
(pop) ; 10
; Joined path conditions
(assert (and
  (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 1)
  (tree_min%precondition $Snap.unit (get_Tree_right<Tree> t@16@00))))
(push) ; 10
(assert (min_f%precondition $Snap.unit (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00)) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00))))
(pop) ; 10
; Joined path conditions
(assert (min_f%precondition $Snap.unit (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00)) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00))))
(push) ; 10
(assert (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (min_f $Snap.unit (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00)) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00)))))
(pop) ; 10
; Joined path conditions
(assert (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (min_f $Snap.unit (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00)) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00)))))
(pop) ; 9
(pop) ; 8
; Joined path conditions
(assert (=>
  (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)
  (and
    (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)
    (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 1)
    (tree_min%precondition $Snap.unit (get_Tree_left<Tree> t@16@00))
    (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00))))))
; Joined path conditions
(assert (=>
  (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))
  (and
    (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))
    (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 1)
    (tree_min%precondition $Snap.unit (get_Tree_left<Tree> t@16@00))
    (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 1)
    (tree_min%precondition $Snap.unit (get_Tree_right<Tree> t@16@00))
    (min_f%precondition $Snap.unit (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00)) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00)))
    (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (min_f $Snap.unit (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00)) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00)))))))
(assert (or
  (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))
  (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=>
  (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
  (and
    (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
    (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 1)
    (tree_min%precondition $Snap.unit (get_Tree_right<Tree> t@16@00))
    (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00))))))
; Joined path conditions
(assert (=>
  (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0))
  (and
    (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0))
    (=>
      (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)
      (and
        (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)
        (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 1)
        (tree_min%precondition $Snap.unit (get_Tree_left<Tree> t@16@00))
        (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00)))))
    (=>
      (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))
      (and
        (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))
        (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 1)
        (tree_min%precondition $Snap.unit (get_Tree_left<Tree> t@16@00))
        (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 1)
        (tree_min%precondition $Snap.unit (get_Tree_right<Tree> t@16@00))
        (min_f%precondition $Snap.unit (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00)) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00)))
        (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (min_f $Snap.unit (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00)) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00))))))
    (or
      (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))
      (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)))))
(assert (or
  (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0))
  (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not
    (and
      (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
      (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)))
  (and
    (not
      (and
        (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
        (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)))
    (=>
      (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
      (and
        (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
        (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 1)
        (tree_min%precondition $Snap.unit (get_Tree_right<Tree> t@16@00))
        (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00)))))
    (=>
      (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0))
      (and
        (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0))
        (=>
          (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)
          (and
            (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)
            (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 1)
            (tree_min%precondition $Snap.unit (get_Tree_left<Tree> t@16@00))
            (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00)))))
        (=>
          (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))
          (and
            (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))
            (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 1)
            (tree_min%precondition $Snap.unit (get_Tree_left<Tree> t@16@00))
            (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 1)
            (tree_min%precondition $Snap.unit (get_Tree_right<Tree> t@16@00))
            (min_f%precondition $Snap.unit (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00)) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00)))
            (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (min_f $Snap.unit (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00)) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00))))))
        (or
          (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))
          (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))))
    (or
      (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0))
      (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)))))
(assert (or
  (not
    (and
      (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
      (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)))
  (and
    (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
    (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
(assert (=>
  (= (Tree_tag<Int> t@16@00) 1)
  (and
    (or
      (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
      (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)))
    (=>
      (not
        (and
          (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
          (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)))
      (and
        (not
          (and
            (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
            (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)))
        (=>
          (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
          (and
            (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
            (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 1)
            (tree_min%precondition $Snap.unit (get_Tree_right<Tree> t@16@00))
            (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00)))))
        (=>
          (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0))
          (and
            (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0))
            (=>
              (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)
              (and
                (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)
                (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 1)
                (tree_min%precondition $Snap.unit (get_Tree_left<Tree> t@16@00))
                (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00)))))
            (=>
              (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))
              (and
                (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))
                (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 1)
                (tree_min%precondition $Snap.unit (get_Tree_left<Tree> t@16@00))
                (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 1)
                (tree_min%precondition $Snap.unit (get_Tree_right<Tree> t@16@00))
                (min_f%precondition $Snap.unit (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00)) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00)))
                (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (min_f $Snap.unit (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00)) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00))))))
            (or
              (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))
              (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))))
        (or
          (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0))
          (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0))))
    (or
      (not
        (and
          (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
          (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)))
      (and
        (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
        (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))))))
(assert (=
  result@17@00
  (ite
    (and
      (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
      (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))
    (get_Tree_value<Int> t@16@00)
    (ite
      (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
      (min_f $Snap.unit (get_Tree_value<Int> t@16@00) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00)))
      (ite
        (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)
        (min_f $Snap.unit (get_Tree_value<Int> t@16@00) (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00)))
        (min_f $Snap.unit (get_Tree_value<Int> t@16@00) (min_f $Snap.unit (tree_min $Snap.unit (get_Tree_left<Tree> t@16@00)) (tree_min $Snap.unit (get_Tree_right<Tree> t@16@00)))))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@16@00 Tree)) (!
  (=>
    (tree_min%precondition s@$ t@16@00)
    (=
      (tree_min s@$ t@16@00)
      (ite
        (= (Tree_tag<Int> t@16@00) 1)
        (ite
          (and
            (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
            (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))
          (get_Tree_value<Int> t@16@00)
          (ite
            (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
            (min_f $Snap.unit (get_Tree_value<Int> t@16@00) (tree_min%limited $Snap.unit (get_Tree_right<Tree> t@16@00)))
            (ite
              (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)
              (min_f $Snap.unit (get_Tree_value<Int> t@16@00) (tree_min%limited $Snap.unit (get_Tree_left<Tree> t@16@00)))
              (min_f $Snap.unit (get_Tree_value<Int> t@16@00) (min_f $Snap.unit (tree_min%limited $Snap.unit (get_Tree_left<Tree> t@16@00)) (tree_min%limited $Snap.unit (get_Tree_right<Tree> t@16@00)))))))
        0)))
  :pattern ((tree_min s@$ t@16@00))
  :qid |quant-u-48|)))
(assert (forall ((s@$ $Snap) (t@16@00 Tree)) (!
  (=>
    (tree_min%precondition s@$ t@16@00)
    (ite
      (= (Tree_tag<Int> t@16@00) 1)
      (ite
        (and
          (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
          (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0))
        true
        (ite
          (= (Tree_tag<Int> (get_Tree_left<Tree> t@16@00)) 0)
          (and
            (tree_min%precondition $Snap.unit (get_Tree_right<Tree> t@16@00))
            (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (tree_min%limited $Snap.unit (get_Tree_right<Tree> t@16@00))))
          (ite
            (= (Tree_tag<Int> (get_Tree_right<Tree> t@16@00)) 0)
            (and
              (tree_min%precondition $Snap.unit (get_Tree_left<Tree> t@16@00))
              (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (tree_min%limited $Snap.unit (get_Tree_left<Tree> t@16@00))))
            (and
              (and
                (tree_min%precondition $Snap.unit (get_Tree_left<Tree> t@16@00))
                (tree_min%precondition $Snap.unit (get_Tree_right<Tree> t@16@00))
                (min_f%precondition $Snap.unit (tree_min%limited $Snap.unit (get_Tree_left<Tree> t@16@00)) (tree_min%limited $Snap.unit (get_Tree_right<Tree> t@16@00))))
              (min_f%precondition $Snap.unit (get_Tree_value<Int> t@16@00) (min_f $Snap.unit (tree_min%limited $Snap.unit (get_Tree_left<Tree> t@16@00)) (tree_min%limited $Snap.unit (get_Tree_right<Tree> t@16@00))))))))
      true))
  :pattern ((tree_min s@$ t@16@00))
  :qid |quant-u-49|)))
; ---------- FUNCTION count_leaves----------
(declare-fun t@18@00 () Tree)
(declare-fun result@19@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@35@00 $Snap)
(assert (= $t@35@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@19@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@18@00 Tree)) (!
  (= (count_leaves%limited s@$ t@18@00) (count_leaves s@$ t@18@00))
  :pattern ((count_leaves s@$ t@18@00))
  :qid |quant-u-14|)))
(assert (forall ((s@$ $Snap) (t@18@00 Tree)) (!
  (count_leaves%stateless t@18@00)
  :pattern ((count_leaves%limited s@$ t@18@00))
  :qid |quant-u-15|)))
(assert (forall ((s@$ $Snap) (t@18@00 Tree)) (!
  (let ((result@19@00 (count_leaves%limited s@$ t@18@00))) (=>
    (count_leaves%precondition s@$ t@18@00)
    (>= result@19@00 0)))
  :pattern ((count_leaves%limited s@$ t@18@00))
  :qid |quant-u-50|)))
(assert (forall ((s@$ $Snap) (t@18@00 Tree)) (!
  (let ((result@19@00 (count_leaves%limited s@$ t@18@00))) true)
  :pattern ((count_leaves%limited s@$ t@18@00))
  :qid |quant-u-51|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (Tree_tag(t) == 0 ? 1 : count_leaves(get_Tree_left(t)) + count_leaves(get_Tree_right(t)))
; [eval] Tree_tag(t) == 0
; [eval] Tree_tag(t)
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Tree_tag<Int> t@18@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Tree_tag<Int> t@18@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 20 | Tree_tag[Int](t@18@00) == 0 | live]
; [else-branch: 20 | Tree_tag[Int](t@18@00) != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 20 | Tree_tag[Int](t@18@00) == 0]
(assert (= (Tree_tag<Int> t@18@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 20 | Tree_tag[Int](t@18@00) != 0]
(assert (not (= (Tree_tag<Int> t@18@00) 0)))
; [eval] count_leaves(get_Tree_left(t)) + count_leaves(get_Tree_right(t))
; [eval] count_leaves(get_Tree_left(t))
; [eval] get_Tree_left(t)
(push) ; 4
(assert (count_leaves%precondition $Snap.unit (get_Tree_left<Tree> t@18@00)))
(pop) ; 4
; Joined path conditions
(assert (count_leaves%precondition $Snap.unit (get_Tree_left<Tree> t@18@00)))
; [eval] count_leaves(get_Tree_right(t))
; [eval] get_Tree_right(t)
(push) ; 4
(assert (count_leaves%precondition $Snap.unit (get_Tree_right<Tree> t@18@00)))
(pop) ; 4
; Joined path conditions
(assert (count_leaves%precondition $Snap.unit (get_Tree_right<Tree> t@18@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Tree_tag<Int> t@18@00) 0))
  (and
    (not (= (Tree_tag<Int> t@18@00) 0))
    (count_leaves%precondition $Snap.unit (get_Tree_left<Tree> t@18@00))
    (count_leaves%precondition $Snap.unit (get_Tree_right<Tree> t@18@00)))))
(assert (or (not (= (Tree_tag<Int> t@18@00) 0)) (= (Tree_tag<Int> t@18@00) 0)))
(assert (=
  result@19@00
  (ite
    (= (Tree_tag<Int> t@18@00) 0)
    1
    (+
      (count_leaves $Snap.unit (get_Tree_left<Tree> t@18@00))
      (count_leaves $Snap.unit (get_Tree_right<Tree> t@18@00))))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@19@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@19@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@18@00 Tree)) (!
  (=>
    (count_leaves%precondition s@$ t@18@00)
    (=
      (count_leaves s@$ t@18@00)
      (ite
        (= (Tree_tag<Int> t@18@00) 0)
        1
        (+
          (count_leaves%limited $Snap.unit (get_Tree_left<Tree> t@18@00))
          (count_leaves%limited $Snap.unit (get_Tree_right<Tree> t@18@00))))))
  :pattern ((count_leaves s@$ t@18@00))
  :qid |quant-u-52|)))
(assert (forall ((s@$ $Snap) (t@18@00 Tree)) (!
  (=>
    (count_leaves%precondition s@$ t@18@00)
    (ite
      (= (Tree_tag<Int> t@18@00) 0)
      true
      (and
        (count_leaves%precondition $Snap.unit (get_Tree_left<Tree> t@18@00))
        (count_leaves%precondition $Snap.unit (get_Tree_right<Tree> t@18@00)))))
  :pattern ((count_leaves s@$ t@18@00))
  :qid |quant-u-53|)))
; ---------- FUNCTION tree_contains----------
(declare-fun t@20@00 () Tree)
(declare-fun x@21@00 () Int)
(declare-fun result@22@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@20@00 Tree) (x@21@00 Int)) (!
  (=
    (tree_contains%limited s@$ t@20@00 x@21@00)
    (tree_contains s@$ t@20@00 x@21@00))
  :pattern ((tree_contains s@$ t@20@00 x@21@00))
  :qid |quant-u-16|)))
(assert (forall ((s@$ $Snap) (t@20@00 Tree) (x@21@00 Int)) (!
  (tree_contains%stateless t@20@00 x@21@00)
  :pattern ((tree_contains%limited s@$ t@20@00 x@21@00))
  :qid |quant-u-17|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (Tree_tag(t) == 0 ? false : get_Tree_value(t) == x || (tree_contains(get_Tree_left(t), x) || tree_contains(get_Tree_right(t), x)))
; [eval] Tree_tag(t) == 0
; [eval] Tree_tag(t)
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Tree_tag<Int> t@20@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Tree_tag<Int> t@20@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 21 | Tree_tag[Int](t@20@00) == 0 | live]
; [else-branch: 21 | Tree_tag[Int](t@20@00) != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 21 | Tree_tag[Int](t@20@00) == 0]
(assert (= (Tree_tag<Int> t@20@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 21 | Tree_tag[Int](t@20@00) != 0]
(assert (not (= (Tree_tag<Int> t@20@00) 0)))
; [eval] get_Tree_value(t) == x || (tree_contains(get_Tree_left(t), x) || tree_contains(get_Tree_right(t), x))
; [eval] get_Tree_value(t) == x
; [eval] get_Tree_value(t)
(push) ; 4
; [then-branch: 22 | get_Tree_value[Int](t@20@00) == x@21@00 | live]
; [else-branch: 22 | get_Tree_value[Int](t@20@00) != x@21@00 | live]
(push) ; 5
; [then-branch: 22 | get_Tree_value[Int](t@20@00) == x@21@00]
(assert (= (get_Tree_value<Int> t@20@00) x@21@00))
(pop) ; 5
(push) ; 5
; [else-branch: 22 | get_Tree_value[Int](t@20@00) != x@21@00]
(assert (not (= (get_Tree_value<Int> t@20@00) x@21@00)))
; [eval] tree_contains(get_Tree_left(t), x)
; [eval] get_Tree_left(t)
(push) ; 6
(assert (tree_contains%precondition $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00))
(pop) ; 6
; Joined path conditions
(assert (tree_contains%precondition $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00))
(push) ; 6
; [then-branch: 23 | tree_contains(_, get_Tree_left[Tree](t@20@00), x@21@00) | live]
; [else-branch: 23 | !(tree_contains(_, get_Tree_left[Tree](t@20@00), x@21@00)) | live]
(push) ; 7
; [then-branch: 23 | tree_contains(_, get_Tree_left[Tree](t@20@00), x@21@00)]
(assert (tree_contains $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00))
(pop) ; 7
(push) ; 7
; [else-branch: 23 | !(tree_contains(_, get_Tree_left[Tree](t@20@00), x@21@00))]
(assert (not (tree_contains $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00)))
; [eval] tree_contains(get_Tree_right(t), x)
; [eval] get_Tree_right(t)
(push) ; 8
(assert (tree_contains%precondition $Snap.unit (get_Tree_right<Tree> t@20@00) x@21@00))
(pop) ; 8
; Joined path conditions
(assert (tree_contains%precondition $Snap.unit (get_Tree_right<Tree> t@20@00) x@21@00))
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (tree_contains $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00))
  (and
    (not (tree_contains $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00))
    (tree_contains%precondition $Snap.unit (get_Tree_right<Tree> t@20@00) x@21@00))))
(assert (or
  (not (tree_contains $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00))
  (tree_contains $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (get_Tree_value<Int> t@20@00) x@21@00))
  (and
    (not (= (get_Tree_value<Int> t@20@00) x@21@00))
    (tree_contains%precondition $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00)
    (=>
      (not (tree_contains $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00))
      (and
        (not (tree_contains $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00))
        (tree_contains%precondition $Snap.unit (get_Tree_right<Tree> t@20@00) x@21@00)))
    (or
      (not (tree_contains $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00))
      (tree_contains $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00)))))
(assert (or
  (not (= (get_Tree_value<Int> t@20@00) x@21@00))
  (= (get_Tree_value<Int> t@20@00) x@21@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Tree_tag<Int> t@20@00) 0))
  (and
    (not (= (Tree_tag<Int> t@20@00) 0))
    (=>
      (not (= (get_Tree_value<Int> t@20@00) x@21@00))
      (and
        (not (= (get_Tree_value<Int> t@20@00) x@21@00))
        (tree_contains%precondition $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00)
        (=>
          (not (tree_contains $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00))
          (and
            (not
              (tree_contains $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00))
            (tree_contains%precondition $Snap.unit (get_Tree_right<Tree> t@20@00) x@21@00)))
        (or
          (not (tree_contains $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00))
          (tree_contains $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00))))
    (or
      (not (= (get_Tree_value<Int> t@20@00) x@21@00))
      (= (get_Tree_value<Int> t@20@00) x@21@00)))))
(assert (or (not (= (Tree_tag<Int> t@20@00) 0)) (= (Tree_tag<Int> t@20@00) 0)))
(assert (=
  result@22@00
  (ite
    (= (Tree_tag<Int> t@20@00) 0)
    false
    (or
      (= (get_Tree_value<Int> t@20@00) x@21@00)
      (or
        (tree_contains $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00)
        (tree_contains $Snap.unit (get_Tree_right<Tree> t@20@00) x@21@00))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@20@00 Tree) (x@21@00 Int)) (!
  (=>
    (tree_contains%precondition s@$ t@20@00 x@21@00)
    (=
      (tree_contains s@$ t@20@00 x@21@00)
      (ite
        (= (Tree_tag<Int> t@20@00) 0)
        false
        (or
          (= (get_Tree_value<Int> t@20@00) x@21@00)
          (or
            (tree_contains%limited $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00)
            (tree_contains%limited $Snap.unit (get_Tree_right<Tree> t@20@00) x@21@00))))))
  :pattern ((tree_contains s@$ t@20@00 x@21@00))
  :qid |quant-u-54|)))
(assert (forall ((s@$ $Snap) (t@20@00 Tree) (x@21@00 Int)) (!
  (=>
    (tree_contains%precondition s@$ t@20@00 x@21@00)
    (ite
      (= (Tree_tag<Int> t@20@00) 0)
      true
      (=>
        (not (= (get_Tree_value<Int> t@20@00) x@21@00))
        (and
          (tree_contains%precondition $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00)
          (=>
            (not
              (tree_contains%limited $Snap.unit (get_Tree_left<Tree> t@20@00) x@21@00))
            (tree_contains%precondition $Snap.unit (get_Tree_right<Tree> t@20@00) x@21@00))))))
  :pattern ((tree_contains s@$ t@20@00 x@21@00))
  :qid |quant-u-55|)))
; ---------- FUNCTION tree_sum----------
(declare-fun t@23@00 () Tree)
(declare-fun result@24@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@23@00 Tree)) (!
  (= (tree_sum%limited s@$ t@23@00) (tree_sum s@$ t@23@00))
  :pattern ((tree_sum s@$ t@23@00))
  :qid |quant-u-18|)))
(assert (forall ((s@$ $Snap) (t@23@00 Tree)) (!
  (tree_sum%stateless t@23@00)
  :pattern ((tree_sum%limited s@$ t@23@00))
  :qid |quant-u-19|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (Tree_tag(t) == 0 ? 0 : get_Tree_value(t) + tree_sum(get_Tree_left(t)) + tree_sum(get_Tree_right(t)))
; [eval] Tree_tag(t) == 0
; [eval] Tree_tag(t)
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Tree_tag<Int> t@23@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Tree_tag<Int> t@23@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 24 | Tree_tag[Int](t@23@00) == 0 | live]
; [else-branch: 24 | Tree_tag[Int](t@23@00) != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 24 | Tree_tag[Int](t@23@00) == 0]
(assert (= (Tree_tag<Int> t@23@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 24 | Tree_tag[Int](t@23@00) != 0]
(assert (not (= (Tree_tag<Int> t@23@00) 0)))
; [eval] get_Tree_value(t) + tree_sum(get_Tree_left(t)) + tree_sum(get_Tree_right(t))
; [eval] get_Tree_value(t) + tree_sum(get_Tree_left(t))
; [eval] get_Tree_value(t)
; [eval] tree_sum(get_Tree_left(t))
; [eval] get_Tree_left(t)
(push) ; 4
(assert (tree_sum%precondition $Snap.unit (get_Tree_left<Tree> t@23@00)))
(pop) ; 4
; Joined path conditions
(assert (tree_sum%precondition $Snap.unit (get_Tree_left<Tree> t@23@00)))
; [eval] tree_sum(get_Tree_right(t))
; [eval] get_Tree_right(t)
(push) ; 4
(assert (tree_sum%precondition $Snap.unit (get_Tree_right<Tree> t@23@00)))
(pop) ; 4
; Joined path conditions
(assert (tree_sum%precondition $Snap.unit (get_Tree_right<Tree> t@23@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Tree_tag<Int> t@23@00) 0))
  (and
    (not (= (Tree_tag<Int> t@23@00) 0))
    (tree_sum%precondition $Snap.unit (get_Tree_left<Tree> t@23@00))
    (tree_sum%precondition $Snap.unit (get_Tree_right<Tree> t@23@00)))))
(assert (or (not (= (Tree_tag<Int> t@23@00) 0)) (= (Tree_tag<Int> t@23@00) 0)))
(assert (=
  result@24@00
  (ite
    (= (Tree_tag<Int> t@23@00) 0)
    0
    (+
      (+
        (get_Tree_value<Int> t@23@00)
        (tree_sum $Snap.unit (get_Tree_left<Tree> t@23@00)))
      (tree_sum $Snap.unit (get_Tree_right<Tree> t@23@00))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@23@00 Tree)) (!
  (=>
    (tree_sum%precondition s@$ t@23@00)
    (=
      (tree_sum s@$ t@23@00)
      (ite
        (= (Tree_tag<Int> t@23@00) 0)
        0
        (+
          (+
            (get_Tree_value<Int> t@23@00)
            (tree_sum%limited $Snap.unit (get_Tree_left<Tree> t@23@00)))
          (tree_sum%limited $Snap.unit (get_Tree_right<Tree> t@23@00))))))
  :pattern ((tree_sum s@$ t@23@00))
  :qid |quant-u-56|)))
(assert (forall ((s@$ $Snap) (t@23@00 Tree)) (!
  (=>
    (tree_sum%precondition s@$ t@23@00)
    (ite
      (= (Tree_tag<Int> t@23@00) 0)
      true
      (and
        (tree_sum%precondition $Snap.unit (get_Tree_left<Tree> t@23@00))
        (tree_sum%precondition $Snap.unit (get_Tree_right<Tree> t@23@00)))))
  :pattern ((tree_sum s@$ t@23@00))
  :qid |quant-u-57|)))
; ---------- FUNCTION tree_max----------
(declare-fun t@25@00 () Tree)
(declare-fun result@26@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] Tree_tag(t) == 1
; [eval] Tree_tag(t)
(assert (= (Tree_tag<Int> t@25@00) 1))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@25@00 Tree)) (!
  (= (tree_max%limited s@$ t@25@00) (tree_max s@$ t@25@00))
  :pattern ((tree_max s@$ t@25@00))
  :qid |quant-u-20|)))
(assert (forall ((s@$ $Snap) (t@25@00 Tree)) (!
  (tree_max%stateless t@25@00)
  :pattern ((tree_max%limited s@$ t@25@00))
  :qid |quant-u-21|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (= (Tree_tag<Int> t@25@00) 1))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (Tree_tag(t) == 1 ? (Tree_tag(get_Tree_left(t)) == 0 && Tree_tag(get_Tree_right(t)) == 0 ? get_Tree_value(t) : (Tree_tag(get_Tree_left(t)) == 0 ? max_f(get_Tree_value(t), tree_max(get_Tree_right(t))) : (Tree_tag(get_Tree_right(t)) == 0 ? max_f(get_Tree_value(t), tree_max(get_Tree_left(t))) : max_f(get_Tree_value(t), max_f(tree_max(get_Tree_left(t)), tree_max(get_Tree_right(t))))))) : 0)
; [eval] Tree_tag(t) == 1
; [eval] Tree_tag(t)
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Tree_tag<Int> t@25@00) 1))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 25 | Tree_tag[Int](t@25@00) == 1 | live]
; [else-branch: 25 | Tree_tag[Int](t@25@00) != 1 | dead]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 25 | Tree_tag[Int](t@25@00) == 1]
; [eval] (Tree_tag(get_Tree_left(t)) == 0 && Tree_tag(get_Tree_right(t)) == 0 ? get_Tree_value(t) : (Tree_tag(get_Tree_left(t)) == 0 ? max_f(get_Tree_value(t), tree_max(get_Tree_right(t))) : (Tree_tag(get_Tree_right(t)) == 0 ? max_f(get_Tree_value(t), tree_max(get_Tree_left(t))) : max_f(get_Tree_value(t), max_f(tree_max(get_Tree_left(t)), tree_max(get_Tree_right(t)))))))
; [eval] Tree_tag(get_Tree_left(t)) == 0 && Tree_tag(get_Tree_right(t)) == 0
; [eval] Tree_tag(get_Tree_left(t)) == 0
; [eval] Tree_tag(get_Tree_left(t))
; [eval] get_Tree_left(t)
(push) ; 4
; [then-branch: 26 | Tree_tag[Int](get_Tree_left[Tree](t@25@00)) != 0 | live]
; [else-branch: 26 | Tree_tag[Int](get_Tree_left[Tree](t@25@00)) == 0 | live]
(push) ; 5
; [then-branch: 26 | Tree_tag[Int](get_Tree_left[Tree](t@25@00)) != 0]
(assert (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)))
(pop) ; 5
(push) ; 5
; [else-branch: 26 | Tree_tag[Int](get_Tree_left[Tree](t@25@00)) == 0]
(assert (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0))
; [eval] Tree_tag(get_Tree_right(t)) == 0
; [eval] Tree_tag(get_Tree_right(t))
; [eval] get_Tree_right(t)
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or
  (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
  (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0))))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (and
    (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
    (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (and
  (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
  (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 27 | Tree_tag[Int](get_Tree_left[Tree](t@25@00)) == 0 && Tree_tag[Int](get_Tree_right[Tree](t@25@00)) == 0 | live]
; [else-branch: 27 | !(Tree_tag[Int](get_Tree_left[Tree](t@25@00)) == 0 && Tree_tag[Int](get_Tree_right[Tree](t@25@00)) == 0) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 27 | Tree_tag[Int](get_Tree_left[Tree](t@25@00)) == 0 && Tree_tag[Int](get_Tree_right[Tree](t@25@00)) == 0]
(assert (and
  (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
  (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)))
; [eval] get_Tree_value(t)
(pop) ; 5
(push) ; 5
; [else-branch: 27 | !(Tree_tag[Int](get_Tree_left[Tree](t@25@00)) == 0 && Tree_tag[Int](get_Tree_right[Tree](t@25@00)) == 0)]
(assert (not
  (and
    (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
    (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))))
; [eval] (Tree_tag(get_Tree_left(t)) == 0 ? max_f(get_Tree_value(t), tree_max(get_Tree_right(t))) : (Tree_tag(get_Tree_right(t)) == 0 ? max_f(get_Tree_value(t), tree_max(get_Tree_left(t))) : max_f(get_Tree_value(t), max_f(tree_max(get_Tree_left(t)), tree_max(get_Tree_right(t))))))
; [eval] Tree_tag(get_Tree_left(t)) == 0
; [eval] Tree_tag(get_Tree_left(t))
; [eval] get_Tree_left(t)
(push) ; 6
(push) ; 7
(set-option :rlimit 16000)
(assert (not (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 16000)
(assert (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 28 | Tree_tag[Int](get_Tree_left[Tree](t@25@00)) == 0 | live]
; [else-branch: 28 | Tree_tag[Int](get_Tree_left[Tree](t@25@00)) != 0 | live]
(set-option :rlimit 0)
(push) ; 7
; [then-branch: 28 | Tree_tag[Int](get_Tree_left[Tree](t@25@00)) == 0]
(assert (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0))
; [eval] max_f(get_Tree_value(t), tree_max(get_Tree_right(t)))
; [eval] get_Tree_value(t)
; [eval] tree_max(get_Tree_right(t))
; [eval] get_Tree_right(t)
(push) ; 8
; [eval] Tree_tag(t) == 1
; [eval] Tree_tag(t)
(push) ; 9
(assert (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 1)))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(assert (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 1))
(assert (tree_max%precondition $Snap.unit (get_Tree_right<Tree> t@25@00)))
(pop) ; 8
; Joined path conditions
(assert (and
  (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 1)
  (tree_max%precondition $Snap.unit (get_Tree_right<Tree> t@25@00))))
(push) ; 8
(assert (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00))))
(pop) ; 8
; Joined path conditions
(assert (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00))))
(pop) ; 7
(push) ; 7
; [else-branch: 28 | Tree_tag[Int](get_Tree_left[Tree](t@25@00)) != 0]
(assert (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)))
; [eval] (Tree_tag(get_Tree_right(t)) == 0 ? max_f(get_Tree_value(t), tree_max(get_Tree_left(t))) : max_f(get_Tree_value(t), max_f(tree_max(get_Tree_left(t)), tree_max(get_Tree_right(t)))))
; [eval] Tree_tag(get_Tree_right(t)) == 0
; [eval] Tree_tag(get_Tree_right(t))
; [eval] get_Tree_right(t)
(push) ; 8
(push) ; 9
(set-option :rlimit 16000)
(assert (not (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))))
(check-sat)
; unknown
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 16000)
(assert (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)))
(check-sat)
; unknown
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
; [then-branch: 29 | Tree_tag[Int](get_Tree_right[Tree](t@25@00)) == 0 | live]
; [else-branch: 29 | Tree_tag[Int](get_Tree_right[Tree](t@25@00)) != 0 | live]
(set-option :rlimit 0)
(push) ; 9
; [then-branch: 29 | Tree_tag[Int](get_Tree_right[Tree](t@25@00)) == 0]
(assert (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))
; [eval] max_f(get_Tree_value(t), tree_max(get_Tree_left(t)))
; [eval] get_Tree_value(t)
; [eval] tree_max(get_Tree_left(t))
; [eval] get_Tree_left(t)
(push) ; 10
; [eval] Tree_tag(t) == 1
; [eval] Tree_tag(t)
(push) ; 11
(assert (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 1)))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
(assert (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 1))
(assert (tree_max%precondition $Snap.unit (get_Tree_left<Tree> t@25@00)))
(pop) ; 10
; Joined path conditions
(assert (and
  (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 1)
  (tree_max%precondition $Snap.unit (get_Tree_left<Tree> t@25@00))))
(push) ; 10
(assert (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00))))
(pop) ; 10
; Joined path conditions
(assert (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00))))
(pop) ; 9
(push) ; 9
; [else-branch: 29 | Tree_tag[Int](get_Tree_right[Tree](t@25@00)) != 0]
(assert (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)))
; [eval] max_f(get_Tree_value(t), max_f(tree_max(get_Tree_left(t)), tree_max(get_Tree_right(t))))
; [eval] get_Tree_value(t)
; [eval] max_f(tree_max(get_Tree_left(t)), tree_max(get_Tree_right(t)))
; [eval] tree_max(get_Tree_left(t))
; [eval] get_Tree_left(t)
(push) ; 10
; [eval] Tree_tag(t) == 1
; [eval] Tree_tag(t)
(push) ; 11
(assert (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 1)))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
(assert (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 1))
(assert (tree_max%precondition $Snap.unit (get_Tree_left<Tree> t@25@00)))
(pop) ; 10
; Joined path conditions
(assert (and
  (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 1)
  (tree_max%precondition $Snap.unit (get_Tree_left<Tree> t@25@00))))
; [eval] tree_max(get_Tree_right(t))
; [eval] get_Tree_right(t)
(push) ; 10
; [eval] Tree_tag(t) == 1
; [eval] Tree_tag(t)
(push) ; 11
(assert (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 1)))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
(assert (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 1))
(assert (tree_max%precondition $Snap.unit (get_Tree_right<Tree> t@25@00)))
(pop) ; 10
; Joined path conditions
(assert (and
  (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 1)
  (tree_max%precondition $Snap.unit (get_Tree_right<Tree> t@25@00))))
(push) ; 10
(assert (max_f%precondition $Snap.unit (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00)) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00))))
(pop) ; 10
; Joined path conditions
(assert (max_f%precondition $Snap.unit (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00)) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00))))
(push) ; 10
(assert (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (max_f $Snap.unit (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00)) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00)))))
(pop) ; 10
; Joined path conditions
(assert (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (max_f $Snap.unit (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00)) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00)))))
(pop) ; 9
(pop) ; 8
; Joined path conditions
(assert (=>
  (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)
  (and
    (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)
    (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 1)
    (tree_max%precondition $Snap.unit (get_Tree_left<Tree> t@25@00))
    (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00))))))
; Joined path conditions
(assert (=>
  (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))
  (and
    (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))
    (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 1)
    (tree_max%precondition $Snap.unit (get_Tree_left<Tree> t@25@00))
    (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 1)
    (tree_max%precondition $Snap.unit (get_Tree_right<Tree> t@25@00))
    (max_f%precondition $Snap.unit (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00)) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00)))
    (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (max_f $Snap.unit (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00)) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00)))))))
(assert (or
  (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))
  (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=>
  (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
  (and
    (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
    (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 1)
    (tree_max%precondition $Snap.unit (get_Tree_right<Tree> t@25@00))
    (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00))))))
; Joined path conditions
(assert (=>
  (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0))
  (and
    (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0))
    (=>
      (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)
      (and
        (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)
        (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 1)
        (tree_max%precondition $Snap.unit (get_Tree_left<Tree> t@25@00))
        (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00)))))
    (=>
      (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))
      (and
        (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))
        (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 1)
        (tree_max%precondition $Snap.unit (get_Tree_left<Tree> t@25@00))
        (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 1)
        (tree_max%precondition $Snap.unit (get_Tree_right<Tree> t@25@00))
        (max_f%precondition $Snap.unit (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00)) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00)))
        (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (max_f $Snap.unit (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00)) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00))))))
    (or
      (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))
      (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)))))
(assert (or
  (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0))
  (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not
    (and
      (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
      (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)))
  (and
    (not
      (and
        (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
        (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)))
    (=>
      (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
      (and
        (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
        (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 1)
        (tree_max%precondition $Snap.unit (get_Tree_right<Tree> t@25@00))
        (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00)))))
    (=>
      (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0))
      (and
        (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0))
        (=>
          (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)
          (and
            (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)
            (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 1)
            (tree_max%precondition $Snap.unit (get_Tree_left<Tree> t@25@00))
            (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00)))))
        (=>
          (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))
          (and
            (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))
            (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 1)
            (tree_max%precondition $Snap.unit (get_Tree_left<Tree> t@25@00))
            (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 1)
            (tree_max%precondition $Snap.unit (get_Tree_right<Tree> t@25@00))
            (max_f%precondition $Snap.unit (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00)) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00)))
            (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (max_f $Snap.unit (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00)) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00))))))
        (or
          (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))
          (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))))
    (or
      (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0))
      (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)))))
(assert (or
  (not
    (and
      (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
      (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)))
  (and
    (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
    (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
(assert (=>
  (= (Tree_tag<Int> t@25@00) 1)
  (and
    (or
      (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
      (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)))
    (=>
      (not
        (and
          (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
          (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)))
      (and
        (not
          (and
            (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
            (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)))
        (=>
          (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
          (and
            (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
            (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 1)
            (tree_max%precondition $Snap.unit (get_Tree_right<Tree> t@25@00))
            (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00)))))
        (=>
          (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0))
          (and
            (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0))
            (=>
              (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)
              (and
                (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)
                (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 1)
                (tree_max%precondition $Snap.unit (get_Tree_left<Tree> t@25@00))
                (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00)))))
            (=>
              (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))
              (and
                (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))
                (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 1)
                (tree_max%precondition $Snap.unit (get_Tree_left<Tree> t@25@00))
                (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 1)
                (tree_max%precondition $Snap.unit (get_Tree_right<Tree> t@25@00))
                (max_f%precondition $Snap.unit (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00)) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00)))
                (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (max_f $Snap.unit (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00)) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00))))))
            (or
              (not (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))
              (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))))
        (or
          (not (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0))
          (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0))))
    (or
      (not
        (and
          (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
          (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)))
      (and
        (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
        (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))))))
(assert (=
  result@26@00
  (ite
    (and
      (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
      (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))
    (get_Tree_value<Int> t@25@00)
    (ite
      (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
      (max_f $Snap.unit (get_Tree_value<Int> t@25@00) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00)))
      (ite
        (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)
        (max_f $Snap.unit (get_Tree_value<Int> t@25@00) (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00)))
        (max_f $Snap.unit (get_Tree_value<Int> t@25@00) (max_f $Snap.unit (tree_max $Snap.unit (get_Tree_left<Tree> t@25@00)) (tree_max $Snap.unit (get_Tree_right<Tree> t@25@00)))))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@25@00 Tree)) (!
  (=>
    (tree_max%precondition s@$ t@25@00)
    (=
      (tree_max s@$ t@25@00)
      (ite
        (= (Tree_tag<Int> t@25@00) 1)
        (ite
          (and
            (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
            (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))
          (get_Tree_value<Int> t@25@00)
          (ite
            (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
            (max_f $Snap.unit (get_Tree_value<Int> t@25@00) (tree_max%limited $Snap.unit (get_Tree_right<Tree> t@25@00)))
            (ite
              (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)
              (max_f $Snap.unit (get_Tree_value<Int> t@25@00) (tree_max%limited $Snap.unit (get_Tree_left<Tree> t@25@00)))
              (max_f $Snap.unit (get_Tree_value<Int> t@25@00) (max_f $Snap.unit (tree_max%limited $Snap.unit (get_Tree_left<Tree> t@25@00)) (tree_max%limited $Snap.unit (get_Tree_right<Tree> t@25@00)))))))
        0)))
  :pattern ((tree_max s@$ t@25@00))
  :qid |quant-u-58|)))
(assert (forall ((s@$ $Snap) (t@25@00 Tree)) (!
  (=>
    (tree_max%precondition s@$ t@25@00)
    (ite
      (= (Tree_tag<Int> t@25@00) 1)
      (ite
        (and
          (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
          (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0))
        true
        (ite
          (= (Tree_tag<Int> (get_Tree_left<Tree> t@25@00)) 0)
          (and
            (tree_max%precondition $Snap.unit (get_Tree_right<Tree> t@25@00))
            (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (tree_max%limited $Snap.unit (get_Tree_right<Tree> t@25@00))))
          (ite
            (= (Tree_tag<Int> (get_Tree_right<Tree> t@25@00)) 0)
            (and
              (tree_max%precondition $Snap.unit (get_Tree_left<Tree> t@25@00))
              (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (tree_max%limited $Snap.unit (get_Tree_left<Tree> t@25@00))))
            (and
              (and
                (tree_max%precondition $Snap.unit (get_Tree_left<Tree> t@25@00))
                (tree_max%precondition $Snap.unit (get_Tree_right<Tree> t@25@00))
                (max_f%precondition $Snap.unit (tree_max%limited $Snap.unit (get_Tree_left<Tree> t@25@00)) (tree_max%limited $Snap.unit (get_Tree_right<Tree> t@25@00))))
              (max_f%precondition $Snap.unit (get_Tree_value<Int> t@25@00) (max_f $Snap.unit (tree_max%limited $Snap.unit (get_Tree_left<Tree> t@25@00)) (tree_max%limited $Snap.unit (get_Tree_right<Tree> t@25@00))))))))
      true))
  :pattern ((tree_max s@$ t@25@00))
  :qid |quant-u-59|)))
; ---------- FUNCTION tree_size----------
(declare-fun t@27@00 () Tree)
(declare-fun result@28@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@36@00 $Snap)
(assert (= $t@36@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@28@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@27@00 Tree)) (!
  (= (tree_size%limited s@$ t@27@00) (tree_size s@$ t@27@00))
  :pattern ((tree_size s@$ t@27@00))
  :qid |quant-u-22|)))
(assert (forall ((s@$ $Snap) (t@27@00 Tree)) (!
  (tree_size%stateless t@27@00)
  :pattern ((tree_size%limited s@$ t@27@00))
  :qid |quant-u-23|)))
(assert (forall ((s@$ $Snap) (t@27@00 Tree)) (!
  (let ((result@28@00 (tree_size%limited s@$ t@27@00))) (=>
    (tree_size%precondition s@$ t@27@00)
    (>= result@28@00 0)))
  :pattern ((tree_size%limited s@$ t@27@00))
  :qid |quant-u-60|)))
(assert (forall ((s@$ $Snap) (t@27@00 Tree)) (!
  (let ((result@28@00 (tree_size%limited s@$ t@27@00))) true)
  :pattern ((tree_size%limited s@$ t@27@00))
  :qid |quant-u-61|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (Tree_tag(t) == 0 ? 0 : 1 + tree_size(get_Tree_left(t)) + tree_size(get_Tree_right(t)))
; [eval] Tree_tag(t) == 0
; [eval] Tree_tag(t)
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Tree_tag<Int> t@27@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Tree_tag<Int> t@27@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 30 | Tree_tag[Int](t@27@00) == 0 | live]
; [else-branch: 30 | Tree_tag[Int](t@27@00) != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 30 | Tree_tag[Int](t@27@00) == 0]
(assert (= (Tree_tag<Int> t@27@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 30 | Tree_tag[Int](t@27@00) != 0]
(assert (not (= (Tree_tag<Int> t@27@00) 0)))
; [eval] 1 + tree_size(get_Tree_left(t)) + tree_size(get_Tree_right(t))
; [eval] 1 + tree_size(get_Tree_left(t))
; [eval] tree_size(get_Tree_left(t))
; [eval] get_Tree_left(t)
(push) ; 4
(assert (tree_size%precondition $Snap.unit (get_Tree_left<Tree> t@27@00)))
(pop) ; 4
; Joined path conditions
(assert (tree_size%precondition $Snap.unit (get_Tree_left<Tree> t@27@00)))
; [eval] tree_size(get_Tree_right(t))
; [eval] get_Tree_right(t)
(push) ; 4
(assert (tree_size%precondition $Snap.unit (get_Tree_right<Tree> t@27@00)))
(pop) ; 4
; Joined path conditions
(assert (tree_size%precondition $Snap.unit (get_Tree_right<Tree> t@27@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Tree_tag<Int> t@27@00) 0))
  (and
    (not (= (Tree_tag<Int> t@27@00) 0))
    (tree_size%precondition $Snap.unit (get_Tree_left<Tree> t@27@00))
    (tree_size%precondition $Snap.unit (get_Tree_right<Tree> t@27@00)))))
(assert (or (not (= (Tree_tag<Int> t@27@00) 0)) (= (Tree_tag<Int> t@27@00) 0)))
(assert (=
  result@28@00
  (ite
    (= (Tree_tag<Int> t@27@00) 0)
    0
    (+
      (+ 1 (tree_size $Snap.unit (get_Tree_left<Tree> t@27@00)))
      (tree_size $Snap.unit (get_Tree_right<Tree> t@27@00))))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@28@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@28@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@27@00 Tree)) (!
  (=>
    (tree_size%precondition s@$ t@27@00)
    (=
      (tree_size s@$ t@27@00)
      (ite
        (= (Tree_tag<Int> t@27@00) 0)
        0
        (+
          (+ 1 (tree_size%limited $Snap.unit (get_Tree_left<Tree> t@27@00)))
          (tree_size%limited $Snap.unit (get_Tree_right<Tree> t@27@00))))))
  :pattern ((tree_size s@$ t@27@00))
  :qid |quant-u-62|)))
(assert (forall ((s@$ $Snap) (t@27@00 Tree)) (!
  (=>
    (tree_size%precondition s@$ t@27@00)
    (ite
      (= (Tree_tag<Int> t@27@00) 0)
      true
      (and
        (tree_size%precondition $Snap.unit (get_Tree_left<Tree> t@27@00))
        (tree_size%precondition $Snap.unit (get_Tree_right<Tree> t@27@00)))))
  :pattern ((tree_size s@$ t@27@00))
  :qid |quant-u-63|)))
; ---------- FUNCTION is_bst----------
(declare-fun t@29@00 () Tree)
(declare-fun result@30@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@29@00 Tree)) (!
  (= (is_bst%limited s@$ t@29@00) (is_bst s@$ t@29@00))
  :pattern ((is_bst s@$ t@29@00))
  :qid |quant-u-24|)))
(assert (forall ((s@$ $Snap) (t@29@00 Tree)) (!
  (is_bst%stateless t@29@00)
  :pattern ((is_bst%limited s@$ t@29@00))
  :qid |quant-u-25|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] is_bst_helper(t, -1000000, 1000000)
; [eval] -1000000
(set-option :rlimit 0)
(push) ; 2
(assert (is_bst_helper%precondition $Snap.unit t@29@00 (- 0 1000000) 1000000))
(pop) ; 2
; Joined path conditions
(assert (is_bst_helper%precondition $Snap.unit t@29@00 (- 0 1000000) 1000000))
(assert (= result@30@00 (is_bst_helper $Snap.unit t@29@00 (- 0 1000000) 1000000)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@29@00 Tree)) (!
  (=>
    (is_bst%precondition s@$ t@29@00)
    (=
      (is_bst s@$ t@29@00)
      (is_bst_helper $Snap.unit t@29@00 (- 0 1000000) 1000000)))
  :pattern ((is_bst s@$ t@29@00))
  :qid |quant-u-64|)))
(assert (forall ((s@$ $Snap) (t@29@00 Tree)) (!
  (=>
    (is_bst%precondition s@$ t@29@00)
    (is_bst_helper%precondition $Snap.unit t@29@00 (- 0 1000000) 1000000))
  :pattern ((is_bst s@$ t@29@00))
  :qid |quant-u-65|)))
