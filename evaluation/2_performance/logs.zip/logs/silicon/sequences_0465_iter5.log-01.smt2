(get-info :version)
; (:version "4.8.7")
; Started: 2025-12-05 12:57:12
; Silicon.version: 1.1-SNAPSHOT (95328487@(detached))
; Input file: ./sequences/0465.vpr
; Verifier id: 00
; ------------------------------------------------------------
; Begin preamble
; ////////// Static preamble
; 
; ; /z3config.smt2
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :smt.qi.max_multi_patterns 1000)
; 
; ; /preamble.smt2
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(define-fun $Perm.min ((p1 $Perm) (p2 $Perm)) Real
    (ite (<= p1 p2) p1 p2))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
; ////////// Sorts
(declare-sort Seq<Int> 0)
(declare-sort Set<Int> 0)
; ////////// Sort wrappers
; Declaring additional sort wrappers
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.Seq<Int>To$Snap (Seq<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<Int> ($Snap) Seq<Int>)
(assert (forall ((x Seq<Int>)) (!
    (= x ($SortWrappers.$SnapToSeq<Int>($SortWrappers.Seq<Int>To$Snap x)))
    :pattern (($SortWrappers.Seq<Int>To$Snap x))
    :qid |$Snap.$SnapToSeq<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<Int>To$Snap($SortWrappers.$SnapToSeq<Int> x)))
    :pattern (($SortWrappers.$SnapToSeq<Int> x))
    :qid |$Snap.Seq<Int>To$SnapToSeq<Int>|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.Set<Int>To$Snap (Set<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<Int> ($Snap) Set<Int>)
(assert (forall ((x Set<Int>)) (!
    (= x ($SortWrappers.$SnapToSet<Int>($SortWrappers.Set<Int>To$Snap x)))
    :pattern (($SortWrappers.Set<Int>To$Snap x))
    :qid |$Snap.$SnapToSet<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<Int>To$Snap($SortWrappers.$SnapToSet<Int> x)))
    :pattern (($SortWrappers.$SnapToSet<Int> x))
    :qid |$Snap.Set<Int>To$SnapToSet<Int>|
    )))
; ////////// Symbols
(declare-fun Set_card (Set<Int>) Int)
(declare-const Set_empty Set<Int>)
(declare-fun Set_in (Int Set<Int>) Bool)
(declare-fun Set_singleton (Int) Set<Int>)
(declare-fun Set_unionone (Set<Int> Int) Set<Int>)
(declare-fun Set_union (Set<Int> Set<Int>) Set<Int>)
(declare-fun Set_intersection (Set<Int> Set<Int>) Set<Int>)
(declare-fun Set_difference (Set<Int> Set<Int>) Set<Int>)
(declare-fun Set_subset (Set<Int> Set<Int>) Bool)
(declare-fun Set_equal (Set<Int> Set<Int>) Bool)
(declare-fun Set_skolem_diff (Set<Int> Set<Int>) Int)
(declare-fun Seq_length (Seq<Int>) Int)
(declare-const Seq_empty Seq<Int>)
(declare-fun Seq_singleton (Int) Seq<Int>)
(declare-fun Seq_append (Seq<Int> Seq<Int>) Seq<Int>)
(declare-fun Seq_index (Seq<Int> Int) Int)
(declare-fun Seq_add (Int Int) Int)
(declare-fun Seq_sub (Int Int) Int)
(declare-fun Seq_update (Seq<Int> Int Int) Seq<Int>)
(declare-fun Seq_take (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_drop (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_contains (Seq<Int> Int) Bool)
(declare-fun Seq_contains_trigger (Seq<Int> Int) Bool)
(declare-fun Seq_skolem (Seq<Int> Int) Int)
(declare-fun Seq_equal (Seq<Int> Seq<Int>) Bool)
(declare-fun Seq_skolem_diff (Seq<Int> Seq<Int>) Int)
(declare-fun Seq_range (Int Int) Seq<Int>)
; Declaring symbols related to program functions (from program analysis)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
; Declaring predicate trigger functions
; ////////// Uniqueness assumptions from domains
; ////////// Axioms
(assert (forall ((s Seq<Int>)) (!
  (<= 0 (Seq_length s))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty  Seq<Int>)) 0))
(assert (forall ((s Seq<Int>)) (!
  (=> (= (Seq_length s) 0) (= s (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_zero|)))
(assert (forall ((e Int)) (!
  (= (Seq_length (Seq_singleton e)) 1)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (not (= s1 (as Seq_empty  Seq<Int>))))
    (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1))))
  :pattern ((Seq_length (Seq_append s0 s1)))
  :qid |$Seq[Int]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (and
    (=> (= s0 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s1))
    (=> (= s1 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s0)))
  :pattern ((Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_empty|)))
(assert (forall ((e Int)) (!
  (= (Seq_index (Seq_singleton e) 0) e)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_add i j) (+ i j))
  :pattern ((Seq_add i j))
  :qid |$Seq[Int]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_sub i j) (- i j))
  :pattern ((Seq_sub i j))
  :qid |$Seq[Int]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= 0 n) (< n (Seq_length s0)))))
    (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n)))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :pattern ((Seq_index s0 n) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1))))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n)
      (=
        (Seq_index (Seq_append s0 s1) n)
        (Seq_index s1 (Seq_sub n (Seq_length s0))))))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :qid |$Seq[Int]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (m Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= 0 m) (< m (Seq_length s1)))))
    (and
      (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m)
      (=
        (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0)))
        (Seq_index s1 m))))
  :pattern ((Seq_index s1 m) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (Seq_length (Seq_update s i v)) (Seq_length s)))
  :pattern ((Seq_length (Seq_update s i v)))
  :pattern ((Seq_length s) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_length|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int) (n Int)) (!
  (=>
    (and (<= 0 n) (< n (Seq_length s)))
    (and
      (=> (= i n) (= (Seq_index (Seq_update s i v) n) v))
      (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n)))))
  :pattern ((Seq_index (Seq_update s i v) n))
  :pattern ((Seq_index s n) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s)))))
    (=> (< n 0) (= (Seq_length (Seq_take s n)) 0)))
  :pattern ((Seq_length (Seq_take s n)))
  :pattern ((Seq_take s n) (Seq_length s))
  :qid |$Seq[Int]_prog.Seq_take_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (<= 0 j) (and (< j n) (< j (Seq_length s))))
    (= (Seq_index (Seq_take s n) j) (Seq_index s j)))
  :pattern ((Seq_index (Seq_take s n) j))
  :pattern ((Seq_index s j) (Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=>
          (<= n (Seq_length s))
          (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n)))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0))))
    (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s))))
  :pattern ((Seq_length (Seq_drop s n)))
  :pattern ((Seq_length s) (Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n))))
    (and
      (= (Seq_sub (Seq_add j n) n) j)
      (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n)))))
  :pattern ((Seq_index (Seq_drop s n) j))
  :qid |$Seq[Int]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<Int>) (n Int) (i Int)) (!
  (=>
    (and (< 0 n) (and (<= n i) (< i (Seq_length s))))
    (and
      (= (Seq_add (Seq_sub i n) n) i)
      (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i))))
  :pattern ((Seq_drop s n) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_take (Seq_append s t) n) (Seq_take s n)))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (=
        (Seq_take (Seq_append s t) n)
        (Seq_append s (Seq_take t (Seq_sub n (Seq_length s)))))))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t)))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (> n (Seq_length s)))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s))))))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_take s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_drop s n) s))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_take s n) s))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_all|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<Int>) (x Int)) (!
  (=>
    (Seq_contains s x)
    (and
      (<= 0 (Seq_skolem s x))
      (and
        (< (Seq_skolem s x) (Seq_length s))
        (= (Seq_index s (Seq_skolem s x)) x))))
  :pattern ((Seq_contains s x))
  :qid |$Seq[Int]_prog.Seq_contains1|)))
(assert (forall ((s Seq<Int>) (x Int) (i Int)) (!
  (=>
    (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x)))
    (Seq_contains s x))
  :pattern ((Seq_contains s x) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains2|)))
(assert (forall ((s Seq<Int>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (Seq_contains_trigger s (Seq_index s i)))
  :pattern ((Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (or
    (and (= s0 s1) (Seq_equal s0 s1))
    (or
      (and
        (not (= s0 s1))
        (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1)))))
      (and
        (not (= s0 s1))
        (and
          (not (Seq_equal s0 s1))
          (and
            (= (Seq_length s0) (Seq_length s1))
            (and
              (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0))
              (and
                (<= 0 (Seq_skolem_diff s0 s1))
                (and
                  (< (Seq_skolem_diff s0 s1) (Seq_length s0))
                  (not
                    (=
                      (Seq_index s0 (Seq_skolem_diff s0 s1))
                      (Seq_index s1 (Seq_skolem_diff s0 s1))))))))))))
  :pattern ((Seq_equal s0 s1))
  :qid |$Seq[Int]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<Int>) (b Seq<Int>)) (!
  (=> (Seq_equal a b) (= a b))
  :pattern ((Seq_equal a b))
  :qid |$Seq[Int]_prog.Seq_equal_ext|)))
(assert (forall ((x Int) (y Int)) (!
  (= (Seq_contains (Seq_singleton x) y) (= x y))
  :pattern ((Seq_contains (Seq_singleton x) y))
  :qid |$Seq[Int]_prog.Seq_singleton_contains|)))
(assert (forall ((min_ Int) (max Int)) (!
  (and
    (=> (< min_ max) (= (Seq_length (Seq_range min_ max)) (- max min_)))
    (=> (<= max min_) (= (Seq_length (Seq_range min_ max)) 0)))
  :pattern ((Seq_length (Seq_range min_ max)))
  :qid |$Seq[Int]_prog.Seq_range_length|)))
(assert (forall ((min_ Int) (max Int) (j Int)) (!
  (=>
    (and (<= 0 j) (< j (- max min_)))
    (= (Seq_index (Seq_range min_ max) j) (+ min_ j)))
  :pattern ((Seq_index (Seq_range min_ max) j))
  :qid |$Seq[Int]_prog.Seq_range_index|)))
(assert (forall ((min_ Int) (max Int) (v Int)) (!
  (= (Seq_contains (Seq_range min_ max) v) (and (<= min_ v) (< v max)))
  :pattern ((Seq_contains (Seq_range min_ max) v))
  :qid |$Seq[Int]_prog.Seq_range_contains|)))
(assert (forall ((s Set<Int>)) (!
  (<= 0 (Set_card s))
  :pattern ((Set_card s))
  :qid |$Set[Int]_prog.Set_card_nonneg|)))
(assert (forall ((o Int)) (!
  (not (Set_in o (as Set_empty  Set<Int>)))
  :pattern ((Set_in o (as Set_empty  Set<Int>)))
  :qid |$Set[Int]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<Int>)) (!
  (and
    (=> (= (Set_card s) 0) (= s (as Set_empty  Set<Int>)))
    (=> (not (= (Set_card s) 0)) (exists ((x Int))  (Set_in x s))))
  :pattern ((Set_card s))
  :qid |$Set[Int]_prog.Set_card_zero|)))
(assert (forall ((r Int)) (!
  (Set_in r (Set_singleton r))
  :pattern ((Set_singleton r))
  :qid |$Set[Int]_prog.Set_singleton_contains1|)))
(assert (forall ((r Int) (o Int)) (!
  (= (Set_in o (Set_singleton r)) (= r o))
  :pattern ((Set_in o (Set_singleton r)))
  :qid |$Set[Int]_prog.Set_singleton_contains2|)))
(assert (forall ((r Int)) (!
  (= (Set_card (Set_singleton r)) 1)
  :pattern ((Set_card (Set_singleton r)))
  :qid |$Set[Int]_prog.Set_singleton_card|)))
(assert (forall ((a Set<Int>) (x Int) (o Int)) (!
  (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a)))
  :pattern ((Set_in o (Set_unionone a x)))
  :qid |$Set[Int]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<Int>) (x Int)) (!
  (Set_in x (Set_unionone a x))
  :pattern ((Set_unionone a x))
  :qid |$Set[Int]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<Int>) (x Int) (y Int)) (!
  (=> (Set_in y a) (Set_in y (Set_unionone a x)))
  :pattern ((Set_unionone a x) (Set_in y a))
  :qid |$Set[Int]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<Int>) (x Int)) (!
  (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[Int]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<Int>) (x Int)) (!
  (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[Int]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (o Int)) (!
  (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_union a b)))
  :qid |$Set[Int]_prog.Set_union_contains1|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (y Int)) (!
  (=> (Set_in y a) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y a))
  :qid |$Set[Int]_prog.Set_union_contains2|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (y Int)) (!
  (=> (Set_in y b) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y b))
  :qid |$Set[Int]_prog.Set_union_contains3|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (o Int)) (!
  (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_intersection a b)))
  :pattern ((Set_intersection a b) (Set_in o a))
  :pattern ((Set_intersection a b) (Set_in o b))
  :qid |$Set[Int]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (= (Set_union (Set_union a b) b) (Set_union a b))
  :pattern ((Set_union (Set_union a b) b))
  :qid |$Set[Int]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (= (Set_union a (Set_union a b)) (Set_union a b))
  :pattern ((Set_union a (Set_union a b)))
  :qid |$Set[Int]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b))
  :pattern ((Set_intersection (Set_intersection a b) b))
  :qid |$Set[Int]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b))
  :pattern ((Set_intersection a (Set_intersection a b)))
  :qid |$Set[Int]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (=
    (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b)))
    (+ (Set_card a) (Set_card b)))
  :pattern ((Set_card (Set_union a b)))
  :pattern ((Set_card (Set_intersection a b)))
  :qid |$Set[Int]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (o Int)) (!
  (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b))))
  :pattern ((Set_in o (Set_difference a b)))
  :pattern ((Set_difference a b) (Set_in o a))
  :qid |$Set[Int]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (y Int)) (!
  (=> (Set_in y b) (not (Set_in y (Set_difference a b))))
  :pattern ((Set_difference a b) (Set_in y b))
  :qid |$Set[Int]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (and
    (=
      (+
        (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a)))
        (Set_card (Set_intersection a b)))
      (Set_card (Set_union a b)))
    (=
      (Set_card (Set_difference a b))
      (- (Set_card a) (Set_card (Set_intersection a b)))))
  :pattern ((Set_card (Set_difference a b)))
  :qid |$Set[Int]_prog.Set_diff_card|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (=
    (Set_subset a b)
    (forall ((o Int)) (!
      (=> (Set_in o a) (Set_in o b))
      :pattern ((Set_in o a))
      :pattern ((Set_in o b))
      )))
  :pattern ((Set_subset a b))
  :qid |$Set[Int]_prog.Set_subset_def|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (or
    (and (Set_equal a b) (= a b))
    (and
      (not (Set_equal a b))
      (and
        (not (= a b))
        (and
          (= (Set_skolem_diff a b) (Set_skolem_diff b a))
          (not
            (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b)))))))
  :pattern ((Set_equal a b))
  :qid |$Set[Int]_prog.Set_equal_def|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (=> (Set_equal a b) (= a b))
  :pattern ((Set_equal a b))
  :qid |$Set[Int]_prog.Set_equal_ext|)))
; End preamble
; ------------------------------------------------------------
; State saturation: after preamble
(set-option :rlimit 160000)
(check-sat)
; unknown
; ------------------------------------------------------------
; Begin function- and predicate-related preamble
; Declaring symbols related to program functions (from verification)
; Declaring symbols related to program functions (from verification)
; End function- and predicate-related preamble
; ------------------------------------------------------------
; ---------- o ----------
(declare-const l@0@01 Seq<Int>)
(declare-const l@1@01 Seq<Int>)
(set-option :rlimit 0)
(push) ; 1
(declare-const $t@2@01 $Snap)
(assert (= $t@2@01 ($Snap.combine ($Snap.first $t@2@01) ($Snap.second $t@2@01))))
(assert (= ($Snap.first $t@2@01) $Snap.unit))
; [eval] |l| == 3
; [eval] |l|
(assert (= (Seq_length l@1@01) 3))
(assert (= ($Snap.second $t@2@01) $Snap.unit))
; [eval] (forall i: Int :: { l[i] } 0 <= i && i < |l| ==> l[i] == 4)
(declare-const i@3@01 Int)
(push) ; 2
; [eval] 0 <= i && i < |l| ==> l[i] == 4
; [eval] 0 <= i && i < |l|
; [eval] 0 <= i
(push) ; 3
; [then-branch: 0 | !(0 <= i@3@01) | live]
; [else-branch: 0 | 0 <= i@3@01 | live]
(push) ; 4
; [then-branch: 0 | !(0 <= i@3@01)]
(assert (not (<= 0 i@3@01)))
(pop) ; 4
(push) ; 4
; [else-branch: 0 | 0 <= i@3@01]
(assert (<= 0 i@3@01))
; [eval] i < |l|
; [eval] |l|
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@3@01) (not (<= 0 i@3@01))))
(push) ; 3
; [then-branch: 1 | 0 <= i@3@01 && i@3@01 < |l@1@01| | live]
; [else-branch: 1 | !(0 <= i@3@01 && i@3@01 < |l@1@01|) | live]
(push) ; 4
; [then-branch: 1 | 0 <= i@3@01 && i@3@01 < |l@1@01|]
(assert (and (<= 0 i@3@01) (< i@3@01 (Seq_length l@1@01))))
; [eval] l[i] == 4
; [eval] l[i]
(push) ; 5
(assert (not (>= i@3@01 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(pop) ; 4
(push) ; 4
; [else-branch: 1 | !(0 <= i@3@01 && i@3@01 < |l@1@01|)]
(assert (not (and (<= 0 i@3@01) (< i@3@01 (Seq_length l@1@01)))))
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (or
  (not (and (<= 0 i@3@01) (< i@3@01 (Seq_length l@1@01))))
  (and (<= 0 i@3@01) (< i@3@01 (Seq_length l@1@01)))))
(pop) ; 2
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@3@01 Int)) (!
  (and
    (or (<= 0 i@3@01) (not (<= 0 i@3@01)))
    (or
      (not (and (<= 0 i@3@01) (< i@3@01 (Seq_length l@1@01))))
      (and (<= 0 i@3@01) (< i@3@01 (Seq_length l@1@01)))))
  :pattern ((Seq_index l@1@01 i@3@01))
  :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@5@24@5@74-aux|)))
(assert (forall ((i@3@01 Int)) (!
  (=>
    (and (<= 0 i@3@01) (< i@3@01 (Seq_length l@1@01)))
    (= (Seq_index l@1@01 i@3@01) 4))
  :pattern ((Seq_index l@1@01 i@3@01))
  :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@5@24@5@74|)))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
(pop) ; 2
(push) ; 2
; [exec]
; assert l[((exists i: Int, s: Set[Int] :: i == 0) ? 1 : 2)] == 4
; [eval] l[((exists i: Int, s: Set[Int] :: i == 0) ? 1 : 2)] == 4
; [eval] l[((exists i: Int, s: Set[Int] :: i == 0) ? 1 : 2)]
; [eval] ((exists i: Int, s: Set[Int] :: i == 0) ? 1 : 2)
; [eval] (exists i: Int, s: Set[Int] :: i == 0)
(declare-const i@4@01 Int)
(declare-const s@5@01 Set<Int>)
(push) ; 3
; [eval] i == 0
(pop) ; 3
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(push) ; 3
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not
  (exists ((i@4@01 Int) (s@5@01 Set<Int>)) (!
    (= i@4@01 0)
    
    :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@7@13@7@49|)))))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not (exists ((i@4@01 Int) (s@5@01 Set<Int>)) (!
  (= i@4@01 0)
  
  :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@7@13@7@49|))))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 2 | QE i@4@01,s@5@01 :: i@4@01 == 0 | live]
; [else-branch: 2 | !(QE i@4@01,s@5@01 :: i@4@01 == 0) | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 2 | QE i@4@01,s@5@01 :: i@4@01 == 0]
(assert (exists ((i@4@01 Int) (s@5@01 Set<Int>)) (!
  (= i@4@01 0)
  
  :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@7@13@7@49|)))
(pop) ; 4
(push) ; 4
; [else-branch: 2 | !(QE i@4@01,s@5@01 :: i@4@01 == 0)]
(assert (not
  (exists ((i@4@01 Int) (s@5@01 Set<Int>)) (!
    (= i@4@01 0)
    
    :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@7@13@7@49|))))
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (or
  (not
    (exists ((i@4@01 Int) (s@5@01 Set<Int>)) (!
      (= i@4@01 0)
      
      :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@7@13@7@49|)))
  (exists ((i@4@01 Int) (s@5@01 Set<Int>)) (!
    (= i@4@01 0)
    
    :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@7@13@7@49|))))
(push) ; 3
(assert (not (>=
  (ite
    (exists ((i@4@01 Int) (s@5@01 Set<Int>)) (!
      (= i@4@01 0)
      
      :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@7@13@7@49|))
    1
    2)
  0)))
(check-sat)
; unsat
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(push) ; 3
(assert (not (<
  (ite
    (exists ((i@4@01 Int) (s@5@01 Set<Int>)) (!
      (= i@4@01 0)
      
      :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@7@13@7@49|))
    1
    2)
  (Seq_length l@1@01))))
(check-sat)
; unsat
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(push) ; 3
(assert (not (=
  (Seq_index
    l@1@01
    (ite
      (exists ((i@4@01 Int) (s@5@01 Set<Int>)) (!
        (= i@4@01 0)
        
        :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@7@13@7@49|))
      1
      2))
  4)))
(check-sat)
; unsat
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(assert (=
  (Seq_index
    l@1@01
    (ite
      (exists ((i@4@01 Int) (s@5@01 Set<Int>)) (!
        (= i@4@01 0)
        
        :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@7@13@7@49|))
      1
      2))
  4))
(pop) ; 2
(pop) ; 1
; ---------- p ----------
(declare-const l@6@01 Seq<Int>)
(declare-const l@7@01 Seq<Int>)
(push) ; 1
(declare-const $t@8@01 $Snap)
(assert (= $t@8@01 ($Snap.combine ($Snap.first $t@8@01) ($Snap.second $t@8@01))))
(assert (= ($Snap.first $t@8@01) $Snap.unit))
; [eval] |l| == 3
; [eval] |l|
(assert (= (Seq_length l@7@01) 3))
(assert (= ($Snap.second $t@8@01) $Snap.unit))
; [eval] (forall i: Int :: { l[i] } 0 <= i && i < |l| ==> l[i] == 4)
(declare-const i@9@01 Int)
(push) ; 2
; [eval] 0 <= i && i < |l| ==> l[i] == 4
; [eval] 0 <= i && i < |l|
; [eval] 0 <= i
(push) ; 3
; [then-branch: 3 | !(0 <= i@9@01) | live]
; [else-branch: 3 | 0 <= i@9@01 | live]
(push) ; 4
; [then-branch: 3 | !(0 <= i@9@01)]
(assert (not (<= 0 i@9@01)))
(pop) ; 4
(push) ; 4
; [else-branch: 3 | 0 <= i@9@01]
(assert (<= 0 i@9@01))
; [eval] i < |l|
; [eval] |l|
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (or (<= 0 i@9@01) (not (<= 0 i@9@01))))
(push) ; 3
; [then-branch: 4 | 0 <= i@9@01 && i@9@01 < |l@7@01| | live]
; [else-branch: 4 | !(0 <= i@9@01 && i@9@01 < |l@7@01|) | live]
(push) ; 4
; [then-branch: 4 | 0 <= i@9@01 && i@9@01 < |l@7@01|]
(assert (and (<= 0 i@9@01) (< i@9@01 (Seq_length l@7@01))))
; [eval] l[i] == 4
; [eval] l[i]
(push) ; 5
(assert (not (>= i@9@01 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(pop) ; 4
(push) ; 4
; [else-branch: 4 | !(0 <= i@9@01 && i@9@01 < |l@7@01|)]
(assert (not (and (<= 0 i@9@01) (< i@9@01 (Seq_length l@7@01)))))
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (or
  (not (and (<= 0 i@9@01) (< i@9@01 (Seq_length l@7@01))))
  (and (<= 0 i@9@01) (< i@9@01 (Seq_length l@7@01)))))
(pop) ; 2
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(assert (forall ((i@9@01 Int)) (!
  (and
    (or (<= 0 i@9@01) (not (<= 0 i@9@01)))
    (or
      (not (and (<= 0 i@9@01) (< i@9@01 (Seq_length l@7@01))))
      (and (<= 0 i@9@01) (< i@9@01 (Seq_length l@7@01)))))
  :pattern ((Seq_index l@7@01 i@9@01))
  :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@11@24@11@74-aux|)))
(assert (forall ((i@9@01 Int)) (!
  (=>
    (and (<= 0 i@9@01) (< i@9@01 (Seq_length l@7@01)))
    (= (Seq_index l@7@01 i@9@01) 4))
  :pattern ((Seq_index l@7@01 i@9@01))
  :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@11@24@11@74|)))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
(pop) ; 2
(push) ; 2
; [exec]
; assert l[((exists i: Int, s: Seq[Int] :: i == 0) ? 1 : 2)] == 4
; [eval] l[((exists i: Int, s: Seq[Int] :: i == 0) ? 1 : 2)] == 4
; [eval] l[((exists i: Int, s: Seq[Int] :: i == 0) ? 1 : 2)]
; [eval] ((exists i: Int, s: Seq[Int] :: i == 0) ? 1 : 2)
; [eval] (exists i: Int, s: Seq[Int] :: i == 0)
(declare-const i@10@01 Int)
(declare-const s@11@01 Seq<Int>)
(push) ; 3
; [eval] i == 0
(pop) ; 3
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
(push) ; 3
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not
  (exists ((i@10@01 Int) (s@11@01 Seq<Int>)) (!
    (= i@10@01 0)
    
    :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@13@13@13@49|)))))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not (exists ((i@10@01 Int) (s@11@01 Seq<Int>)) (!
  (= i@10@01 0)
  
  :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@13@13@13@49|))))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 5 | QE i@10@01,s@11@01 :: i@10@01 == 0 | live]
; [else-branch: 5 | !(QE i@10@01,s@11@01 :: i@10@01 == 0) | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 5 | QE i@10@01,s@11@01 :: i@10@01 == 0]
(assert (exists ((i@10@01 Int) (s@11@01 Seq<Int>)) (!
  (= i@10@01 0)
  
  :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@13@13@13@49|)))
(pop) ; 4
(push) ; 4
; [else-branch: 5 | !(QE i@10@01,s@11@01 :: i@10@01 == 0)]
(assert (not
  (exists ((i@10@01 Int) (s@11@01 Seq<Int>)) (!
    (= i@10@01 0)
    
    :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@13@13@13@49|))))
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(assert (or
  (not
    (exists ((i@10@01 Int) (s@11@01 Seq<Int>)) (!
      (= i@10@01 0)
      
      :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@13@13@13@49|)))
  (exists ((i@10@01 Int) (s@11@01 Seq<Int>)) (!
    (= i@10@01 0)
    
    :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@13@13@13@49|))))
(push) ; 3
(assert (not (>=
  (ite
    (exists ((i@10@01 Int) (s@11@01 Seq<Int>)) (!
      (= i@10@01 0)
      
      :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@13@13@13@49|))
    1
    2)
  0)))
(check-sat)
; unsat
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(push) ; 3
(assert (not (<
  (ite
    (exists ((i@10@01 Int) (s@11@01 Seq<Int>)) (!
      (= i@10@01 0)
      
      :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@13@13@13@49|))
    1
    2)
  (Seq_length l@7@01))))
(check-sat)
; unsat
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(push) ; 3
(assert (not (=
  (Seq_index
    l@7@01
    (ite
      (exists ((i@10@01 Int) (s@11@01 Seq<Int>)) (!
        (= i@10@01 0)
        
        :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@13@13@13@49|))
      1
      2))
  4)))
(check-sat)
; unsat
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(assert (=
  (Seq_index
    l@7@01
    (ite
      (exists ((i@10@01 Int) (s@11@01 Seq<Int>)) (!
        (= i@10@01 0)
        
        :qid |prog./root/evaluation/2_performance/sequences/0465.vpr@13@13@13@49|))
      1
      2))
  4))
(pop) ; 2
(pop) ; 1
