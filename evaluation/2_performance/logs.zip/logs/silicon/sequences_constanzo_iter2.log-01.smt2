(get-info :version)
; (:version "4.8.7")
; Started: 2025-12-05 13:05:10
; Silicon.version: 1.1-SNAPSHOT (95328487@(detached))
; Input file: ./sequences/constanzo.vpr
; Verifier id: 00
; ------------------------------------------------------------
; Begin preamble
; ////////// Static preamble
; 
; ; /z3config.smt2
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :smt.qi.max_multi_patterns 1000)
; 
; ; /preamble.smt2
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(define-fun $Perm.min ((p1 $Perm) (p2 $Perm)) Real
    (ite (<= p1 p2) p1 p2))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
; ////////// Sorts
(declare-sort Seq<Int> 0)
; ////////// Sort wrappers
; Declaring additional sort wrappers
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.Seq<Int>To$Snap (Seq<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<Int> ($Snap) Seq<Int>)
(assert (forall ((x Seq<Int>)) (!
    (= x ($SortWrappers.$SnapToSeq<Int>($SortWrappers.Seq<Int>To$Snap x)))
    :pattern (($SortWrappers.Seq<Int>To$Snap x))
    :qid |$Snap.$SnapToSeq<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<Int>To$Snap($SortWrappers.$SnapToSeq<Int> x)))
    :pattern (($SortWrappers.$SnapToSeq<Int> x))
    :qid |$Snap.Seq<Int>To$SnapToSeq<Int>|
    )))
; ////////// Symbols
(declare-fun Seq_length (Seq<Int>) Int)
(declare-const Seq_empty Seq<Int>)
(declare-fun Seq_singleton (Int) Seq<Int>)
(declare-fun Seq_append (Seq<Int> Seq<Int>) Seq<Int>)
(declare-fun Seq_index (Seq<Int> Int) Int)
(declare-fun Seq_add (Int Int) Int)
(declare-fun Seq_sub (Int Int) Int)
(declare-fun Seq_update (Seq<Int> Int Int) Seq<Int>)
(declare-fun Seq_take (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_drop (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_contains (Seq<Int> Int) Bool)
(declare-fun Seq_contains_trigger (Seq<Int> Int) Bool)
(declare-fun Seq_skolem (Seq<Int> Int) Int)
(declare-fun Seq_equal (Seq<Int> Seq<Int>) Bool)
(declare-fun Seq_skolem_diff (Seq<Int> Seq<Int>) Int)
(declare-fun Seq_range (Int Int) Seq<Int>)
; Declaring symbols related to program functions (from program analysis)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
; Declaring predicate trigger functions
; ////////// Uniqueness assumptions from domains
; ////////// Axioms
(assert (forall ((s Seq<Int>)) (!
  (<= 0 (Seq_length s))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty  Seq<Int>)) 0))
(assert (forall ((s Seq<Int>)) (!
  (=> (= (Seq_length s) 0) (= s (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_zero|)))
(assert (forall ((e Int)) (!
  (= (Seq_length (Seq_singleton e)) 1)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (not (= s1 (as Seq_empty  Seq<Int>))))
    (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1))))
  :pattern ((Seq_length (Seq_append s0 s1)))
  :qid |$Seq[Int]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (and
    (=> (= s0 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s1))
    (=> (= s1 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s0)))
  :pattern ((Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_empty|)))
(assert (forall ((e Int)) (!
  (= (Seq_index (Seq_singleton e) 0) e)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_add i j) (+ i j))
  :pattern ((Seq_add i j))
  :qid |$Seq[Int]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_sub i j) (- i j))
  :pattern ((Seq_sub i j))
  :qid |$Seq[Int]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= 0 n) (< n (Seq_length s0)))))
    (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n)))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :pattern ((Seq_index s0 n) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1))))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n)
      (=
        (Seq_index (Seq_append s0 s1) n)
        (Seq_index s1 (Seq_sub n (Seq_length s0))))))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :qid |$Seq[Int]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (m Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= 0 m) (< m (Seq_length s1)))))
    (and
      (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m)
      (=
        (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0)))
        (Seq_index s1 m))))
  :pattern ((Seq_index s1 m) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (Seq_length (Seq_update s i v)) (Seq_length s)))
  :pattern ((Seq_length (Seq_update s i v)))
  :pattern ((Seq_length s) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_length|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int) (n Int)) (!
  (=>
    (and (<= 0 n) (< n (Seq_length s)))
    (and
      (=> (= i n) (= (Seq_index (Seq_update s i v) n) v))
      (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n)))))
  :pattern ((Seq_index (Seq_update s i v) n))
  :pattern ((Seq_index s n) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s)))))
    (=> (< n 0) (= (Seq_length (Seq_take s n)) 0)))
  :pattern ((Seq_length (Seq_take s n)))
  :pattern ((Seq_take s n) (Seq_length s))
  :qid |$Seq[Int]_prog.Seq_take_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (<= 0 j) (and (< j n) (< j (Seq_length s))))
    (= (Seq_index (Seq_take s n) j) (Seq_index s j)))
  :pattern ((Seq_index (Seq_take s n) j))
  :pattern ((Seq_index s j) (Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=>
          (<= n (Seq_length s))
          (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n)))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0))))
    (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s))))
  :pattern ((Seq_length (Seq_drop s n)))
  :pattern ((Seq_length s) (Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n))))
    (and
      (= (Seq_sub (Seq_add j n) n) j)
      (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n)))))
  :pattern ((Seq_index (Seq_drop s n) j))
  :qid |$Seq[Int]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<Int>) (n Int) (i Int)) (!
  (=>
    (and (< 0 n) (and (<= n i) (< i (Seq_length s))))
    (and
      (= (Seq_add (Seq_sub i n) n) i)
      (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i))))
  :pattern ((Seq_drop s n) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_take (Seq_append s t) n) (Seq_take s n)))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (=
        (Seq_take (Seq_append s t) n)
        (Seq_append s (Seq_take t (Seq_sub n (Seq_length s)))))))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t)))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (> n (Seq_length s)))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s))))))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_take s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_drop s n) s))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_take s n) s))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_all|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<Int>) (x Int)) (!
  (=>
    (Seq_contains s x)
    (and
      (<= 0 (Seq_skolem s x))
      (and
        (< (Seq_skolem s x) (Seq_length s))
        (= (Seq_index s (Seq_skolem s x)) x))))
  :pattern ((Seq_contains s x))
  :qid |$Seq[Int]_prog.Seq_contains1|)))
(assert (forall ((s Seq<Int>) (x Int) (i Int)) (!
  (=>
    (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x)))
    (Seq_contains s x))
  :pattern ((Seq_contains s x) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains2|)))
(assert (forall ((s Seq<Int>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (Seq_contains_trigger s (Seq_index s i)))
  :pattern ((Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (or
    (and (= s0 s1) (Seq_equal s0 s1))
    (or
      (and
        (not (= s0 s1))
        (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1)))))
      (and
        (not (= s0 s1))
        (and
          (not (Seq_equal s0 s1))
          (and
            (= (Seq_length s0) (Seq_length s1))
            (and
              (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0))
              (and
                (<= 0 (Seq_skolem_diff s0 s1))
                (and
                  (< (Seq_skolem_diff s0 s1) (Seq_length s0))
                  (not
                    (=
                      (Seq_index s0 (Seq_skolem_diff s0 s1))
                      (Seq_index s1 (Seq_skolem_diff s0 s1))))))))))))
  :pattern ((Seq_equal s0 s1))
  :qid |$Seq[Int]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<Int>) (b Seq<Int>)) (!
  (=> (Seq_equal a b) (= a b))
  :pattern ((Seq_equal a b))
  :qid |$Seq[Int]_prog.Seq_equal_ext|)))
(assert (forall ((x Int) (y Int)) (!
  (= (Seq_contains (Seq_singleton x) y) (= x y))
  :pattern ((Seq_contains (Seq_singleton x) y))
  :qid |$Seq[Int]_prog.Seq_singleton_contains|)))
(assert (forall ((min_ Int) (max Int)) (!
  (and
    (=> (< min_ max) (= (Seq_length (Seq_range min_ max)) (- max min_)))
    (=> (<= max min_) (= (Seq_length (Seq_range min_ max)) 0)))
  :pattern ((Seq_length (Seq_range min_ max)))
  :qid |$Seq[Int]_prog.Seq_range_length|)))
(assert (forall ((min_ Int) (max Int) (j Int)) (!
  (=>
    (and (<= 0 j) (< j (- max min_)))
    (= (Seq_index (Seq_range min_ max) j) (+ min_ j)))
  :pattern ((Seq_index (Seq_range min_ max) j))
  :qid |$Seq[Int]_prog.Seq_range_index|)))
(assert (forall ((min_ Int) (max Int) (v Int)) (!
  (= (Seq_contains (Seq_range min_ max) v) (and (<= min_ v) (< v max)))
  :pattern ((Seq_contains (Seq_range min_ max) v))
  :qid |$Seq[Int]_prog.Seq_range_contains|)))
; End preamble
; ------------------------------------------------------------
; State saturation: after preamble
(set-option :rlimit 160000)
(check-sat)
; unknown
; ------------------------------------------------------------
; Begin function- and predicate-related preamble
; Declaring symbols related to program functions (from verification)
; Declaring symbols related to program functions (from verification)
; End function- and predicate-related preamble
; ------------------------------------------------------------
; ---------- main ----------
(declare-const p0_0@0@01 Bool)
(declare-const p1_0@1@01 Bool)
(declare-const A@2@01 Seq<Int>)
(declare-const A_0@3@01 Seq<Int>)
(declare-const p0_0@4@01 Bool)
(declare-const p1_0@5@01 Bool)
(declare-const A@6@01 Seq<Int>)
(declare-const A_0@7@01 Seq<Int>)
(set-option :rlimit 0)
(push) ; 1
(declare-const $t@8@01 $Snap)
(assert (= $t@8@01 ($Snap.combine ($Snap.first $t@8@01) ($Snap.second $t@8@01))))
(assert (= ($Snap.first $t@8@01) $Snap.unit))
; [eval] p0_0 ==> |A| == 64
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p0_0@4@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p0_0@4@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 0 | p0_0@4@01 | live]
; [else-branch: 0 | !(p0_0@4@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 0 | p0_0@4@01]
(assert p0_0@4@01)
; [eval] |A| == 64
; [eval] |A|
(pop) ; 3
(push) ; 3
; [else-branch: 0 | !(p0_0@4@01)]
(assert (not p0_0@4@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not p0_0@4@01) p0_0@4@01))
(assert (=> p0_0@4@01 (= (Seq_length A@6@01) 64)))
(assert (=
  ($Snap.second $t@8@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@8@01))
    ($Snap.second ($Snap.second $t@8@01)))))
(assert (= ($Snap.first ($Snap.second $t@8@01)) $Snap.unit))
; [eval] p1_0 ==> |A_0| == 64
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p1_0@5@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p1_0@5@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1 | p1_0@5@01 | live]
; [else-branch: 1 | !(p1_0@5@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 1 | p1_0@5@01]
(assert p1_0@5@01)
; [eval] |A_0| == 64
; [eval] |A_0|
(pop) ; 3
(push) ; 3
; [else-branch: 1 | !(p1_0@5@01)]
(assert (not p1_0@5@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not p1_0@5@01) p1_0@5@01))
(assert (=> p1_0@5@01 (= (Seq_length A_0@7@01) 64)))
(assert (=
  ($Snap.second ($Snap.second $t@8@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@8@01)))
    ($Snap.second ($Snap.second ($Snap.second $t@8@01))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@8@01))) $Snap.unit))
; [eval] p0_0 == p1_0
(assert (= p0_0@4@01 p1_0@5@01))
(assert (= ($Snap.second ($Snap.second ($Snap.second $t@8@01))) $Snap.unit))
; [eval] (forall i: Int ::(p0_0 ==> true) && (p1_0 ==> true))
(declare-const i@9@01 Int)
(push) ; 2
; [eval] (p0_0 ==> true) && (p1_0 ==> true)
; [eval] p0_0 ==> true
(push) ; 3
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not p0_0@4@01)))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not p0_0@4@01))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 2 | p0_0@4@01 | live]
; [else-branch: 2 | !(p0_0@4@01) | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 2 | p0_0@4@01]
(assert p0_0@4@01)
(pop) ; 4
(push) ; 4
; [else-branch: 2 | !(p0_0@4@01)]
(assert (not p0_0@4@01))
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(push) ; 3
; [then-branch: 3 | False | live]
; [else-branch: 3 | True | live]
(push) ; 4
; [then-branch: 3 | False]
(assert false)
(pop) ; 4
(push) ; 4
; [else-branch: 3 | True]
; [eval] p1_0 ==> true
(push) ; 5
(push) ; 6
(set-option :rlimit 16000)
(assert (not (not p1_0@5@01)))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
(set-option :rlimit 16000)
(assert (not p1_0@5@01))
(check-sat)
; unknown
(pop) ; 6
; 0.01s
; (get-info :all-statistics)
; [then-branch: 4 | p1_0@5@01 | live]
; [else-branch: 4 | !(p1_0@5@01) | live]
(set-option :rlimit 0)
(push) ; 6
; [then-branch: 4 | p1_0@5@01]
(assert p1_0@5@01)
(pop) ; 6
(push) ; 6
; [else-branch: 4 | !(p1_0@5@01)]
(assert (not p1_0@5@01))
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(pop) ; 4
(pop) ; 3
; Joined path conditions
; Joined path conditions
(pop) ; 2
; Nested auxiliary terms: globals (aux)
; Nested auxiliary terms: non-globals (aux)
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
(pop) ; 2
(push) ; 2
; [exec]
; var i: Int
(declare-const i@10@01 Int)
; [exec]
; var _cond0: Bool
(declare-const _cond0@11@01 Bool)
; [exec]
; var i_0: Int
(declare-const i_0@12@01 Int)
; [exec]
; var _cond0_0: Bool
(declare-const _cond0_0@13@01 Bool)
; [exec]
; var tmp0: Int
(declare-const tmp0@14@01 Int)
; [exec]
; var tmp1: Int
(declare-const tmp1@15@01 Int)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p0_0@4@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p0_0@4@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 5 | p0_0@4@01 | live]
; [else-branch: 5 | !(p0_0@4@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 5 | p0_0@4@01]
(assert p0_0@4@01)
; [exec]
; _cond0 := false
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not p1_0@5@01)))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not p1_0@5@01))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 6 | p1_0@5@01 | live]
; [else-branch: 6 | !(p1_0@5@01) | dead]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 6 | p1_0@5@01]
(assert p1_0@5@01)
; [exec]
; _cond0_0 := false
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not p0_0@4@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 7 | p0_0@4@01 | live]
; [else-branch: 7 | !(p0_0@4@01) | dead]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 7 | p0_0@4@01]
; [exec]
; i := 0
(push) ; 6
(set-option :rlimit 16000)
(assert (not (not p1_0@5@01)))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [then-branch: 8 | p1_0@5@01 | live]
; [else-branch: 8 | !(p1_0@5@01) | dead]
(set-option :rlimit 0)
(push) ; 6
; [then-branch: 8 | p1_0@5@01]
; [exec]
; i_0 := 0
; [eval] !p0_0
; [then-branch: 9 | !(p0_0@4@01) | dead]
; [else-branch: 9 | p0_0@4@01 | live]
(push) ; 7
; [else-branch: 9 | p0_0@4@01]
(pop) ; 7
; [eval] !!p0_0
; [eval] !p0_0
(push) ; 7
(set-option :rlimit 16000)
(assert (not (not p0_0@4@01)))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 10 | p0_0@4@01 | live]
; [else-branch: 10 | !(p0_0@4@01) | dead]
(set-option :rlimit 0)
(push) ; 7
; [then-branch: 10 | p0_0@4@01]
; [eval] !p1_0
; [then-branch: 11 | !(p1_0@5@01) | dead]
; [else-branch: 11 | p1_0@5@01 | live]
(push) ; 8
; [else-branch: 11 | p1_0@5@01]
(pop) ; 8
; [eval] !!p1_0
; [eval] !p1_0
(push) ; 8
(set-option :rlimit 16000)
(assert (not (not p1_0@5@01)))
(check-sat)
; unknown
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
; [then-branch: 12 | p1_0@5@01 | live]
; [else-branch: 12 | !(p1_0@5@01) | dead]
(set-option :rlimit 0)
(push) ; 8
; [then-branch: 12 | p1_0@5@01]
(declare-const p0_1@16@01 Bool)
(declare-const p1_1@17@01 Bool)
(declare-const x@18@01 Int)
(declare-const x_0@19@01 Int)
(declare-const pt0@20@01 Bool)
(declare-const pt1@21@01 Bool)
(declare-const pf0@22@01 Bool)
(declare-const pf1@23@01 Bool)
(declare-const tmp0_0@24@01 Int)
(declare-const tmp1_0@25@01 Int)
(declare-const i@26@01 Int)
(declare-const i_0@27@01 Int)
(push) ; 9
; Loop head block: Check well-definedness of invariant
(declare-const $t@28@01 $Snap)
(assert (= $t@28@01 ($Snap.combine ($Snap.first $t@28@01) ($Snap.second $t@28@01))))
(assert (= ($Snap.first $t@28@01) $Snap.unit))
; [eval] p0_0 ==> i >= 0
(push) ; 10
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not p0_0@4@01)))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 13 | p0_0@4@01 | live]
; [else-branch: 13 | !(p0_0@4@01) | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 13 | p0_0@4@01]
; [eval] i >= 0
(pop) ; 11
(pop) ; 10
; Joined path conditions
(assert (=> p0_0@4@01 (>= i@26@01 0)))
(assert (=
  ($Snap.second $t@28@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@28@01))
    ($Snap.second ($Snap.second $t@28@01)))))
(assert (= ($Snap.first ($Snap.second $t@28@01)) $Snap.unit))
; [eval] p1_0 ==> i_0 >= 0
(push) ; 10
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not p1_0@5@01)))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 14 | p1_0@5@01 | live]
; [else-branch: 14 | !(p1_0@5@01) | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 14 | p1_0@5@01]
; [eval] i_0 >= 0
(pop) ; 11
(pop) ; 10
; Joined path conditions
(assert (=> p1_0@5@01 (>= i_0@27@01 0)))
(assert (=
  ($Snap.second ($Snap.second $t@28@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@28@01)))
    ($Snap.second ($Snap.second ($Snap.second $t@28@01))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@28@01))) $Snap.unit))
; [eval] p0_0 ==> i <= 64
(push) ; 10
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not p0_0@4@01)))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 15 | p0_0@4@01 | live]
; [else-branch: 15 | !(p0_0@4@01) | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 15 | p0_0@4@01]
; [eval] i <= 64
(pop) ; 11
(pop) ; 10
; Joined path conditions
(assert (=> p0_0@4@01 (<= i@26@01 64)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second $t@28@01)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@28@01))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01)))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@28@01))))
  $Snap.unit))
; [eval] p1_0 ==> i_0 <= 64
(push) ; 10
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not p1_0@5@01)))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 16 | p1_0@5@01 | live]
; [else-branch: 16 | !(p1_0@5@01) | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 16 | p1_0@5@01]
; [eval] i_0 <= 64
(pop) ; 11
(pop) ; 10
; Joined path conditions
(assert (=> p1_0@5@01 (<= i_0@27@01 64)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01)))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01)))))
  $Snap.unit))
; [eval] p0_0 ==> p0_0 && p1_0 ==> i == i_0
(push) ; 10
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not p0_0@4@01)))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 17 | p0_0@4@01 | live]
; [else-branch: 17 | !(p0_0@4@01) | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 17 | p0_0@4@01]
; [eval] p0_0 && p1_0 ==> i == i_0
; [eval] p0_0 && p1_0
(push) ; 12
; [then-branch: 18 | !(p0_0@4@01) | live]
; [else-branch: 18 | p0_0@4@01 | live]
(push) ; 13
; [then-branch: 18 | !(p0_0@4@01)]
(assert (not p0_0@4@01))
(pop) ; 13
(push) ; 13
; [else-branch: 18 | p0_0@4@01]
(pop) ; 13
(pop) ; 12
; Joined path conditions
; Joined path conditions
(assert (or p0_0@4@01 (not p0_0@4@01)))
(push) ; 12
(push) ; 13
(set-option :rlimit 16000)
(assert (not (not (and p0_0@4@01 p1_0@5@01))))
(check-sat)
; unknown
(pop) ; 13
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 16000)
(assert (not (and p0_0@4@01 p1_0@5@01)))
(check-sat)
; unsat
(pop) ; 13
; 0.00s
; (get-info :all-statistics)
; [then-branch: 19 | p0_0@4@01 && p1_0@5@01 | live]
; [else-branch: 19 | !(p0_0@4@01 && p1_0@5@01) | dead]
(set-option :rlimit 0)
(push) ; 13
; [then-branch: 19 | p0_0@4@01 && p1_0@5@01]
(assert (and p0_0@4@01 p1_0@5@01))
; [eval] i == i_0
(pop) ; 13
(pop) ; 12
; Joined path conditions
(assert (and p0_0@4@01 p1_0@5@01))
(pop) ; 11
(pop) ; 10
; Joined path conditions
(assert (=> p0_0@4@01 (and (or p0_0@4@01 (not p0_0@4@01)) p0_0@4@01 p1_0@5@01)))
(assert p0_0@4@01)
(assert (=> (and p0_0@4@01 (and p0_0@4@01 p1_0@5@01)) (= i@26@01 i_0@27@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01)))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01)))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01))))))
  $Snap.unit))
; [eval] p1_0 ==> true
(push) ; 10
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not p1_0@5@01)))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 16000)
(assert (not p1_0@5@01))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 20 | p1_0@5@01 | live]
; [else-branch: 20 | !(p1_0@5@01) | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 20 | p1_0@5@01]
(assert p1_0@5@01)
(pop) ; 11
(pop) ; 10
; Joined path conditions
(assert p1_0@5@01)
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01)))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01)))))))
  $Snap.unit))
; [eval] !p0_0 ==> tmp0 == i
; [eval] !p0_0
(push) ; 10
; [then-branch: 21 | !(p0_0@4@01) | dead]
; [else-branch: 21 | p0_0@4@01 | live]
(push) ; 11
; [else-branch: 21 | p0_0@4@01]
(pop) ; 11
(pop) ; 10
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01)))))))
  $Snap.unit))
; [eval] !p1_0 ==> tmp1 == i_0
; [eval] !p1_0
(push) ; 10
; [then-branch: 22 | !(p1_0@5@01) | dead]
; [else-branch: 22 | p1_0@5@01 | live]
(push) ; 11
; [else-branch: 22 | p1_0@5@01]
(pop) ; 11
(pop) ; 10
; Joined path conditions
(pop) ; 9
(push) ; 9
; Loop head block: Establish invariant
; [eval] p0_0 ==> i >= 0
(push) ; 10
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not p0_0@4@01)))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 16000)
(assert (not p0_0@4@01))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 23 | p0_0@4@01 | live]
; [else-branch: 23 | !(p0_0@4@01) | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 23 | p0_0@4@01]
(assert p0_0@4@01)
; [eval] i >= 0
(pop) ; 11
(pop) ; 10
; Joined path conditions
(assert p0_0@4@01)
; [eval] p1_0 ==> i_0 >= 0
(push) ; 10
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not p1_0@5@01)))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 16000)
(assert (not p1_0@5@01))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 24 | p1_0@5@01 | live]
; [else-branch: 24 | !(p1_0@5@01) | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 24 | p1_0@5@01]
(assert p1_0@5@01)
; [eval] i_0 >= 0
(pop) ; 11
(pop) ; 10
; Joined path conditions
(assert p1_0@5@01)
; [eval] p0_0 ==> i <= 64
(push) ; 10
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not p0_0@4@01)))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 25 | p0_0@4@01 | live]
; [else-branch: 25 | !(p0_0@4@01) | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 25 | p0_0@4@01]
; [eval] i <= 64
(pop) ; 11
(pop) ; 10
; Joined path conditions
; [eval] p1_0 ==> i_0 <= 64
(push) ; 10
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not p1_0@5@01)))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 26 | p1_0@5@01 | live]
; [else-branch: 26 | !(p1_0@5@01) | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 26 | p1_0@5@01]
; [eval] i_0 <= 64
(pop) ; 11
(pop) ; 10
; Joined path conditions
; [eval] p0_0 ==> p0_0 && p1_0 ==> i == i_0
(push) ; 10
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not p0_0@4@01)))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 27 | p0_0@4@01 | live]
; [else-branch: 27 | !(p0_0@4@01) | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 27 | p0_0@4@01]
; [eval] p0_0 && p1_0 ==> i == i_0
; [eval] p0_0 && p1_0
(push) ; 12
; [then-branch: 28 | !(p0_0@4@01) | live]
; [else-branch: 28 | p0_0@4@01 | live]
(push) ; 13
; [then-branch: 28 | !(p0_0@4@01)]
(assert (not p0_0@4@01))
(pop) ; 13
(push) ; 13
; [else-branch: 28 | p0_0@4@01]
(pop) ; 13
(pop) ; 12
; Joined path conditions
; Joined path conditions
(assert (or p0_0@4@01 (not p0_0@4@01)))
(push) ; 12
(push) ; 13
(set-option :rlimit 16000)
(assert (not (not (and p0_0@4@01 p1_0@5@01))))
(check-sat)
; unknown
(pop) ; 13
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 16000)
(assert (not (and p0_0@4@01 p1_0@5@01)))
(check-sat)
; unsat
(pop) ; 13
; 0.00s
; (get-info :all-statistics)
; [then-branch: 29 | p0_0@4@01 && p1_0@5@01 | live]
; [else-branch: 29 | !(p0_0@4@01 && p1_0@5@01) | dead]
(set-option :rlimit 0)
(push) ; 13
; [then-branch: 29 | p0_0@4@01 && p1_0@5@01]
(assert (and p0_0@4@01 p1_0@5@01))
; [eval] i == i_0
(pop) ; 13
(pop) ; 12
; Joined path conditions
(assert (and p0_0@4@01 p1_0@5@01))
(pop) ; 11
(pop) ; 10
; Joined path conditions
(assert (=> p0_0@4@01 (and (or p0_0@4@01 (not p0_0@4@01)) p0_0@4@01 p1_0@5@01)))
(assert p0_0@4@01)
; [eval] p1_0 ==> true
(push) ; 10
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not p1_0@5@01)))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 16000)
(assert (not p1_0@5@01))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 30 | p1_0@5@01 | live]
; [else-branch: 30 | !(p1_0@5@01) | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 30 | p1_0@5@01]
(assert p1_0@5@01)
(pop) ; 11
(pop) ; 10
; Joined path conditions
(assert p1_0@5@01)
; [eval] !p0_0 ==> tmp0 == i
; [eval] !p0_0
(push) ; 10
; [then-branch: 31 | !(p0_0@4@01) | dead]
; [else-branch: 31 | p0_0@4@01 | live]
(push) ; 11
; [else-branch: 31 | p0_0@4@01]
(pop) ; 11
(pop) ; 10
; Joined path conditions
; [eval] !p1_0 ==> tmp1 == i_0
; [eval] !p1_0
(push) ; 10
; [then-branch: 32 | !(p1_0@5@01) | dead]
; [else-branch: 32 | p1_0@5@01 | live]
(push) ; 11
; [else-branch: 32 | p1_0@5@01]
(pop) ; 11
(pop) ; 10
; Joined path conditions
; Loop head block: Execute statements of loop head block (in invariant state)
(push) ; 10
(assert (= $t@28@01 ($Snap.combine ($Snap.first $t@28@01) ($Snap.second $t@28@01))))
(assert (= ($Snap.first $t@28@01) $Snap.unit))
(assert (=> p0_0@4@01 (>= i@26@01 0)))
(assert (=
  ($Snap.second $t@28@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@28@01))
    ($Snap.second ($Snap.second $t@28@01)))))
(assert (= ($Snap.first ($Snap.second $t@28@01)) $Snap.unit))
(assert (=> p1_0@5@01 (>= i_0@27@01 0)))
(assert (=
  ($Snap.second ($Snap.second $t@28@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@28@01)))
    ($Snap.second ($Snap.second ($Snap.second $t@28@01))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@28@01))) $Snap.unit))
(assert (=> p0_0@4@01 (<= i@26@01 64)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second $t@28@01)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@28@01))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01)))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@28@01))))
  $Snap.unit))
(assert (=> p1_0@5@01 (<= i_0@27@01 64)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01)))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01)))))
  $Snap.unit))
(assert (=> (and p0_0@4@01 (and p0_0@4@01 p1_0@5@01)) (= i@26@01 i_0@27@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01)))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01)))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01)))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01)))))))
  $Snap.unit))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@28@01)))))))
  $Snap.unit))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 16000)
(check-sat)
; unknown
; Loop head block: Check well-definedness of edge conditions
(set-option :rlimit 0)
(push) ; 11
; [eval] p0_0 && i < 64 || p1_0 && i_0 < 64
; [eval] p0_0 && i < 64
(push) ; 12
; [then-branch: 33 | !(p0_0@4@01) | live]
; [else-branch: 33 | p0_0@4@01 | live]
(push) ; 13
; [then-branch: 33 | !(p0_0@4@01)]
(assert (not p0_0@4@01))
(pop) ; 13
(push) ; 13
; [else-branch: 33 | p0_0@4@01]
; [eval] i < 64
(pop) ; 13
(pop) ; 12
; Joined path conditions
; Joined path conditions
(assert (or p0_0@4@01 (not p0_0@4@01)))
(push) ; 12
; [then-branch: 34 | p0_0@4@01 && i@26@01 < 64 | live]
; [else-branch: 34 | !(p0_0@4@01 && i@26@01 < 64) | live]
(push) ; 13
; [then-branch: 34 | p0_0@4@01 && i@26@01 < 64]
(assert (and p0_0@4@01 (< i@26@01 64)))
(pop) ; 13
(push) ; 13
; [else-branch: 34 | !(p0_0@4@01 && i@26@01 < 64)]
(assert (not (and p0_0@4@01 (< i@26@01 64))))
; [eval] p1_0 && i_0 < 64
(push) ; 14
; [then-branch: 35 | !(p1_0@5@01) | live]
; [else-branch: 35 | p1_0@5@01 | live]
(push) ; 15
; [then-branch: 35 | !(p1_0@5@01)]
(assert (not p1_0@5@01))
(pop) ; 15
(push) ; 15
; [else-branch: 35 | p1_0@5@01]
; [eval] i_0 < 64
(pop) ; 15
(pop) ; 14
; Joined path conditions
; Joined path conditions
(assert (or p1_0@5@01 (not p1_0@5@01)))
(pop) ; 13
(pop) ; 12
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0_0@4@01 (< i@26@01 64)))
  (and (not (and p0_0@4@01 (< i@26@01 64))) (or p1_0@5@01 (not p1_0@5@01)))))
(assert (or (not (and p0_0@4@01 (< i@26@01 64))) (and p0_0@4@01 (< i@26@01 64))))
(pop) ; 11
(push) ; 11
; [eval] !(p0_0 && i < 64 || p1_0 && i_0 < 64)
; [eval] p0_0 && i < 64 || p1_0 && i_0 < 64
; [eval] p0_0 && i < 64
(push) ; 12
; [then-branch: 36 | !(p0_0@4@01) | live]
; [else-branch: 36 | p0_0@4@01 | live]
(push) ; 13
; [then-branch: 36 | !(p0_0@4@01)]
(assert (not p0_0@4@01))
(pop) ; 13
(push) ; 13
; [else-branch: 36 | p0_0@4@01]
(assert p0_0@4@01)
; [eval] i < 64
(pop) ; 13
(pop) ; 12
; Joined path conditions
; Joined path conditions
(assert (or p0_0@4@01 (not p0_0@4@01)))
(push) ; 12
; [then-branch: 37 | p0_0@4@01 && i@26@01 < 64 | live]
; [else-branch: 37 | !(p0_0@4@01 && i@26@01 < 64) | live]
(push) ; 13
; [then-branch: 37 | p0_0@4@01 && i@26@01 < 64]
(assert (and p0_0@4@01 (< i@26@01 64)))
(pop) ; 13
(push) ; 13
; [else-branch: 37 | !(p0_0@4@01 && i@26@01 < 64)]
(assert (not (and p0_0@4@01 (< i@26@01 64))))
; [eval] p1_0 && i_0 < 64
(push) ; 14
; [then-branch: 38 | !(p1_0@5@01) | live]
; [else-branch: 38 | p1_0@5@01 | live]
(push) ; 15
; [then-branch: 38 | !(p1_0@5@01)]
(assert (not p1_0@5@01))
(pop) ; 15
(push) ; 15
; [else-branch: 38 | p1_0@5@01]
; [eval] i_0 < 64
(pop) ; 15
(pop) ; 14
; Joined path conditions
; Joined path conditions
(assert (or p1_0@5@01 (not p1_0@5@01)))
(pop) ; 13
(pop) ; 12
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0_0@4@01 (< i@26@01 64)))
  (and (not (and p0_0@4@01 (< i@26@01 64))) (or p1_0@5@01 (not p1_0@5@01)))))
(assert (or (not (and p0_0@4@01 (< i@26@01 64))) (and p0_0@4@01 (< i@26@01 64))))
(pop) ; 11
; Loop head block: Follow loop-internal edges
; [eval] p0_0 && i < 64 || p1_0 && i_0 < 64
; [eval] p0_0 && i < 64
(push) ; 11
; [then-branch: 39 | !(p0_0@4@01) | live]
; [else-branch: 39 | p0_0@4@01 | live]
(push) ; 12
; [then-branch: 39 | !(p0_0@4@01)]
(assert (not p0_0@4@01))
(pop) ; 12
(push) ; 12
; [else-branch: 39 | p0_0@4@01]
(assert p0_0@4@01)
; [eval] i < 64
(pop) ; 12
(pop) ; 11
; Joined path conditions
; Joined path conditions
(assert (or p0_0@4@01 (not p0_0@4@01)))
(push) ; 11
; [then-branch: 40 | p0_0@4@01 && i@26@01 < 64 | live]
; [else-branch: 40 | !(p0_0@4@01 && i@26@01 < 64) | live]
(push) ; 12
; [then-branch: 40 | p0_0@4@01 && i@26@01 < 64]
(assert (and p0_0@4@01 (< i@26@01 64)))
(pop) ; 12
(push) ; 12
; [else-branch: 40 | !(p0_0@4@01 && i@26@01 < 64)]
(assert (not (and p0_0@4@01 (< i@26@01 64))))
; [eval] p1_0 && i_0 < 64
(push) ; 13
; [then-branch: 41 | !(p1_0@5@01) | live]
; [else-branch: 41 | p1_0@5@01 | live]
(push) ; 14
; [then-branch: 41 | !(p1_0@5@01)]
(assert (not p1_0@5@01))
(pop) ; 14
(push) ; 14
; [else-branch: 41 | p1_0@5@01]
; [eval] i_0 < 64
(pop) ; 14
(pop) ; 13
; Joined path conditions
; Joined path conditions
(assert (or p1_0@5@01 (not p1_0@5@01)))
(pop) ; 12
(pop) ; 11
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (and p0_0@4@01 (< i@26@01 64)))
  (and (not (and p0_0@4@01 (< i@26@01 64))) (or p1_0@5@01 (not p1_0@5@01)))))
(assert (or (not (and p0_0@4@01 (< i@26@01 64))) (and p0_0@4@01 (< i@26@01 64))))
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not (or (and p0_0@4@01 (< i@26@01 64)) (and p1_0@5@01 (< i_0@27@01 64))))))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 16000)
(assert (not (or (and p0_0@4@01 (< i@26@01 64)) (and p1_0@5@01 (< i_0@27@01 64)))))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 42 | p0_0@4@01 && i@26@01 < 64 || p1_0@5@01 && i_0@27@01 < 64 | live]
; [else-branch: 42 | !(p0_0@4@01 && i@26@01 < 64 || p1_0@5@01 && i_0@27@01 < 64) | live]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 42 | p0_0@4@01 && i@26@01 < 64 || p1_0@5@01 && i_0@27@01 < 64]
(assert (or (and p0_0@4@01 (< i@26@01 64)) (and p1_0@5@01 (< i_0@27@01 64))))
; [exec]
; var p0_1: Bool
(declare-const p0_1@29@01 Bool)
; [exec]
; var p1_1: Bool
(declare-const p1_1@30@01 Bool)
; [exec]
; var x: Int
(declare-const x@31@01 Int)
; [exec]
; var x_0: Int
(declare-const x_0@32@01 Int)
; [exec]
; var pt0: Bool
(declare-const pt0@33@01 Bool)
; [exec]
; var pt1: Bool
(declare-const pt1@34@01 Bool)
; [exec]
; var pf0: Bool
(declare-const pf0@35@01 Bool)
; [exec]
; var pf1: Bool
(declare-const pf1@36@01 Bool)
; [exec]
; var tmp0_0: Int
(declare-const tmp0_0@37@01 Int)
; [exec]
; var tmp1_0: Int
(declare-const tmp1_0@38@01 Int)
; [exec]
; p0_1 := p0_0 && i < 64
; [eval] p0_0 && i < 64
(push) ; 12
; [then-branch: 43 | !(p0_0@4@01) | live]
; [else-branch: 43 | p0_0@4@01 | live]
(push) ; 13
; [then-branch: 43 | !(p0_0@4@01)]
(assert (not p0_0@4@01))
(pop) ; 13
(push) ; 13
; [else-branch: 43 | p0_0@4@01]
(assert p0_0@4@01)
; [eval] i < 64
(pop) ; 13
(pop) ; 12
; Joined path conditions
; Joined path conditions
(declare-const p0_1@39@01 Bool)
(assert (= p0_1@39@01 (and p0_0@4@01 (< i@26@01 64))))
; [exec]
; p1_1 := p1_0 && i_0 < 64
; [eval] p1_0 && i_0 < 64
(push) ; 12
; [then-branch: 44 | !(p1_0@5@01) | live]
; [else-branch: 44 | p1_0@5@01 | live]
(push) ; 13
; [then-branch: 44 | !(p1_0@5@01)]
(assert (not p1_0@5@01))
(pop) ; 13
(push) ; 13
; [else-branch: 44 | p1_0@5@01]
; [eval] i_0 < 64
(pop) ; 13
(pop) ; 12
; Joined path conditions
; Joined path conditions
(assert (or p1_0@5@01 (not p1_0@5@01)))
(declare-const p1_1@40@01 Bool)
(assert (= p1_1@40@01 (and p1_0@5@01 (< i_0@27@01 64))))
(push) ; 12
(set-option :rlimit 16000)
(assert (not (not p0_1@39@01)))
(check-sat)
; unknown
(pop) ; 12
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 12
(set-option :rlimit 16000)
(assert (not p0_1@39@01))
(check-sat)
; unsat
(pop) ; 12
; 0.00s
; (get-info :all-statistics)
; [then-branch: 45 | p0_1@39@01 | live]
; [else-branch: 45 | !(p0_1@39@01) | dead]
(set-option :rlimit 0)
(push) ; 12
; [then-branch: 45 | p0_1@39@01]
(assert p0_1@39@01)
; [exec]
; x := A[i]
; [eval] A[i]
(push) ; 13
(assert (not (>= i@26@01 0)))
(check-sat)
; unsat
(pop) ; 13
; 0.00s
; (get-info :all-statistics)
(push) ; 13
(assert (not (< i@26@01 (Seq_length A@6@01))))
(check-sat)
; unsat
(pop) ; 13
; 0.00s
; (get-info :all-statistics)
(declare-const x@41@01 Int)
(assert (= x@41@01 (Seq_index A@6@01 i@26@01)))
(push) ; 13
(set-option :rlimit 16000)
(assert (not (not p1_1@40@01)))
(check-sat)
; unknown
(pop) ; 13
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 13
(set-option :rlimit 16000)
(assert (not p1_1@40@01))
(check-sat)
; unsat
(pop) ; 13
; 0.00s
; (get-info :all-statistics)
; [then-branch: 46 | p1_1@40@01 | live]
; [else-branch: 46 | !(p1_1@40@01) | dead]
(set-option :rlimit 0)
(push) ; 13
; [then-branch: 46 | p1_1@40@01]
(assert p1_1@40@01)
; [exec]
; x_0 := A_0[i_0]
; [eval] A_0[i_0]
(push) ; 14
(assert (not (>= i_0@27@01 0)))
(check-sat)
; unsat
(pop) ; 14
; 0.00s
; (get-info :all-statistics)
(push) ; 14
(assert (not (< i_0@27@01 (Seq_length A_0@7@01))))
(check-sat)
; unsat
(pop) ; 14
; 0.00s
; (get-info :all-statistics)
(declare-const x_0@42@01 Int)
(assert (= x_0@42@01 (Seq_index A_0@7@01 i_0@27@01)))
; [exec]
; pt0 := p0_1 && x == 0
; [eval] p0_1 && x == 0
(push) ; 14
; [then-branch: 47 | !(p0_1@39@01) | live]
; [else-branch: 47 | p0_1@39@01 | live]
(push) ; 15
; [then-branch: 47 | !(p0_1@39@01)]
(assert (not p0_1@39@01))
(pop) ; 15
(push) ; 15
; [else-branch: 47 | p0_1@39@01]
; [eval] x == 0
(pop) ; 15
(pop) ; 14
; Joined path conditions
; Joined path conditions
(assert (or p0_1@39@01 (not p0_1@39@01)))
(declare-const pt0@43@01 Bool)
(assert (= pt0@43@01 (and p0_1@39@01 (= x@41@01 0))))
; [exec]
; pt1 := p1_1 && x_0 == 0
; [eval] p1_1 && x_0 == 0
(push) ; 14
; [then-branch: 48 | !(p1_1@40@01) | live]
; [else-branch: 48 | p1_1@40@01 | live]
(push) ; 15
; [then-branch: 48 | !(p1_1@40@01)]
(assert (not p1_1@40@01))
(pop) ; 15
(push) ; 15
; [else-branch: 48 | p1_1@40@01]
; [eval] x_0 == 0
(pop) ; 15
(pop) ; 14
; Joined path conditions
; Joined path conditions
(assert (or p1_1@40@01 (not p1_1@40@01)))
(declare-const pt1@44@01 Bool)
(assert (= pt1@44@01 (and p1_1@40@01 (= x_0@42@01 0))))
; [exec]
; pf0 := p0_1 && !(x == 0)
; [eval] p0_1 && !(x == 0)
(push) ; 14
; [then-branch: 49 | !(p0_1@39@01) | live]
; [else-branch: 49 | p0_1@39@01 | live]
(push) ; 15
; [then-branch: 49 | !(p0_1@39@01)]
(assert (not p0_1@39@01))
(pop) ; 15
(push) ; 15
; [else-branch: 49 | p0_1@39@01]
; [eval] !(x == 0)
; [eval] x == 0
(pop) ; 15
(pop) ; 14
; Joined path conditions
; Joined path conditions
(declare-const pf0@45@01 Bool)
(assert (= pf0@45@01 (and p0_1@39@01 (not (= x@41@01 0)))))
; [exec]
; pf1 := p1_1 && !(x_0 == 0)
; [eval] p1_1 && !(x_0 == 0)
(push) ; 14
; [then-branch: 50 | !(p1_1@40@01) | live]
; [else-branch: 50 | p1_1@40@01 | live]
(push) ; 15
; [then-branch: 50 | !(p1_1@40@01)]
(assert (not p1_1@40@01))
(pop) ; 15
(push) ; 15
; [else-branch: 50 | p1_1@40@01]
; [eval] !(x_0 == 0)
; [eval] x_0 == 0
(pop) ; 15
(pop) ; 14
; Joined path conditions
; Joined path conditions
(declare-const pf1@46@01 Bool)
(assert (= pf1@46@01 (and p1_1@40@01 (not (= x_0@42@01 0)))))
(push) ; 14
(set-option :rlimit 16000)
(assert (not (not pt0@43@01)))
(check-sat)
; unknown
(pop) ; 14
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 14
(set-option :rlimit 16000)
(assert (not pt0@43@01))
(check-sat)
; unknown
(pop) ; 14
; 0.00s
; (get-info :all-statistics)
; [then-branch: 51 | pt0@43@01 | live]
; [else-branch: 51 | !(pt0@43@01) | live]
(set-option :rlimit 0)
(push) ; 14
; [then-branch: 51 | pt0@43@01]
(assert pt0@43@01)
; [exec]
; tmp0_0 := i
(push) ; 15
(set-option :rlimit 16000)
(assert (not (not pt1@44@01)))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 16000)
(assert (not pt1@44@01))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
; [then-branch: 52 | pt1@44@01 | live]
; [else-branch: 52 | !(pt1@44@01) | live]
(set-option :rlimit 0)
(push) ; 15
; [then-branch: 52 | pt1@44@01]
(assert pt1@44@01)
; [exec]
; tmp1_0 := i_0
; [exec]
; print(pt0, pt1, tmp0_0, tmp1_0)
; [eval] p0 ==> p0 && p1 ==> val == val_0
(push) ; 16
(push) ; 17
(set-option :rlimit 16000)
(assert (not (not pt0@43@01)))
(check-sat)
; unknown
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
; [then-branch: 53 | pt0@43@01 | live]
; [else-branch: 53 | !(pt0@43@01) | dead]
(set-option :rlimit 0)
(push) ; 17
; [then-branch: 53 | pt0@43@01]
; [eval] p0 && p1 ==> val == val_0
; [eval] p0 && p1
(push) ; 18
; [then-branch: 54 | !(pt0@43@01) | live]
; [else-branch: 54 | pt0@43@01 | live]
(push) ; 19
; [then-branch: 54 | !(pt0@43@01)]
(assert (not pt0@43@01))
(pop) ; 19
(push) ; 19
; [else-branch: 54 | pt0@43@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; Joined path conditions
(assert (or pt0@43@01 (not pt0@43@01)))
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not (and pt0@43@01 pt1@44@01))))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not (and pt0@43@01 pt1@44@01)))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 55 | pt0@43@01 && pt1@44@01 | live]
; [else-branch: 55 | !(pt0@43@01 && pt1@44@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 55 | pt0@43@01 && pt1@44@01]
(assert (and pt0@43@01 pt1@44@01))
; [eval] val == val_0
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (and pt0@43@01 pt1@44@01))
(pop) ; 17
(pop) ; 16
; Joined path conditions
(assert (=> pt0@43@01 (and (or pt0@43@01 (not pt0@43@01)) pt0@43@01 pt1@44@01)))
(assert pt0@43@01)
(push) ; 16
(assert (not (=> (and pt0@43@01 (and pt0@43@01 pt1@44@01)) (= i@26@01 i_0@27@01))))
(check-sat)
; unsat
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
(assert (=> (and pt0@43@01 (and pt0@43@01 pt1@44@01)) (= i@26@01 i_0@27@01)))
; [eval] p1 ==> true
(push) ; 16
(push) ; 17
(set-option :rlimit 16000)
(assert (not (not pt1@44@01)))
(check-sat)
; unknown
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 17
(set-option :rlimit 16000)
(assert (not pt1@44@01))
(check-sat)
; unsat
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
; [then-branch: 56 | pt1@44@01 | live]
; [else-branch: 56 | !(pt1@44@01) | dead]
(set-option :rlimit 0)
(push) ; 17
; [then-branch: 56 | pt1@44@01]
(assert pt1@44@01)
(pop) ; 17
(pop) ; 16
; Joined path conditions
(assert pt1@44@01)
; [eval] p0 == p1
(push) ; 16
(assert (not (= pt0@43@01 pt1@44@01)))
(check-sat)
; unsat
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
(assert (= pt0@43@01 pt1@44@01))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 16000)
(assert (not (not p0_1@39@01)))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [then-branch: 57 | p0_1@39@01 | live]
; [else-branch: 57 | !(p0_1@39@01) | dead]
(set-option :rlimit 0)
(push) ; 16
; [then-branch: 57 | p0_1@39@01]
; [exec]
; i := i + 1
; [eval] i + 1
(declare-const i@47@01 Int)
(assert (= i@47@01 (+ i@26@01 1)))
(push) ; 17
(set-option :rlimit 16000)
(assert (not (not p1_1@40@01)))
(check-sat)
; unknown
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
; [then-branch: 58 | p1_1@40@01 | live]
; [else-branch: 58 | !(p1_1@40@01) | dead]
(set-option :rlimit 0)
(push) ; 17
; [then-branch: 58 | p1_1@40@01]
; [exec]
; i_0 := i_0 + 1
; [eval] i_0 + 1
(declare-const i_0@48@01 Int)
(assert (= i_0@48@01 (+ i_0@27@01 1)))
; Loop head block: Re-establish invariant
; [eval] p0_0 ==> i >= 0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_0@4@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not p0_0@4@01))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 59 | p0_0@4@01 | live]
; [else-branch: 59 | !(p0_0@4@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 59 | p0_0@4@01]
(assert p0_0@4@01)
; [eval] i >= 0
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p0_0@4@01)
(push) ; 18
(assert (not (=> p0_0@4@01 (>= i@47@01 0))))
(check-sat)
; unsat
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
(assert (=> p0_0@4@01 (>= i@47@01 0)))
; [eval] p1_0 ==> i_0 >= 0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_0@5@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 60 | p1_0@5@01 | live]
; [else-branch: 60 | !(p1_0@5@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 60 | p1_0@5@01]
; [eval] i_0 >= 0
(pop) ; 19
(pop) ; 18
; Joined path conditions
(push) ; 18
(assert (not (=> p1_0@5@01 (>= i_0@48@01 0))))
(check-sat)
; unsat
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
(assert (=> p1_0@5@01 (>= i_0@48@01 0)))
; [eval] p0_0 ==> i <= 64
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_0@4@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 61 | p0_0@4@01 | live]
; [else-branch: 61 | !(p0_0@4@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 61 | p0_0@4@01]
; [eval] i <= 64
(pop) ; 19
(pop) ; 18
; Joined path conditions
(push) ; 18
(assert (not (=> p0_0@4@01 (<= i@47@01 64))))
(check-sat)
; unsat
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
(assert (=> p0_0@4@01 (<= i@47@01 64)))
; [eval] p1_0 ==> i_0 <= 64
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_0@5@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 62 | p1_0@5@01 | live]
; [else-branch: 62 | !(p1_0@5@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 62 | p1_0@5@01]
; [eval] i_0 <= 64
(pop) ; 19
(pop) ; 18
; Joined path conditions
(push) ; 18
(assert (not (=> p1_0@5@01 (<= i_0@48@01 64))))
(check-sat)
; unsat
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
(assert (=> p1_0@5@01 (<= i_0@48@01 64)))
; [eval] p0_0 ==> p0_0 && p1_0 ==> i == i_0
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p0_0@4@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 63 | p0_0@4@01 | live]
; [else-branch: 63 | !(p0_0@4@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 63 | p0_0@4@01]
; [eval] p0_0 && p1_0 ==> i == i_0
; [eval] p0_0 && p1_0
(push) ; 20
; [then-branch: 64 | !(p0_0@4@01) | live]
; [else-branch: 64 | p0_0@4@01 | live]
(push) ; 21
; [then-branch: 64 | !(p0_0@4@01)]
(assert (not p0_0@4@01))
(pop) ; 21
(push) ; 21
; [else-branch: 64 | p0_0@4@01]
(pop) ; 21
(pop) ; 20
; Joined path conditions
; Joined path conditions
(push) ; 20
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not (and p0_0@4@01 p1_0@5@01))))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (and p0_0@4@01 p1_0@5@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 65 | p0_0@4@01 && p1_0@5@01 | live]
; [else-branch: 65 | !(p0_0@4@01 && p1_0@5@01) | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 65 | p0_0@4@01 && p1_0@5@01]
(assert (and p0_0@4@01 p1_0@5@01))
; [eval] i == i_0
(pop) ; 21
(pop) ; 20
; Joined path conditions
(assert (and p0_0@4@01 p1_0@5@01))
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (=> p0_0@4@01 (and p0_0@4@01 p1_0@5@01)))
(assert p0_0@4@01)
(push) ; 18
(assert (not (=> (and p0_0@4@01 (and p0_0@4@01 p1_0@5@01)) (= i@47@01 i_0@48@01))))
(check-sat)
; unsat
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
(assert (=> (and p0_0@4@01 (and p0_0@4@01 p1_0@5@01)) (= i@47@01 i_0@48@01)))
; [eval] p1_0 ==> true
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not p1_0@5@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 19
(set-option :rlimit 16000)
(assert (not p1_0@5@01))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 66 | p1_0@5@01 | live]
; [else-branch: 66 | !(p1_0@5@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 66 | p1_0@5@01]
(assert p1_0@5@01)
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert p1_0@5@01)
; [eval] !p0_0 ==> tmp0 == i
; [eval] !p0_0
(push) ; 18
; [then-branch: 67 | !(p0_0@4@01) | dead]
; [else-branch: 67 | p0_0@4@01 | live]
(push) ; 19
; [else-branch: 67 | p0_0@4@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; [eval] !p1_0 ==> tmp1 == i_0
; [eval] !p1_0
(push) ; 18
; [then-branch: 68 | !(p1_0@5@01) | dead]
; [else-branch: 68 | p1_0@5@01 | live]
(push) ; 19
; [else-branch: 68 | p1_0@5@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
(pop) ; 17
; [eval] !p1_1
; [then-branch: 69 | !(p1_1@40@01) | dead]
; [else-branch: 69 | p1_1@40@01 | live]
(push) ; 17
; [else-branch: 69 | p1_1@40@01]
(pop) ; 17
(pop) ; 16
; [eval] !p0_1
; [then-branch: 70 | !(p0_1@39@01) | dead]
; [else-branch: 70 | p0_1@39@01 | live]
(push) ; 16
; [else-branch: 70 | p0_1@39@01]
(pop) ; 16
(pop) ; 15
(push) ; 15
; [else-branch: 52 | !(pt1@44@01)]
(assert (not pt1@44@01))
(pop) ; 15
; [eval] !pt1
(push) ; 15
(set-option :rlimit 16000)
(assert (not pt1@44@01))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 16000)
(assert (not (not pt1@44@01)))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
; [then-branch: 71 | !(pt1@44@01) | live]
; [else-branch: 71 | pt1@44@01 | live]
(set-option :rlimit 0)
(push) ; 15
; [then-branch: 71 | !(pt1@44@01)]
(assert (not pt1@44@01))
; [exec]
; print(pt0, pt1, tmp0_0, tmp1_0)
; [eval] p0 ==> p0 && p1 ==> val == val_0
(push) ; 16
(push) ; 17
(set-option :rlimit 16000)
(assert (not (not pt0@43@01)))
(check-sat)
; unknown
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 17
(set-option :rlimit 16000)
(assert (not pt0@43@01))
(check-sat)
; unsat
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
; [then-branch: 72 | pt0@43@01 | live]
; [else-branch: 72 | !(pt0@43@01) | dead]
(set-option :rlimit 0)
(push) ; 17
; [then-branch: 72 | pt0@43@01]
(assert pt0@43@01)
; [eval] p0 && p1 ==> val == val_0
; [eval] p0 && p1
(push) ; 18
; [then-branch: 73 | !(pt0@43@01) | live]
; [else-branch: 73 | pt0@43@01 | live]
(push) ; 19
; [then-branch: 73 | !(pt0@43@01)]
(assert (not pt0@43@01))
(pop) ; 19
(push) ; 19
; [else-branch: 73 | pt0@43@01]
(pop) ; 19
(pop) ; 18
; Joined path conditions
; Joined path conditions
(assert (or pt0@43@01 (not pt0@43@01)))
(push) ; 18
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not (and pt0@43@01 pt1@44@01))))
(check-sat)
; unsat
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 74 | pt0@43@01 && pt1@44@01 | dead]
; [else-branch: 74 | !(pt0@43@01 && pt1@44@01) | live]
(set-option :rlimit 0)
(push) ; 19
; [else-branch: 74 | !(pt0@43@01 && pt1@44@01)]
(assert (not (and pt0@43@01 pt1@44@01)))
(pop) ; 19
(pop) ; 18
; Joined path conditions
(assert (not (and pt0@43@01 pt1@44@01)))
(pop) ; 17
(pop) ; 16
; Joined path conditions
(assert (=>
  pt0@43@01
  (and pt0@43@01 (or pt0@43@01 (not pt0@43@01)) (not (and pt0@43@01 pt1@44@01)))))
(assert pt0@43@01)
; [eval] p1 ==> true
(push) ; 16
; [then-branch: 75 | pt1@44@01 | dead]
; [else-branch: 75 | !(pt1@44@01) | live]
(push) ; 17
; [else-branch: 75 | !(pt1@44@01)]
(pop) ; 17
(pop) ; 16
; Joined path conditions
; [eval] p0 == p1
(push) ; 16
(assert (not (= pt0@43@01 pt1@44@01)))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] p0 == p1
(set-option :rlimit 0)
(push) ; 16
(assert (not (= pt0@43@01 pt1@44@01)))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] p0 == p1
(set-option :rlimit 0)
(push) ; 16
(assert (not (= pt0@43@01 pt1@44@01)))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] p0 == p1
(set-option :rlimit 0)
(push) ; 16
(assert (not (= pt0@43@01 pt1@44@01)))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
(pop) ; 15
(pop) ; 14
(pop) ; 13
(pop) ; 12
(pop) ; 11
(pop) ; 10
(pop) ; 9
(pop) ; 8
(pop) ; 7
(pop) ; 6
(pop) ; 5
(pop) ; 4
(pop) ; 3
(pop) ; 2
(pop) ; 1
; ---------- print ----------
(declare-const p0@49@01 Bool)
(declare-const p1@50@01 Bool)
(declare-const val@51@01 Int)
(declare-const val_0@52@01 Int)
(declare-const p0@53@01 Bool)
(declare-const p1@54@01 Bool)
(declare-const val@55@01 Int)
(declare-const val_0@56@01 Int)
(push) ; 1
(declare-const $t@57@01 $Snap)
(assert (= $t@57@01 ($Snap.combine ($Snap.first $t@57@01) ($Snap.second $t@57@01))))
(assert (= ($Snap.first $t@57@01) $Snap.unit))
; [eval] p0 ==> p0 && p1 ==> val == val_0
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p0@53@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p0@53@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 76 | p0@53@01 | live]
; [else-branch: 76 | !(p0@53@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 76 | p0@53@01]
(assert p0@53@01)
; [eval] p0 && p1 ==> val == val_0
; [eval] p0 && p1
(push) ; 4
; [then-branch: 77 | !(p0@53@01) | live]
; [else-branch: 77 | p0@53@01 | live]
(push) ; 5
; [then-branch: 77 | !(p0@53@01)]
(assert (not p0@53@01))
(pop) ; 5
(push) ; 5
; [else-branch: 77 | p0@53@01]
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or p0@53@01 (not p0@53@01)))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (and p0@53@01 p1@54@01))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (and p0@53@01 p1@54@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 78 | p0@53@01 && p1@54@01 | live]
; [else-branch: 78 | !(p0@53@01 && p1@54@01) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 78 | p0@53@01 && p1@54@01]
(assert (and p0@53@01 p1@54@01))
; [eval] val == val_0
(pop) ; 5
(push) ; 5
; [else-branch: 78 | !(p0@53@01 && p1@54@01)]
(assert (not (and p0@53@01 p1@54@01)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (not (and p0@53@01 p1@54@01)) (and p0@53@01 p1@54@01)))
(pop) ; 3
(push) ; 3
; [else-branch: 76 | !(p0@53@01)]
(assert (not p0@53@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
(assert (=>
  p0@53@01
  (and
    p0@53@01
    (or p0@53@01 (not p0@53@01))
    (or (not (and p0@53@01 p1@54@01)) (and p0@53@01 p1@54@01)))))
; Joined path conditions
(assert (or (not p0@53@01) p0@53@01))
(assert (=> (and p0@53@01 (and p0@53@01 p1@54@01)) (= val@55@01 val_0@56@01)))
(assert (=
  ($Snap.second $t@57@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@57@01))
    ($Snap.second ($Snap.second $t@57@01)))))
(assert (= ($Snap.first ($Snap.second $t@57@01)) $Snap.unit))
; [eval] p1 ==> true
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p1@54@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p1@54@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 79 | p1@54@01 | live]
; [else-branch: 79 | !(p1@54@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 79 | p1@54@01]
(assert p1@54@01)
(pop) ; 3
(push) ; 3
; [else-branch: 79 | !(p1@54@01)]
(assert (not p1@54@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not p1@54@01) p1@54@01))
(assert (= ($Snap.second ($Snap.second $t@57@01)) $Snap.unit))
; [eval] p0 == p1
(assert (= p0@53@01 p1@54@01))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
(pop) ; 2
(push) ; 2
; [exec]
; inhale false
(pop) ; 2
(pop) ; 1
