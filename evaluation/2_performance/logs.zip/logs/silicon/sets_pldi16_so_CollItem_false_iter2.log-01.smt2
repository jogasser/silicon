(get-info :version)
; (:version "4.8.7")
; Started: 2025-12-05 14:06:02
; Silicon.version: 1.1-SNAPSHOT (95328487@(detached))
; Input file: ./sets/pldi16_so_CollItem_false.vpr
; Verifier id: 00
; ------------------------------------------------------------
; Begin preamble
; ////////// Static preamble
; 
; ; /z3config.smt2
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :smt.qi.max_multi_patterns 1000)
; 
; ; /preamble.smt2
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(define-fun $Perm.min ((p1 $Perm) (p2 $Perm)) Real
    (ite (<= p1 p2) p1 p2))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
; ////////// Sorts
; ////////// Sort wrappers
; Declaring additional sort wrappers
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
; ////////// Symbols
; Declaring symbols related to program functions (from program analysis)
(declare-fun getCardId ($Snap $Ref) Int)
(declare-fun getCardId%limited ($Snap $Ref) Int)
(declare-fun getCardId%stateless ($Ref) Bool)
(declare-fun getCardId%precondition ($Snap $Ref) Bool)
(declare-fun getCardRarity ($Snap $Ref) Int)
(declare-fun getCardRarity%limited ($Snap $Ref) Int)
(declare-fun getCardRarity%stateless ($Ref) Bool)
(declare-fun getCardRarity%precondition ($Snap $Ref) Bool)
(declare-fun getCardSet ($Snap $Ref) Int)
(declare-fun getCardSet%limited ($Snap $Ref) Int)
(declare-fun getCardSet%stateless ($Ref) Bool)
(declare-fun getCardSet%precondition ($Snap $Ref) Bool)
(declare-fun sgn ($Snap Int) Int)
(declare-fun sgn%limited ($Snap Int) Int)
(declare-fun sgn%stateless (Int) Bool)
(declare-fun sgn%precondition ($Snap Int) Bool)
(declare-fun cardType ($Snap $Ref) Int)
(declare-fun cardType%limited ($Snap $Ref) Int)
(declare-fun cardType%stateless ($Ref) Bool)
(declare-fun cardType%precondition ($Snap $Ref) Bool)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
; Declaring predicate trigger functions
; ////////// Uniqueness assumptions from domains
; ////////// Axioms
; End preamble
; ------------------------------------------------------------
; State saturation: after preamble
(set-option :rlimit 160000)
(check-sat)
; unknown
; ------------------------------------------------------------
; Begin function- and predicate-related preamble
; Declaring symbols related to program functions (from verification)
; Declaring symbols related to program functions (from verification)
(assert (forall ((s@$ $Snap) (self@0@00 $Ref)) (!
  (= (getCardId%limited s@$ self@0@00) (getCardId s@$ self@0@00))
  :pattern ((getCardId s@$ self@0@00))
  :qid |quant-u-0|)))
(assert (forall ((s@$ $Snap) (self@0@00 $Ref)) (!
  (getCardId%stateless self@0@00)
  :pattern ((getCardId%limited s@$ self@0@00))
  :qid |quant-u-1|)))
(assert (forall ((s@$ $Snap) (self@2@00 $Ref)) (!
  (= (getCardRarity%limited s@$ self@2@00) (getCardRarity s@$ self@2@00))
  :pattern ((getCardRarity s@$ self@2@00))
  :qid |quant-u-2|)))
(assert (forall ((s@$ $Snap) (self@2@00 $Ref)) (!
  (getCardRarity%stateless self@2@00)
  :pattern ((getCardRarity%limited s@$ self@2@00))
  :qid |quant-u-3|)))
(assert (forall ((s@$ $Snap) (self@4@00 $Ref)) (!
  (= (getCardSet%limited s@$ self@4@00) (getCardSet s@$ self@4@00))
  :pattern ((getCardSet s@$ self@4@00))
  :qid |quant-u-4|)))
(assert (forall ((s@$ $Snap) (self@4@00 $Ref)) (!
  (getCardSet%stateless self@4@00)
  :pattern ((getCardSet%limited s@$ self@4@00))
  :qid |quant-u-5|)))
(assert (forall ((s@$ $Snap) (i@6@00 Int)) (!
  (= (sgn%limited s@$ i@6@00) (sgn s@$ i@6@00))
  :pattern ((sgn s@$ i@6@00))
  :qid |quant-u-6|)))
(assert (forall ((s@$ $Snap) (i@6@00 Int)) (!
  (sgn%stateless i@6@00)
  :pattern ((sgn%limited s@$ i@6@00))
  :qid |quant-u-7|)))
(assert (forall ((s@$ $Snap) (i@6@00 Int)) (!
  (let ((result@7@00 (sgn%limited s@$ i@6@00))) (=>
    (sgn%precondition s@$ i@6@00)
    (and
      (=> (> i@6@00 0) (= result@7@00 1))
      (=> (= i@6@00 0) (= result@7@00 0))
      (=> (< i@6@00 0) (= result@7@00 (- 0 1))))))
  :pattern ((sgn%limited s@$ i@6@00))
  :qid |quant-u-10|)))
(assert (forall ((s@$ $Snap) (i@6@00 Int)) (!
  (let ((result@7@00 (sgn%limited s@$ i@6@00))) true)
  :pattern ((sgn%limited s@$ i@6@00))
  :qid |quant-u-11|)))
(assert (forall ((s@$ $Snap) (i@6@00 Int)) (!
  (let ((result@7@00 (sgn%limited s@$ i@6@00))) true)
  :pattern ((sgn%limited s@$ i@6@00))
  :qid |quant-u-12|)))
(assert (forall ((s@$ $Snap) (i@6@00 Int)) (!
  (let ((result@7@00 (sgn%limited s@$ i@6@00))) true)
  :pattern ((sgn%limited s@$ i@6@00))
  :qid |quant-u-13|)))
(assert (forall ((s@$ $Snap) (self@8@00 $Ref)) (!
  (= (cardType%limited s@$ self@8@00) (cardType s@$ self@8@00))
  :pattern ((cardType s@$ self@8@00))
  :qid |quant-u-8|)))
(assert (forall ((s@$ $Snap) (self@8@00 $Ref)) (!
  (cardType%stateless self@8@00)
  :pattern ((cardType%limited s@$ self@8@00))
  :qid |quant-u-9|)))
; End function- and predicate-related preamble
; ------------------------------------------------------------
; ---------- compare ----------
(declare-const p0@0@01 Bool)
(declare-const p1@1@01 Bool)
(declare-const p2@2@01 Bool)
(declare-const o1@3@01 $Ref)
(declare-const o1_0@4@01 $Ref)
(declare-const o1_1@5@01 $Ref)
(declare-const o2@6@01 $Ref)
(declare-const o2_0@7@01 $Ref)
(declare-const o2_1@8@01 $Ref)
(declare-const res@9@01 Int)
(declare-const res_0@10@01 Int)
(declare-const res_1@11@01 Int)
(declare-const p0@12@01 Bool)
(declare-const p1@13@01 Bool)
(declare-const p2@14@01 Bool)
(declare-const o1@15@01 $Ref)
(declare-const o1_0@16@01 $Ref)
(declare-const o1_1@17@01 $Ref)
(declare-const o2@18@01 $Ref)
(declare-const o2_0@19@01 $Ref)
(declare-const o2_1@20@01 $Ref)
(declare-const res@21@01 Int)
(declare-const res_0@22@01 Int)
(declare-const res_1@23@01 Int)
(set-option :rlimit 0)
(push) ; 1
(declare-const $t@24@01 $Snap)
(assert (= $t@24@01 ($Snap.combine ($Snap.first $t@24@01) ($Snap.second $t@24@01))))
(assert (= ($Snap.first $t@24@01) $Snap.unit))
; [eval] p0 ==> true && (p0 && p1) ==> o2 == o1_0
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 0 | p0@12@01 | live]
; [else-branch: 0 | !(p0@12@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 0 | p0@12@01]
(assert p0@12@01)
; [eval] true && (p0 && p1) ==> o2 == o1_0
; [eval] true && (p0 && p1)
(push) ; 4
; [then-branch: 1 | False | live]
; [else-branch: 1 | True | live]
(push) ; 5
; [then-branch: 1 | False]
(assert false)
(pop) ; 5
(push) ; 5
; [else-branch: 1 | True]
(push) ; 6
; [then-branch: 2 | !(p0@12@01) | live]
; [else-branch: 2 | p0@12@01 | live]
(push) ; 7
; [then-branch: 2 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 7
(push) ; 7
; [else-branch: 2 | p0@12@01]
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (or p0@12@01 (not p0@12@01)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or p0@12@01 (not p0@12@01)))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 p1@13@01))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (and p0@12@01 p1@13@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 3 | p0@12@01 && p1@13@01 | live]
; [else-branch: 3 | !(p0@12@01 && p1@13@01) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 3 | p0@12@01 && p1@13@01]
(assert (and p0@12@01 p1@13@01))
; [eval] o2 == o1_0
(pop) ; 5
(push) ; 5
; [else-branch: 3 | !(p0@12@01 && p1@13@01)]
(assert (not (and p0@12@01 p1@13@01)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (not (and p0@12@01 p1@13@01)) (and p0@12@01 p1@13@01)))
(pop) ; 3
(push) ; 3
; [else-branch: 0 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    p0@12@01
    (or p0@12@01 (not p0@12@01))
    (or (not (and p0@12@01 p1@13@01)) (and p0@12@01 p1@13@01)))))
; Joined path conditions
(assert (or (not p0@12@01) p0@12@01))
(assert (=> (and p0@12@01 (and p0@12@01 p1@13@01)) (= o2@18@01 o1_0@16@01)))
(assert (=
  ($Snap.second $t@24@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@24@01))
    ($Snap.second ($Snap.second $t@24@01)))))
(assert (= ($Snap.first ($Snap.second $t@24@01)) $Snap.unit))
; [eval] p1 ==> true && (p0 && p1) ==> o2 == o1_0
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 4 | p1@13@01 | live]
; [else-branch: 4 | !(p1@13@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 4 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && p1) ==> o2 == o1_0
; [eval] true && (p0 && p1)
(push) ; 4
; [then-branch: 5 | False | live]
; [else-branch: 5 | True | live]
(push) ; 5
; [then-branch: 5 | False]
(assert false)
(pop) ; 5
(push) ; 5
; [else-branch: 5 | True]
(push) ; 6
; [then-branch: 6 | !(p0@12@01) | live]
; [else-branch: 6 | p0@12@01 | live]
(push) ; 7
; [then-branch: 6 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 7
(push) ; 7
; [else-branch: 6 | p0@12@01]
(assert p0@12@01)
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (or p0@12@01 (not p0@12@01)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or p0@12@01 (not p0@12@01)))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 p1@13@01))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (and p0@12@01 p1@13@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 7 | p0@12@01 && p1@13@01 | live]
; [else-branch: 7 | !(p0@12@01 && p1@13@01) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 7 | p0@12@01 && p1@13@01]
(assert (and p0@12@01 p1@13@01))
; [eval] o2 == o1_0
(pop) ; 5
(push) ; 5
; [else-branch: 7 | !(p0@12@01 && p1@13@01)]
(assert (not (and p0@12@01 p1@13@01)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (not (and p0@12@01 p1@13@01)) (and p0@12@01 p1@13@01)))
(pop) ; 3
(push) ; 3
; [else-branch: 4 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (or p0@12@01 (not p0@12@01))
    (or (not (and p0@12@01 p1@13@01)) (and p0@12@01 p1@13@01)))))
; Joined path conditions
(assert (or (not p1@13@01) p1@13@01))
(assert (=> (and p1@13@01 (and p0@12@01 p1@13@01)) (= o2@18@01 o1_0@16@01)))
(assert (=
  ($Snap.second ($Snap.second $t@24@01))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second $t@24@01)))
    ($Snap.second ($Snap.second ($Snap.second $t@24@01))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second $t@24@01))) $Snap.unit))
; [eval] p2 ==> true
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 8 | p2@14@01 | live]
; [else-branch: 8 | !(p2@14@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 8 | p2@14@01]
(assert p2@14@01)
(pop) ; 3
(push) ; 3
; [else-branch: 8 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not p2@14@01) p2@14@01))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second $t@24@01)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@24@01))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01)))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second $t@24@01))))
  $Snap.unit))
; [eval] p0 ==> true && (p2 && p0) ==> o1_1 == o1
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 9 | p0@12@01 | live]
; [else-branch: 9 | !(p0@12@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 9 | p0@12@01]
(assert p0@12@01)
; [eval] true && (p2 && p0) ==> o1_1 == o1
; [eval] true && (p2 && p0)
(push) ; 4
; [then-branch: 10 | False | live]
; [else-branch: 10 | True | live]
(push) ; 5
; [then-branch: 10 | False]
(assert false)
(pop) ; 5
(push) ; 5
; [else-branch: 10 | True]
(push) ; 6
; [then-branch: 11 | !(p2@14@01) | live]
; [else-branch: 11 | p2@14@01 | live]
(push) ; 7
; [then-branch: 11 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 7
(push) ; 7
; [else-branch: 11 | p2@14@01]
(assert p2@14@01)
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (or p2@14@01 (not p2@14@01)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or p2@14@01 (not p2@14@01)))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (and p2@14@01 p0@12@01))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (and p2@14@01 p0@12@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 12 | p2@14@01 && p0@12@01 | live]
; [else-branch: 12 | !(p2@14@01 && p0@12@01) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 12 | p2@14@01 && p0@12@01]
(assert (and p2@14@01 p0@12@01))
; [eval] o1_1 == o1
(pop) ; 5
(push) ; 5
; [else-branch: 12 | !(p2@14@01 && p0@12@01)]
(assert (not (and p2@14@01 p0@12@01)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (not (and p2@14@01 p0@12@01)) (and p2@14@01 p0@12@01)))
(pop) ; 3
(push) ; 3
; [else-branch: 9 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    p0@12@01
    (or p2@14@01 (not p2@14@01))
    (or (not (and p2@14@01 p0@12@01)) (and p2@14@01 p0@12@01)))))
; Joined path conditions
(assert (=> (and p0@12@01 (and p2@14@01 p0@12@01)) (= o1_1@17@01 o1@15@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01)))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01)))))
  $Snap.unit))
; [eval] p1 ==> true
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 13 | p1@13@01 | live]
; [else-branch: 13 | !(p1@13@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 13 | p1@13@01]
(assert p1@13@01)
(pop) ; 3
(push) ; 3
; [else-branch: 13 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01)))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01)))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01))))))
  $Snap.unit))
; [eval] p2 ==> true && (p2 && p0) ==> o1_1 == o1
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 14 | p2@14@01 | live]
; [else-branch: 14 | !(p2@14@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 14 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p2 && p0) ==> o1_1 == o1
; [eval] true && (p2 && p0)
(push) ; 4
; [then-branch: 15 | False | live]
; [else-branch: 15 | True | live]
(push) ; 5
; [then-branch: 15 | False]
(assert false)
(pop) ; 5
(push) ; 5
; [else-branch: 15 | True]
(push) ; 6
; [then-branch: 16 | !(p2@14@01) | live]
; [else-branch: 16 | p2@14@01 | live]
(push) ; 7
; [then-branch: 16 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 7
(push) ; 7
; [else-branch: 16 | p2@14@01]
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (or p2@14@01 (not p2@14@01)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or p2@14@01 (not p2@14@01)))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (and p2@14@01 p0@12@01))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (and p2@14@01 p0@12@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 17 | p2@14@01 && p0@12@01 | live]
; [else-branch: 17 | !(p2@14@01 && p0@12@01) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 17 | p2@14@01 && p0@12@01]
(assert (and p2@14@01 p0@12@01))
; [eval] o1_1 == o1
(pop) ; 5
(push) ; 5
; [else-branch: 17 | !(p2@14@01 && p0@12@01)]
(assert (not (and p2@14@01 p0@12@01)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (not (and p2@14@01 p0@12@01)) (and p2@14@01 p0@12@01)))
(pop) ; 3
(push) ; 3
; [else-branch: 14 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (or p2@14@01 (not p2@14@01))
    (or (not (and p2@14@01 p0@12@01)) (and p2@14@01 p0@12@01)))))
; Joined path conditions
(assert (=> (and p2@14@01 (and p2@14@01 p0@12@01)) (= o1_1@17@01 o1@15@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01)))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01)))))))
  $Snap.unit))
; [eval] p0 ==> true
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 18 | p0@12@01 | live]
; [else-branch: 18 | !(p0@12@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 18 | p0@12@01]
(assert p0@12@01)
(pop) ; 3
(push) ; 3
; [else-branch: 18 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01)))))))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01))))))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01)))))))))))
(assert (=
  ($Snap.first ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01))))))))
  $Snap.unit))
; [eval] p1 ==> true && (p2 && p1) ==> o2_1 == o2_0
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 19 | p1@13@01 | live]
; [else-branch: 19 | !(p1@13@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 19 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p2 && p1) ==> o2_1 == o2_0
; [eval] true && (p2 && p1)
(push) ; 4
; [then-branch: 20 | False | live]
; [else-branch: 20 | True | live]
(push) ; 5
; [then-branch: 20 | False]
(assert false)
(pop) ; 5
(push) ; 5
; [else-branch: 20 | True]
(push) ; 6
; [then-branch: 21 | !(p2@14@01) | live]
; [else-branch: 21 | p2@14@01 | live]
(push) ; 7
; [then-branch: 21 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 7
(push) ; 7
; [else-branch: 21 | p2@14@01]
(assert p2@14@01)
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (or p2@14@01 (not p2@14@01)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or p2@14@01 (not p2@14@01)))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (and p2@14@01 p1@13@01))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (and p2@14@01 p1@13@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 22 | p2@14@01 && p1@13@01 | live]
; [else-branch: 22 | !(p2@14@01 && p1@13@01) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 22 | p2@14@01 && p1@13@01]
(assert (and p2@14@01 p1@13@01))
; [eval] o2_1 == o2_0
(pop) ; 5
(push) ; 5
; [else-branch: 22 | !(p2@14@01 && p1@13@01)]
(assert (not (and p2@14@01 p1@13@01)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (not (and p2@14@01 p1@13@01)) (and p2@14@01 p1@13@01)))
(pop) ; 3
(push) ; 3
; [else-branch: 19 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (or p2@14@01 (not p2@14@01))
    (or (not (and p2@14@01 p1@13@01)) (and p2@14@01 p1@13@01)))))
; Joined path conditions
(assert (=> (and p1@13@01 (and p2@14@01 p1@13@01)) (= o2_1@20@01 o2_0@19@01)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second ($Snap.second $t@24@01))))))))
  $Snap.unit))
; [eval] p2 ==> true && (p2 && p1) ==> o2_1 == o2_0
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 23 | p2@14@01 | live]
; [else-branch: 23 | !(p2@14@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 23 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p2 && p1) ==> o2_1 == o2_0
; [eval] true && (p2 && p1)
(push) ; 4
; [then-branch: 24 | False | live]
; [else-branch: 24 | True | live]
(push) ; 5
; [then-branch: 24 | False]
(assert false)
(pop) ; 5
(push) ; 5
; [else-branch: 24 | True]
(push) ; 6
; [then-branch: 25 | !(p2@14@01) | live]
; [else-branch: 25 | p2@14@01 | live]
(push) ; 7
; [then-branch: 25 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 7
(push) ; 7
; [else-branch: 25 | p2@14@01]
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (or p2@14@01 (not p2@14@01)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or p2@14@01 (not p2@14@01)))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (and p2@14@01 p1@13@01))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (and p2@14@01 p1@13@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 26 | p2@14@01 && p1@13@01 | live]
; [else-branch: 26 | !(p2@14@01 && p1@13@01) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 26 | p2@14@01 && p1@13@01]
(assert (and p2@14@01 p1@13@01))
; [eval] o2_1 == o2_0
(pop) ; 5
(push) ; 5
; [else-branch: 26 | !(p2@14@01 && p1@13@01)]
(assert (not (and p2@14@01 p1@13@01)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (not (and p2@14@01 p1@13@01)) (and p2@14@01 p1@13@01)))
(pop) ; 3
(push) ; 3
; [else-branch: 23 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 3
(pop) ; 2
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (or p2@14@01 (not p2@14@01))
    (or (not (and p2@14@01 p1@13@01)) (and p2@14@01 p1@13@01)))))
; Joined path conditions
(assert (=> (and p2@14@01 (and p2@14@01 p1@13@01)) (= o2_1@20@01 o2_0@19@01)))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
(declare-const $t@25@01 $Snap)
(assert (= $t@25@01 ($Snap.combine ($Snap.first $t@25@01) ($Snap.second $t@25@01))))
(assert (= ($Snap.first $t@25@01) $Snap.unit))
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 3
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 27 | p0@12@01 | live]
; [else-branch: 27 | !(p0@12@01) | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 27 | p0@12@01]
(assert p0@12@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 5
; [then-branch: 28 | False | live]
; [else-branch: 28 | True | live]
(push) ; 6
; [then-branch: 28 | False]
(assert false)
(pop) ; 6
(push) ; 6
; [else-branch: 28 | True]
(push) ; 7
; [then-branch: 29 | !(p0@12@01) | live]
; [else-branch: 29 | p0@12@01 | live]
(push) ; 8
; [then-branch: 29 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 8
(push) ; 8
; [else-branch: 29 | p0@12@01]
(push) ; 9
; [then-branch: 30 | !(p1@13@01) | live]
; [else-branch: 30 | p1@13@01 | live]
(push) ; 10
; [then-branch: 30 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 10
(push) ; 10
; [else-branch: 30 | p1@13@01]
(assert p1@13@01)
(pop) ; 10
(pop) ; 9
; Joined path conditions
; Joined path conditions
(assert (or p1@13@01 (not p1@13@01)))
(pop) ; 8
(pop) ; 7
; Joined path conditions
; Joined path conditions
(assert (=> p0@12@01 (or p1@13@01 (not p1@13@01))))
(assert (or p0@12@01 (not p0@12@01)))
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (and (=> p0@12@01 (or p1@13@01 (not p1@13@01))) (or p0@12@01 (not p0@12@01))))
(push) ; 5
(push) ; 6
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [then-branch: 31 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 31 | !(p0@12@01 && p1@13@01 && p2@14@01) | live]
(set-option :rlimit 0)
(push) ; 6
; [then-branch: 31 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 7
; [then-branch: 32 | !(res@21@01 > 0) | live]
; [else-branch: 32 | res@21@01 > 0 | live]
(push) ; 8
; [then-branch: 32 | !(res@21@01 > 0)]
(assert (not (> res@21@01 0)))
(pop) ; 8
(push) ; 8
; [else-branch: 32 | res@21@01 > 0]
(assert (> res@21@01 0))
; [eval] res_0 > 0
(pop) ; 8
(pop) ; 7
; Joined path conditions
; Joined path conditions
(assert (or (> res@21@01 0) (not (> res@21@01 0))))
(push) ; 7
(push) ; 8
(set-option :rlimit 16000)
(assert (not (not (and (> res@21@01 0) (> res_0@22@01 0)))))
(check-sat)
; unknown
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 8
(set-option :rlimit 16000)
(assert (not (and (> res@21@01 0) (> res_0@22@01 0))))
(check-sat)
; unknown
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
; [then-branch: 33 | res@21@01 > 0 && res_0@22@01 > 0 | live]
; [else-branch: 33 | !(res@21@01 > 0 && res_0@22@01 > 0) | live]
(set-option :rlimit 0)
(push) ; 8
; [then-branch: 33 | res@21@01 > 0 && res_0@22@01 > 0]
(assert (and (> res@21@01 0) (> res_0@22@01 0)))
; [eval] res_1 > 0
(pop) ; 8
(push) ; 8
; [else-branch: 33 | !(res@21@01 > 0 && res_0@22@01 > 0)]
(assert (not (and (> res@21@01 0) (> res_0@22@01 0))))
(pop) ; 8
(pop) ; 7
; Joined path conditions
; Joined path conditions
(assert (or
  (not (and (> res@21@01 0) (> res_0@22@01 0)))
  (and (> res@21@01 0) (> res_0@22@01 0))))
(pop) ; 6
(push) ; 6
; [else-branch: 31 | !(p0@12@01 && p1@13@01 && p2@14@01)]
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (=>
  (and p0@12@01 (and p1@13@01 p2@14@01))
  (and
    p0@12@01
    p1@13@01
    p2@14@01
    (or (> res@21@01 0) (not (> res@21@01 0)))
    (or
      (not (and (> res@21@01 0) (> res_0@22@01 0)))
      (and (> res@21@01 0) (> res_0@22@01 0))))))
; Joined path conditions
(assert (or
  (not (and p0@12@01 (and p1@13@01 p2@14@01)))
  (and p0@12@01 (and p1@13@01 p2@14@01))))
(pop) ; 4
(push) ; 4
; [else-branch: 27 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 4
(pop) ; 3
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    p0@12@01
    (=> p0@12@01 (or p1@13@01 (not p1@13@01)))
    (or p0@12@01 (not p0@12@01))
    (=>
      (and p0@12@01 (and p1@13@01 p2@14@01))
      (and
        p0@12@01
        p1@13@01
        p2@14@01
        (or (> res@21@01 0) (not (> res@21@01 0)))
        (or
          (not (and (> res@21@01 0) (> res_0@22@01 0)))
          (and (> res@21@01 0) (> res_0@22@01 0)))))
    (or
      (not (and p0@12@01 (and p1@13@01 p2@14@01)))
      (and p0@12@01 (and p1@13@01 p2@14@01))))))
; Joined path conditions
(assert (=>
  (and
    p0@12@01
    (and
      (and p0@12@01 (and p1@13@01 p2@14@01))
      (and (> res@21@01 0) (> res_0@22@01 0))))
  (> res_1@23@01 0)))
(assert (=
  ($Snap.second $t@25@01)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@25@01))
    ($Snap.second ($Snap.second $t@25@01)))))
(assert (= ($Snap.first ($Snap.second $t@25@01)) $Snap.unit))
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 3
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 34 | p1@13@01 | live]
; [else-branch: 34 | !(p1@13@01) | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 34 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 5
; [then-branch: 35 | False | live]
; [else-branch: 35 | True | live]
(push) ; 6
; [then-branch: 35 | False]
(assert false)
(pop) ; 6
(push) ; 6
; [else-branch: 35 | True]
(push) ; 7
; [then-branch: 36 | !(p0@12@01) | live]
; [else-branch: 36 | p0@12@01 | live]
(push) ; 8
; [then-branch: 36 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 8
(push) ; 8
; [else-branch: 36 | p0@12@01]
(assert p0@12@01)
(push) ; 9
; [then-branch: 37 | !(p1@13@01) | live]
; [else-branch: 37 | p1@13@01 | live]
(push) ; 10
; [then-branch: 37 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 10
(push) ; 10
; [else-branch: 37 | p1@13@01]
(pop) ; 10
(pop) ; 9
; Joined path conditions
; Joined path conditions
(assert (or p1@13@01 (not p1@13@01)))
(pop) ; 8
(pop) ; 7
; Joined path conditions
; Joined path conditions
(assert (=> p0@12@01 (and p0@12@01 (or p1@13@01 (not p1@13@01)))))
(assert (or p0@12@01 (not p0@12@01)))
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (and
  (=> p0@12@01 (and p0@12@01 (or p1@13@01 (not p1@13@01))))
  (or p0@12@01 (not p0@12@01))))
(push) ; 5
(push) ; 6
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [then-branch: 38 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 38 | !(p0@12@01 && p1@13@01 && p2@14@01) | live]
(set-option :rlimit 0)
(push) ; 6
; [then-branch: 38 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 7
; [then-branch: 39 | !(res@21@01 > 0) | live]
; [else-branch: 39 | res@21@01 > 0 | live]
(push) ; 8
; [then-branch: 39 | !(res@21@01 > 0)]
(assert (not (> res@21@01 0)))
(pop) ; 8
(push) ; 8
; [else-branch: 39 | res@21@01 > 0]
(assert (> res@21@01 0))
; [eval] res_0 > 0
(pop) ; 8
(pop) ; 7
; Joined path conditions
; Joined path conditions
(assert (or (> res@21@01 0) (not (> res@21@01 0))))
(push) ; 7
(push) ; 8
(set-option :rlimit 16000)
(assert (not (not (and (> res@21@01 0) (> res_0@22@01 0)))))
(check-sat)
; unknown
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 8
(set-option :rlimit 16000)
(assert (not (and (> res@21@01 0) (> res_0@22@01 0))))
(check-sat)
; unknown
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
; [then-branch: 40 | res@21@01 > 0 && res_0@22@01 > 0 | live]
; [else-branch: 40 | !(res@21@01 > 0 && res_0@22@01 > 0) | live]
(set-option :rlimit 0)
(push) ; 8
; [then-branch: 40 | res@21@01 > 0 && res_0@22@01 > 0]
(assert (and (> res@21@01 0) (> res_0@22@01 0)))
; [eval] res_1 > 0
(pop) ; 8
(push) ; 8
; [else-branch: 40 | !(res@21@01 > 0 && res_0@22@01 > 0)]
(assert (not (and (> res@21@01 0) (> res_0@22@01 0))))
(pop) ; 8
(pop) ; 7
; Joined path conditions
; Joined path conditions
(assert (or
  (not (and (> res@21@01 0) (> res_0@22@01 0)))
  (and (> res@21@01 0) (> res_0@22@01 0))))
(pop) ; 6
(push) ; 6
; [else-branch: 38 | !(p0@12@01 && p1@13@01 && p2@14@01)]
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (=>
  (and p0@12@01 (and p1@13@01 p2@14@01))
  (and
    p0@12@01
    p1@13@01
    p2@14@01
    (or (> res@21@01 0) (not (> res@21@01 0)))
    (or
      (not (and (> res@21@01 0) (> res_0@22@01 0)))
      (and (> res@21@01 0) (> res_0@22@01 0))))))
; Joined path conditions
(assert (or
  (not (and p0@12@01 (and p1@13@01 p2@14@01)))
  (and p0@12@01 (and p1@13@01 p2@14@01))))
(pop) ; 4
(push) ; 4
; [else-branch: 34 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 4
(pop) ; 3
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> p0@12@01 (and p0@12@01 (or p1@13@01 (not p1@13@01))))
    (or p0@12@01 (not p0@12@01))
    (=>
      (and p0@12@01 (and p1@13@01 p2@14@01))
      (and
        p0@12@01
        p1@13@01
        p2@14@01
        (or (> res@21@01 0) (not (> res@21@01 0)))
        (or
          (not (and (> res@21@01 0) (> res_0@22@01 0)))
          (and (> res@21@01 0) (> res_0@22@01 0)))))
    (or
      (not (and p0@12@01 (and p1@13@01 p2@14@01)))
      (and p0@12@01 (and p1@13@01 p2@14@01))))))
; Joined path conditions
(assert (=>
  (and
    p1@13@01
    (and
      (and p0@12@01 (and p1@13@01 p2@14@01))
      (and (> res@21@01 0) (> res_0@22@01 0))))
  (> res_1@23@01 0)))
(assert (= ($Snap.second ($Snap.second $t@25@01)) $Snap.unit))
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 3
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 41 | p2@14@01 | live]
; [else-branch: 41 | !(p2@14@01) | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 41 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 5
; [then-branch: 42 | False | live]
; [else-branch: 42 | True | live]
(push) ; 6
; [then-branch: 42 | False]
(assert false)
(pop) ; 6
(push) ; 6
; [else-branch: 42 | True]
(push) ; 7
; [then-branch: 43 | !(p0@12@01) | live]
; [else-branch: 43 | p0@12@01 | live]
(push) ; 8
; [then-branch: 43 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 8
(push) ; 8
; [else-branch: 43 | p0@12@01]
(assert p0@12@01)
(push) ; 9
; [then-branch: 44 | !(p1@13@01) | live]
; [else-branch: 44 | p1@13@01 | live]
(push) ; 10
; [then-branch: 44 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 10
(push) ; 10
; [else-branch: 44 | p1@13@01]
(assert p1@13@01)
(pop) ; 10
(pop) ; 9
; Joined path conditions
; Joined path conditions
(assert (or p1@13@01 (not p1@13@01)))
(pop) ; 8
(pop) ; 7
; Joined path conditions
; Joined path conditions
(assert (=> p0@12@01 (and p0@12@01 (or p1@13@01 (not p1@13@01)))))
(assert (or p0@12@01 (not p0@12@01)))
(pop) ; 6
(pop) ; 5
; Joined path conditions
; Joined path conditions
(assert (and
  (=> p0@12@01 (and p0@12@01 (or p1@13@01 (not p1@13@01))))
  (or p0@12@01 (not p0@12@01))))
(push) ; 5
(push) ; 6
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 6
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [then-branch: 45 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 45 | !(p0@12@01 && p1@13@01 && p2@14@01) | live]
(set-option :rlimit 0)
(push) ; 6
; [then-branch: 45 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 7
; [then-branch: 46 | !(res@21@01 > 0) | live]
; [else-branch: 46 | res@21@01 > 0 | live]
(push) ; 8
; [then-branch: 46 | !(res@21@01 > 0)]
(assert (not (> res@21@01 0)))
(pop) ; 8
(push) ; 8
; [else-branch: 46 | res@21@01 > 0]
(assert (> res@21@01 0))
; [eval] res_0 > 0
(pop) ; 8
(pop) ; 7
; Joined path conditions
; Joined path conditions
(assert (or (> res@21@01 0) (not (> res@21@01 0))))
(push) ; 7
(push) ; 8
(set-option :rlimit 16000)
(assert (not (not (and (> res@21@01 0) (> res_0@22@01 0)))))
(check-sat)
; unknown
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 8
(set-option :rlimit 16000)
(assert (not (and (> res@21@01 0) (> res_0@22@01 0))))
(check-sat)
; unknown
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
; [then-branch: 47 | res@21@01 > 0 && res_0@22@01 > 0 | live]
; [else-branch: 47 | !(res@21@01 > 0 && res_0@22@01 > 0) | live]
(set-option :rlimit 0)
(push) ; 8
; [then-branch: 47 | res@21@01 > 0 && res_0@22@01 > 0]
(assert (and (> res@21@01 0) (> res_0@22@01 0)))
; [eval] res_1 > 0
(pop) ; 8
(push) ; 8
; [else-branch: 47 | !(res@21@01 > 0 && res_0@22@01 > 0)]
(assert (not (and (> res@21@01 0) (> res_0@22@01 0))))
(pop) ; 8
(pop) ; 7
; Joined path conditions
; Joined path conditions
(assert (or
  (not (and (> res@21@01 0) (> res_0@22@01 0)))
  (and (> res@21@01 0) (> res_0@22@01 0))))
(pop) ; 6
(push) ; 6
; [else-branch: 45 | !(p0@12@01 && p1@13@01 && p2@14@01)]
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(pop) ; 6
(pop) ; 5
; Joined path conditions
(assert (=>
  (and p0@12@01 (and p1@13@01 p2@14@01))
  (and
    p0@12@01
    p1@13@01
    p2@14@01
    (or (> res@21@01 0) (not (> res@21@01 0)))
    (or
      (not (and (> res@21@01 0) (> res_0@22@01 0)))
      (and (> res@21@01 0) (> res_0@22@01 0))))))
; Joined path conditions
(assert (or
  (not (and p0@12@01 (and p1@13@01 p2@14@01)))
  (and p0@12@01 (and p1@13@01 p2@14@01))))
(pop) ; 4
(push) ; 4
; [else-branch: 41 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 4
(pop) ; 3
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> p0@12@01 (and p0@12@01 (or p1@13@01 (not p1@13@01))))
    (or p0@12@01 (not p0@12@01))
    (=>
      (and p0@12@01 (and p1@13@01 p2@14@01))
      (and
        p0@12@01
        p1@13@01
        p2@14@01
        (or (> res@21@01 0) (not (> res@21@01 0)))
        (or
          (not (and (> res@21@01 0) (> res_0@22@01 0)))
          (and (> res@21@01 0) (> res_0@22@01 0)))))
    (or
      (not (and p0@12@01 (and p1@13@01 p2@14@01)))
      (and p0@12@01 (and p1@13@01 p2@14@01))))))
; Joined path conditions
(assert (=>
  (and
    p2@14@01
    (and
      (and p0@12@01 (and p1@13@01 p2@14@01))
      (and (> res@21@01 0) (> res_0@22@01 0))))
  (> res_1@23@01 0)))
(pop) ; 2
(push) ; 2
; [exec]
; var returned: Bool
(declare-const returned@26@01 Bool)
; [exec]
; var _cond0: Bool
(declare-const _cond0@27@01 Bool)
; [exec]
; var returned_0: Bool
(declare-const returned_0@28@01 Bool)
; [exec]
; var returned_1: Bool
(declare-const returned_1@29@01 Bool)
; [exec]
; var _cond0_0: Bool
(declare-const _cond0_0@30@01 Bool)
; [exec]
; var _cond0_1: Bool
(declare-const _cond0_1@31@01 Bool)
; [exec]
; var pt0: Bool
(declare-const pt0@32@01 Bool)
; [exec]
; var pt1: Bool
(declare-const pt1@33@01 Bool)
; [exec]
; var pt2: Bool
(declare-const pt2@34@01 Bool)
; [exec]
; var pf0: Bool
(declare-const pf0@35@01 Bool)
; [exec]
; var pf1: Bool
(declare-const pf1@36@01 Bool)
; [exec]
; var pf2: Bool
(declare-const pf2@37@01 Bool)
; [exec]
; var pt0_0: Bool
(declare-const pt0_0@38@01 Bool)
; [exec]
; var pt1_0: Bool
(declare-const pt1_0@39@01 Bool)
; [exec]
; var pt2_0: Bool
(declare-const pt2_0@40@01 Bool)
; [exec]
; var pf0_0: Bool
(declare-const pf0_0@41@01 Bool)
; [exec]
; var pf1_0: Bool
(declare-const pf1_0@42@01 Bool)
; [exec]
; var pf2_0: Bool
(declare-const pf2_0@43@01 Bool)
; [exec]
; var pt0_1: Bool
(declare-const pt0_1@44@01 Bool)
; [exec]
; var pt1_1: Bool
(declare-const pt1_1@45@01 Bool)
; [exec]
; var pt2_1: Bool
(declare-const pt2_1@46@01 Bool)
; [exec]
; var pf0_1: Bool
(declare-const pf0_1@47@01 Bool)
; [exec]
; var pf1_1: Bool
(declare-const pf1_1@48@01 Bool)
; [exec]
; var pf2_1: Bool
(declare-const pf2_1@49@01 Bool)
; [exec]
; var pt0_2: Bool
(declare-const pt0_2@50@01 Bool)
; [exec]
; var pt1_2: Bool
(declare-const pt1_2@51@01 Bool)
; [exec]
; var pt2_2: Bool
(declare-const pt2_2@52@01 Bool)
; [exec]
; var pf0_2: Bool
(declare-const pf0_2@53@01 Bool)
; [exec]
; var pf1_2: Bool
(declare-const pf1_2@54@01 Bool)
; [exec]
; var pf2_2: Bool
(declare-const pf2_2@55@01 Bool)
; [exec]
; var pt0_3: Bool
(declare-const pt0_3@56@01 Bool)
; [exec]
; var pt1_3: Bool
(declare-const pt1_3@57@01 Bool)
; [exec]
; var pt2_3: Bool
(declare-const pt2_3@58@01 Bool)
; [exec]
; var pf0_3: Bool
(declare-const pf0_3@59@01 Bool)
; [exec]
; var pf1_3: Bool
(declare-const pf1_3@60@01 Bool)
; [exec]
; var pf2_3: Bool
(declare-const pf2_3@61@01 Bool)
; [exec]
; var pt0_4: Bool
(declare-const pt0_4@62@01 Bool)
; [exec]
; var pt1_4: Bool
(declare-const pt1_4@63@01 Bool)
; [exec]
; var pt2_4: Bool
(declare-const pt2_4@64@01 Bool)
; [exec]
; var pf0_4: Bool
(declare-const pf0_4@65@01 Bool)
; [exec]
; var pf1_4: Bool
(declare-const pf1_4@66@01 Bool)
; [exec]
; var pf2_4: Bool
(declare-const pf2_4@67@01 Bool)
; [exec]
; var pt0_5: Bool
(declare-const pt0_5@68@01 Bool)
; [exec]
; var pt1_5: Bool
(declare-const pt1_5@69@01 Bool)
; [exec]
; var pt2_5: Bool
(declare-const pt2_5@70@01 Bool)
; [exec]
; var pf0_5: Bool
(declare-const pf0_5@71@01 Bool)
; [exec]
; var pf1_5: Bool
(declare-const pf1_5@72@01 Bool)
; [exec]
; var pf2_5: Bool
(declare-const pf2_5@73@01 Bool)
; [exec]
; var pt0_6: Bool
(declare-const pt0_6@74@01 Bool)
; [exec]
; var pt1_6: Bool
(declare-const pt1_6@75@01 Bool)
; [exec]
; var pt2_6: Bool
(declare-const pt2_6@76@01 Bool)
; [exec]
; var pf0_6: Bool
(declare-const pf0_6@77@01 Bool)
; [exec]
; var pf1_6: Bool
(declare-const pf1_6@78@01 Bool)
; [exec]
; var pf2_6: Bool
(declare-const pf2_6@79@01 Bool)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 48 | p0@12@01 | live]
; [else-branch: 48 | !(p0@12@01) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 48 | p0@12@01]
(assert p0@12@01)
; [exec]
; _cond0 := false
(push) ; 4
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 4
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unknown
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [then-branch: 49 | p1@13@01 | live]
; [else-branch: 49 | !(p1@13@01) | live]
(set-option :rlimit 0)
(push) ; 4
; [then-branch: 49 | p1@13@01]
(assert p1@13@01)
; [exec]
; _cond0_0 := false
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 50 | p2@14@01 | live]
; [else-branch: 50 | !(p2@14@01) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 50 | p2@14@01]
(assert p2@14@01)
; [exec]
; _cond0_1 := false
(push) ; 6
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [then-branch: 51 | p0@12@01 | live]
; [else-branch: 51 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 6
; [then-branch: 51 | p0@12@01]
; [exec]
; returned := false
(push) ; 7
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 52 | p1@13@01 | live]
; [else-branch: 52 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 7
; [then-branch: 52 | p1@13@01]
; [exec]
; returned_0 := false
(push) ; 8
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
; [then-branch: 53 | p2@14@01 | live]
; [else-branch: 53 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 8
; [then-branch: 53 | p2@14@01]
; [exec]
; returned_1 := false
; [exec]
; pt0 := p0 && o1 == o2
; [eval] p0 && o1 == o2
(push) ; 9
; [then-branch: 54 | !(p0@12@01) | live]
; [else-branch: 54 | p0@12@01 | live]
(push) ; 10
; [then-branch: 54 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 10
(push) ; 10
; [else-branch: 54 | p0@12@01]
; [eval] o1 == o2
(pop) ; 10
(pop) ; 9
; Joined path conditions
; Joined path conditions
(assert (or p0@12@01 (not p0@12@01)))
(declare-const pt0@80@01 Bool)
(assert (= pt0@80@01 (and p0@12@01 (= o1@15@01 o2@18@01))))
; [exec]
; pt1 := p1 && o1_0 == o2_0
; [eval] p1 && o1_0 == o2_0
(push) ; 9
; [then-branch: 55 | !(p1@13@01) | live]
; [else-branch: 55 | p1@13@01 | live]
(push) ; 10
; [then-branch: 55 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 10
(push) ; 10
; [else-branch: 55 | p1@13@01]
; [eval] o1_0 == o2_0
(pop) ; 10
(pop) ; 9
; Joined path conditions
; Joined path conditions
(assert (or p1@13@01 (not p1@13@01)))
(declare-const pt1@81@01 Bool)
(assert (= pt1@81@01 (and p1@13@01 (= o1_0@16@01 o2_0@19@01))))
; [exec]
; pt2 := p2 && o1_1 == o2_1
; [eval] p2 && o1_1 == o2_1
(push) ; 9
; [then-branch: 56 | !(p2@14@01) | live]
; [else-branch: 56 | p2@14@01 | live]
(push) ; 10
; [then-branch: 56 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 10
(push) ; 10
; [else-branch: 56 | p2@14@01]
; [eval] o1_1 == o2_1
(pop) ; 10
(pop) ; 9
; Joined path conditions
; Joined path conditions
(assert (or p2@14@01 (not p2@14@01)))
(declare-const pt2@82@01 Bool)
(assert (= pt2@82@01 (and p2@14@01 (= o1_1@17@01 o2_1@20@01))))
; [exec]
; pf0 := p0 && !(o1 == o2)
; [eval] p0 && !(o1 == o2)
(push) ; 9
; [then-branch: 57 | !(p0@12@01) | live]
; [else-branch: 57 | p0@12@01 | live]
(push) ; 10
; [then-branch: 57 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 10
(push) ; 10
; [else-branch: 57 | p0@12@01]
; [eval] !(o1 == o2)
; [eval] o1 == o2
(pop) ; 10
(pop) ; 9
; Joined path conditions
; Joined path conditions
(declare-const pf0@83@01 Bool)
(assert (= pf0@83@01 (and p0@12@01 (not (= o1@15@01 o2@18@01)))))
; [exec]
; pf1 := p1 && !(o1_0 == o2_0)
; [eval] p1 && !(o1_0 == o2_0)
(push) ; 9
; [then-branch: 58 | !(p1@13@01) | live]
; [else-branch: 58 | p1@13@01 | live]
(push) ; 10
; [then-branch: 58 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 10
(push) ; 10
; [else-branch: 58 | p1@13@01]
; [eval] !(o1_0 == o2_0)
; [eval] o1_0 == o2_0
(pop) ; 10
(pop) ; 9
; Joined path conditions
; Joined path conditions
(declare-const pf1@84@01 Bool)
(assert (= pf1@84@01 (and p1@13@01 (not (= o1_0@16@01 o2_0@19@01)))))
; [exec]
; pf2 := p2 && !(o1_1 == o2_1)
; [eval] p2 && !(o1_1 == o2_1)
(push) ; 9
; [then-branch: 59 | !(p2@14@01) | live]
; [else-branch: 59 | p2@14@01 | live]
(push) ; 10
; [then-branch: 59 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 10
(push) ; 10
; [else-branch: 59 | p2@14@01]
; [eval] !(o1_1 == o2_1)
; [eval] o1_1 == o2_1
(pop) ; 10
(pop) ; 9
; Joined path conditions
; Joined path conditions
(declare-const pf2@85@01 Bool)
(assert (= pf2@85@01 (and p2@14@01 (not (= o1_1@17@01 o2_1@20@01)))))
(push) ; 9
(set-option :rlimit 16000)
(assert (not (not pt0@80@01)))
(check-sat)
; unknown
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 16000)
(assert (not pt0@80@01))
(check-sat)
; unknown
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
; [then-branch: 60 | pt0@80@01 | live]
; [else-branch: 60 | !(pt0@80@01) | live]
(set-option :rlimit 0)
(push) ; 9
; [then-branch: 60 | pt0@80@01]
(assert pt0@80@01)
; [exec]
; res := 0
(push) ; 10
(set-option :rlimit 16000)
(assert (not (not pt1@81@01)))
(check-sat)
; unknown
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 10
(set-option :rlimit 16000)
(assert (not pt1@81@01))
(check-sat)
; unknown
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
; [then-branch: 61 | pt1@81@01 | live]
; [else-branch: 61 | !(pt1@81@01) | live]
(set-option :rlimit 0)
(push) ; 10
; [then-branch: 61 | pt1@81@01]
(assert pt1@81@01)
; [exec]
; res_0 := 0
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not pt2@82@01)))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 16000)
(assert (not pt2@82@01))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 62 | pt2@82@01 | live]
; [else-branch: 62 | !(pt2@82@01) | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 62 | pt2@82@01]
(assert pt2@82@01)
; [exec]
; res_1 := 0
(push) ; 12
(set-option :rlimit 16000)
(assert (not (not pt0@80@01)))
(check-sat)
; unknown
(pop) ; 12
; 0.00s
; (get-info :all-statistics)
; [then-branch: 63 | pt0@80@01 | live]
; [else-branch: 63 | !(pt0@80@01) | dead]
(set-option :rlimit 0)
(push) ; 12
; [then-branch: 63 | pt0@80@01]
; [exec]
; returned := true
(push) ; 13
(set-option :rlimit 16000)
(assert (not (not pt1@81@01)))
(check-sat)
; unknown
(pop) ; 13
; 0.00s
; (get-info :all-statistics)
; [then-branch: 64 | pt1@81@01 | live]
; [else-branch: 64 | !(pt1@81@01) | dead]
(set-option :rlimit 0)
(push) ; 13
; [then-branch: 64 | pt1@81@01]
; [exec]
; returned_0 := true
(push) ; 14
(set-option :rlimit 16000)
(assert (not (not pt2@82@01)))
(check-sat)
; unknown
(pop) ; 14
; 0.00s
; (get-info :all-statistics)
; [then-branch: 65 | pt2@82@01 | live]
; [else-branch: 65 | !(pt2@82@01) | dead]
(set-option :rlimit 0)
(push) ; 14
; [then-branch: 65 | pt2@82@01]
; [exec]
; returned_1 := true
; [exec]
; pt0_0 := p0 && !returned
; [eval] p0 && !returned
(push) ; 15
; [then-branch: 66 | !(p0@12@01) | live]
; [else-branch: 66 | p0@12@01 | live]
(push) ; 16
; [then-branch: 66 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 16
(push) ; 16
; [else-branch: 66 | p0@12@01]
; [eval] !returned
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pt1_0 := p1 && !returned_0
; [eval] p1 && !returned_0
(push) ; 15
; [then-branch: 67 | !(p1@13@01) | live]
; [else-branch: 67 | p1@13@01 | live]
(push) ; 16
; [then-branch: 67 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 16
(push) ; 16
; [else-branch: 67 | p1@13@01]
; [eval] !returned_0
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pt2_0 := p2 && !returned_1
; [eval] p2 && !returned_1
(push) ; 15
; [then-branch: 68 | !(p2@14@01) | live]
; [else-branch: 68 | p2@14@01 | live]
(push) ; 16
; [then-branch: 68 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 16
(push) ; 16
; [else-branch: 68 | p2@14@01]
; [eval] !returned_1
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pf0_0 := p0 && !!returned
; [eval] p0 && !!returned
(push) ; 15
; [then-branch: 69 | !(p0@12@01) | live]
; [else-branch: 69 | p0@12@01 | live]
(push) ; 16
; [then-branch: 69 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 16
(push) ; 16
; [else-branch: 69 | p0@12@01]
; [eval] !!returned
; [eval] !returned
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pf1_0 := p1 && !!returned_0
; [eval] p1 && !!returned_0
(push) ; 15
; [then-branch: 70 | !(p1@13@01) | live]
; [else-branch: 70 | p1@13@01 | live]
(push) ; 16
; [then-branch: 70 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 16
(push) ; 16
; [else-branch: 70 | p1@13@01]
; [eval] !!returned_0
; [eval] !returned_0
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pf2_0 := p2 && !!returned_1
; [eval] p2 && !!returned_1
(push) ; 15
; [then-branch: 71 | !(p2@14@01) | live]
; [else-branch: 71 | p2@14@01 | live]
(push) ; 16
; [then-branch: 71 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 16
(push) ; 16
; [else-branch: 71 | p2@14@01]
; [eval] !!returned_1
; [eval] !returned_1
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pt0_1 := pt0_0 && getCardSet(o1) < getCardSet(o2)
; [eval] pt0_0 && getCardSet(o1) < getCardSet(o2)
; [exec]
; pt1_1 := pt1_0 && getCardSet(o1_0) < getCardSet(o2_0)
; [eval] pt1_0 && getCardSet(o1_0) < getCardSet(o2_0)
; [exec]
; pt2_1 := pt2_0 && getCardSet(o1_1) < getCardSet(o2_1)
; [eval] pt2_0 && getCardSet(o1_1) < getCardSet(o2_1)
; [exec]
; pf0_1 := pt0_0 && !(getCardSet(o1) < getCardSet(o2))
; [eval] pt0_0 && !(getCardSet(o1) < getCardSet(o2))
; [exec]
; pf1_1 := pt1_0 && !(getCardSet(o1_0) < getCardSet(o2_0))
; [eval] pt1_0 && !(getCardSet(o1_0) < getCardSet(o2_0))
; [exec]
; pf2_1 := pt2_0 && !(getCardSet(o1_1) < getCardSet(o2_1))
; [eval] pt2_0 && !(getCardSet(o1_1) < getCardSet(o2_1))
; [then-branch: 72 | False | dead]
; [else-branch: 72 | True | live]
(push) ; 15
; [else-branch: 72 | True]
(pop) ; 15
; [eval] !pt0_1
(push) ; 15
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
; [then-branch: 73 | True | live]
; [else-branch: 73 | False | dead]
(set-option :rlimit 0)
(push) ; 15
; [then-branch: 73 | True]
; [then-branch: 74 | False | dead]
; [else-branch: 74 | True | live]
(push) ; 16
; [else-branch: 74 | True]
(pop) ; 16
; [eval] !pt1_1
(push) ; 16
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [then-branch: 75 | True | live]
; [else-branch: 75 | False | dead]
(set-option :rlimit 0)
(push) ; 16
; [then-branch: 75 | True]
; [then-branch: 76 | False | dead]
; [else-branch: 76 | True | live]
(push) ; 17
; [else-branch: 76 | True]
(pop) ; 17
; [eval] !pt2_1
(push) ; 17
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
; [then-branch: 77 | True | live]
; [else-branch: 77 | False | dead]
(set-option :rlimit 0)
(push) ; 17
; [then-branch: 77 | True]
; [then-branch: 78 | False | dead]
; [else-branch: 78 | True | live]
(push) ; 18
; [else-branch: 78 | True]
(pop) ; 18
; [eval] !pt0_1
(push) ; 18
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
; [then-branch: 79 | True | live]
; [else-branch: 79 | False | dead]
(set-option :rlimit 0)
(push) ; 18
; [then-branch: 79 | True]
; [then-branch: 80 | False | dead]
; [else-branch: 80 | True | live]
(push) ; 19
; [else-branch: 80 | True]
(pop) ; 19
; [eval] !pt1_1
(push) ; 19
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 81 | True | live]
; [else-branch: 81 | False | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 81 | True]
; [then-branch: 82 | False | dead]
; [else-branch: 82 | True | live]
(push) ; 20
; [else-branch: 82 | True]
(pop) ; 20
; [eval] !pt2_1
(push) ; 20
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 83 | True | live]
; [else-branch: 83 | False | dead]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 83 | True]
; [exec]
; pt0_2 := pf0_1 && getCardSet(o1) == getCardSet(o2)
; [eval] pf0_1 && getCardSet(o1) == getCardSet(o2)
; [exec]
; pt1_2 := pf1_1 && getCardSet(o1_0) == getCardSet(o2_0)
; [eval] pf1_1 && getCardSet(o1_0) == getCardSet(o2_0)
; [exec]
; pt2_2 := pf2_1 && getCardSet(o1_1) == getCardSet(o2_1)
; [eval] pf2_1 && getCardSet(o1_1) == getCardSet(o2_1)
; [exec]
; pf0_2 := pf0_1 && !(getCardSet(o1) == getCardSet(o2))
; [eval] pf0_1 && !(getCardSet(o1) == getCardSet(o2))
; [exec]
; pf1_2 := pf1_1 && !(getCardSet(o1_0) == getCardSet(o2_0))
; [eval] pf1_1 && !(getCardSet(o1_0) == getCardSet(o2_0))
; [exec]
; pf2_2 := pf2_1 && !(getCardSet(o1_1) == getCardSet(o2_1))
; [eval] pf2_1 && !(getCardSet(o1_1) == getCardSet(o2_1))
; [exec]
; pt0_3 := pt0_2 && getCardRarity(o1) < getCardRarity(o2)
; [eval] pt0_2 && getCardRarity(o1) < getCardRarity(o2)
; [exec]
; pt1_3 := pt1_2 && getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] pt1_2 && getCardRarity(o1_0) < getCardRarity(o2_0)
; [exec]
; pt2_3 := pt2_2 && getCardRarity(o1_1) < getCardRarity(o2_1)
; [eval] pt2_2 && getCardRarity(o1_1) < getCardRarity(o2_1)
; [exec]
; pf0_3 := pt0_2 && !(getCardRarity(o1) < getCardRarity(o2))
; [eval] pt0_2 && !(getCardRarity(o1) < getCardRarity(o2))
; [exec]
; pf1_3 := pt1_2 && !(getCardRarity(o1_0) < getCardRarity(o2_0))
; [eval] pt1_2 && !(getCardRarity(o1_0) < getCardRarity(o2_0))
; [exec]
; pf2_3 := pt2_2 && !(getCardRarity(o1_1) < getCardRarity(o2_1))
; [eval] pt2_2 && !(getCardRarity(o1_1) < getCardRarity(o2_1))
; [then-branch: 84 | False | dead]
; [else-branch: 84 | True | live]
(push) ; 21
; [else-branch: 84 | True]
(pop) ; 21
; [eval] !pt0_3
(push) ; 21
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 85 | True | live]
; [else-branch: 85 | False | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 85 | True]
; [then-branch: 86 | False | dead]
; [else-branch: 86 | True | live]
(push) ; 22
; [else-branch: 86 | True]
(pop) ; 22
; [eval] !pt1_3
(push) ; 22
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 87 | True | live]
; [else-branch: 87 | False | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 87 | True]
; [then-branch: 88 | False | dead]
; [else-branch: 88 | True | live]
(push) ; 23
; [else-branch: 88 | True]
(pop) ; 23
; [eval] !pt2_3
(push) ; 23
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 89 | True | live]
; [else-branch: 89 | False | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 89 | True]
; [then-branch: 90 | False | dead]
; [else-branch: 90 | True | live]
(push) ; 24
; [else-branch: 90 | True]
(pop) ; 24
; [eval] !pt0_3
(push) ; 24
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
; [then-branch: 91 | True | live]
; [else-branch: 91 | False | dead]
(set-option :rlimit 0)
(push) ; 24
; [then-branch: 91 | True]
; [then-branch: 92 | False | dead]
; [else-branch: 92 | True | live]
(push) ; 25
; [else-branch: 92 | True]
(pop) ; 25
; [eval] !pt1_3
(push) ; 25
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 93 | True | live]
; [else-branch: 93 | False | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 93 | True]
; [then-branch: 94 | False | dead]
; [else-branch: 94 | True | live]
(push) ; 26
; [else-branch: 94 | True]
(pop) ; 26
; [eval] !pt2_3
(push) ; 26
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 26
; 0.00s
; (get-info :all-statistics)
; [then-branch: 95 | True | live]
; [else-branch: 95 | False | dead]
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 95 | True]
; [exec]
; pt0_4 := pf0_3 && getCardId(o1) == getCardId(o2)
; [eval] pf0_3 && getCardId(o1) == getCardId(o2)
; [exec]
; pt1_4 := pf1_3 && getCardId(o1_0) == getCardId(o2_0)
; [eval] pf1_3 && getCardId(o1_0) == getCardId(o2_0)
; [exec]
; pt2_4 := pf2_3 && getCardId(o1_1) == getCardId(o2_1)
; [eval] pf2_3 && getCardId(o1_1) == getCardId(o2_1)
; [exec]
; pf0_4 := pf0_3 && !(getCardId(o1) == getCardId(o2))
; [eval] pf0_3 && !(getCardId(o1) == getCardId(o2))
; [exec]
; pf1_4 := pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
; [eval] pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
; [exec]
; pf2_4 := pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
; [eval] pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
; [exec]
; pt0_5 := pt0_4 && cardType(o1) > cardType(o2)
; [eval] pt0_4 && cardType(o1) > cardType(o2)
; [exec]
; pt1_5 := pt1_4 && cardType(o1_0) > cardType(o2_0)
; [eval] pt1_4 && cardType(o1_0) > cardType(o2_0)
; [exec]
; pt2_5 := pt2_4 && cardType(o1_1) > cardType(o2_1)
; [eval] pt2_4 && cardType(o1_1) > cardType(o2_1)
; [exec]
; pf0_5 := pt0_4 && !(cardType(o1) > cardType(o2))
; [eval] pt0_4 && !(cardType(o1) > cardType(o2))
; [exec]
; pf1_5 := pt1_4 && !(cardType(o1_0) > cardType(o2_0))
; [eval] pt1_4 && !(cardType(o1_0) > cardType(o2_0))
; [exec]
; pf2_5 := pt2_4 && !(cardType(o1_1) > cardType(o2_1))
; [eval] pt2_4 && !(cardType(o1_1) > cardType(o2_1))
; [then-branch: 96 | False | dead]
; [else-branch: 96 | True | live]
(push) ; 27
; [else-branch: 96 | True]
(pop) ; 27
; [eval] !pt0_5
(push) ; 27
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 97 | True | live]
; [else-branch: 97 | False | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 97 | True]
; [then-branch: 98 | False | dead]
; [else-branch: 98 | True | live]
(push) ; 28
; [else-branch: 98 | True]
(pop) ; 28
; [eval] !pt1_5
(push) ; 28
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 99 | True | live]
; [else-branch: 99 | False | dead]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 99 | True]
; [then-branch: 100 | False | dead]
; [else-branch: 100 | True | live]
(push) ; 29
; [else-branch: 100 | True]
(pop) ; 29
; [eval] !pt2_5
(push) ; 29
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 101 | True | live]
; [else-branch: 101 | False | dead]
(set-option :rlimit 0)
(push) ; 29
; [then-branch: 101 | True]
; [then-branch: 102 | False | dead]
; [else-branch: 102 | True | live]
(push) ; 30
; [else-branch: 102 | True]
(pop) ; 30
; [eval] !pt0_5
(push) ; 30
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 30
; 0.00s
; (get-info :all-statistics)
; [then-branch: 103 | True | live]
; [else-branch: 103 | False | dead]
(set-option :rlimit 0)
(push) ; 30
; [then-branch: 103 | True]
; [then-branch: 104 | False | dead]
; [else-branch: 104 | True | live]
(push) ; 31
; [else-branch: 104 | True]
(pop) ; 31
; [eval] !pt1_5
(push) ; 31
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 31
; 0.00s
; (get-info :all-statistics)
; [then-branch: 105 | True | live]
; [else-branch: 105 | False | dead]
(set-option :rlimit 0)
(push) ; 31
; [then-branch: 105 | True]
; [then-branch: 106 | False | dead]
; [else-branch: 106 | True | live]
(push) ; 32
; [else-branch: 106 | True]
(pop) ; 32
; [eval] !pt2_5
(push) ; 32
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 32
; 0.00s
; (get-info :all-statistics)
; [then-branch: 107 | True | live]
; [else-branch: 107 | False | dead]
(set-option :rlimit 0)
(push) ; 32
; [then-branch: 107 | True]
; [exec]
; pt0_6 := pf0_5 && cardType(o1) == cardType(o2)
; [eval] pf0_5 && cardType(o1) == cardType(o2)
; [exec]
; pt1_6 := pf1_5 && cardType(o1_0) == cardType(o2_0)
; [eval] pf1_5 && cardType(o1_0) == cardType(o2_0)
; [exec]
; pt2_6 := pf2_5 && cardType(o1_1) == cardType(o2_1)
; [eval] pf2_5 && cardType(o1_1) == cardType(o2_1)
; [exec]
; pf0_6 := pf0_5 && !(cardType(o1) == cardType(o2))
; [eval] pf0_5 && !(cardType(o1) == cardType(o2))
; [exec]
; pf1_6 := pf1_5 && !(cardType(o1_0) == cardType(o2_0))
; [eval] pf1_5 && !(cardType(o1_0) == cardType(o2_0))
; [exec]
; pf2_6 := pf2_5 && !(cardType(o1_1) == cardType(o2_1))
; [eval] pf2_5 && !(cardType(o1_1) == cardType(o2_1))
; [then-branch: 108 | False | dead]
; [else-branch: 108 | True | live]
(push) ; 33
; [else-branch: 108 | True]
(pop) ; 33
; [eval] !pt0_6
(push) ; 33
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 109 | True | live]
; [else-branch: 109 | False | dead]
(set-option :rlimit 0)
(push) ; 33
; [then-branch: 109 | True]
; [then-branch: 110 | False | dead]
; [else-branch: 110 | True | live]
(push) ; 34
; [else-branch: 110 | True]
(pop) ; 34
; [eval] !pt1_6
(push) ; 34
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 111 | True | live]
; [else-branch: 111 | False | dead]
(set-option :rlimit 0)
(push) ; 34
; [then-branch: 111 | True]
; [then-branch: 112 | False | dead]
; [else-branch: 112 | True | live]
(push) ; 35
; [else-branch: 112 | True]
(pop) ; 35
; [eval] !pt2_6
(push) ; 35
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 113 | True | live]
; [else-branch: 113 | False | dead]
(set-option :rlimit 0)
(push) ; 35
; [then-branch: 113 | True]
; [then-branch: 114 | False | dead]
; [else-branch: 114 | True | live]
(push) ; 36
; [else-branch: 114 | True]
(pop) ; 36
; [eval] !pt0_6
(push) ; 36
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 36
; 0.00s
; (get-info :all-statistics)
; [then-branch: 115 | True | live]
; [else-branch: 115 | False | dead]
(set-option :rlimit 0)
(push) ; 36
; [then-branch: 115 | True]
; [then-branch: 116 | False | dead]
; [else-branch: 116 | True | live]
(push) ; 37
; [else-branch: 116 | True]
(pop) ; 37
; [eval] !pt1_6
(push) ; 37
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 37
; 0.00s
; (get-info :all-statistics)
; [then-branch: 117 | True | live]
; [else-branch: 117 | False | dead]
(set-option :rlimit 0)
(push) ; 37
; [then-branch: 117 | True]
; [then-branch: 118 | False | dead]
; [else-branch: 118 | True | live]
(push) ; 38
; [else-branch: 118 | True]
(pop) ; 38
; [eval] !pt2_6
(push) ; 38
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 38
; 0.00s
; (get-info :all-statistics)
; [then-branch: 119 | True | live]
; [else-branch: 119 | False | dead]
(set-option :rlimit 0)
(push) ; 38
; [then-branch: 119 | True]
; [then-branch: 120 | False | dead]
; [else-branch: 120 | True | live]
(push) ; 39
; [else-branch: 120 | True]
(pop) ; 39
; [eval] !pf0_6
(push) ; 39
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 121 | True | live]
; [else-branch: 121 | False | dead]
(set-option :rlimit 0)
(push) ; 39
; [then-branch: 121 | True]
; [then-branch: 122 | False | dead]
; [else-branch: 122 | True | live]
(push) ; 40
; [else-branch: 122 | True]
(pop) ; 40
; [eval] !pf1_6
(push) ; 40
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 123 | True | live]
; [else-branch: 123 | False | dead]
(set-option :rlimit 0)
(push) ; 40
; [then-branch: 123 | True]
; [then-branch: 124 | False | dead]
; [else-branch: 124 | True | live]
(push) ; 41
; [else-branch: 124 | True]
(pop) ; 41
; [eval] !pf2_6
(push) ; 41
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 125 | True | live]
; [else-branch: 125 | False | dead]
(set-option :rlimit 0)
(push) ; 41
; [then-branch: 125 | True]
; [then-branch: 126 | False | dead]
; [else-branch: 126 | True | live]
(push) ; 42
; [else-branch: 126 | True]
(pop) ; 42
; [eval] !pf0_6
(push) ; 42
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 42
; 0.00s
; (get-info :all-statistics)
; [then-branch: 127 | True | live]
; [else-branch: 127 | False | dead]
(set-option :rlimit 0)
(push) ; 42
; [then-branch: 127 | True]
; [then-branch: 128 | False | dead]
; [else-branch: 128 | True | live]
(push) ; 43
; [else-branch: 128 | True]
(pop) ; 43
; [eval] !pf1_6
(push) ; 43
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 43
; 0.00s
; (get-info :all-statistics)
; [then-branch: 129 | True | live]
; [else-branch: 129 | False | dead]
(set-option :rlimit 0)
(push) ; 43
; [then-branch: 129 | True]
; [then-branch: 130 | False | dead]
; [else-branch: 130 | True | live]
(push) ; 44
; [else-branch: 130 | True]
(pop) ; 44
; [eval] !pf2_6
(push) ; 44
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 44
; 0.00s
; (get-info :all-statistics)
; [then-branch: 131 | True | live]
; [else-branch: 131 | False | dead]
(set-option :rlimit 0)
(push) ; 44
; [then-branch: 131 | True]
; [then-branch: 132 | False | dead]
; [else-branch: 132 | True | live]
(push) ; 45
; [else-branch: 132 | True]
(pop) ; 45
; [eval] !pf0_4
(push) ; 45
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 133 | True | live]
; [else-branch: 133 | False | dead]
(set-option :rlimit 0)
(push) ; 45
; [then-branch: 133 | True]
; [then-branch: 134 | False | dead]
; [else-branch: 134 | True | live]
(push) ; 46
; [else-branch: 134 | True]
(pop) ; 46
; [eval] !pf1_4
(push) ; 46
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 135 | True | live]
; [else-branch: 135 | False | dead]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 135 | True]
; [then-branch: 136 | False | dead]
; [else-branch: 136 | True | live]
(push) ; 47
; [else-branch: 136 | True]
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 137 | True | live]
; [else-branch: 137 | False | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 137 | True]
; [then-branch: 138 | False | dead]
; [else-branch: 138 | True | live]
(push) ; 48
; [else-branch: 138 | True]
(pop) ; 48
; [eval] !pf0_4
(push) ; 48
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 139 | True | live]
; [else-branch: 139 | False | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 139 | True]
; [then-branch: 140 | False | dead]
; [else-branch: 140 | True | live]
(push) ; 49
; [else-branch: 140 | True]
(pop) ; 49
; [eval] !pf1_4
(push) ; 49
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 141 | True | live]
; [else-branch: 141 | False | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 141 | True]
; [then-branch: 142 | False | dead]
; [else-branch: 142 | True | live]
(push) ; 50
; [else-branch: 142 | True]
(pop) ; 50
; [eval] !pf2_4
(push) ; 50
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 143 | True | live]
; [else-branch: 143 | False | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 143 | True]
; [then-branch: 144 | False | dead]
; [else-branch: 144 | True | live]
(push) ; 51
; [else-branch: 144 | True]
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 145 | True | live]
; [else-branch: 145 | False | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 145 | True]
; [then-branch: 146 | False | dead]
; [else-branch: 146 | True | live]
(push) ; 52
; [else-branch: 146 | True]
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 147 | True | live]
; [else-branch: 147 | False | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 147 | True]
; [then-branch: 148 | False | dead]
; [else-branch: 148 | True | live]
(push) ; 53
; [else-branch: 148 | True]
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 149 | True | live]
; [else-branch: 149 | False | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 149 | True]
; [then-branch: 150 | False | dead]
; [else-branch: 150 | True | live]
(push) ; 54
; [else-branch: 150 | True]
(pop) ; 54
; [eval] !pf0_2
(push) ; 54
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 151 | True | live]
; [else-branch: 151 | False | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 151 | True]
; [then-branch: 152 | False | dead]
; [else-branch: 152 | True | live]
(push) ; 55
; [else-branch: 152 | True]
(pop) ; 55
; [eval] !pf1_2
(push) ; 55
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 153 | True | live]
; [else-branch: 153 | False | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 153 | True]
; [then-branch: 154 | False | dead]
; [else-branch: 154 | True | live]
(push) ; 56
; [else-branch: 154 | True]
(pop) ; 56
; [eval] !pf2_2
(push) ; 56
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 155 | True | live]
; [else-branch: 155 | False | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 155 | True]
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 156 | p0@12@01 | live]
; [else-branch: 156 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 156 | p0@12@01]
(pop) ; 58
(pop) ; 57
; Joined path conditions
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 157 | p1@13@01 | live]
; [else-branch: 157 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 157 | p1@13@01]
(pop) ; 58
(pop) ; 57
; Joined path conditions
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 158 | p2@14@01 | live]
; [else-branch: 158 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 158 | p2@14@01]
(pop) ; 58
(pop) ; 57
; Joined path conditions
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 159 | p0@12@01 | live]
; [else-branch: 159 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 159 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 160 | False | live]
; [else-branch: 160 | True | live]
(push) ; 60
; [then-branch: 160 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 160 | True]
(push) ; 61
; [then-branch: 161 | !(p0@12@01) | live]
; [else-branch: 161 | p0@12@01 | live]
(push) ; 62
; [then-branch: 161 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 161 | p0@12@01]
(push) ; 63
; [then-branch: 162 | !(p1@13@01) | live]
; [else-branch: 162 | p1@13@01 | live]
(push) ; 64
; [then-branch: 162 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 162 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 163 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 163 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 163 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 164 | False | dead]
; [else-branch: 164 | True | live]
(push) ; 62
; [else-branch: 164 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 165 | p1@13@01 | live]
; [else-branch: 165 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 165 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 166 | False | live]
; [else-branch: 166 | True | live]
(push) ; 60
; [then-branch: 166 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 166 | True]
(push) ; 61
; [then-branch: 167 | !(p0@12@01) | live]
; [else-branch: 167 | p0@12@01 | live]
(push) ; 62
; [then-branch: 167 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 167 | p0@12@01]
(push) ; 63
; [then-branch: 168 | !(p1@13@01) | live]
; [else-branch: 168 | p1@13@01 | live]
(push) ; 64
; [then-branch: 168 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 168 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 169 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 169 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 169 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 170 | False | dead]
; [else-branch: 170 | True | live]
(push) ; 62
; [else-branch: 170 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p2@14@01)))
(assert p1@13@01)
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 171 | p2@14@01 | live]
; [else-branch: 171 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 171 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 172 | False | live]
; [else-branch: 172 | True | live]
(push) ; 60
; [then-branch: 172 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 172 | True]
(push) ; 61
; [then-branch: 173 | !(p0@12@01) | live]
; [else-branch: 173 | p0@12@01 | live]
(push) ; 62
; [then-branch: 173 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 173 | p0@12@01]
(assert p0@12@01)
(push) ; 63
; [then-branch: 174 | !(p1@13@01) | live]
; [else-branch: 174 | p1@13@01 | live]
(push) ; 64
; [then-branch: 174 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 174 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 175 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 175 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 175 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 176 | False | dead]
; [else-branch: 176 | True | live]
(push) ; 62
; [else-branch: 176 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01)))
(assert p2@14@01)
(pop) ; 56
(pop) ; 55
(pop) ; 54
(pop) ; 53
(pop) ; 52
(pop) ; 51
(pop) ; 50
(pop) ; 49
(pop) ; 48
(pop) ; 47
(pop) ; 46
(pop) ; 45
(pop) ; 44
(pop) ; 43
(pop) ; 42
(pop) ; 41
(pop) ; 40
(pop) ; 39
(pop) ; 38
(pop) ; 37
(pop) ; 36
(pop) ; 35
(pop) ; 34
(pop) ; 33
(pop) ; 32
(pop) ; 31
(pop) ; 30
(pop) ; 29
(pop) ; 28
(pop) ; 27
(pop) ; 26
(pop) ; 25
(pop) ; 24
(pop) ; 23
(pop) ; 22
(pop) ; 21
(pop) ; 20
(pop) ; 19
(pop) ; 18
(pop) ; 17
(pop) ; 16
(pop) ; 15
(pop) ; 14
; [eval] !pt2
; [then-branch: 177 | !(pt2@82@01) | dead]
; [else-branch: 177 | pt2@82@01 | live]
(push) ; 14
; [else-branch: 177 | pt2@82@01]
(pop) ; 14
(pop) ; 13
; [eval] !pt1
; [then-branch: 178 | !(pt1@81@01) | dead]
; [else-branch: 178 | pt1@81@01 | live]
(push) ; 13
; [else-branch: 178 | pt1@81@01]
(pop) ; 13
(pop) ; 12
; [eval] !pt0
; [then-branch: 179 | !(pt0@80@01) | dead]
; [else-branch: 179 | pt0@80@01 | live]
(push) ; 12
; [else-branch: 179 | pt0@80@01]
(pop) ; 12
(pop) ; 11
; [eval] !pt2
(push) ; 11
(set-option :rlimit 16000)
(assert (not pt2@82@01))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 180 | !(pt2@82@01) | dead]
; [else-branch: 180 | pt2@82@01 | live]
(set-option :rlimit 0)
(push) ; 11
; [else-branch: 180 | pt2@82@01]
(assert pt2@82@01)
(pop) ; 11
(pop) ; 10
(push) ; 10
; [else-branch: 61 | !(pt1@81@01)]
(assert (not pt1@81@01))
(pop) ; 10
; [eval] !pt1
(push) ; 10
(set-option :rlimit 16000)
(assert (not pt1@81@01))
(check-sat)
; unknown
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 10
(set-option :rlimit 16000)
(assert (not (not pt1@81@01)))
(check-sat)
; unknown
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
; [then-branch: 181 | !(pt1@81@01) | live]
; [else-branch: 181 | pt1@81@01 | live]
(set-option :rlimit 0)
(push) ; 10
; [then-branch: 181 | !(pt1@81@01)]
(assert (not pt1@81@01))
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not pt2@82@01)))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 182 | pt2@82@01 | dead]
; [else-branch: 182 | !(pt2@82@01) | live]
(set-option :rlimit 0)
(push) ; 11
; [else-branch: 182 | !(pt2@82@01)]
(assert (not pt2@82@01))
(pop) ; 11
; [eval] !pt2
(push) ; 11
(set-option :rlimit 16000)
(assert (not pt2@82@01))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not pt2@82@01)))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 183 | !(pt2@82@01) | live]
; [else-branch: 183 | pt2@82@01 | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 183 | !(pt2@82@01)]
(assert (not pt2@82@01))
(push) ; 12
(set-option :rlimit 16000)
(assert (not (not pt0@80@01)))
(check-sat)
; unknown
(pop) ; 12
; 0.00s
; (get-info :all-statistics)
; [then-branch: 184 | pt0@80@01 | live]
; [else-branch: 184 | !(pt0@80@01) | dead]
(set-option :rlimit 0)
(push) ; 12
; [then-branch: 184 | pt0@80@01]
; [exec]
; returned := true
; [then-branch: 185 | pt1@81@01 | dead]
; [else-branch: 185 | !(pt1@81@01) | live]
(push) ; 13
; [else-branch: 185 | !(pt1@81@01)]
(pop) ; 13
; [eval] !pt1
(push) ; 13
(set-option :rlimit 16000)
(assert (not pt1@81@01))
(check-sat)
; unknown
(pop) ; 13
; 0.00s
; (get-info :all-statistics)
; [then-branch: 186 | !(pt1@81@01) | live]
; [else-branch: 186 | pt1@81@01 | dead]
(set-option :rlimit 0)
(push) ; 13
; [then-branch: 186 | !(pt1@81@01)]
; [then-branch: 187 | pt2@82@01 | dead]
; [else-branch: 187 | !(pt2@82@01) | live]
(push) ; 14
; [else-branch: 187 | !(pt2@82@01)]
(pop) ; 14
; [eval] !pt2
(push) ; 14
(set-option :rlimit 16000)
(assert (not pt2@82@01))
(check-sat)
; unknown
(pop) ; 14
; 0.00s
; (get-info :all-statistics)
; [then-branch: 188 | !(pt2@82@01) | live]
; [else-branch: 188 | pt2@82@01 | dead]
(set-option :rlimit 0)
(push) ; 14
; [then-branch: 188 | !(pt2@82@01)]
; [exec]
; pt0_0 := p0 && !returned
; [eval] p0 && !returned
(push) ; 15
; [then-branch: 189 | !(p0@12@01) | live]
; [else-branch: 189 | p0@12@01 | live]
(push) ; 16
; [then-branch: 189 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 16
(push) ; 16
; [else-branch: 189 | p0@12@01]
(assert p0@12@01)
; [eval] !returned
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pt1_0 := p1 && !returned_0
; [eval] p1 && !returned_0
(push) ; 15
; [then-branch: 190 | !(p1@13@01) | live]
; [else-branch: 190 | p1@13@01 | live]
(push) ; 16
; [then-branch: 190 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 16
(push) ; 16
; [else-branch: 190 | p1@13@01]
(assert p1@13@01)
; [eval] !returned_0
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pt2_0 := p2 && !returned_1
; [eval] p2 && !returned_1
(push) ; 15
; [then-branch: 191 | !(p2@14@01) | live]
; [else-branch: 191 | p2@14@01 | live]
(push) ; 16
; [then-branch: 191 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 16
(push) ; 16
; [else-branch: 191 | p2@14@01]
(assert p2@14@01)
; [eval] !returned_1
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pf0_0 := p0 && !!returned
; [eval] p0 && !!returned
(push) ; 15
; [then-branch: 192 | !(p0@12@01) | live]
; [else-branch: 192 | p0@12@01 | live]
(push) ; 16
; [then-branch: 192 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 16
(push) ; 16
; [else-branch: 192 | p0@12@01]
(assert p0@12@01)
; [eval] !!returned
; [eval] !returned
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pf1_0 := p1 && !!returned_0
; [eval] p1 && !!returned_0
(push) ; 15
; [then-branch: 193 | !(p1@13@01) | live]
; [else-branch: 193 | p1@13@01 | live]
(push) ; 16
; [then-branch: 193 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 16
(push) ; 16
; [else-branch: 193 | p1@13@01]
(assert p1@13@01)
; [eval] !!returned_0
; [eval] !returned_0
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pf2_0 := p2 && !!returned_1
; [eval] p2 && !!returned_1
(push) ; 15
; [then-branch: 194 | !(p2@14@01) | live]
; [else-branch: 194 | p2@14@01 | live]
(push) ; 16
; [then-branch: 194 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 16
(push) ; 16
; [else-branch: 194 | p2@14@01]
(assert p2@14@01)
; [eval] !!returned_1
; [eval] !returned_1
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pt0_1 := pt0_0 && getCardSet(o1) < getCardSet(o2)
; [eval] pt0_0 && getCardSet(o1) < getCardSet(o2)
; [exec]
; pt1_1 := pt1_0 && getCardSet(o1_0) < getCardSet(o2_0)
; [eval] pt1_0 && getCardSet(o1_0) < getCardSet(o2_0)
(push) ; 15
; [then-branch: 195 | !(p1@13@01) | live]
; [else-branch: 195 | p1@13@01 | live]
(push) ; 16
; [then-branch: 195 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 16
(push) ; 16
; [else-branch: 195 | p1@13@01]
(assert p1@13@01)
; [eval] getCardSet(o1_0) < getCardSet(o2_0)
; [eval] getCardSet(o1_0)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
; [eval] getCardSet(o2_0)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (getCardSet%precondition $Snap.unit o1_0@16@01)
    (getCardSet%precondition $Snap.unit o2_0@19@01))))
(declare-const pt1_1@86@01 Bool)
(assert (=
  pt1_1@86@01
  (and
    p1@13@01
    (< (getCardSet $Snap.unit o1_0@16@01) (getCardSet $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_1 := pt2_0 && getCardSet(o1_1) < getCardSet(o2_1)
; [eval] pt2_0 && getCardSet(o1_1) < getCardSet(o2_1)
(push) ; 15
; [then-branch: 196 | !(p2@14@01) | live]
; [else-branch: 196 | p2@14@01 | live]
(push) ; 16
; [then-branch: 196 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 16
(push) ; 16
; [else-branch: 196 | p2@14@01]
(assert p2@14@01)
; [eval] getCardSet(o1_1) < getCardSet(o2_1)
; [eval] getCardSet(o1_1)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
; [eval] getCardSet(o2_1)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (getCardSet%precondition $Snap.unit o1_1@17@01)
    (getCardSet%precondition $Snap.unit o2_1@20@01))))
(declare-const pt2_1@87@01 Bool)
(assert (=
  pt2_1@87@01
  (and
    p2@14@01
    (< (getCardSet $Snap.unit o1_1@17@01) (getCardSet $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_1 := pt0_0 && !(getCardSet(o1) < getCardSet(o2))
; [eval] pt0_0 && !(getCardSet(o1) < getCardSet(o2))
; [exec]
; pf1_1 := pt1_0 && !(getCardSet(o1_0) < getCardSet(o2_0))
; [eval] pt1_0 && !(getCardSet(o1_0) < getCardSet(o2_0))
(push) ; 15
; [then-branch: 197 | !(p1@13@01) | live]
; [else-branch: 197 | p1@13@01 | live]
(push) ; 16
; [then-branch: 197 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 16
(push) ; 16
; [else-branch: 197 | p1@13@01]
(assert p1@13@01)
; [eval] !(getCardSet(o1_0) < getCardSet(o2_0))
; [eval] getCardSet(o1_0) < getCardSet(o2_0)
; [eval] getCardSet(o1_0)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
; [eval] getCardSet(o2_0)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
(declare-const pf1_1@88@01 Bool)
(assert (=
  pf1_1@88@01
  (and
    p1@13@01
    (not
      (< (getCardSet $Snap.unit o1_0@16@01) (getCardSet $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_1 := pt2_0 && !(getCardSet(o1_1) < getCardSet(o2_1))
; [eval] pt2_0 && !(getCardSet(o1_1) < getCardSet(o2_1))
(push) ; 15
; [then-branch: 198 | !(p2@14@01) | live]
; [else-branch: 198 | p2@14@01 | live]
(push) ; 16
; [then-branch: 198 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 16
(push) ; 16
; [else-branch: 198 | p2@14@01]
(assert p2@14@01)
; [eval] !(getCardSet(o1_1) < getCardSet(o2_1))
; [eval] getCardSet(o1_1) < getCardSet(o2_1)
; [eval] getCardSet(o1_1)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
; [eval] getCardSet(o2_1)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
(declare-const pf2_1@89@01 Bool)
(assert (=
  pf2_1@89@01
  (and
    p2@14@01
    (not
      (< (getCardSet $Snap.unit o1_1@17@01) (getCardSet $Snap.unit o2_1@20@01))))))
; [then-branch: 199 | False | dead]
; [else-branch: 199 | True | live]
(push) ; 15
; [else-branch: 199 | True]
(pop) ; 15
; [eval] !pt0_1
(push) ; 15
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
; [then-branch: 200 | True | live]
; [else-branch: 200 | False | dead]
(set-option :rlimit 0)
(push) ; 15
; [then-branch: 200 | True]
(push) ; 16
(set-option :rlimit 16000)
(assert (not (not pt1_1@86@01)))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 16000)
(assert (not pt1_1@86@01))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [then-branch: 201 | pt1_1@86@01 | live]
; [else-branch: 201 | !(pt1_1@86@01) | live]
(set-option :rlimit 0)
(push) ; 16
; [then-branch: 201 | pt1_1@86@01]
(assert pt1_1@86@01)
; [exec]
; res_0 := -1
; [eval] -1
(push) ; 17
(set-option :rlimit 16000)
(assert (not (not pt2_1@87@01)))
(check-sat)
; unknown
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 17
(set-option :rlimit 16000)
(assert (not pt2_1@87@01))
(check-sat)
; unsat
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
; [then-branch: 202 | pt2_1@87@01 | live]
; [else-branch: 202 | !(pt2_1@87@01) | dead]
(set-option :rlimit 0)
(push) ; 17
; [then-branch: 202 | pt2_1@87@01]
(assert pt2_1@87@01)
; [exec]
; res_1 := -1
; [eval] -1
; [then-branch: 203 | False | dead]
; [else-branch: 203 | True | live]
(push) ; 18
; [else-branch: 203 | True]
(pop) ; 18
; [eval] !pt0_1
(push) ; 18
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
; [then-branch: 204 | True | live]
; [else-branch: 204 | False | dead]
(set-option :rlimit 0)
(push) ; 18
; [then-branch: 204 | True]
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not pt1_1@86@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 205 | pt1_1@86@01 | live]
; [else-branch: 205 | !(pt1_1@86@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 205 | pt1_1@86@01]
; [exec]
; returned_0 := true
(push) ; 20
(set-option :rlimit 16000)
(assert (not (not pt2_1@87@01)))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 206 | pt2_1@87@01 | live]
; [else-branch: 206 | !(pt2_1@87@01) | dead]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 206 | pt2_1@87@01]
; [exec]
; returned_1 := true
; [exec]
; pt0_2 := pf0_1 && getCardSet(o1) == getCardSet(o2)
; [eval] pf0_1 && getCardSet(o1) == getCardSet(o2)
; [exec]
; pt1_2 := pf1_1 && getCardSet(o1_0) == getCardSet(o2_0)
; [eval] pf1_1 && getCardSet(o1_0) == getCardSet(o2_0)
(push) ; 21
; [then-branch: 207 | !(pf1_1@88@01) | live]
; [else-branch: 207 | pf1_1@88@01 | live]
(push) ; 22
; [then-branch: 207 | !(pf1_1@88@01)]
(assert (not pf1_1@88@01))
(pop) ; 22
(push) ; 22
; [else-branch: 207 | pf1_1@88@01]
(assert pf1_1@88@01)
; [eval] getCardSet(o1_0) == getCardSet(o2_0)
; [eval] getCardSet(o1_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
; [eval] getCardSet(o2_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_1@88@01
  (and
    pf1_1@88@01
    (getCardSet%precondition $Snap.unit o1_0@16@01)
    (getCardSet%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_1@88@01 (not pf1_1@88@01)))
(declare-const pt1_2@90@01 Bool)
(assert (=
  pt1_2@90@01
  (and
    pf1_1@88@01
    (= (getCardSet $Snap.unit o1_0@16@01) (getCardSet $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_2 := pf2_1 && getCardSet(o1_1) == getCardSet(o2_1)
; [eval] pf2_1 && getCardSet(o1_1) == getCardSet(o2_1)
(push) ; 21
; [then-branch: 208 | !(pf2_1@89@01) | live]
; [else-branch: 208 | pf2_1@89@01 | live]
(push) ; 22
; [then-branch: 208 | !(pf2_1@89@01)]
(assert (not pf2_1@89@01))
(pop) ; 22
(push) ; 22
; [else-branch: 208 | pf2_1@89@01]
(assert pf2_1@89@01)
; [eval] getCardSet(o1_1) == getCardSet(o2_1)
; [eval] getCardSet(o1_1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
; [eval] getCardSet(o2_1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_1@89@01
  (and
    pf2_1@89@01
    (getCardSet%precondition $Snap.unit o1_1@17@01)
    (getCardSet%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_1@89@01 (not pf2_1@89@01)))
(declare-const pt2_2@91@01 Bool)
(assert (=
  pt2_2@91@01
  (and
    pf2_1@89@01
    (= (getCardSet $Snap.unit o1_1@17@01) (getCardSet $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_2 := pf0_1 && !(getCardSet(o1) == getCardSet(o2))
; [eval] pf0_1 && !(getCardSet(o1) == getCardSet(o2))
; [exec]
; pf1_2 := pf1_1 && !(getCardSet(o1_0) == getCardSet(o2_0))
; [eval] pf1_1 && !(getCardSet(o1_0) == getCardSet(o2_0))
(push) ; 21
; [then-branch: 209 | !(pf1_1@88@01) | live]
; [else-branch: 209 | pf1_1@88@01 | live]
(push) ; 22
; [then-branch: 209 | !(pf1_1@88@01)]
(assert (not pf1_1@88@01))
(pop) ; 22
(push) ; 22
; [else-branch: 209 | pf1_1@88@01]
(assert pf1_1@88@01)
; [eval] !(getCardSet(o1_0) == getCardSet(o2_0))
; [eval] getCardSet(o1_0) == getCardSet(o2_0)
; [eval] getCardSet(o1_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
; [eval] getCardSet(o2_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf1_2@92@01 Bool)
(assert (=
  pf1_2@92@01
  (and
    pf1_1@88@01
    (not
      (= (getCardSet $Snap.unit o1_0@16@01) (getCardSet $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_2 := pf2_1 && !(getCardSet(o1_1) == getCardSet(o2_1))
; [eval] pf2_1 && !(getCardSet(o1_1) == getCardSet(o2_1))
(push) ; 21
; [then-branch: 210 | !(pf2_1@89@01) | live]
; [else-branch: 210 | pf2_1@89@01 | live]
(push) ; 22
; [then-branch: 210 | !(pf2_1@89@01)]
(assert (not pf2_1@89@01))
(pop) ; 22
(push) ; 22
; [else-branch: 210 | pf2_1@89@01]
(assert pf2_1@89@01)
; [eval] !(getCardSet(o1_1) == getCardSet(o2_1))
; [eval] getCardSet(o1_1) == getCardSet(o2_1)
; [eval] getCardSet(o1_1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
; [eval] getCardSet(o2_1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf2_2@93@01 Bool)
(assert (=
  pf2_2@93@01
  (and
    pf2_1@89@01
    (not
      (= (getCardSet $Snap.unit o1_1@17@01) (getCardSet $Snap.unit o2_1@20@01))))))
; [exec]
; pt0_3 := pt0_2 && getCardRarity(o1) < getCardRarity(o2)
; [eval] pt0_2 && getCardRarity(o1) < getCardRarity(o2)
; [exec]
; pt1_3 := pt1_2 && getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] pt1_2 && getCardRarity(o1_0) < getCardRarity(o2_0)
(push) ; 21
; [then-branch: 211 | !(pt1_2@90@01) | live]
; [else-branch: 211 | pt1_2@90@01 | live]
(push) ; 22
; [then-branch: 211 | !(pt1_2@90@01)]
(assert (not pt1_2@90@01))
(pop) ; 22
(push) ; 22
; [else-branch: 211 | pt1_2@90@01]
(assert pt1_2@90@01)
; [eval] getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] getCardRarity(o1_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
; [eval] getCardRarity(o2_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pt1_2@90@01
  (and
    pt1_2@90@01
    (getCardRarity%precondition $Snap.unit o1_0@16@01)
    (getCardRarity%precondition $Snap.unit o2_0@19@01))))
(assert (or pt1_2@90@01 (not pt1_2@90@01)))
(declare-const pt1_3@94@01 Bool)
(assert (=
  pt1_3@94@01
  (and
    pt1_2@90@01
    (<
      (getCardRarity $Snap.unit o1_0@16@01)
      (getCardRarity $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_3 := pt2_2 && getCardRarity(o1_1) < getCardRarity(o2_1)
; [eval] pt2_2 && getCardRarity(o1_1) < getCardRarity(o2_1)
(push) ; 21
; [then-branch: 212 | !(pt2_2@91@01) | live]
; [else-branch: 212 | pt2_2@91@01 | live]
(push) ; 22
; [then-branch: 212 | !(pt2_2@91@01)]
(assert (not pt2_2@91@01))
(pop) ; 22
(push) ; 22
; [else-branch: 212 | pt2_2@91@01]
(assert pt2_2@91@01)
; [eval] getCardRarity(o1_1) < getCardRarity(o2_1)
; [eval] getCardRarity(o1_1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_1@17@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_1@17@01))
; [eval] getCardRarity(o2_1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_1@20@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_1@20@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pt2_2@91@01
  (and
    pt2_2@91@01
    (getCardRarity%precondition $Snap.unit o1_1@17@01)
    (getCardRarity%precondition $Snap.unit o2_1@20@01))))
(assert (or pt2_2@91@01 (not pt2_2@91@01)))
(declare-const pt2_3@95@01 Bool)
(assert (=
  pt2_3@95@01
  (and
    pt2_2@91@01
    (<
      (getCardRarity $Snap.unit o1_1@17@01)
      (getCardRarity $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_3 := pt0_2 && !(getCardRarity(o1) < getCardRarity(o2))
; [eval] pt0_2 && !(getCardRarity(o1) < getCardRarity(o2))
; [exec]
; pf1_3 := pt1_2 && !(getCardRarity(o1_0) < getCardRarity(o2_0))
; [eval] pt1_2 && !(getCardRarity(o1_0) < getCardRarity(o2_0))
(push) ; 21
; [then-branch: 213 | !(pt1_2@90@01) | live]
; [else-branch: 213 | pt1_2@90@01 | live]
(push) ; 22
; [then-branch: 213 | !(pt1_2@90@01)]
(assert (not pt1_2@90@01))
(pop) ; 22
(push) ; 22
; [else-branch: 213 | pt1_2@90@01]
(assert pt1_2@90@01)
; [eval] !(getCardRarity(o1_0) < getCardRarity(o2_0))
; [eval] getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] getCardRarity(o1_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
; [eval] getCardRarity(o2_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf1_3@96@01 Bool)
(assert (=
  pf1_3@96@01
  (and
    pt1_2@90@01
    (not
      (<
        (getCardRarity $Snap.unit o1_0@16@01)
        (getCardRarity $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_3 := pt2_2 && !(getCardRarity(o1_1) < getCardRarity(o2_1))
; [eval] pt2_2 && !(getCardRarity(o1_1) < getCardRarity(o2_1))
(push) ; 21
; [then-branch: 214 | !(pt2_2@91@01) | live]
; [else-branch: 214 | pt2_2@91@01 | live]
(push) ; 22
; [then-branch: 214 | !(pt2_2@91@01)]
(assert (not pt2_2@91@01))
(pop) ; 22
(push) ; 22
; [else-branch: 214 | pt2_2@91@01]
(assert pt2_2@91@01)
; [eval] !(getCardRarity(o1_1) < getCardRarity(o2_1))
; [eval] getCardRarity(o1_1) < getCardRarity(o2_1)
; [eval] getCardRarity(o1_1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_1@17@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_1@17@01))
; [eval] getCardRarity(o2_1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_1@20@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_1@20@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf2_3@97@01 Bool)
(assert (=
  pf2_3@97@01
  (and
    pt2_2@91@01
    (not
      (<
        (getCardRarity $Snap.unit o1_1@17@01)
        (getCardRarity $Snap.unit o2_1@20@01))))))
; [then-branch: 215 | False | dead]
; [else-branch: 215 | True | live]
(push) ; 21
; [else-branch: 215 | True]
(pop) ; 21
; [eval] !pt0_3
(push) ; 21
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 216 | True | live]
; [else-branch: 216 | False | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 216 | True]
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not pt1_3@94@01)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 217 | pt1_3@94@01 | dead]
; [else-branch: 217 | !(pt1_3@94@01) | live]
(set-option :rlimit 0)
(push) ; 22
; [else-branch: 217 | !(pt1_3@94@01)]
(assert (not pt1_3@94@01))
(pop) ; 22
; [eval] !pt1_3
(push) ; 22
(set-option :rlimit 16000)
(assert (not pt1_3@94@01))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not pt1_3@94@01)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 218 | !(pt1_3@94@01) | live]
; [else-branch: 218 | pt1_3@94@01 | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 218 | !(pt1_3@94@01)]
(assert (not pt1_3@94@01))
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not pt2_3@95@01)))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 219 | pt2_3@95@01 | dead]
; [else-branch: 219 | !(pt2_3@95@01) | live]
(set-option :rlimit 0)
(push) ; 23
; [else-branch: 219 | !(pt2_3@95@01)]
(assert (not pt2_3@95@01))
(pop) ; 23
; [eval] !pt2_3
(push) ; 23
(set-option :rlimit 16000)
(assert (not pt2_3@95@01))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not pt2_3@95@01)))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 220 | !(pt2_3@95@01) | live]
; [else-branch: 220 | pt2_3@95@01 | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 220 | !(pt2_3@95@01)]
(assert (not pt2_3@95@01))
; [then-branch: 221 | False | dead]
; [else-branch: 221 | True | live]
(push) ; 24
; [else-branch: 221 | True]
(pop) ; 24
; [eval] !pt0_3
(push) ; 24
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
; [then-branch: 222 | True | live]
; [else-branch: 222 | False | dead]
(set-option :rlimit 0)
(push) ; 24
; [then-branch: 222 | True]
; [then-branch: 223 | pt1_3@94@01 | dead]
; [else-branch: 223 | !(pt1_3@94@01) | live]
(push) ; 25
; [else-branch: 223 | !(pt1_3@94@01)]
(pop) ; 25
; [eval] !pt1_3
(push) ; 25
(set-option :rlimit 16000)
(assert (not pt1_3@94@01))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 224 | !(pt1_3@94@01) | live]
; [else-branch: 224 | pt1_3@94@01 | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 224 | !(pt1_3@94@01)]
; [then-branch: 225 | pt2_3@95@01 | dead]
; [else-branch: 225 | !(pt2_3@95@01) | live]
(push) ; 26
; [else-branch: 225 | !(pt2_3@95@01)]
(pop) ; 26
; [eval] !pt2_3
(push) ; 26
(set-option :rlimit 16000)
(assert (not pt2_3@95@01))
(check-sat)
; unknown
(pop) ; 26
; 0.00s
; (get-info :all-statistics)
; [then-branch: 226 | !(pt2_3@95@01) | live]
; [else-branch: 226 | pt2_3@95@01 | dead]
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 226 | !(pt2_3@95@01)]
; [exec]
; pt0_4 := pf0_3 && getCardId(o1) == getCardId(o2)
; [eval] pf0_3 && getCardId(o1) == getCardId(o2)
; [exec]
; pt1_4 := pf1_3 && getCardId(o1_0) == getCardId(o2_0)
; [eval] pf1_3 && getCardId(o1_0) == getCardId(o2_0)
(push) ; 27
; [then-branch: 227 | !(pf1_3@96@01) | live]
; [else-branch: 227 | pf1_3@96@01 | live]
(push) ; 28
; [then-branch: 227 | !(pf1_3@96@01)]
(assert (not pf1_3@96@01))
(pop) ; 28
(push) ; 28
; [else-branch: 227 | pf1_3@96@01]
(assert pf1_3@96@01)
; [eval] getCardId(o1_0) == getCardId(o2_0)
; [eval] getCardId(o1_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
; [eval] getCardId(o2_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_3@96@01
  (and
    pf1_3@96@01
    (getCardId%precondition $Snap.unit o1_0@16@01)
    (getCardId%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_3@96@01 (not pf1_3@96@01)))
(declare-const pt1_4@98@01 Bool)
(assert (=
  pt1_4@98@01
  (and
    pf1_3@96@01
    (= (getCardId $Snap.unit o1_0@16@01) (getCardId $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_4 := pf2_3 && getCardId(o1_1) == getCardId(o2_1)
; [eval] pf2_3 && getCardId(o1_1) == getCardId(o2_1)
(push) ; 27
; [then-branch: 228 | !(pf2_3@97@01) | live]
; [else-branch: 228 | pf2_3@97@01 | live]
(push) ; 28
; [then-branch: 228 | !(pf2_3@97@01)]
(assert (not pf2_3@97@01))
(pop) ; 28
(push) ; 28
; [else-branch: 228 | pf2_3@97@01]
(assert pf2_3@97@01)
; [eval] getCardId(o1_1) == getCardId(o2_1)
; [eval] getCardId(o1_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
; [eval] getCardId(o2_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_3@97@01
  (and
    pf2_3@97@01
    (getCardId%precondition $Snap.unit o1_1@17@01)
    (getCardId%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_3@97@01 (not pf2_3@97@01)))
(declare-const pt2_4@99@01 Bool)
(assert (=
  pt2_4@99@01
  (and
    pf2_3@97@01
    (= (getCardId $Snap.unit o1_1@17@01) (getCardId $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_4 := pf0_3 && !(getCardId(o1) == getCardId(o2))
; [eval] pf0_3 && !(getCardId(o1) == getCardId(o2))
; [exec]
; pf1_4 := pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
; [eval] pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
(push) ; 27
; [then-branch: 229 | !(pf1_3@96@01) | live]
; [else-branch: 229 | pf1_3@96@01 | live]
(push) ; 28
; [then-branch: 229 | !(pf1_3@96@01)]
(assert (not pf1_3@96@01))
(pop) ; 28
(push) ; 28
; [else-branch: 229 | pf1_3@96@01]
(assert pf1_3@96@01)
; [eval] !(getCardId(o1_0) == getCardId(o2_0))
; [eval] getCardId(o1_0) == getCardId(o2_0)
; [eval] getCardId(o1_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
; [eval] getCardId(o2_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf1_4@100@01 Bool)
(assert (=
  pf1_4@100@01
  (and
    pf1_3@96@01
    (not (= (getCardId $Snap.unit o1_0@16@01) (getCardId $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_4 := pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
; [eval] pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
(push) ; 27
; [then-branch: 230 | !(pf2_3@97@01) | live]
; [else-branch: 230 | pf2_3@97@01 | live]
(push) ; 28
; [then-branch: 230 | !(pf2_3@97@01)]
(assert (not pf2_3@97@01))
(pop) ; 28
(push) ; 28
; [else-branch: 230 | pf2_3@97@01]
(assert pf2_3@97@01)
; [eval] !(getCardId(o1_1) == getCardId(o2_1))
; [eval] getCardId(o1_1) == getCardId(o2_1)
; [eval] getCardId(o1_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
; [eval] getCardId(o2_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf2_4@101@01 Bool)
(assert (=
  pf2_4@101@01
  (and
    pf2_3@97@01
    (not (= (getCardId $Snap.unit o1_1@17@01) (getCardId $Snap.unit o2_1@20@01))))))
; [exec]
; pt0_5 := pt0_4 && cardType(o1) > cardType(o2)
; [eval] pt0_4 && cardType(o1) > cardType(o2)
; [exec]
; pt1_5 := pt1_4 && cardType(o1_0) > cardType(o2_0)
; [eval] pt1_4 && cardType(o1_0) > cardType(o2_0)
(push) ; 27
; [then-branch: 231 | !(pt1_4@98@01) | live]
; [else-branch: 231 | pt1_4@98@01 | live]
(push) ; 28
; [then-branch: 231 | !(pt1_4@98@01)]
(assert (not pt1_4@98@01))
(pop) ; 28
(push) ; 28
; [else-branch: 231 | pt1_4@98@01]
(assert pt1_4@98@01)
; [eval] cardType(o1_0) > cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt1_4@98@01
  (and
    pt1_4@98@01
    (cardType%precondition $Snap.unit o1_0@16@01)
    (cardType%precondition $Snap.unit o2_0@19@01))))
(assert (or pt1_4@98@01 (not pt1_4@98@01)))
(declare-const pt1_5@102@01 Bool)
(assert (=
  pt1_5@102@01
  (and
    pt1_4@98@01
    (> (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_5 := pt2_4 && cardType(o1_1) > cardType(o2_1)
; [eval] pt2_4 && cardType(o1_1) > cardType(o2_1)
(push) ; 27
; [then-branch: 232 | !(pt2_4@99@01) | live]
; [else-branch: 232 | pt2_4@99@01 | live]
(push) ; 28
; [then-branch: 232 | !(pt2_4@99@01)]
(assert (not pt2_4@99@01))
(pop) ; 28
(push) ; 28
; [else-branch: 232 | pt2_4@99@01]
(assert pt2_4@99@01)
; [eval] cardType(o1_1) > cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt2_4@99@01
  (and
    pt2_4@99@01
    (cardType%precondition $Snap.unit o1_1@17@01)
    (cardType%precondition $Snap.unit o2_1@20@01))))
(assert (or pt2_4@99@01 (not pt2_4@99@01)))
(declare-const pt2_5@103@01 Bool)
(assert (=
  pt2_5@103@01
  (and
    pt2_4@99@01
    (> (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_5 := pt0_4 && !(cardType(o1) > cardType(o2))
; [eval] pt0_4 && !(cardType(o1) > cardType(o2))
; [exec]
; pf1_5 := pt1_4 && !(cardType(o1_0) > cardType(o2_0))
; [eval] pt1_4 && !(cardType(o1_0) > cardType(o2_0))
(push) ; 27
; [then-branch: 233 | !(pt1_4@98@01) | live]
; [else-branch: 233 | pt1_4@98@01 | live]
(push) ; 28
; [then-branch: 233 | !(pt1_4@98@01)]
(assert (not pt1_4@98@01))
(pop) ; 28
(push) ; 28
; [else-branch: 233 | pt1_4@98@01]
(assert pt1_4@98@01)
; [eval] !(cardType(o1_0) > cardType(o2_0))
; [eval] cardType(o1_0) > cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf1_5@104@01 Bool)
(assert (=
  pf1_5@104@01
  (and
    pt1_4@98@01
    (not (> (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_5 := pt2_4 && !(cardType(o1_1) > cardType(o2_1))
; [eval] pt2_4 && !(cardType(o1_1) > cardType(o2_1))
(push) ; 27
; [then-branch: 234 | !(pt2_4@99@01) | live]
; [else-branch: 234 | pt2_4@99@01 | live]
(push) ; 28
; [then-branch: 234 | !(pt2_4@99@01)]
(assert (not pt2_4@99@01))
(pop) ; 28
(push) ; 28
; [else-branch: 234 | pt2_4@99@01]
(assert pt2_4@99@01)
; [eval] !(cardType(o1_1) > cardType(o2_1))
; [eval] cardType(o1_1) > cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf2_5@105@01 Bool)
(assert (=
  pf2_5@105@01
  (and
    pt2_4@99@01
    (not (> (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01))))))
; [then-branch: 235 | False | dead]
; [else-branch: 235 | True | live]
(push) ; 27
; [else-branch: 235 | True]
(pop) ; 27
; [eval] !pt0_5
(push) ; 27
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 236 | True | live]
; [else-branch: 236 | False | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 236 | True]
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not pt1_5@102@01)))
(check-sat)
; unsat
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 237 | pt1_5@102@01 | dead]
; [else-branch: 237 | !(pt1_5@102@01) | live]
(set-option :rlimit 0)
(push) ; 28
; [else-branch: 237 | !(pt1_5@102@01)]
(assert (not pt1_5@102@01))
(pop) ; 28
; [eval] !pt1_5
(push) ; 28
(set-option :rlimit 16000)
(assert (not pt1_5@102@01))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not pt1_5@102@01)))
(check-sat)
; unsat
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 238 | !(pt1_5@102@01) | live]
; [else-branch: 238 | pt1_5@102@01 | dead]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 238 | !(pt1_5@102@01)]
(assert (not pt1_5@102@01))
(push) ; 29
(set-option :rlimit 16000)
(assert (not (not pt2_5@103@01)))
(check-sat)
; unsat
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 239 | pt2_5@103@01 | dead]
; [else-branch: 239 | !(pt2_5@103@01) | live]
(set-option :rlimit 0)
(push) ; 29
; [else-branch: 239 | !(pt2_5@103@01)]
(assert (not pt2_5@103@01))
(pop) ; 29
; [eval] !pt2_5
(push) ; 29
(set-option :rlimit 16000)
(assert (not pt2_5@103@01))
(check-sat)
; unknown
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 29
(set-option :rlimit 16000)
(assert (not (not pt2_5@103@01)))
(check-sat)
; unsat
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 240 | !(pt2_5@103@01) | live]
; [else-branch: 240 | pt2_5@103@01 | dead]
(set-option :rlimit 0)
(push) ; 29
; [then-branch: 240 | !(pt2_5@103@01)]
(assert (not pt2_5@103@01))
; [then-branch: 241 | False | dead]
; [else-branch: 241 | True | live]
(push) ; 30
; [else-branch: 241 | True]
(pop) ; 30
; [eval] !pt0_5
(push) ; 30
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 30
; 0.00s
; (get-info :all-statistics)
; [then-branch: 242 | True | live]
; [else-branch: 242 | False | dead]
(set-option :rlimit 0)
(push) ; 30
; [then-branch: 242 | True]
; [then-branch: 243 | pt1_5@102@01 | dead]
; [else-branch: 243 | !(pt1_5@102@01) | live]
(push) ; 31
; [else-branch: 243 | !(pt1_5@102@01)]
(pop) ; 31
; [eval] !pt1_5
(push) ; 31
(set-option :rlimit 16000)
(assert (not pt1_5@102@01))
(check-sat)
; unknown
(pop) ; 31
; 0.00s
; (get-info :all-statistics)
; [then-branch: 244 | !(pt1_5@102@01) | live]
; [else-branch: 244 | pt1_5@102@01 | dead]
(set-option :rlimit 0)
(push) ; 31
; [then-branch: 244 | !(pt1_5@102@01)]
; [then-branch: 245 | pt2_5@103@01 | dead]
; [else-branch: 245 | !(pt2_5@103@01) | live]
(push) ; 32
; [else-branch: 245 | !(pt2_5@103@01)]
(pop) ; 32
; [eval] !pt2_5
(push) ; 32
(set-option :rlimit 16000)
(assert (not pt2_5@103@01))
(check-sat)
; unknown
(pop) ; 32
; 0.00s
; (get-info :all-statistics)
; [then-branch: 246 | !(pt2_5@103@01) | live]
; [else-branch: 246 | pt2_5@103@01 | dead]
(set-option :rlimit 0)
(push) ; 32
; [then-branch: 246 | !(pt2_5@103@01)]
; [exec]
; pt0_6 := pf0_5 && cardType(o1) == cardType(o2)
; [eval] pf0_5 && cardType(o1) == cardType(o2)
; [exec]
; pt1_6 := pf1_5 && cardType(o1_0) == cardType(o2_0)
; [eval] pf1_5 && cardType(o1_0) == cardType(o2_0)
(push) ; 33
; [then-branch: 247 | !(pf1_5@104@01) | live]
; [else-branch: 247 | pf1_5@104@01 | live]
(push) ; 34
; [then-branch: 247 | !(pf1_5@104@01)]
(assert (not pf1_5@104@01))
(pop) ; 34
(push) ; 34
; [else-branch: 247 | pf1_5@104@01]
(assert pf1_5@104@01)
; [eval] cardType(o1_0) == cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_5@104@01
  (and
    pf1_5@104@01
    (cardType%precondition $Snap.unit o1_0@16@01)
    (cardType%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_5@104@01 (not pf1_5@104@01)))
(declare-const pt1_6@106@01 Bool)
(assert (=
  pt1_6@106@01
  (and
    pf1_5@104@01
    (= (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_6 := pf2_5 && cardType(o1_1) == cardType(o2_1)
; [eval] pf2_5 && cardType(o1_1) == cardType(o2_1)
(push) ; 33
; [then-branch: 248 | !(pf2_5@105@01) | live]
; [else-branch: 248 | pf2_5@105@01 | live]
(push) ; 34
; [then-branch: 248 | !(pf2_5@105@01)]
(assert (not pf2_5@105@01))
(pop) ; 34
(push) ; 34
; [else-branch: 248 | pf2_5@105@01]
(assert pf2_5@105@01)
; [eval] cardType(o1_1) == cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_5@105@01
  (and
    pf2_5@105@01
    (cardType%precondition $Snap.unit o1_1@17@01)
    (cardType%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_5@105@01 (not pf2_5@105@01)))
(declare-const pt2_6@107@01 Bool)
(assert (=
  pt2_6@107@01
  (and
    pf2_5@105@01
    (= (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_6 := pf0_5 && !(cardType(o1) == cardType(o2))
; [eval] pf0_5 && !(cardType(o1) == cardType(o2))
; [exec]
; pf1_6 := pf1_5 && !(cardType(o1_0) == cardType(o2_0))
; [eval] pf1_5 && !(cardType(o1_0) == cardType(o2_0))
(push) ; 33
; [then-branch: 249 | !(pf1_5@104@01) | live]
; [else-branch: 249 | pf1_5@104@01 | live]
(push) ; 34
; [then-branch: 249 | !(pf1_5@104@01)]
(assert (not pf1_5@104@01))
(pop) ; 34
(push) ; 34
; [else-branch: 249 | pf1_5@104@01]
(assert pf1_5@104@01)
; [eval] !(cardType(o1_0) == cardType(o2_0))
; [eval] cardType(o1_0) == cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf1_6@108@01 Bool)
(assert (=
  pf1_6@108@01
  (and
    pf1_5@104@01
    (not (= (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_6 := pf2_5 && !(cardType(o1_1) == cardType(o2_1))
; [eval] pf2_5 && !(cardType(o1_1) == cardType(o2_1))
(push) ; 33
; [then-branch: 250 | !(pf2_5@105@01) | live]
; [else-branch: 250 | pf2_5@105@01 | live]
(push) ; 34
; [then-branch: 250 | !(pf2_5@105@01)]
(assert (not pf2_5@105@01))
(pop) ; 34
(push) ; 34
; [else-branch: 250 | pf2_5@105@01]
(assert pf2_5@105@01)
; [eval] !(cardType(o1_1) == cardType(o2_1))
; [eval] cardType(o1_1) == cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf2_6@109@01 Bool)
(assert (=
  pf2_6@109@01
  (and
    pf2_5@105@01
    (not (= (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01))))))
; [then-branch: 251 | False | dead]
; [else-branch: 251 | True | live]
(push) ; 33
; [else-branch: 251 | True]
(pop) ; 33
; [eval] !pt0_6
(push) ; 33
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 252 | True | live]
; [else-branch: 252 | False | dead]
(set-option :rlimit 0)
(push) ; 33
; [then-branch: 252 | True]
(push) ; 34
(set-option :rlimit 16000)
(assert (not (not pt1_6@106@01)))
(check-sat)
; unsat
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 253 | pt1_6@106@01 | dead]
; [else-branch: 253 | !(pt1_6@106@01) | live]
(set-option :rlimit 0)
(push) ; 34
; [else-branch: 253 | !(pt1_6@106@01)]
(assert (not pt1_6@106@01))
(pop) ; 34
; [eval] !pt1_6
(push) ; 34
(set-option :rlimit 16000)
(assert (not pt1_6@106@01))
(check-sat)
; unknown
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 34
(set-option :rlimit 16000)
(assert (not (not pt1_6@106@01)))
(check-sat)
; unsat
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 254 | !(pt1_6@106@01) | live]
; [else-branch: 254 | pt1_6@106@01 | dead]
(set-option :rlimit 0)
(push) ; 34
; [then-branch: 254 | !(pt1_6@106@01)]
(assert (not pt1_6@106@01))
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@107@01)))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 255 | pt2_6@107@01 | dead]
; [else-branch: 255 | !(pt2_6@107@01) | live]
(set-option :rlimit 0)
(push) ; 35
; [else-branch: 255 | !(pt2_6@107@01)]
(assert (not pt2_6@107@01))
(pop) ; 35
; [eval] !pt2_6
(push) ; 35
(set-option :rlimit 16000)
(assert (not pt2_6@107@01))
(check-sat)
; unknown
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@107@01)))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 256 | !(pt2_6@107@01) | live]
; [else-branch: 256 | pt2_6@107@01 | dead]
(set-option :rlimit 0)
(push) ; 35
; [then-branch: 256 | !(pt2_6@107@01)]
(assert (not pt2_6@107@01))
; [then-branch: 257 | False | dead]
; [else-branch: 257 | True | live]
(push) ; 36
; [else-branch: 257 | True]
(pop) ; 36
; [eval] !pt0_6
(push) ; 36
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 36
; 0.00s
; (get-info :all-statistics)
; [then-branch: 258 | True | live]
; [else-branch: 258 | False | dead]
(set-option :rlimit 0)
(push) ; 36
; [then-branch: 258 | True]
; [then-branch: 259 | pt1_6@106@01 | dead]
; [else-branch: 259 | !(pt1_6@106@01) | live]
(push) ; 37
; [else-branch: 259 | !(pt1_6@106@01)]
(pop) ; 37
; [eval] !pt1_6
(push) ; 37
(set-option :rlimit 16000)
(assert (not pt1_6@106@01))
(check-sat)
; unknown
(pop) ; 37
; 0.00s
; (get-info :all-statistics)
; [then-branch: 260 | !(pt1_6@106@01) | live]
; [else-branch: 260 | pt1_6@106@01 | dead]
(set-option :rlimit 0)
(push) ; 37
; [then-branch: 260 | !(pt1_6@106@01)]
; [then-branch: 261 | pt2_6@107@01 | dead]
; [else-branch: 261 | !(pt2_6@107@01) | live]
(push) ; 38
; [else-branch: 261 | !(pt2_6@107@01)]
(pop) ; 38
; [eval] !pt2_6
(push) ; 38
(set-option :rlimit 16000)
(assert (not pt2_6@107@01))
(check-sat)
; unknown
(pop) ; 38
; 0.00s
; (get-info :all-statistics)
; [then-branch: 262 | !(pt2_6@107@01) | live]
; [else-branch: 262 | pt2_6@107@01 | dead]
(set-option :rlimit 0)
(push) ; 38
; [then-branch: 262 | !(pt2_6@107@01)]
; [then-branch: 263 | False | dead]
; [else-branch: 263 | True | live]
(push) ; 39
; [else-branch: 263 | True]
(pop) ; 39
; [eval] !pf0_6
(push) ; 39
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 264 | True | live]
; [else-branch: 264 | False | dead]
(set-option :rlimit 0)
(push) ; 39
; [then-branch: 264 | True]
(push) ; 40
(set-option :rlimit 16000)
(assert (not (not pf1_6@108@01)))
(check-sat)
; unsat
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 265 | pf1_6@108@01 | dead]
; [else-branch: 265 | !(pf1_6@108@01) | live]
(set-option :rlimit 0)
(push) ; 40
; [else-branch: 265 | !(pf1_6@108@01)]
(assert (not pf1_6@108@01))
(pop) ; 40
; [eval] !pf1_6
(push) ; 40
(set-option :rlimit 16000)
(assert (not pf1_6@108@01))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 40
(set-option :rlimit 16000)
(assert (not (not pf1_6@108@01)))
(check-sat)
; unsat
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 266 | !(pf1_6@108@01) | live]
; [else-branch: 266 | pf1_6@108@01 | dead]
(set-option :rlimit 0)
(push) ; 40
; [then-branch: 266 | !(pf1_6@108@01)]
(assert (not pf1_6@108@01))
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@109@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 267 | pf2_6@109@01 | dead]
; [else-branch: 267 | !(pf2_6@109@01) | live]
(set-option :rlimit 0)
(push) ; 41
; [else-branch: 267 | !(pf2_6@109@01)]
(assert (not pf2_6@109@01))
(pop) ; 41
; [eval] !pf2_6
(push) ; 41
(set-option :rlimit 16000)
(assert (not pf2_6@109@01))
(check-sat)
; unknown
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@109@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 268 | !(pf2_6@109@01) | live]
; [else-branch: 268 | pf2_6@109@01 | dead]
(set-option :rlimit 0)
(push) ; 41
; [then-branch: 268 | !(pf2_6@109@01)]
(assert (not pf2_6@109@01))
; [then-branch: 269 | False | dead]
; [else-branch: 269 | True | live]
(push) ; 42
; [else-branch: 269 | True]
(pop) ; 42
; [eval] !pf0_6
(push) ; 42
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 42
; 0.00s
; (get-info :all-statistics)
; [then-branch: 270 | True | live]
; [else-branch: 270 | False | dead]
(set-option :rlimit 0)
(push) ; 42
; [then-branch: 270 | True]
; [then-branch: 271 | pf1_6@108@01 | dead]
; [else-branch: 271 | !(pf1_6@108@01) | live]
(push) ; 43
; [else-branch: 271 | !(pf1_6@108@01)]
(pop) ; 43
; [eval] !pf1_6
(push) ; 43
(set-option :rlimit 16000)
(assert (not pf1_6@108@01))
(check-sat)
; unknown
(pop) ; 43
; 0.00s
; (get-info :all-statistics)
; [then-branch: 272 | !(pf1_6@108@01) | live]
; [else-branch: 272 | pf1_6@108@01 | dead]
(set-option :rlimit 0)
(push) ; 43
; [then-branch: 272 | !(pf1_6@108@01)]
; [then-branch: 273 | pf2_6@109@01 | dead]
; [else-branch: 273 | !(pf2_6@109@01) | live]
(push) ; 44
; [else-branch: 273 | !(pf2_6@109@01)]
(pop) ; 44
; [eval] !pf2_6
(push) ; 44
(set-option :rlimit 16000)
(assert (not pf2_6@109@01))
(check-sat)
; unknown
(pop) ; 44
; 0.00s
; (get-info :all-statistics)
; [then-branch: 274 | !(pf2_6@109@01) | live]
; [else-branch: 274 | pf2_6@109@01 | dead]
(set-option :rlimit 0)
(push) ; 44
; [then-branch: 274 | !(pf2_6@109@01)]
; [then-branch: 275 | False | dead]
; [else-branch: 275 | True | live]
(push) ; 45
; [else-branch: 275 | True]
(pop) ; 45
; [eval] !pf0_4
(push) ; 45
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 276 | True | live]
; [else-branch: 276 | False | dead]
(set-option :rlimit 0)
(push) ; 45
; [then-branch: 276 | True]
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@100@01)))
(check-sat)
; unsat
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 277 | pf1_4@100@01 | dead]
; [else-branch: 277 | !(pf1_4@100@01) | live]
(set-option :rlimit 0)
(push) ; 46
; [else-branch: 277 | !(pf1_4@100@01)]
(assert (not pf1_4@100@01))
(pop) ; 46
; [eval] !pf1_4
(push) ; 46
(set-option :rlimit 16000)
(assert (not pf1_4@100@01))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@100@01)))
(check-sat)
; unsat
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 278 | !(pf1_4@100@01) | live]
; [else-branch: 278 | pf1_4@100@01 | dead]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 278 | !(pf1_4@100@01)]
(assert (not pf1_4@100@01))
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@101@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 279 | pf2_4@101@01 | dead]
; [else-branch: 279 | !(pf2_4@101@01) | live]
(set-option :rlimit 0)
(push) ; 47
; [else-branch: 279 | !(pf2_4@101@01)]
(assert (not pf2_4@101@01))
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not pf2_4@101@01))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@101@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 280 | !(pf2_4@101@01) | live]
; [else-branch: 280 | pf2_4@101@01 | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 280 | !(pf2_4@101@01)]
(assert (not pf2_4@101@01))
; [then-branch: 281 | False | dead]
; [else-branch: 281 | True | live]
(push) ; 48
; [else-branch: 281 | True]
(pop) ; 48
; [eval] !pf0_4
(push) ; 48
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 282 | True | live]
; [else-branch: 282 | False | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 282 | True]
; [then-branch: 283 | pf1_4@100@01 | dead]
; [else-branch: 283 | !(pf1_4@100@01) | live]
(push) ; 49
; [else-branch: 283 | !(pf1_4@100@01)]
(pop) ; 49
; [eval] !pf1_4
(push) ; 49
(set-option :rlimit 16000)
(assert (not pf1_4@100@01))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 284 | !(pf1_4@100@01) | live]
; [else-branch: 284 | pf1_4@100@01 | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 284 | !(pf1_4@100@01)]
; [then-branch: 285 | pf2_4@101@01 | dead]
; [else-branch: 285 | !(pf2_4@101@01) | live]
(push) ; 50
; [else-branch: 285 | !(pf2_4@101@01)]
(pop) ; 50
; [eval] !pf2_4
(push) ; 50
(set-option :rlimit 16000)
(assert (not pf2_4@101@01))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 286 | !(pf2_4@101@01) | live]
; [else-branch: 286 | pf2_4@101@01 | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 286 | !(pf2_4@101@01)]
; [then-branch: 287 | False | dead]
; [else-branch: 287 | True | live]
(push) ; 51
; [else-branch: 287 | True]
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 288 | True | live]
; [else-branch: 288 | False | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 288 | True]
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@92@01)))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 289 | pf1_2@92@01 | dead]
; [else-branch: 289 | !(pf1_2@92@01) | live]
(set-option :rlimit 0)
(push) ; 52
; [else-branch: 289 | !(pf1_2@92@01)]
(assert (not pf1_2@92@01))
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not pf1_2@92@01))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@92@01)))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 290 | !(pf1_2@92@01) | live]
; [else-branch: 290 | pf1_2@92@01 | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 290 | !(pf1_2@92@01)]
(assert (not pf1_2@92@01))
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@93@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 291 | pf2_2@93@01 | dead]
; [else-branch: 291 | !(pf2_2@93@01) | live]
(set-option :rlimit 0)
(push) ; 53
; [else-branch: 291 | !(pf2_2@93@01)]
(assert (not pf2_2@93@01))
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not pf2_2@93@01))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@93@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 292 | !(pf2_2@93@01) | live]
; [else-branch: 292 | pf2_2@93@01 | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 292 | !(pf2_2@93@01)]
(assert (not pf2_2@93@01))
; [then-branch: 293 | False | dead]
; [else-branch: 293 | True | live]
(push) ; 54
; [else-branch: 293 | True]
(pop) ; 54
; [eval] !pf0_2
(push) ; 54
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 294 | True | live]
; [else-branch: 294 | False | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 294 | True]
; [then-branch: 295 | pf1_2@92@01 | dead]
; [else-branch: 295 | !(pf1_2@92@01) | live]
(push) ; 55
; [else-branch: 295 | !(pf1_2@92@01)]
(pop) ; 55
; [eval] !pf1_2
(push) ; 55
(set-option :rlimit 16000)
(assert (not pf1_2@92@01))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 296 | !(pf1_2@92@01) | live]
; [else-branch: 296 | pf1_2@92@01 | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 296 | !(pf1_2@92@01)]
; [then-branch: 297 | pf2_2@93@01 | dead]
; [else-branch: 297 | !(pf2_2@93@01) | live]
(push) ; 56
; [else-branch: 297 | !(pf2_2@93@01)]
(pop) ; 56
; [eval] !pf2_2
(push) ; 56
(set-option :rlimit 16000)
(assert (not pf2_2@93@01))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 298 | !(pf2_2@93@01) | live]
; [else-branch: 298 | pf2_2@93@01 | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 298 | !(pf2_2@93@01)]
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 299 | p0@12@01 | live]
; [else-branch: 299 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 299 | p0@12@01]
(assert p0@12@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 300 | p1@13@01 | live]
; [else-branch: 300 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 300 | p1@13@01]
(assert p1@13@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p1@13@01)
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 301 | p2@14@01 | live]
; [else-branch: 301 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 301 | p2@14@01]
(assert p2@14@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p2@14@01)
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 302 | p0@12@01 | live]
; [else-branch: 302 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 302 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 303 | False | live]
; [else-branch: 303 | True | live]
(push) ; 60
; [then-branch: 303 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 303 | True]
(push) ; 61
; [then-branch: 304 | !(p0@12@01) | live]
; [else-branch: 304 | p0@12@01 | live]
(push) ; 62
; [then-branch: 304 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 304 | p0@12@01]
(push) ; 63
; [then-branch: 305 | !(p1@13@01) | live]
; [else-branch: 305 | p1@13@01 | live]
(push) ; 64
; [then-branch: 305 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 305 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 306 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 306 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 306 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 307 | False | dead]
; [else-branch: 307 | True | live]
(push) ; 62
; [else-branch: 307 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 308 | p1@13@01 | live]
; [else-branch: 308 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 308 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 309 | False | live]
; [else-branch: 309 | True | live]
(push) ; 60
; [then-branch: 309 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 309 | True]
(push) ; 61
; [then-branch: 310 | !(p0@12@01) | live]
; [else-branch: 310 | p0@12@01 | live]
(push) ; 62
; [then-branch: 310 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 310 | p0@12@01]
(push) ; 63
; [then-branch: 311 | !(p1@13@01) | live]
; [else-branch: 311 | p1@13@01 | live]
(push) ; 64
; [then-branch: 311 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 311 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 312 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 312 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 312 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 313 | False | dead]
; [else-branch: 313 | True | live]
(push) ; 62
; [else-branch: 313 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p2@14@01)))
(assert p1@13@01)
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 314 | p2@14@01 | live]
; [else-branch: 314 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 314 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 315 | False | live]
; [else-branch: 315 | True | live]
(push) ; 60
; [then-branch: 315 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 315 | True]
(push) ; 61
; [then-branch: 316 | !(p0@12@01) | live]
; [else-branch: 316 | p0@12@01 | live]
(push) ; 62
; [then-branch: 316 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 316 | p0@12@01]
(assert p0@12@01)
(push) ; 63
; [then-branch: 317 | !(p1@13@01) | live]
; [else-branch: 317 | p1@13@01 | live]
(push) ; 64
; [then-branch: 317 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 317 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 318 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 318 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 318 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 319 | False | dead]
; [else-branch: 319 | True | live]
(push) ; 62
; [else-branch: 319 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01)))
(assert p2@14@01)
(pop) ; 56
(pop) ; 55
(pop) ; 54
(pop) ; 53
(pop) ; 52
(pop) ; 51
(pop) ; 50
(pop) ; 49
(pop) ; 48
(pop) ; 47
(pop) ; 46
(pop) ; 45
(pop) ; 44
(pop) ; 43
(pop) ; 42
(pop) ; 41
(pop) ; 40
(pop) ; 39
(pop) ; 38
(pop) ; 37
(pop) ; 36
(pop) ; 35
(pop) ; 34
(pop) ; 33
(pop) ; 32
(pop) ; 31
(pop) ; 30
(pop) ; 29
(pop) ; 28
(pop) ; 27
(pop) ; 26
(pop) ; 25
(pop) ; 24
(pop) ; 23
(pop) ; 22
(pop) ; 21
(pop) ; 20
; [eval] !pt2_1
; [then-branch: 320 | !(pt2_1@87@01) | dead]
; [else-branch: 320 | pt2_1@87@01 | live]
(push) ; 20
; [else-branch: 320 | pt2_1@87@01]
(pop) ; 20
(pop) ; 19
; [eval] !pt1_1
; [then-branch: 321 | !(pt1_1@86@01) | dead]
; [else-branch: 321 | pt1_1@86@01 | live]
(push) ; 19
; [else-branch: 321 | pt1_1@86@01]
(pop) ; 19
(pop) ; 18
(pop) ; 17
; [eval] !pt2_1
(push) ; 17
(set-option :rlimit 16000)
(assert (not pt2_1@87@01))
(check-sat)
; unsat
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
; [then-branch: 322 | !(pt2_1@87@01) | dead]
; [else-branch: 322 | pt2_1@87@01 | live]
(set-option :rlimit 0)
(push) ; 17
; [else-branch: 322 | pt2_1@87@01]
(assert pt2_1@87@01)
(pop) ; 17
(pop) ; 16
(push) ; 16
; [else-branch: 201 | !(pt1_1@86@01)]
(assert (not pt1_1@86@01))
(pop) ; 16
; [eval] !pt1_1
(push) ; 16
(set-option :rlimit 16000)
(assert (not pt1_1@86@01))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 16000)
(assert (not (not pt1_1@86@01)))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [then-branch: 323 | !(pt1_1@86@01) | live]
; [else-branch: 323 | pt1_1@86@01 | live]
(set-option :rlimit 0)
(push) ; 16
; [then-branch: 323 | !(pt1_1@86@01)]
(assert (not pt1_1@86@01))
(push) ; 17
(set-option :rlimit 16000)
(assert (not (not pt2_1@87@01)))
(check-sat)
; unsat
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
; [then-branch: 324 | pt2_1@87@01 | dead]
; [else-branch: 324 | !(pt2_1@87@01) | live]
(set-option :rlimit 0)
(push) ; 17
; [else-branch: 324 | !(pt2_1@87@01)]
(assert (not pt2_1@87@01))
(pop) ; 17
; [eval] !pt2_1
(push) ; 17
(set-option :rlimit 16000)
(assert (not pt2_1@87@01))
(check-sat)
; unknown
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 17
(set-option :rlimit 16000)
(assert (not (not pt2_1@87@01)))
(check-sat)
; unsat
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
; [then-branch: 325 | !(pt2_1@87@01) | live]
; [else-branch: 325 | pt2_1@87@01 | dead]
(set-option :rlimit 0)
(push) ; 17
; [then-branch: 325 | !(pt2_1@87@01)]
(assert (not pt2_1@87@01))
; [then-branch: 326 | False | dead]
; [else-branch: 326 | True | live]
(push) ; 18
; [else-branch: 326 | True]
(pop) ; 18
; [eval] !pt0_1
(push) ; 18
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
; [then-branch: 327 | True | live]
; [else-branch: 327 | False | dead]
(set-option :rlimit 0)
(push) ; 18
; [then-branch: 327 | True]
; [then-branch: 328 | pt1_1@86@01 | dead]
; [else-branch: 328 | !(pt1_1@86@01) | live]
(push) ; 19
; [else-branch: 328 | !(pt1_1@86@01)]
(pop) ; 19
; [eval] !pt1_1
(push) ; 19
(set-option :rlimit 16000)
(assert (not pt1_1@86@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 329 | !(pt1_1@86@01) | live]
; [else-branch: 329 | pt1_1@86@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 329 | !(pt1_1@86@01)]
; [then-branch: 330 | pt2_1@87@01 | dead]
; [else-branch: 330 | !(pt2_1@87@01) | live]
(push) ; 20
; [else-branch: 330 | !(pt2_1@87@01)]
(pop) ; 20
; [eval] !pt2_1
(push) ; 20
(set-option :rlimit 16000)
(assert (not pt2_1@87@01))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 331 | !(pt2_1@87@01) | live]
; [else-branch: 331 | pt2_1@87@01 | dead]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 331 | !(pt2_1@87@01)]
; [exec]
; pt0_2 := pf0_1 && getCardSet(o1) == getCardSet(o2)
; [eval] pf0_1 && getCardSet(o1) == getCardSet(o2)
; [exec]
; pt1_2 := pf1_1 && getCardSet(o1_0) == getCardSet(o2_0)
; [eval] pf1_1 && getCardSet(o1_0) == getCardSet(o2_0)
(push) ; 21
; [then-branch: 332 | !(pf1_1@88@01) | live]
; [else-branch: 332 | pf1_1@88@01 | live]
(push) ; 22
; [then-branch: 332 | !(pf1_1@88@01)]
(assert (not pf1_1@88@01))
(pop) ; 22
(push) ; 22
; [else-branch: 332 | pf1_1@88@01]
(assert pf1_1@88@01)
; [eval] getCardSet(o1_0) == getCardSet(o2_0)
; [eval] getCardSet(o1_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
; [eval] getCardSet(o2_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_1@88@01
  (and
    pf1_1@88@01
    (getCardSet%precondition $Snap.unit o1_0@16@01)
    (getCardSet%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_1@88@01 (not pf1_1@88@01)))
(declare-const pt1_2@110@01 Bool)
(assert (=
  pt1_2@110@01
  (and
    pf1_1@88@01
    (= (getCardSet $Snap.unit o1_0@16@01) (getCardSet $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_2 := pf2_1 && getCardSet(o1_1) == getCardSet(o2_1)
; [eval] pf2_1 && getCardSet(o1_1) == getCardSet(o2_1)
(push) ; 21
; [then-branch: 333 | !(pf2_1@89@01) | live]
; [else-branch: 333 | pf2_1@89@01 | live]
(push) ; 22
; [then-branch: 333 | !(pf2_1@89@01)]
(assert (not pf2_1@89@01))
(pop) ; 22
(push) ; 22
; [else-branch: 333 | pf2_1@89@01]
(assert pf2_1@89@01)
; [eval] getCardSet(o1_1) == getCardSet(o2_1)
; [eval] getCardSet(o1_1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
; [eval] getCardSet(o2_1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_1@89@01
  (and
    pf2_1@89@01
    (getCardSet%precondition $Snap.unit o1_1@17@01)
    (getCardSet%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_1@89@01 (not pf2_1@89@01)))
(declare-const pt2_2@111@01 Bool)
(assert (=
  pt2_2@111@01
  (and
    pf2_1@89@01
    (= (getCardSet $Snap.unit o1_1@17@01) (getCardSet $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_2 := pf0_1 && !(getCardSet(o1) == getCardSet(o2))
; [eval] pf0_1 && !(getCardSet(o1) == getCardSet(o2))
; [exec]
; pf1_2 := pf1_1 && !(getCardSet(o1_0) == getCardSet(o2_0))
; [eval] pf1_1 && !(getCardSet(o1_0) == getCardSet(o2_0))
(push) ; 21
; [then-branch: 334 | !(pf1_1@88@01) | live]
; [else-branch: 334 | pf1_1@88@01 | live]
(push) ; 22
; [then-branch: 334 | !(pf1_1@88@01)]
(assert (not pf1_1@88@01))
(pop) ; 22
(push) ; 22
; [else-branch: 334 | pf1_1@88@01]
(assert pf1_1@88@01)
; [eval] !(getCardSet(o1_0) == getCardSet(o2_0))
; [eval] getCardSet(o1_0) == getCardSet(o2_0)
; [eval] getCardSet(o1_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
; [eval] getCardSet(o2_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf1_2@112@01 Bool)
(assert (=
  pf1_2@112@01
  (and
    pf1_1@88@01
    (not
      (= (getCardSet $Snap.unit o1_0@16@01) (getCardSet $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_2 := pf2_1 && !(getCardSet(o1_1) == getCardSet(o2_1))
; [eval] pf2_1 && !(getCardSet(o1_1) == getCardSet(o2_1))
(push) ; 21
; [then-branch: 335 | !(pf2_1@89@01) | live]
; [else-branch: 335 | pf2_1@89@01 | live]
(push) ; 22
; [then-branch: 335 | !(pf2_1@89@01)]
(assert (not pf2_1@89@01))
(pop) ; 22
(push) ; 22
; [else-branch: 335 | pf2_1@89@01]
(assert pf2_1@89@01)
; [eval] !(getCardSet(o1_1) == getCardSet(o2_1))
; [eval] getCardSet(o1_1) == getCardSet(o2_1)
; [eval] getCardSet(o1_1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
; [eval] getCardSet(o2_1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf2_2@113@01 Bool)
(assert (=
  pf2_2@113@01
  (and
    pf2_1@89@01
    (not
      (= (getCardSet $Snap.unit o1_1@17@01) (getCardSet $Snap.unit o2_1@20@01))))))
; [exec]
; pt0_3 := pt0_2 && getCardRarity(o1) < getCardRarity(o2)
; [eval] pt0_2 && getCardRarity(o1) < getCardRarity(o2)
; [exec]
; pt1_3 := pt1_2 && getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] pt1_2 && getCardRarity(o1_0) < getCardRarity(o2_0)
(push) ; 21
; [then-branch: 336 | !(pt1_2@110@01) | live]
; [else-branch: 336 | pt1_2@110@01 | live]
(push) ; 22
; [then-branch: 336 | !(pt1_2@110@01)]
(assert (not pt1_2@110@01))
(pop) ; 22
(push) ; 22
; [else-branch: 336 | pt1_2@110@01]
(assert pt1_2@110@01)
; [eval] getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] getCardRarity(o1_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
; [eval] getCardRarity(o2_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pt1_2@110@01
  (and
    pt1_2@110@01
    (getCardRarity%precondition $Snap.unit o1_0@16@01)
    (getCardRarity%precondition $Snap.unit o2_0@19@01))))
(assert (or pt1_2@110@01 (not pt1_2@110@01)))
(declare-const pt1_3@114@01 Bool)
(assert (=
  pt1_3@114@01
  (and
    pt1_2@110@01
    (<
      (getCardRarity $Snap.unit o1_0@16@01)
      (getCardRarity $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_3 := pt2_2 && getCardRarity(o1_1) < getCardRarity(o2_1)
; [eval] pt2_2 && getCardRarity(o1_1) < getCardRarity(o2_1)
(push) ; 21
; [then-branch: 337 | !(pt2_2@111@01) | live]
; [else-branch: 337 | pt2_2@111@01 | live]
(push) ; 22
; [then-branch: 337 | !(pt2_2@111@01)]
(assert (not pt2_2@111@01))
(pop) ; 22
(push) ; 22
; [else-branch: 337 | pt2_2@111@01]
(assert pt2_2@111@01)
; [eval] getCardRarity(o1_1) < getCardRarity(o2_1)
; [eval] getCardRarity(o1_1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_1@17@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_1@17@01))
; [eval] getCardRarity(o2_1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_1@20@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_1@20@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pt2_2@111@01
  (and
    pt2_2@111@01
    (getCardRarity%precondition $Snap.unit o1_1@17@01)
    (getCardRarity%precondition $Snap.unit o2_1@20@01))))
(assert (or pt2_2@111@01 (not pt2_2@111@01)))
(declare-const pt2_3@115@01 Bool)
(assert (=
  pt2_3@115@01
  (and
    pt2_2@111@01
    (<
      (getCardRarity $Snap.unit o1_1@17@01)
      (getCardRarity $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_3 := pt0_2 && !(getCardRarity(o1) < getCardRarity(o2))
; [eval] pt0_2 && !(getCardRarity(o1) < getCardRarity(o2))
; [exec]
; pf1_3 := pt1_2 && !(getCardRarity(o1_0) < getCardRarity(o2_0))
; [eval] pt1_2 && !(getCardRarity(o1_0) < getCardRarity(o2_0))
(push) ; 21
; [then-branch: 338 | !(pt1_2@110@01) | live]
; [else-branch: 338 | pt1_2@110@01 | live]
(push) ; 22
; [then-branch: 338 | !(pt1_2@110@01)]
(assert (not pt1_2@110@01))
(pop) ; 22
(push) ; 22
; [else-branch: 338 | pt1_2@110@01]
(assert pt1_2@110@01)
; [eval] !(getCardRarity(o1_0) < getCardRarity(o2_0))
; [eval] getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] getCardRarity(o1_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
; [eval] getCardRarity(o2_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf1_3@116@01 Bool)
(assert (=
  pf1_3@116@01
  (and
    pt1_2@110@01
    (not
      (<
        (getCardRarity $Snap.unit o1_0@16@01)
        (getCardRarity $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_3 := pt2_2 && !(getCardRarity(o1_1) < getCardRarity(o2_1))
; [eval] pt2_2 && !(getCardRarity(o1_1) < getCardRarity(o2_1))
(push) ; 21
; [then-branch: 339 | !(pt2_2@111@01) | live]
; [else-branch: 339 | pt2_2@111@01 | live]
(push) ; 22
; [then-branch: 339 | !(pt2_2@111@01)]
(assert (not pt2_2@111@01))
(pop) ; 22
(push) ; 22
; [else-branch: 339 | pt2_2@111@01]
(assert pt2_2@111@01)
; [eval] !(getCardRarity(o1_1) < getCardRarity(o2_1))
; [eval] getCardRarity(o1_1) < getCardRarity(o2_1)
; [eval] getCardRarity(o1_1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_1@17@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_1@17@01))
; [eval] getCardRarity(o2_1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_1@20@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_1@20@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf2_3@117@01 Bool)
(assert (=
  pf2_3@117@01
  (and
    pt2_2@111@01
    (not
      (<
        (getCardRarity $Snap.unit o1_1@17@01)
        (getCardRarity $Snap.unit o2_1@20@01))))))
; [then-branch: 340 | False | dead]
; [else-branch: 340 | True | live]
(push) ; 21
; [else-branch: 340 | True]
(pop) ; 21
; [eval] !pt0_3
(push) ; 21
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 341 | True | live]
; [else-branch: 341 | False | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 341 | True]
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not pt1_3@114@01)))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 22
(set-option :rlimit 16000)
(assert (not pt1_3@114@01))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 342 | pt1_3@114@01 | live]
; [else-branch: 342 | !(pt1_3@114@01) | live]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 342 | pt1_3@114@01]
(assert pt1_3@114@01)
; [exec]
; res_0 := 1
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not pt2_3@115@01)))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 23
(set-option :rlimit 16000)
(assert (not pt2_3@115@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 343 | pt2_3@115@01 | live]
; [else-branch: 343 | !(pt2_3@115@01) | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 343 | pt2_3@115@01]
(assert pt2_3@115@01)
; [exec]
; res_1 := 1
; [then-branch: 344 | False | dead]
; [else-branch: 344 | True | live]
(push) ; 24
; [else-branch: 344 | True]
(pop) ; 24
; [eval] !pt0_3
(push) ; 24
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
; [then-branch: 345 | True | live]
; [else-branch: 345 | False | dead]
(set-option :rlimit 0)
(push) ; 24
; [then-branch: 345 | True]
(push) ; 25
(set-option :rlimit 16000)
(assert (not (not pt1_3@114@01)))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 346 | pt1_3@114@01 | live]
; [else-branch: 346 | !(pt1_3@114@01) | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 346 | pt1_3@114@01]
; [exec]
; returned_0 := true
(push) ; 26
(set-option :rlimit 16000)
(assert (not (not pt2_3@115@01)))
(check-sat)
; unknown
(pop) ; 26
; 0.00s
; (get-info :all-statistics)
; [then-branch: 347 | pt2_3@115@01 | live]
; [else-branch: 347 | !(pt2_3@115@01) | dead]
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 347 | pt2_3@115@01]
; [exec]
; returned_1 := true
; [exec]
; pt0_4 := pf0_3 && getCardId(o1) == getCardId(o2)
; [eval] pf0_3 && getCardId(o1) == getCardId(o2)
; [exec]
; pt1_4 := pf1_3 && getCardId(o1_0) == getCardId(o2_0)
; [eval] pf1_3 && getCardId(o1_0) == getCardId(o2_0)
(push) ; 27
; [then-branch: 348 | !(pf1_3@116@01) | live]
; [else-branch: 348 | pf1_3@116@01 | live]
(push) ; 28
; [then-branch: 348 | !(pf1_3@116@01)]
(assert (not pf1_3@116@01))
(pop) ; 28
(push) ; 28
; [else-branch: 348 | pf1_3@116@01]
(assert pf1_3@116@01)
; [eval] getCardId(o1_0) == getCardId(o2_0)
; [eval] getCardId(o1_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
; [eval] getCardId(o2_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_3@116@01
  (and
    pf1_3@116@01
    (getCardId%precondition $Snap.unit o1_0@16@01)
    (getCardId%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_3@116@01 (not pf1_3@116@01)))
(declare-const pt1_4@118@01 Bool)
(assert (=
  pt1_4@118@01
  (and
    pf1_3@116@01
    (= (getCardId $Snap.unit o1_0@16@01) (getCardId $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_4 := pf2_3 && getCardId(o1_1) == getCardId(o2_1)
; [eval] pf2_3 && getCardId(o1_1) == getCardId(o2_1)
(push) ; 27
; [then-branch: 349 | !(pf2_3@117@01) | live]
; [else-branch: 349 | pf2_3@117@01 | live]
(push) ; 28
; [then-branch: 349 | !(pf2_3@117@01)]
(assert (not pf2_3@117@01))
(pop) ; 28
(push) ; 28
; [else-branch: 349 | pf2_3@117@01]
(assert pf2_3@117@01)
; [eval] getCardId(o1_1) == getCardId(o2_1)
; [eval] getCardId(o1_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
; [eval] getCardId(o2_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_3@117@01
  (and
    pf2_3@117@01
    (getCardId%precondition $Snap.unit o1_1@17@01)
    (getCardId%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_3@117@01 (not pf2_3@117@01)))
(declare-const pt2_4@119@01 Bool)
(assert (=
  pt2_4@119@01
  (and
    pf2_3@117@01
    (= (getCardId $Snap.unit o1_1@17@01) (getCardId $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_4 := pf0_3 && !(getCardId(o1) == getCardId(o2))
; [eval] pf0_3 && !(getCardId(o1) == getCardId(o2))
; [exec]
; pf1_4 := pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
; [eval] pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
(push) ; 27
; [then-branch: 350 | !(pf1_3@116@01) | live]
; [else-branch: 350 | pf1_3@116@01 | live]
(push) ; 28
; [then-branch: 350 | !(pf1_3@116@01)]
(assert (not pf1_3@116@01))
(pop) ; 28
(push) ; 28
; [else-branch: 350 | pf1_3@116@01]
(assert pf1_3@116@01)
; [eval] !(getCardId(o1_0) == getCardId(o2_0))
; [eval] getCardId(o1_0) == getCardId(o2_0)
; [eval] getCardId(o1_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
; [eval] getCardId(o2_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf1_4@120@01 Bool)
(assert (=
  pf1_4@120@01
  (and
    pf1_3@116@01
    (not (= (getCardId $Snap.unit o1_0@16@01) (getCardId $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_4 := pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
; [eval] pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
(push) ; 27
; [then-branch: 351 | !(pf2_3@117@01) | live]
; [else-branch: 351 | pf2_3@117@01 | live]
(push) ; 28
; [then-branch: 351 | !(pf2_3@117@01)]
(assert (not pf2_3@117@01))
(pop) ; 28
(push) ; 28
; [else-branch: 351 | pf2_3@117@01]
(assert pf2_3@117@01)
; [eval] !(getCardId(o1_1) == getCardId(o2_1))
; [eval] getCardId(o1_1) == getCardId(o2_1)
; [eval] getCardId(o1_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
; [eval] getCardId(o2_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf2_4@121@01 Bool)
(assert (=
  pf2_4@121@01
  (and
    pf2_3@117@01
    (not (= (getCardId $Snap.unit o1_1@17@01) (getCardId $Snap.unit o2_1@20@01))))))
; [exec]
; pt0_5 := pt0_4 && cardType(o1) > cardType(o2)
; [eval] pt0_4 && cardType(o1) > cardType(o2)
; [exec]
; pt1_5 := pt1_4 && cardType(o1_0) > cardType(o2_0)
; [eval] pt1_4 && cardType(o1_0) > cardType(o2_0)
(push) ; 27
; [then-branch: 352 | !(pt1_4@118@01) | live]
; [else-branch: 352 | pt1_4@118@01 | live]
(push) ; 28
; [then-branch: 352 | !(pt1_4@118@01)]
(assert (not pt1_4@118@01))
(pop) ; 28
(push) ; 28
; [else-branch: 352 | pt1_4@118@01]
(assert pt1_4@118@01)
; [eval] cardType(o1_0) > cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt1_4@118@01
  (and
    pt1_4@118@01
    (cardType%precondition $Snap.unit o1_0@16@01)
    (cardType%precondition $Snap.unit o2_0@19@01))))
(assert (or pt1_4@118@01 (not pt1_4@118@01)))
(declare-const pt1_5@122@01 Bool)
(assert (=
  pt1_5@122@01
  (and
    pt1_4@118@01
    (> (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_5 := pt2_4 && cardType(o1_1) > cardType(o2_1)
; [eval] pt2_4 && cardType(o1_1) > cardType(o2_1)
(push) ; 27
; [then-branch: 353 | !(pt2_4@119@01) | live]
; [else-branch: 353 | pt2_4@119@01 | live]
(push) ; 28
; [then-branch: 353 | !(pt2_4@119@01)]
(assert (not pt2_4@119@01))
(pop) ; 28
(push) ; 28
; [else-branch: 353 | pt2_4@119@01]
(assert pt2_4@119@01)
; [eval] cardType(o1_1) > cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt2_4@119@01
  (and
    pt2_4@119@01
    (cardType%precondition $Snap.unit o1_1@17@01)
    (cardType%precondition $Snap.unit o2_1@20@01))))
(assert (or pt2_4@119@01 (not pt2_4@119@01)))
(declare-const pt2_5@123@01 Bool)
(assert (=
  pt2_5@123@01
  (and
    pt2_4@119@01
    (> (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_5 := pt0_4 && !(cardType(o1) > cardType(o2))
; [eval] pt0_4 && !(cardType(o1) > cardType(o2))
; [exec]
; pf1_5 := pt1_4 && !(cardType(o1_0) > cardType(o2_0))
; [eval] pt1_4 && !(cardType(o1_0) > cardType(o2_0))
(push) ; 27
; [then-branch: 354 | !(pt1_4@118@01) | live]
; [else-branch: 354 | pt1_4@118@01 | live]
(push) ; 28
; [then-branch: 354 | !(pt1_4@118@01)]
(assert (not pt1_4@118@01))
(pop) ; 28
(push) ; 28
; [else-branch: 354 | pt1_4@118@01]
(assert pt1_4@118@01)
; [eval] !(cardType(o1_0) > cardType(o2_0))
; [eval] cardType(o1_0) > cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf1_5@124@01 Bool)
(assert (=
  pf1_5@124@01
  (and
    pt1_4@118@01
    (not (> (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_5 := pt2_4 && !(cardType(o1_1) > cardType(o2_1))
; [eval] pt2_4 && !(cardType(o1_1) > cardType(o2_1))
(push) ; 27
; [then-branch: 355 | !(pt2_4@119@01) | live]
; [else-branch: 355 | pt2_4@119@01 | live]
(push) ; 28
; [then-branch: 355 | !(pt2_4@119@01)]
(assert (not pt2_4@119@01))
(pop) ; 28
(push) ; 28
; [else-branch: 355 | pt2_4@119@01]
(assert pt2_4@119@01)
; [eval] !(cardType(o1_1) > cardType(o2_1))
; [eval] cardType(o1_1) > cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf2_5@125@01 Bool)
(assert (=
  pf2_5@125@01
  (and
    pt2_4@119@01
    (not (> (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01))))))
; [then-branch: 356 | False | dead]
; [else-branch: 356 | True | live]
(push) ; 27
; [else-branch: 356 | True]
(pop) ; 27
; [eval] !pt0_5
(push) ; 27
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 357 | True | live]
; [else-branch: 357 | False | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 357 | True]
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not pt1_5@122@01)))
(check-sat)
; unsat
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 358 | pt1_5@122@01 | dead]
; [else-branch: 358 | !(pt1_5@122@01) | live]
(set-option :rlimit 0)
(push) ; 28
; [else-branch: 358 | !(pt1_5@122@01)]
(assert (not pt1_5@122@01))
(pop) ; 28
; [eval] !pt1_5
(push) ; 28
(set-option :rlimit 16000)
(assert (not pt1_5@122@01))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not pt1_5@122@01)))
(check-sat)
; unsat
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 359 | !(pt1_5@122@01) | live]
; [else-branch: 359 | pt1_5@122@01 | dead]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 359 | !(pt1_5@122@01)]
(assert (not pt1_5@122@01))
(push) ; 29
(set-option :rlimit 16000)
(assert (not (not pt2_5@123@01)))
(check-sat)
; unsat
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 360 | pt2_5@123@01 | dead]
; [else-branch: 360 | !(pt2_5@123@01) | live]
(set-option :rlimit 0)
(push) ; 29
; [else-branch: 360 | !(pt2_5@123@01)]
(assert (not pt2_5@123@01))
(pop) ; 29
; [eval] !pt2_5
(push) ; 29
(set-option :rlimit 16000)
(assert (not pt2_5@123@01))
(check-sat)
; unknown
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 29
(set-option :rlimit 16000)
(assert (not (not pt2_5@123@01)))
(check-sat)
; unsat
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 361 | !(pt2_5@123@01) | live]
; [else-branch: 361 | pt2_5@123@01 | dead]
(set-option :rlimit 0)
(push) ; 29
; [then-branch: 361 | !(pt2_5@123@01)]
(assert (not pt2_5@123@01))
; [then-branch: 362 | False | dead]
; [else-branch: 362 | True | live]
(push) ; 30
; [else-branch: 362 | True]
(pop) ; 30
; [eval] !pt0_5
(push) ; 30
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 30
; 0.00s
; (get-info :all-statistics)
; [then-branch: 363 | True | live]
; [else-branch: 363 | False | dead]
(set-option :rlimit 0)
(push) ; 30
; [then-branch: 363 | True]
; [then-branch: 364 | pt1_5@122@01 | dead]
; [else-branch: 364 | !(pt1_5@122@01) | live]
(push) ; 31
; [else-branch: 364 | !(pt1_5@122@01)]
(pop) ; 31
; [eval] !pt1_5
(push) ; 31
(set-option :rlimit 16000)
(assert (not pt1_5@122@01))
(check-sat)
; unknown
(pop) ; 31
; 0.00s
; (get-info :all-statistics)
; [then-branch: 365 | !(pt1_5@122@01) | live]
; [else-branch: 365 | pt1_5@122@01 | dead]
(set-option :rlimit 0)
(push) ; 31
; [then-branch: 365 | !(pt1_5@122@01)]
; [then-branch: 366 | pt2_5@123@01 | dead]
; [else-branch: 366 | !(pt2_5@123@01) | live]
(push) ; 32
; [else-branch: 366 | !(pt2_5@123@01)]
(pop) ; 32
; [eval] !pt2_5
(push) ; 32
(set-option :rlimit 16000)
(assert (not pt2_5@123@01))
(check-sat)
; unknown
(pop) ; 32
; 0.00s
; (get-info :all-statistics)
; [then-branch: 367 | !(pt2_5@123@01) | live]
; [else-branch: 367 | pt2_5@123@01 | dead]
(set-option :rlimit 0)
(push) ; 32
; [then-branch: 367 | !(pt2_5@123@01)]
; [exec]
; pt0_6 := pf0_5 && cardType(o1) == cardType(o2)
; [eval] pf0_5 && cardType(o1) == cardType(o2)
; [exec]
; pt1_6 := pf1_5 && cardType(o1_0) == cardType(o2_0)
; [eval] pf1_5 && cardType(o1_0) == cardType(o2_0)
(push) ; 33
; [then-branch: 368 | !(pf1_5@124@01) | live]
; [else-branch: 368 | pf1_5@124@01 | live]
(push) ; 34
; [then-branch: 368 | !(pf1_5@124@01)]
(assert (not pf1_5@124@01))
(pop) ; 34
(push) ; 34
; [else-branch: 368 | pf1_5@124@01]
(assert pf1_5@124@01)
; [eval] cardType(o1_0) == cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_5@124@01
  (and
    pf1_5@124@01
    (cardType%precondition $Snap.unit o1_0@16@01)
    (cardType%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_5@124@01 (not pf1_5@124@01)))
(declare-const pt1_6@126@01 Bool)
(assert (=
  pt1_6@126@01
  (and
    pf1_5@124@01
    (= (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_6 := pf2_5 && cardType(o1_1) == cardType(o2_1)
; [eval] pf2_5 && cardType(o1_1) == cardType(o2_1)
(push) ; 33
; [then-branch: 369 | !(pf2_5@125@01) | live]
; [else-branch: 369 | pf2_5@125@01 | live]
(push) ; 34
; [then-branch: 369 | !(pf2_5@125@01)]
(assert (not pf2_5@125@01))
(pop) ; 34
(push) ; 34
; [else-branch: 369 | pf2_5@125@01]
(assert pf2_5@125@01)
; [eval] cardType(o1_1) == cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_5@125@01
  (and
    pf2_5@125@01
    (cardType%precondition $Snap.unit o1_1@17@01)
    (cardType%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_5@125@01 (not pf2_5@125@01)))
(declare-const pt2_6@127@01 Bool)
(assert (=
  pt2_6@127@01
  (and
    pf2_5@125@01
    (= (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_6 := pf0_5 && !(cardType(o1) == cardType(o2))
; [eval] pf0_5 && !(cardType(o1) == cardType(o2))
; [exec]
; pf1_6 := pf1_5 && !(cardType(o1_0) == cardType(o2_0))
; [eval] pf1_5 && !(cardType(o1_0) == cardType(o2_0))
(push) ; 33
; [then-branch: 370 | !(pf1_5@124@01) | live]
; [else-branch: 370 | pf1_5@124@01 | live]
(push) ; 34
; [then-branch: 370 | !(pf1_5@124@01)]
(assert (not pf1_5@124@01))
(pop) ; 34
(push) ; 34
; [else-branch: 370 | pf1_5@124@01]
(assert pf1_5@124@01)
; [eval] !(cardType(o1_0) == cardType(o2_0))
; [eval] cardType(o1_0) == cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf1_6@128@01 Bool)
(assert (=
  pf1_6@128@01
  (and
    pf1_5@124@01
    (not (= (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_6 := pf2_5 && !(cardType(o1_1) == cardType(o2_1))
; [eval] pf2_5 && !(cardType(o1_1) == cardType(o2_1))
(push) ; 33
; [then-branch: 371 | !(pf2_5@125@01) | live]
; [else-branch: 371 | pf2_5@125@01 | live]
(push) ; 34
; [then-branch: 371 | !(pf2_5@125@01)]
(assert (not pf2_5@125@01))
(pop) ; 34
(push) ; 34
; [else-branch: 371 | pf2_5@125@01]
(assert pf2_5@125@01)
; [eval] !(cardType(o1_1) == cardType(o2_1))
; [eval] cardType(o1_1) == cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf2_6@129@01 Bool)
(assert (=
  pf2_6@129@01
  (and
    pf2_5@125@01
    (not (= (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01))))))
; [then-branch: 372 | False | dead]
; [else-branch: 372 | True | live]
(push) ; 33
; [else-branch: 372 | True]
(pop) ; 33
; [eval] !pt0_6
(push) ; 33
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 373 | True | live]
; [else-branch: 373 | False | dead]
(set-option :rlimit 0)
(push) ; 33
; [then-branch: 373 | True]
(push) ; 34
(set-option :rlimit 16000)
(assert (not (not pt1_6@126@01)))
(check-sat)
; unsat
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 374 | pt1_6@126@01 | dead]
; [else-branch: 374 | !(pt1_6@126@01) | live]
(set-option :rlimit 0)
(push) ; 34
; [else-branch: 374 | !(pt1_6@126@01)]
(assert (not pt1_6@126@01))
(pop) ; 34
; [eval] !pt1_6
(push) ; 34
(set-option :rlimit 16000)
(assert (not pt1_6@126@01))
(check-sat)
; unknown
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 34
(set-option :rlimit 16000)
(assert (not (not pt1_6@126@01)))
(check-sat)
; unsat
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 375 | !(pt1_6@126@01) | live]
; [else-branch: 375 | pt1_6@126@01 | dead]
(set-option :rlimit 0)
(push) ; 34
; [then-branch: 375 | !(pt1_6@126@01)]
(assert (not pt1_6@126@01))
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@127@01)))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 376 | pt2_6@127@01 | dead]
; [else-branch: 376 | !(pt2_6@127@01) | live]
(set-option :rlimit 0)
(push) ; 35
; [else-branch: 376 | !(pt2_6@127@01)]
(assert (not pt2_6@127@01))
(pop) ; 35
; [eval] !pt2_6
(push) ; 35
(set-option :rlimit 16000)
(assert (not pt2_6@127@01))
(check-sat)
; unknown
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@127@01)))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 377 | !(pt2_6@127@01) | live]
; [else-branch: 377 | pt2_6@127@01 | dead]
(set-option :rlimit 0)
(push) ; 35
; [then-branch: 377 | !(pt2_6@127@01)]
(assert (not pt2_6@127@01))
; [then-branch: 378 | False | dead]
; [else-branch: 378 | True | live]
(push) ; 36
; [else-branch: 378 | True]
(pop) ; 36
; [eval] !pt0_6
(push) ; 36
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 36
; 0.00s
; (get-info :all-statistics)
; [then-branch: 379 | True | live]
; [else-branch: 379 | False | dead]
(set-option :rlimit 0)
(push) ; 36
; [then-branch: 379 | True]
; [then-branch: 380 | pt1_6@126@01 | dead]
; [else-branch: 380 | !(pt1_6@126@01) | live]
(push) ; 37
; [else-branch: 380 | !(pt1_6@126@01)]
(pop) ; 37
; [eval] !pt1_6
(push) ; 37
(set-option :rlimit 16000)
(assert (not pt1_6@126@01))
(check-sat)
; unknown
(pop) ; 37
; 0.00s
; (get-info :all-statistics)
; [then-branch: 381 | !(pt1_6@126@01) | live]
; [else-branch: 381 | pt1_6@126@01 | dead]
(set-option :rlimit 0)
(push) ; 37
; [then-branch: 381 | !(pt1_6@126@01)]
; [then-branch: 382 | pt2_6@127@01 | dead]
; [else-branch: 382 | !(pt2_6@127@01) | live]
(push) ; 38
; [else-branch: 382 | !(pt2_6@127@01)]
(pop) ; 38
; [eval] !pt2_6
(push) ; 38
(set-option :rlimit 16000)
(assert (not pt2_6@127@01))
(check-sat)
; unknown
(pop) ; 38
; 0.00s
; (get-info :all-statistics)
; [then-branch: 383 | !(pt2_6@127@01) | live]
; [else-branch: 383 | pt2_6@127@01 | dead]
(set-option :rlimit 0)
(push) ; 38
; [then-branch: 383 | !(pt2_6@127@01)]
; [then-branch: 384 | False | dead]
; [else-branch: 384 | True | live]
(push) ; 39
; [else-branch: 384 | True]
(pop) ; 39
; [eval] !pf0_6
(push) ; 39
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 385 | True | live]
; [else-branch: 385 | False | dead]
(set-option :rlimit 0)
(push) ; 39
; [then-branch: 385 | True]
(push) ; 40
(set-option :rlimit 16000)
(assert (not (not pf1_6@128@01)))
(check-sat)
; unsat
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 386 | pf1_6@128@01 | dead]
; [else-branch: 386 | !(pf1_6@128@01) | live]
(set-option :rlimit 0)
(push) ; 40
; [else-branch: 386 | !(pf1_6@128@01)]
(assert (not pf1_6@128@01))
(pop) ; 40
; [eval] !pf1_6
(push) ; 40
(set-option :rlimit 16000)
(assert (not pf1_6@128@01))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 40
(set-option :rlimit 16000)
(assert (not (not pf1_6@128@01)))
(check-sat)
; unsat
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 387 | !(pf1_6@128@01) | live]
; [else-branch: 387 | pf1_6@128@01 | dead]
(set-option :rlimit 0)
(push) ; 40
; [then-branch: 387 | !(pf1_6@128@01)]
(assert (not pf1_6@128@01))
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@129@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 388 | pf2_6@129@01 | dead]
; [else-branch: 388 | !(pf2_6@129@01) | live]
(set-option :rlimit 0)
(push) ; 41
; [else-branch: 388 | !(pf2_6@129@01)]
(assert (not pf2_6@129@01))
(pop) ; 41
; [eval] !pf2_6
(push) ; 41
(set-option :rlimit 16000)
(assert (not pf2_6@129@01))
(check-sat)
; unknown
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@129@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 389 | !(pf2_6@129@01) | live]
; [else-branch: 389 | pf2_6@129@01 | dead]
(set-option :rlimit 0)
(push) ; 41
; [then-branch: 389 | !(pf2_6@129@01)]
(assert (not pf2_6@129@01))
; [then-branch: 390 | False | dead]
; [else-branch: 390 | True | live]
(push) ; 42
; [else-branch: 390 | True]
(pop) ; 42
; [eval] !pf0_6
(push) ; 42
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 42
; 0.00s
; (get-info :all-statistics)
; [then-branch: 391 | True | live]
; [else-branch: 391 | False | dead]
(set-option :rlimit 0)
(push) ; 42
; [then-branch: 391 | True]
; [then-branch: 392 | pf1_6@128@01 | dead]
; [else-branch: 392 | !(pf1_6@128@01) | live]
(push) ; 43
; [else-branch: 392 | !(pf1_6@128@01)]
(pop) ; 43
; [eval] !pf1_6
(push) ; 43
(set-option :rlimit 16000)
(assert (not pf1_6@128@01))
(check-sat)
; unknown
(pop) ; 43
; 0.00s
; (get-info :all-statistics)
; [then-branch: 393 | !(pf1_6@128@01) | live]
; [else-branch: 393 | pf1_6@128@01 | dead]
(set-option :rlimit 0)
(push) ; 43
; [then-branch: 393 | !(pf1_6@128@01)]
; [then-branch: 394 | pf2_6@129@01 | dead]
; [else-branch: 394 | !(pf2_6@129@01) | live]
(push) ; 44
; [else-branch: 394 | !(pf2_6@129@01)]
(pop) ; 44
; [eval] !pf2_6
(push) ; 44
(set-option :rlimit 16000)
(assert (not pf2_6@129@01))
(check-sat)
; unknown
(pop) ; 44
; 0.00s
; (get-info :all-statistics)
; [then-branch: 395 | !(pf2_6@129@01) | live]
; [else-branch: 395 | pf2_6@129@01 | dead]
(set-option :rlimit 0)
(push) ; 44
; [then-branch: 395 | !(pf2_6@129@01)]
; [then-branch: 396 | False | dead]
; [else-branch: 396 | True | live]
(push) ; 45
; [else-branch: 396 | True]
(pop) ; 45
; [eval] !pf0_4
(push) ; 45
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 397 | True | live]
; [else-branch: 397 | False | dead]
(set-option :rlimit 0)
(push) ; 45
; [then-branch: 397 | True]
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@120@01)))
(check-sat)
; unsat
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 398 | pf1_4@120@01 | dead]
; [else-branch: 398 | !(pf1_4@120@01) | live]
(set-option :rlimit 0)
(push) ; 46
; [else-branch: 398 | !(pf1_4@120@01)]
(assert (not pf1_4@120@01))
(pop) ; 46
; [eval] !pf1_4
(push) ; 46
(set-option :rlimit 16000)
(assert (not pf1_4@120@01))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@120@01)))
(check-sat)
; unsat
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 399 | !(pf1_4@120@01) | live]
; [else-branch: 399 | pf1_4@120@01 | dead]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 399 | !(pf1_4@120@01)]
(assert (not pf1_4@120@01))
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@121@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 400 | pf2_4@121@01 | dead]
; [else-branch: 400 | !(pf2_4@121@01) | live]
(set-option :rlimit 0)
(push) ; 47
; [else-branch: 400 | !(pf2_4@121@01)]
(assert (not pf2_4@121@01))
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not pf2_4@121@01))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@121@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 401 | !(pf2_4@121@01) | live]
; [else-branch: 401 | pf2_4@121@01 | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 401 | !(pf2_4@121@01)]
(assert (not pf2_4@121@01))
; [then-branch: 402 | False | dead]
; [else-branch: 402 | True | live]
(push) ; 48
; [else-branch: 402 | True]
(pop) ; 48
; [eval] !pf0_4
(push) ; 48
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 403 | True | live]
; [else-branch: 403 | False | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 403 | True]
; [then-branch: 404 | pf1_4@120@01 | dead]
; [else-branch: 404 | !(pf1_4@120@01) | live]
(push) ; 49
; [else-branch: 404 | !(pf1_4@120@01)]
(pop) ; 49
; [eval] !pf1_4
(push) ; 49
(set-option :rlimit 16000)
(assert (not pf1_4@120@01))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 405 | !(pf1_4@120@01) | live]
; [else-branch: 405 | pf1_4@120@01 | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 405 | !(pf1_4@120@01)]
; [then-branch: 406 | pf2_4@121@01 | dead]
; [else-branch: 406 | !(pf2_4@121@01) | live]
(push) ; 50
; [else-branch: 406 | !(pf2_4@121@01)]
(pop) ; 50
; [eval] !pf2_4
(push) ; 50
(set-option :rlimit 16000)
(assert (not pf2_4@121@01))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 407 | !(pf2_4@121@01) | live]
; [else-branch: 407 | pf2_4@121@01 | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 407 | !(pf2_4@121@01)]
; [then-branch: 408 | False | dead]
; [else-branch: 408 | True | live]
(push) ; 51
; [else-branch: 408 | True]
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 409 | True | live]
; [else-branch: 409 | False | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 409 | True]
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@112@01)))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 410 | pf1_2@112@01 | dead]
; [else-branch: 410 | !(pf1_2@112@01) | live]
(set-option :rlimit 0)
(push) ; 52
; [else-branch: 410 | !(pf1_2@112@01)]
(assert (not pf1_2@112@01))
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not pf1_2@112@01))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@112@01)))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 411 | !(pf1_2@112@01) | live]
; [else-branch: 411 | pf1_2@112@01 | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 411 | !(pf1_2@112@01)]
(assert (not pf1_2@112@01))
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@113@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 412 | pf2_2@113@01 | dead]
; [else-branch: 412 | !(pf2_2@113@01) | live]
(set-option :rlimit 0)
(push) ; 53
; [else-branch: 412 | !(pf2_2@113@01)]
(assert (not pf2_2@113@01))
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not pf2_2@113@01))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@113@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 413 | !(pf2_2@113@01) | live]
; [else-branch: 413 | pf2_2@113@01 | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 413 | !(pf2_2@113@01)]
(assert (not pf2_2@113@01))
; [then-branch: 414 | False | dead]
; [else-branch: 414 | True | live]
(push) ; 54
; [else-branch: 414 | True]
(pop) ; 54
; [eval] !pf0_2
(push) ; 54
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 415 | True | live]
; [else-branch: 415 | False | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 415 | True]
; [then-branch: 416 | pf1_2@112@01 | dead]
; [else-branch: 416 | !(pf1_2@112@01) | live]
(push) ; 55
; [else-branch: 416 | !(pf1_2@112@01)]
(pop) ; 55
; [eval] !pf1_2
(push) ; 55
(set-option :rlimit 16000)
(assert (not pf1_2@112@01))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 417 | !(pf1_2@112@01) | live]
; [else-branch: 417 | pf1_2@112@01 | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 417 | !(pf1_2@112@01)]
; [then-branch: 418 | pf2_2@113@01 | dead]
; [else-branch: 418 | !(pf2_2@113@01) | live]
(push) ; 56
; [else-branch: 418 | !(pf2_2@113@01)]
(pop) ; 56
; [eval] !pf2_2
(push) ; 56
(set-option :rlimit 16000)
(assert (not pf2_2@113@01))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 419 | !(pf2_2@113@01) | live]
; [else-branch: 419 | pf2_2@113@01 | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 419 | !(pf2_2@113@01)]
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 420 | p0@12@01 | live]
; [else-branch: 420 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 420 | p0@12@01]
(assert p0@12@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 421 | p1@13@01 | live]
; [else-branch: 421 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 421 | p1@13@01]
(assert p1@13@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p1@13@01)
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 422 | p2@14@01 | live]
; [else-branch: 422 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 422 | p2@14@01]
(assert p2@14@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p2@14@01)
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 423 | p0@12@01 | live]
; [else-branch: 423 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 423 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 424 | False | live]
; [else-branch: 424 | True | live]
(push) ; 60
; [then-branch: 424 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 424 | True]
(push) ; 61
; [then-branch: 425 | !(p0@12@01) | live]
; [else-branch: 425 | p0@12@01 | live]
(push) ; 62
; [then-branch: 425 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 425 | p0@12@01]
(push) ; 63
; [then-branch: 426 | !(p1@13@01) | live]
; [else-branch: 426 | p1@13@01 | live]
(push) ; 64
; [then-branch: 426 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 426 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 427 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 427 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 427 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 428 | False | dead]
; [else-branch: 428 | True | live]
(push) ; 62
; [else-branch: 428 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 429 | p1@13@01 | live]
; [else-branch: 429 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 429 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 430 | False | live]
; [else-branch: 430 | True | live]
(push) ; 60
; [then-branch: 430 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 430 | True]
(push) ; 61
; [then-branch: 431 | !(p0@12@01) | live]
; [else-branch: 431 | p0@12@01 | live]
(push) ; 62
; [then-branch: 431 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 431 | p0@12@01]
(push) ; 63
; [then-branch: 432 | !(p1@13@01) | live]
; [else-branch: 432 | p1@13@01 | live]
(push) ; 64
; [then-branch: 432 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 432 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 433 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 433 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 433 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 434 | False | dead]
; [else-branch: 434 | True | live]
(push) ; 62
; [else-branch: 434 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p2@14@01)))
(assert p1@13@01)
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 435 | p2@14@01 | live]
; [else-branch: 435 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 435 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 436 | False | live]
; [else-branch: 436 | True | live]
(push) ; 60
; [then-branch: 436 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 436 | True]
(push) ; 61
; [then-branch: 437 | !(p0@12@01) | live]
; [else-branch: 437 | p0@12@01 | live]
(push) ; 62
; [then-branch: 437 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 437 | p0@12@01]
(assert p0@12@01)
(push) ; 63
; [then-branch: 438 | !(p1@13@01) | live]
; [else-branch: 438 | p1@13@01 | live]
(push) ; 64
; [then-branch: 438 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 438 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 439 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 439 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 439 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 440 | False | dead]
; [else-branch: 440 | True | live]
(push) ; 62
; [else-branch: 440 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01)))
(assert p2@14@01)
(pop) ; 56
(pop) ; 55
(pop) ; 54
(pop) ; 53
(pop) ; 52
(pop) ; 51
(pop) ; 50
(pop) ; 49
(pop) ; 48
(pop) ; 47
(pop) ; 46
(pop) ; 45
(pop) ; 44
(pop) ; 43
(pop) ; 42
(pop) ; 41
(pop) ; 40
(pop) ; 39
(pop) ; 38
(pop) ; 37
(pop) ; 36
(pop) ; 35
(pop) ; 34
(pop) ; 33
(pop) ; 32
(pop) ; 31
(pop) ; 30
(pop) ; 29
(pop) ; 28
(pop) ; 27
(pop) ; 26
; [eval] !pt2_3
; [then-branch: 441 | !(pt2_3@115@01) | dead]
; [else-branch: 441 | pt2_3@115@01 | live]
(push) ; 26
; [else-branch: 441 | pt2_3@115@01]
(pop) ; 26
(pop) ; 25
; [eval] !pt1_3
; [then-branch: 442 | !(pt1_3@114@01) | dead]
; [else-branch: 442 | pt1_3@114@01 | live]
(push) ; 25
; [else-branch: 442 | pt1_3@114@01]
(pop) ; 25
(pop) ; 24
(pop) ; 23
; [eval] !pt2_3
(push) ; 23
(set-option :rlimit 16000)
(assert (not pt2_3@115@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 443 | !(pt2_3@115@01) | dead]
; [else-branch: 443 | pt2_3@115@01 | live]
(set-option :rlimit 0)
(push) ; 23
; [else-branch: 443 | pt2_3@115@01]
(assert pt2_3@115@01)
(pop) ; 23
(pop) ; 22
(push) ; 22
; [else-branch: 342 | !(pt1_3@114@01)]
(assert (not pt1_3@114@01))
(pop) ; 22
; [eval] !pt1_3
(push) ; 22
(set-option :rlimit 16000)
(assert (not pt1_3@114@01))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not pt1_3@114@01)))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 444 | !(pt1_3@114@01) | live]
; [else-branch: 444 | pt1_3@114@01 | live]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 444 | !(pt1_3@114@01)]
(assert (not pt1_3@114@01))
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not pt2_3@115@01)))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 445 | pt2_3@115@01 | dead]
; [else-branch: 445 | !(pt2_3@115@01) | live]
(set-option :rlimit 0)
(push) ; 23
; [else-branch: 445 | !(pt2_3@115@01)]
(assert (not pt2_3@115@01))
(pop) ; 23
; [eval] !pt2_3
(push) ; 23
(set-option :rlimit 16000)
(assert (not pt2_3@115@01))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not pt2_3@115@01)))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 446 | !(pt2_3@115@01) | live]
; [else-branch: 446 | pt2_3@115@01 | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 446 | !(pt2_3@115@01)]
(assert (not pt2_3@115@01))
; [then-branch: 447 | False | dead]
; [else-branch: 447 | True | live]
(push) ; 24
; [else-branch: 447 | True]
(pop) ; 24
; [eval] !pt0_3
(push) ; 24
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
; [then-branch: 448 | True | live]
; [else-branch: 448 | False | dead]
(set-option :rlimit 0)
(push) ; 24
; [then-branch: 448 | True]
; [then-branch: 449 | pt1_3@114@01 | dead]
; [else-branch: 449 | !(pt1_3@114@01) | live]
(push) ; 25
; [else-branch: 449 | !(pt1_3@114@01)]
(pop) ; 25
; [eval] !pt1_3
(push) ; 25
(set-option :rlimit 16000)
(assert (not pt1_3@114@01))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 450 | !(pt1_3@114@01) | live]
; [else-branch: 450 | pt1_3@114@01 | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 450 | !(pt1_3@114@01)]
; [then-branch: 451 | pt2_3@115@01 | dead]
; [else-branch: 451 | !(pt2_3@115@01) | live]
(push) ; 26
; [else-branch: 451 | !(pt2_3@115@01)]
(pop) ; 26
; [eval] !pt2_3
(push) ; 26
(set-option :rlimit 16000)
(assert (not pt2_3@115@01))
(check-sat)
; unknown
(pop) ; 26
; 0.00s
; (get-info :all-statistics)
; [then-branch: 452 | !(pt2_3@115@01) | live]
; [else-branch: 452 | pt2_3@115@01 | dead]
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 452 | !(pt2_3@115@01)]
; [exec]
; pt0_4 := pf0_3 && getCardId(o1) == getCardId(o2)
; [eval] pf0_3 && getCardId(o1) == getCardId(o2)
; [exec]
; pt1_4 := pf1_3 && getCardId(o1_0) == getCardId(o2_0)
; [eval] pf1_3 && getCardId(o1_0) == getCardId(o2_0)
(push) ; 27
; [then-branch: 453 | !(pf1_3@116@01) | live]
; [else-branch: 453 | pf1_3@116@01 | live]
(push) ; 28
; [then-branch: 453 | !(pf1_3@116@01)]
(assert (not pf1_3@116@01))
(pop) ; 28
(push) ; 28
; [else-branch: 453 | pf1_3@116@01]
(assert pf1_3@116@01)
; [eval] getCardId(o1_0) == getCardId(o2_0)
; [eval] getCardId(o1_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
; [eval] getCardId(o2_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_3@116@01
  (and
    pf1_3@116@01
    (getCardId%precondition $Snap.unit o1_0@16@01)
    (getCardId%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_3@116@01 (not pf1_3@116@01)))
(declare-const pt1_4@130@01 Bool)
(assert (=
  pt1_4@130@01
  (and
    pf1_3@116@01
    (= (getCardId $Snap.unit o1_0@16@01) (getCardId $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_4 := pf2_3 && getCardId(o1_1) == getCardId(o2_1)
; [eval] pf2_3 && getCardId(o1_1) == getCardId(o2_1)
(push) ; 27
; [then-branch: 454 | !(pf2_3@117@01) | live]
; [else-branch: 454 | pf2_3@117@01 | live]
(push) ; 28
; [then-branch: 454 | !(pf2_3@117@01)]
(assert (not pf2_3@117@01))
(pop) ; 28
(push) ; 28
; [else-branch: 454 | pf2_3@117@01]
(assert pf2_3@117@01)
; [eval] getCardId(o1_1) == getCardId(o2_1)
; [eval] getCardId(o1_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
; [eval] getCardId(o2_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_3@117@01
  (and
    pf2_3@117@01
    (getCardId%precondition $Snap.unit o1_1@17@01)
    (getCardId%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_3@117@01 (not pf2_3@117@01)))
(declare-const pt2_4@131@01 Bool)
(assert (=
  pt2_4@131@01
  (and
    pf2_3@117@01
    (= (getCardId $Snap.unit o1_1@17@01) (getCardId $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_4 := pf0_3 && !(getCardId(o1) == getCardId(o2))
; [eval] pf0_3 && !(getCardId(o1) == getCardId(o2))
; [exec]
; pf1_4 := pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
; [eval] pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
(push) ; 27
; [then-branch: 455 | !(pf1_3@116@01) | live]
; [else-branch: 455 | pf1_3@116@01 | live]
(push) ; 28
; [then-branch: 455 | !(pf1_3@116@01)]
(assert (not pf1_3@116@01))
(pop) ; 28
(push) ; 28
; [else-branch: 455 | pf1_3@116@01]
(assert pf1_3@116@01)
; [eval] !(getCardId(o1_0) == getCardId(o2_0))
; [eval] getCardId(o1_0) == getCardId(o2_0)
; [eval] getCardId(o1_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
; [eval] getCardId(o2_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf1_4@132@01 Bool)
(assert (=
  pf1_4@132@01
  (and
    pf1_3@116@01
    (not (= (getCardId $Snap.unit o1_0@16@01) (getCardId $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_4 := pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
; [eval] pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
(push) ; 27
; [then-branch: 456 | !(pf2_3@117@01) | live]
; [else-branch: 456 | pf2_3@117@01 | live]
(push) ; 28
; [then-branch: 456 | !(pf2_3@117@01)]
(assert (not pf2_3@117@01))
(pop) ; 28
(push) ; 28
; [else-branch: 456 | pf2_3@117@01]
(assert pf2_3@117@01)
; [eval] !(getCardId(o1_1) == getCardId(o2_1))
; [eval] getCardId(o1_1) == getCardId(o2_1)
; [eval] getCardId(o1_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
; [eval] getCardId(o2_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf2_4@133@01 Bool)
(assert (=
  pf2_4@133@01
  (and
    pf2_3@117@01
    (not (= (getCardId $Snap.unit o1_1@17@01) (getCardId $Snap.unit o2_1@20@01))))))
; [exec]
; pt0_5 := pt0_4 && cardType(o1) > cardType(o2)
; [eval] pt0_4 && cardType(o1) > cardType(o2)
; [exec]
; pt1_5 := pt1_4 && cardType(o1_0) > cardType(o2_0)
; [eval] pt1_4 && cardType(o1_0) > cardType(o2_0)
(push) ; 27
; [then-branch: 457 | !(pt1_4@130@01) | live]
; [else-branch: 457 | pt1_4@130@01 | live]
(push) ; 28
; [then-branch: 457 | !(pt1_4@130@01)]
(assert (not pt1_4@130@01))
(pop) ; 28
(push) ; 28
; [else-branch: 457 | pt1_4@130@01]
(assert pt1_4@130@01)
; [eval] cardType(o1_0) > cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt1_4@130@01
  (and
    pt1_4@130@01
    (cardType%precondition $Snap.unit o1_0@16@01)
    (cardType%precondition $Snap.unit o2_0@19@01))))
(assert (or pt1_4@130@01 (not pt1_4@130@01)))
(declare-const pt1_5@134@01 Bool)
(assert (=
  pt1_5@134@01
  (and
    pt1_4@130@01
    (> (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_5 := pt2_4 && cardType(o1_1) > cardType(o2_1)
; [eval] pt2_4 && cardType(o1_1) > cardType(o2_1)
(push) ; 27
; [then-branch: 458 | !(pt2_4@131@01) | live]
; [else-branch: 458 | pt2_4@131@01 | live]
(push) ; 28
; [then-branch: 458 | !(pt2_4@131@01)]
(assert (not pt2_4@131@01))
(pop) ; 28
(push) ; 28
; [else-branch: 458 | pt2_4@131@01]
(assert pt2_4@131@01)
; [eval] cardType(o1_1) > cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt2_4@131@01
  (and
    pt2_4@131@01
    (cardType%precondition $Snap.unit o1_1@17@01)
    (cardType%precondition $Snap.unit o2_1@20@01))))
(assert (or pt2_4@131@01 (not pt2_4@131@01)))
(declare-const pt2_5@135@01 Bool)
(assert (=
  pt2_5@135@01
  (and
    pt2_4@131@01
    (> (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_5 := pt0_4 && !(cardType(o1) > cardType(o2))
; [eval] pt0_4 && !(cardType(o1) > cardType(o2))
; [exec]
; pf1_5 := pt1_4 && !(cardType(o1_0) > cardType(o2_0))
; [eval] pt1_4 && !(cardType(o1_0) > cardType(o2_0))
(push) ; 27
; [then-branch: 459 | !(pt1_4@130@01) | live]
; [else-branch: 459 | pt1_4@130@01 | live]
(push) ; 28
; [then-branch: 459 | !(pt1_4@130@01)]
(assert (not pt1_4@130@01))
(pop) ; 28
(push) ; 28
; [else-branch: 459 | pt1_4@130@01]
(assert pt1_4@130@01)
; [eval] !(cardType(o1_0) > cardType(o2_0))
; [eval] cardType(o1_0) > cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf1_5@136@01 Bool)
(assert (=
  pf1_5@136@01
  (and
    pt1_4@130@01
    (not (> (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_5 := pt2_4 && !(cardType(o1_1) > cardType(o2_1))
; [eval] pt2_4 && !(cardType(o1_1) > cardType(o2_1))
(push) ; 27
; [then-branch: 460 | !(pt2_4@131@01) | live]
; [else-branch: 460 | pt2_4@131@01 | live]
(push) ; 28
; [then-branch: 460 | !(pt2_4@131@01)]
(assert (not pt2_4@131@01))
(pop) ; 28
(push) ; 28
; [else-branch: 460 | pt2_4@131@01]
(assert pt2_4@131@01)
; [eval] !(cardType(o1_1) > cardType(o2_1))
; [eval] cardType(o1_1) > cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf2_5@137@01 Bool)
(assert (=
  pf2_5@137@01
  (and
    pt2_4@131@01
    (not (> (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01))))))
; [then-branch: 461 | False | dead]
; [else-branch: 461 | True | live]
(push) ; 27
; [else-branch: 461 | True]
(pop) ; 27
; [eval] !pt0_5
(push) ; 27
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 462 | True | live]
; [else-branch: 462 | False | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 462 | True]
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not pt1_5@134@01)))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 28
(set-option :rlimit 16000)
(assert (not pt1_5@134@01))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 463 | pt1_5@134@01 | live]
; [else-branch: 463 | !(pt1_5@134@01) | live]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 463 | pt1_5@134@01]
(assert pt1_5@134@01)
; [exec]
; res_0 := 1
(push) ; 29
(set-option :rlimit 16000)
(assert (not (not pt2_5@135@01)))
(check-sat)
; unknown
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 29
(set-option :rlimit 16000)
(assert (not pt2_5@135@01))
(check-sat)
; unsat
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 464 | pt2_5@135@01 | live]
; [else-branch: 464 | !(pt2_5@135@01) | dead]
(set-option :rlimit 0)
(push) ; 29
; [then-branch: 464 | pt2_5@135@01]
(assert pt2_5@135@01)
; [exec]
; res_1 := 1
; [then-branch: 465 | False | dead]
; [else-branch: 465 | True | live]
(push) ; 30
; [else-branch: 465 | True]
(pop) ; 30
; [eval] !pt0_5
(push) ; 30
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 30
; 0.00s
; (get-info :all-statistics)
; [then-branch: 466 | True | live]
; [else-branch: 466 | False | dead]
(set-option :rlimit 0)
(push) ; 30
; [then-branch: 466 | True]
(push) ; 31
(set-option :rlimit 16000)
(assert (not (not pt1_5@134@01)))
(check-sat)
; unknown
(pop) ; 31
; 0.00s
; (get-info :all-statistics)
; [then-branch: 467 | pt1_5@134@01 | live]
; [else-branch: 467 | !(pt1_5@134@01) | dead]
(set-option :rlimit 0)
(push) ; 31
; [then-branch: 467 | pt1_5@134@01]
; [exec]
; returned_0 := true
(push) ; 32
(set-option :rlimit 16000)
(assert (not (not pt2_5@135@01)))
(check-sat)
; unknown
(pop) ; 32
; 0.00s
; (get-info :all-statistics)
; [then-branch: 468 | pt2_5@135@01 | live]
; [else-branch: 468 | !(pt2_5@135@01) | dead]
(set-option :rlimit 0)
(push) ; 32
; [then-branch: 468 | pt2_5@135@01]
; [exec]
; returned_1 := true
; [exec]
; pt0_6 := pf0_5 && cardType(o1) == cardType(o2)
; [eval] pf0_5 && cardType(o1) == cardType(o2)
; [exec]
; pt1_6 := pf1_5 && cardType(o1_0) == cardType(o2_0)
; [eval] pf1_5 && cardType(o1_0) == cardType(o2_0)
(push) ; 33
; [then-branch: 469 | !(pf1_5@136@01) | live]
; [else-branch: 469 | pf1_5@136@01 | live]
(push) ; 34
; [then-branch: 469 | !(pf1_5@136@01)]
(assert (not pf1_5@136@01))
(pop) ; 34
(push) ; 34
; [else-branch: 469 | pf1_5@136@01]
(assert pf1_5@136@01)
; [eval] cardType(o1_0) == cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_5@136@01
  (and
    pf1_5@136@01
    (cardType%precondition $Snap.unit o1_0@16@01)
    (cardType%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_5@136@01 (not pf1_5@136@01)))
(declare-const pt1_6@138@01 Bool)
(assert (=
  pt1_6@138@01
  (and
    pf1_5@136@01
    (= (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_6 := pf2_5 && cardType(o1_1) == cardType(o2_1)
; [eval] pf2_5 && cardType(o1_1) == cardType(o2_1)
(push) ; 33
; [then-branch: 470 | !(pf2_5@137@01) | live]
; [else-branch: 470 | pf2_5@137@01 | live]
(push) ; 34
; [then-branch: 470 | !(pf2_5@137@01)]
(assert (not pf2_5@137@01))
(pop) ; 34
(push) ; 34
; [else-branch: 470 | pf2_5@137@01]
(assert pf2_5@137@01)
; [eval] cardType(o1_1) == cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_5@137@01
  (and
    pf2_5@137@01
    (cardType%precondition $Snap.unit o1_1@17@01)
    (cardType%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_5@137@01 (not pf2_5@137@01)))
(declare-const pt2_6@139@01 Bool)
(assert (=
  pt2_6@139@01
  (and
    pf2_5@137@01
    (= (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_6 := pf0_5 && !(cardType(o1) == cardType(o2))
; [eval] pf0_5 && !(cardType(o1) == cardType(o2))
; [exec]
; pf1_6 := pf1_5 && !(cardType(o1_0) == cardType(o2_0))
; [eval] pf1_5 && !(cardType(o1_0) == cardType(o2_0))
(push) ; 33
; [then-branch: 471 | !(pf1_5@136@01) | live]
; [else-branch: 471 | pf1_5@136@01 | live]
(push) ; 34
; [then-branch: 471 | !(pf1_5@136@01)]
(assert (not pf1_5@136@01))
(pop) ; 34
(push) ; 34
; [else-branch: 471 | pf1_5@136@01]
(assert pf1_5@136@01)
; [eval] !(cardType(o1_0) == cardType(o2_0))
; [eval] cardType(o1_0) == cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf1_6@140@01 Bool)
(assert (=
  pf1_6@140@01
  (and
    pf1_5@136@01
    (not (= (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_6 := pf2_5 && !(cardType(o1_1) == cardType(o2_1))
; [eval] pf2_5 && !(cardType(o1_1) == cardType(o2_1))
(push) ; 33
; [then-branch: 472 | !(pf2_5@137@01) | live]
; [else-branch: 472 | pf2_5@137@01 | live]
(push) ; 34
; [then-branch: 472 | !(pf2_5@137@01)]
(assert (not pf2_5@137@01))
(pop) ; 34
(push) ; 34
; [else-branch: 472 | pf2_5@137@01]
(assert pf2_5@137@01)
; [eval] !(cardType(o1_1) == cardType(o2_1))
; [eval] cardType(o1_1) == cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf2_6@141@01 Bool)
(assert (=
  pf2_6@141@01
  (and
    pf2_5@137@01
    (not (= (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01))))))
; [then-branch: 473 | False | dead]
; [else-branch: 473 | True | live]
(push) ; 33
; [else-branch: 473 | True]
(pop) ; 33
; [eval] !pt0_6
(push) ; 33
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 474 | True | live]
; [else-branch: 474 | False | dead]
(set-option :rlimit 0)
(push) ; 33
; [then-branch: 474 | True]
(push) ; 34
(set-option :rlimit 16000)
(assert (not (not pt1_6@138@01)))
(check-sat)
; unsat
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 475 | pt1_6@138@01 | dead]
; [else-branch: 475 | !(pt1_6@138@01) | live]
(set-option :rlimit 0)
(push) ; 34
; [else-branch: 475 | !(pt1_6@138@01)]
(assert (not pt1_6@138@01))
(pop) ; 34
; [eval] !pt1_6
(push) ; 34
(set-option :rlimit 16000)
(assert (not pt1_6@138@01))
(check-sat)
; unknown
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 34
(set-option :rlimit 16000)
(assert (not (not pt1_6@138@01)))
(check-sat)
; unsat
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 476 | !(pt1_6@138@01) | live]
; [else-branch: 476 | pt1_6@138@01 | dead]
(set-option :rlimit 0)
(push) ; 34
; [then-branch: 476 | !(pt1_6@138@01)]
(assert (not pt1_6@138@01))
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@139@01)))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 477 | pt2_6@139@01 | dead]
; [else-branch: 477 | !(pt2_6@139@01) | live]
(set-option :rlimit 0)
(push) ; 35
; [else-branch: 477 | !(pt2_6@139@01)]
(assert (not pt2_6@139@01))
(pop) ; 35
; [eval] !pt2_6
(push) ; 35
(set-option :rlimit 16000)
(assert (not pt2_6@139@01))
(check-sat)
; unknown
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@139@01)))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 478 | !(pt2_6@139@01) | live]
; [else-branch: 478 | pt2_6@139@01 | dead]
(set-option :rlimit 0)
(push) ; 35
; [then-branch: 478 | !(pt2_6@139@01)]
(assert (not pt2_6@139@01))
; [then-branch: 479 | False | dead]
; [else-branch: 479 | True | live]
(push) ; 36
; [else-branch: 479 | True]
(pop) ; 36
; [eval] !pt0_6
(push) ; 36
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 36
; 0.00s
; (get-info :all-statistics)
; [then-branch: 480 | True | live]
; [else-branch: 480 | False | dead]
(set-option :rlimit 0)
(push) ; 36
; [then-branch: 480 | True]
; [then-branch: 481 | pt1_6@138@01 | dead]
; [else-branch: 481 | !(pt1_6@138@01) | live]
(push) ; 37
; [else-branch: 481 | !(pt1_6@138@01)]
(pop) ; 37
; [eval] !pt1_6
(push) ; 37
(set-option :rlimit 16000)
(assert (not pt1_6@138@01))
(check-sat)
; unknown
(pop) ; 37
; 0.00s
; (get-info :all-statistics)
; [then-branch: 482 | !(pt1_6@138@01) | live]
; [else-branch: 482 | pt1_6@138@01 | dead]
(set-option :rlimit 0)
(push) ; 37
; [then-branch: 482 | !(pt1_6@138@01)]
; [then-branch: 483 | pt2_6@139@01 | dead]
; [else-branch: 483 | !(pt2_6@139@01) | live]
(push) ; 38
; [else-branch: 483 | !(pt2_6@139@01)]
(pop) ; 38
; [eval] !pt2_6
(push) ; 38
(set-option :rlimit 16000)
(assert (not pt2_6@139@01))
(check-sat)
; unknown
(pop) ; 38
; 0.00s
; (get-info :all-statistics)
; [then-branch: 484 | !(pt2_6@139@01) | live]
; [else-branch: 484 | pt2_6@139@01 | dead]
(set-option :rlimit 0)
(push) ; 38
; [then-branch: 484 | !(pt2_6@139@01)]
; [then-branch: 485 | False | dead]
; [else-branch: 485 | True | live]
(push) ; 39
; [else-branch: 485 | True]
(pop) ; 39
; [eval] !pf0_6
(push) ; 39
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 486 | True | live]
; [else-branch: 486 | False | dead]
(set-option :rlimit 0)
(push) ; 39
; [then-branch: 486 | True]
(push) ; 40
(set-option :rlimit 16000)
(assert (not (not pf1_6@140@01)))
(check-sat)
; unsat
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 487 | pf1_6@140@01 | dead]
; [else-branch: 487 | !(pf1_6@140@01) | live]
(set-option :rlimit 0)
(push) ; 40
; [else-branch: 487 | !(pf1_6@140@01)]
(assert (not pf1_6@140@01))
(pop) ; 40
; [eval] !pf1_6
(push) ; 40
(set-option :rlimit 16000)
(assert (not pf1_6@140@01))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 40
(set-option :rlimit 16000)
(assert (not (not pf1_6@140@01)))
(check-sat)
; unsat
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 488 | !(pf1_6@140@01) | live]
; [else-branch: 488 | pf1_6@140@01 | dead]
(set-option :rlimit 0)
(push) ; 40
; [then-branch: 488 | !(pf1_6@140@01)]
(assert (not pf1_6@140@01))
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@141@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 489 | pf2_6@141@01 | dead]
; [else-branch: 489 | !(pf2_6@141@01) | live]
(set-option :rlimit 0)
(push) ; 41
; [else-branch: 489 | !(pf2_6@141@01)]
(assert (not pf2_6@141@01))
(pop) ; 41
; [eval] !pf2_6
(push) ; 41
(set-option :rlimit 16000)
(assert (not pf2_6@141@01))
(check-sat)
; unknown
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@141@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 490 | !(pf2_6@141@01) | live]
; [else-branch: 490 | pf2_6@141@01 | dead]
(set-option :rlimit 0)
(push) ; 41
; [then-branch: 490 | !(pf2_6@141@01)]
(assert (not pf2_6@141@01))
; [then-branch: 491 | False | dead]
; [else-branch: 491 | True | live]
(push) ; 42
; [else-branch: 491 | True]
(pop) ; 42
; [eval] !pf0_6
(push) ; 42
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 42
; 0.00s
; (get-info :all-statistics)
; [then-branch: 492 | True | live]
; [else-branch: 492 | False | dead]
(set-option :rlimit 0)
(push) ; 42
; [then-branch: 492 | True]
; [then-branch: 493 | pf1_6@140@01 | dead]
; [else-branch: 493 | !(pf1_6@140@01) | live]
(push) ; 43
; [else-branch: 493 | !(pf1_6@140@01)]
(pop) ; 43
; [eval] !pf1_6
(push) ; 43
(set-option :rlimit 16000)
(assert (not pf1_6@140@01))
(check-sat)
; unknown
(pop) ; 43
; 0.00s
; (get-info :all-statistics)
; [then-branch: 494 | !(pf1_6@140@01) | live]
; [else-branch: 494 | pf1_6@140@01 | dead]
(set-option :rlimit 0)
(push) ; 43
; [then-branch: 494 | !(pf1_6@140@01)]
; [then-branch: 495 | pf2_6@141@01 | dead]
; [else-branch: 495 | !(pf2_6@141@01) | live]
(push) ; 44
; [else-branch: 495 | !(pf2_6@141@01)]
(pop) ; 44
; [eval] !pf2_6
(push) ; 44
(set-option :rlimit 16000)
(assert (not pf2_6@141@01))
(check-sat)
; unknown
(pop) ; 44
; 0.00s
; (get-info :all-statistics)
; [then-branch: 496 | !(pf2_6@141@01) | live]
; [else-branch: 496 | pf2_6@141@01 | dead]
(set-option :rlimit 0)
(push) ; 44
; [then-branch: 496 | !(pf2_6@141@01)]
; [then-branch: 497 | False | dead]
; [else-branch: 497 | True | live]
(push) ; 45
; [else-branch: 497 | True]
(pop) ; 45
; [eval] !pf0_4
(push) ; 45
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 498 | True | live]
; [else-branch: 498 | False | dead]
(set-option :rlimit 0)
(push) ; 45
; [then-branch: 498 | True]
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@132@01)))
(check-sat)
; unsat
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 499 | pf1_4@132@01 | dead]
; [else-branch: 499 | !(pf1_4@132@01) | live]
(set-option :rlimit 0)
(push) ; 46
; [else-branch: 499 | !(pf1_4@132@01)]
(assert (not pf1_4@132@01))
(pop) ; 46
; [eval] !pf1_4
(push) ; 46
(set-option :rlimit 16000)
(assert (not pf1_4@132@01))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@132@01)))
(check-sat)
; unsat
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 500 | !(pf1_4@132@01) | live]
; [else-branch: 500 | pf1_4@132@01 | dead]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 500 | !(pf1_4@132@01)]
(assert (not pf1_4@132@01))
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@133@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 501 | pf2_4@133@01 | dead]
; [else-branch: 501 | !(pf2_4@133@01) | live]
(set-option :rlimit 0)
(push) ; 47
; [else-branch: 501 | !(pf2_4@133@01)]
(assert (not pf2_4@133@01))
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not pf2_4@133@01))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@133@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 502 | !(pf2_4@133@01) | live]
; [else-branch: 502 | pf2_4@133@01 | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 502 | !(pf2_4@133@01)]
(assert (not pf2_4@133@01))
; [then-branch: 503 | False | dead]
; [else-branch: 503 | True | live]
(push) ; 48
; [else-branch: 503 | True]
(pop) ; 48
; [eval] !pf0_4
(push) ; 48
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 504 | True | live]
; [else-branch: 504 | False | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 504 | True]
; [then-branch: 505 | pf1_4@132@01 | dead]
; [else-branch: 505 | !(pf1_4@132@01) | live]
(push) ; 49
; [else-branch: 505 | !(pf1_4@132@01)]
(pop) ; 49
; [eval] !pf1_4
(push) ; 49
(set-option :rlimit 16000)
(assert (not pf1_4@132@01))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 506 | !(pf1_4@132@01) | live]
; [else-branch: 506 | pf1_4@132@01 | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 506 | !(pf1_4@132@01)]
; [then-branch: 507 | pf2_4@133@01 | dead]
; [else-branch: 507 | !(pf2_4@133@01) | live]
(push) ; 50
; [else-branch: 507 | !(pf2_4@133@01)]
(pop) ; 50
; [eval] !pf2_4
(push) ; 50
(set-option :rlimit 16000)
(assert (not pf2_4@133@01))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 508 | !(pf2_4@133@01) | live]
; [else-branch: 508 | pf2_4@133@01 | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 508 | !(pf2_4@133@01)]
; [then-branch: 509 | False | dead]
; [else-branch: 509 | True | live]
(push) ; 51
; [else-branch: 509 | True]
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 510 | True | live]
; [else-branch: 510 | False | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 510 | True]
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@112@01)))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 511 | pf1_2@112@01 | dead]
; [else-branch: 511 | !(pf1_2@112@01) | live]
(set-option :rlimit 0)
(push) ; 52
; [else-branch: 511 | !(pf1_2@112@01)]
(assert (not pf1_2@112@01))
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not pf1_2@112@01))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@112@01)))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 512 | !(pf1_2@112@01) | live]
; [else-branch: 512 | pf1_2@112@01 | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 512 | !(pf1_2@112@01)]
(assert (not pf1_2@112@01))
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@113@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 513 | pf2_2@113@01 | dead]
; [else-branch: 513 | !(pf2_2@113@01) | live]
(set-option :rlimit 0)
(push) ; 53
; [else-branch: 513 | !(pf2_2@113@01)]
(assert (not pf2_2@113@01))
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not pf2_2@113@01))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@113@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 514 | !(pf2_2@113@01) | live]
; [else-branch: 514 | pf2_2@113@01 | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 514 | !(pf2_2@113@01)]
(assert (not pf2_2@113@01))
; [then-branch: 515 | False | dead]
; [else-branch: 515 | True | live]
(push) ; 54
; [else-branch: 515 | True]
(pop) ; 54
; [eval] !pf0_2
(push) ; 54
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 516 | True | live]
; [else-branch: 516 | False | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 516 | True]
; [then-branch: 517 | pf1_2@112@01 | dead]
; [else-branch: 517 | !(pf1_2@112@01) | live]
(push) ; 55
; [else-branch: 517 | !(pf1_2@112@01)]
(pop) ; 55
; [eval] !pf1_2
(push) ; 55
(set-option :rlimit 16000)
(assert (not pf1_2@112@01))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 518 | !(pf1_2@112@01) | live]
; [else-branch: 518 | pf1_2@112@01 | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 518 | !(pf1_2@112@01)]
; [then-branch: 519 | pf2_2@113@01 | dead]
; [else-branch: 519 | !(pf2_2@113@01) | live]
(push) ; 56
; [else-branch: 519 | !(pf2_2@113@01)]
(pop) ; 56
; [eval] !pf2_2
(push) ; 56
(set-option :rlimit 16000)
(assert (not pf2_2@113@01))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 520 | !(pf2_2@113@01) | live]
; [else-branch: 520 | pf2_2@113@01 | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 520 | !(pf2_2@113@01)]
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 521 | p0@12@01 | live]
; [else-branch: 521 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 521 | p0@12@01]
(assert p0@12@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 522 | p1@13@01 | live]
; [else-branch: 522 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 522 | p1@13@01]
(assert p1@13@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p1@13@01)
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 523 | p2@14@01 | live]
; [else-branch: 523 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 523 | p2@14@01]
(assert p2@14@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p2@14@01)
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 524 | p0@12@01 | live]
; [else-branch: 524 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 524 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 525 | False | live]
; [else-branch: 525 | True | live]
(push) ; 60
; [then-branch: 525 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 525 | True]
(push) ; 61
; [then-branch: 526 | !(p0@12@01) | live]
; [else-branch: 526 | p0@12@01 | live]
(push) ; 62
; [then-branch: 526 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 526 | p0@12@01]
(push) ; 63
; [then-branch: 527 | !(p1@13@01) | live]
; [else-branch: 527 | p1@13@01 | live]
(push) ; 64
; [then-branch: 527 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 527 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 528 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 528 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 528 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 529 | False | dead]
; [else-branch: 529 | True | live]
(push) ; 62
; [else-branch: 529 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 530 | p1@13@01 | live]
; [else-branch: 530 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 530 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 531 | False | live]
; [else-branch: 531 | True | live]
(push) ; 60
; [then-branch: 531 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 531 | True]
(push) ; 61
; [then-branch: 532 | !(p0@12@01) | live]
; [else-branch: 532 | p0@12@01 | live]
(push) ; 62
; [then-branch: 532 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 532 | p0@12@01]
(push) ; 63
; [then-branch: 533 | !(p1@13@01) | live]
; [else-branch: 533 | p1@13@01 | live]
(push) ; 64
; [then-branch: 533 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 533 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 534 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 534 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 534 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 535 | False | dead]
; [else-branch: 535 | True | live]
(push) ; 62
; [else-branch: 535 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p2@14@01)))
(assert p1@13@01)
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 536 | p2@14@01 | live]
; [else-branch: 536 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 536 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 537 | False | live]
; [else-branch: 537 | True | live]
(push) ; 60
; [then-branch: 537 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 537 | True]
(push) ; 61
; [then-branch: 538 | !(p0@12@01) | live]
; [else-branch: 538 | p0@12@01 | live]
(push) ; 62
; [then-branch: 538 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 538 | p0@12@01]
(assert p0@12@01)
(push) ; 63
; [then-branch: 539 | !(p1@13@01) | live]
; [else-branch: 539 | p1@13@01 | live]
(push) ; 64
; [then-branch: 539 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 539 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 540 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 540 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 540 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 541 | False | dead]
; [else-branch: 541 | True | live]
(push) ; 62
; [else-branch: 541 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01)))
(assert p2@14@01)
(pop) ; 56
(pop) ; 55
(pop) ; 54
(pop) ; 53
(pop) ; 52
(pop) ; 51
(pop) ; 50
(pop) ; 49
(pop) ; 48
(pop) ; 47
(pop) ; 46
(pop) ; 45
(pop) ; 44
(pop) ; 43
(pop) ; 42
(pop) ; 41
(pop) ; 40
(pop) ; 39
(pop) ; 38
(pop) ; 37
(pop) ; 36
(pop) ; 35
(pop) ; 34
(pop) ; 33
(pop) ; 32
; [eval] !pt2_5
; [then-branch: 542 | !(pt2_5@135@01) | dead]
; [else-branch: 542 | pt2_5@135@01 | live]
(push) ; 32
; [else-branch: 542 | pt2_5@135@01]
(pop) ; 32
(pop) ; 31
; [eval] !pt1_5
; [then-branch: 543 | !(pt1_5@134@01) | dead]
; [else-branch: 543 | pt1_5@134@01 | live]
(push) ; 31
; [else-branch: 543 | pt1_5@134@01]
(pop) ; 31
(pop) ; 30
(pop) ; 29
; [eval] !pt2_5
(push) ; 29
(set-option :rlimit 16000)
(assert (not pt2_5@135@01))
(check-sat)
; unsat
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 544 | !(pt2_5@135@01) | dead]
; [else-branch: 544 | pt2_5@135@01 | live]
(set-option :rlimit 0)
(push) ; 29
; [else-branch: 544 | pt2_5@135@01]
(assert pt2_5@135@01)
(pop) ; 29
(pop) ; 28
(push) ; 28
; [else-branch: 463 | !(pt1_5@134@01)]
(assert (not pt1_5@134@01))
(pop) ; 28
; [eval] !pt1_5
(push) ; 28
(set-option :rlimit 16000)
(assert (not pt1_5@134@01))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not pt1_5@134@01)))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 545 | !(pt1_5@134@01) | live]
; [else-branch: 545 | pt1_5@134@01 | live]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 545 | !(pt1_5@134@01)]
(assert (not pt1_5@134@01))
(push) ; 29
(set-option :rlimit 16000)
(assert (not (not pt2_5@135@01)))
(check-sat)
; unsat
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 546 | pt2_5@135@01 | dead]
; [else-branch: 546 | !(pt2_5@135@01) | live]
(set-option :rlimit 0)
(push) ; 29
; [else-branch: 546 | !(pt2_5@135@01)]
(assert (not pt2_5@135@01))
(pop) ; 29
; [eval] !pt2_5
(push) ; 29
(set-option :rlimit 16000)
(assert (not pt2_5@135@01))
(check-sat)
; unknown
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 29
(set-option :rlimit 16000)
(assert (not (not pt2_5@135@01)))
(check-sat)
; unsat
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 547 | !(pt2_5@135@01) | live]
; [else-branch: 547 | pt2_5@135@01 | dead]
(set-option :rlimit 0)
(push) ; 29
; [then-branch: 547 | !(pt2_5@135@01)]
(assert (not pt2_5@135@01))
; [then-branch: 548 | False | dead]
; [else-branch: 548 | True | live]
(push) ; 30
; [else-branch: 548 | True]
(pop) ; 30
; [eval] !pt0_5
(push) ; 30
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 30
; 0.00s
; (get-info :all-statistics)
; [then-branch: 549 | True | live]
; [else-branch: 549 | False | dead]
(set-option :rlimit 0)
(push) ; 30
; [then-branch: 549 | True]
; [then-branch: 550 | pt1_5@134@01 | dead]
; [else-branch: 550 | !(pt1_5@134@01) | live]
(push) ; 31
; [else-branch: 550 | !(pt1_5@134@01)]
(pop) ; 31
; [eval] !pt1_5
(push) ; 31
(set-option :rlimit 16000)
(assert (not pt1_5@134@01))
(check-sat)
; unknown
(pop) ; 31
; 0.00s
; (get-info :all-statistics)
; [then-branch: 551 | !(pt1_5@134@01) | live]
; [else-branch: 551 | pt1_5@134@01 | dead]
(set-option :rlimit 0)
(push) ; 31
; [then-branch: 551 | !(pt1_5@134@01)]
; [then-branch: 552 | pt2_5@135@01 | dead]
; [else-branch: 552 | !(pt2_5@135@01) | live]
(push) ; 32
; [else-branch: 552 | !(pt2_5@135@01)]
(pop) ; 32
; [eval] !pt2_5
(push) ; 32
(set-option :rlimit 16000)
(assert (not pt2_5@135@01))
(check-sat)
; unknown
(pop) ; 32
; 0.00s
; (get-info :all-statistics)
; [then-branch: 553 | !(pt2_5@135@01) | live]
; [else-branch: 553 | pt2_5@135@01 | dead]
(set-option :rlimit 0)
(push) ; 32
; [then-branch: 553 | !(pt2_5@135@01)]
; [exec]
; pt0_6 := pf0_5 && cardType(o1) == cardType(o2)
; [eval] pf0_5 && cardType(o1) == cardType(o2)
; [exec]
; pt1_6 := pf1_5 && cardType(o1_0) == cardType(o2_0)
; [eval] pf1_5 && cardType(o1_0) == cardType(o2_0)
(push) ; 33
; [then-branch: 554 | !(pf1_5@136@01) | live]
; [else-branch: 554 | pf1_5@136@01 | live]
(push) ; 34
; [then-branch: 554 | !(pf1_5@136@01)]
(assert (not pf1_5@136@01))
(pop) ; 34
(push) ; 34
; [else-branch: 554 | pf1_5@136@01]
(assert pf1_5@136@01)
; [eval] cardType(o1_0) == cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_5@136@01
  (and
    pf1_5@136@01
    (cardType%precondition $Snap.unit o1_0@16@01)
    (cardType%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_5@136@01 (not pf1_5@136@01)))
(declare-const pt1_6@142@01 Bool)
(assert (=
  pt1_6@142@01
  (and
    pf1_5@136@01
    (= (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_6 := pf2_5 && cardType(o1_1) == cardType(o2_1)
; [eval] pf2_5 && cardType(o1_1) == cardType(o2_1)
(push) ; 33
; [then-branch: 555 | !(pf2_5@137@01) | live]
; [else-branch: 555 | pf2_5@137@01 | live]
(push) ; 34
; [then-branch: 555 | !(pf2_5@137@01)]
(assert (not pf2_5@137@01))
(pop) ; 34
(push) ; 34
; [else-branch: 555 | pf2_5@137@01]
(assert pf2_5@137@01)
; [eval] cardType(o1_1) == cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_5@137@01
  (and
    pf2_5@137@01
    (cardType%precondition $Snap.unit o1_1@17@01)
    (cardType%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_5@137@01 (not pf2_5@137@01)))
(declare-const pt2_6@143@01 Bool)
(assert (=
  pt2_6@143@01
  (and
    pf2_5@137@01
    (= (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_6 := pf0_5 && !(cardType(o1) == cardType(o2))
; [eval] pf0_5 && !(cardType(o1) == cardType(o2))
; [exec]
; pf1_6 := pf1_5 && !(cardType(o1_0) == cardType(o2_0))
; [eval] pf1_5 && !(cardType(o1_0) == cardType(o2_0))
(push) ; 33
; [then-branch: 556 | !(pf1_5@136@01) | live]
; [else-branch: 556 | pf1_5@136@01 | live]
(push) ; 34
; [then-branch: 556 | !(pf1_5@136@01)]
(assert (not pf1_5@136@01))
(pop) ; 34
(push) ; 34
; [else-branch: 556 | pf1_5@136@01]
(assert pf1_5@136@01)
; [eval] !(cardType(o1_0) == cardType(o2_0))
; [eval] cardType(o1_0) == cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf1_6@144@01 Bool)
(assert (=
  pf1_6@144@01
  (and
    pf1_5@136@01
    (not (= (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_6 := pf2_5 && !(cardType(o1_1) == cardType(o2_1))
; [eval] pf2_5 && !(cardType(o1_1) == cardType(o2_1))
(push) ; 33
; [then-branch: 557 | !(pf2_5@137@01) | live]
; [else-branch: 557 | pf2_5@137@01 | live]
(push) ; 34
; [then-branch: 557 | !(pf2_5@137@01)]
(assert (not pf2_5@137@01))
(pop) ; 34
(push) ; 34
; [else-branch: 557 | pf2_5@137@01]
(assert pf2_5@137@01)
; [eval] !(cardType(o1_1) == cardType(o2_1))
; [eval] cardType(o1_1) == cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf2_6@145@01 Bool)
(assert (=
  pf2_6@145@01
  (and
    pf2_5@137@01
    (not (= (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01))))))
; [then-branch: 558 | False | dead]
; [else-branch: 558 | True | live]
(push) ; 33
; [else-branch: 558 | True]
(pop) ; 33
; [eval] !pt0_6
(push) ; 33
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 559 | True | live]
; [else-branch: 559 | False | dead]
(set-option :rlimit 0)
(push) ; 33
; [then-branch: 559 | True]
(push) ; 34
(set-option :rlimit 16000)
(assert (not (not pt1_6@142@01)))
(check-sat)
; unknown
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 34
(set-option :rlimit 16000)
(assert (not pt1_6@142@01))
(check-sat)
; unknown
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 560 | pt1_6@142@01 | live]
; [else-branch: 560 | !(pt1_6@142@01) | live]
(set-option :rlimit 0)
(push) ; 34
; [then-branch: 560 | pt1_6@142@01]
(assert pt1_6@142@01)
; [exec]
; res_0 := 0
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@143@01)))
(check-sat)
; unknown
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 35
(set-option :rlimit 16000)
(assert (not pt2_6@143@01))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 561 | pt2_6@143@01 | live]
; [else-branch: 561 | !(pt2_6@143@01) | dead]
(set-option :rlimit 0)
(push) ; 35
; [then-branch: 561 | pt2_6@143@01]
(assert pt2_6@143@01)
; [exec]
; res_1 := 0
; [then-branch: 562 | False | dead]
; [else-branch: 562 | True | live]
(push) ; 36
; [else-branch: 562 | True]
(pop) ; 36
; [eval] !pt0_6
(push) ; 36
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 36
; 0.00s
; (get-info :all-statistics)
; [then-branch: 563 | True | live]
; [else-branch: 563 | False | dead]
(set-option :rlimit 0)
(push) ; 36
; [then-branch: 563 | True]
(push) ; 37
(set-option :rlimit 16000)
(assert (not (not pt1_6@142@01)))
(check-sat)
; unknown
(pop) ; 37
; 0.00s
; (get-info :all-statistics)
; [then-branch: 564 | pt1_6@142@01 | live]
; [else-branch: 564 | !(pt1_6@142@01) | dead]
(set-option :rlimit 0)
(push) ; 37
; [then-branch: 564 | pt1_6@142@01]
; [exec]
; returned_0 := true
(push) ; 38
(set-option :rlimit 16000)
(assert (not (not pt2_6@143@01)))
(check-sat)
; unknown
(pop) ; 38
; 0.00s
; (get-info :all-statistics)
; [then-branch: 565 | pt2_6@143@01 | live]
; [else-branch: 565 | !(pt2_6@143@01) | dead]
(set-option :rlimit 0)
(push) ; 38
; [then-branch: 565 | pt2_6@143@01]
; [exec]
; returned_1 := true
; [then-branch: 566 | False | dead]
; [else-branch: 566 | True | live]
(push) ; 39
; [else-branch: 566 | True]
(pop) ; 39
; [eval] !pf0_6
(push) ; 39
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 567 | True | live]
; [else-branch: 567 | False | dead]
(set-option :rlimit 0)
(push) ; 39
; [then-branch: 567 | True]
(push) ; 40
(set-option :rlimit 16000)
(assert (not (not pf1_6@144@01)))
(check-sat)
; unsat
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 568 | pf1_6@144@01 | dead]
; [else-branch: 568 | !(pf1_6@144@01) | live]
(set-option :rlimit 0)
(push) ; 40
; [else-branch: 568 | !(pf1_6@144@01)]
(assert (not pf1_6@144@01))
(pop) ; 40
; [eval] !pf1_6
(push) ; 40
(set-option :rlimit 16000)
(assert (not pf1_6@144@01))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 40
(set-option :rlimit 16000)
(assert (not (not pf1_6@144@01)))
(check-sat)
; unsat
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 569 | !(pf1_6@144@01) | live]
; [else-branch: 569 | pf1_6@144@01 | dead]
(set-option :rlimit 0)
(push) ; 40
; [then-branch: 569 | !(pf1_6@144@01)]
(assert (not pf1_6@144@01))
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@145@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 570 | pf2_6@145@01 | dead]
; [else-branch: 570 | !(pf2_6@145@01) | live]
(set-option :rlimit 0)
(push) ; 41
; [else-branch: 570 | !(pf2_6@145@01)]
(assert (not pf2_6@145@01))
(pop) ; 41
; [eval] !pf2_6
(push) ; 41
(set-option :rlimit 16000)
(assert (not pf2_6@145@01))
(check-sat)
; unknown
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@145@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 571 | !(pf2_6@145@01) | live]
; [else-branch: 571 | pf2_6@145@01 | dead]
(set-option :rlimit 0)
(push) ; 41
; [then-branch: 571 | !(pf2_6@145@01)]
(assert (not pf2_6@145@01))
; [then-branch: 572 | False | dead]
; [else-branch: 572 | True | live]
(push) ; 42
; [else-branch: 572 | True]
(pop) ; 42
; [eval] !pf0_6
(push) ; 42
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 42
; 0.00s
; (get-info :all-statistics)
; [then-branch: 573 | True | live]
; [else-branch: 573 | False | dead]
(set-option :rlimit 0)
(push) ; 42
; [then-branch: 573 | True]
; [then-branch: 574 | pf1_6@144@01 | dead]
; [else-branch: 574 | !(pf1_6@144@01) | live]
(push) ; 43
; [else-branch: 574 | !(pf1_6@144@01)]
(pop) ; 43
; [eval] !pf1_6
(push) ; 43
(set-option :rlimit 16000)
(assert (not pf1_6@144@01))
(check-sat)
; unknown
(pop) ; 43
; 0.00s
; (get-info :all-statistics)
; [then-branch: 575 | !(pf1_6@144@01) | live]
; [else-branch: 575 | pf1_6@144@01 | dead]
(set-option :rlimit 0)
(push) ; 43
; [then-branch: 575 | !(pf1_6@144@01)]
; [then-branch: 576 | pf2_6@145@01 | dead]
; [else-branch: 576 | !(pf2_6@145@01) | live]
(push) ; 44
; [else-branch: 576 | !(pf2_6@145@01)]
(pop) ; 44
; [eval] !pf2_6
(push) ; 44
(set-option :rlimit 16000)
(assert (not pf2_6@145@01))
(check-sat)
; unknown
(pop) ; 44
; 0.00s
; (get-info :all-statistics)
; [then-branch: 577 | !(pf2_6@145@01) | live]
; [else-branch: 577 | pf2_6@145@01 | dead]
(set-option :rlimit 0)
(push) ; 44
; [then-branch: 577 | !(pf2_6@145@01)]
; [then-branch: 578 | False | dead]
; [else-branch: 578 | True | live]
(push) ; 45
; [else-branch: 578 | True]
(pop) ; 45
; [eval] !pf0_4
(push) ; 45
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 579 | True | live]
; [else-branch: 579 | False | dead]
(set-option :rlimit 0)
(push) ; 45
; [then-branch: 579 | True]
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@132@01)))
(check-sat)
; unsat
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 580 | pf1_4@132@01 | dead]
; [else-branch: 580 | !(pf1_4@132@01) | live]
(set-option :rlimit 0)
(push) ; 46
; [else-branch: 580 | !(pf1_4@132@01)]
(assert (not pf1_4@132@01))
(pop) ; 46
; [eval] !pf1_4
(push) ; 46
(set-option :rlimit 16000)
(assert (not pf1_4@132@01))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@132@01)))
(check-sat)
; unsat
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 581 | !(pf1_4@132@01) | live]
; [else-branch: 581 | pf1_4@132@01 | dead]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 581 | !(pf1_4@132@01)]
(assert (not pf1_4@132@01))
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@133@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 582 | pf2_4@133@01 | dead]
; [else-branch: 582 | !(pf2_4@133@01) | live]
(set-option :rlimit 0)
(push) ; 47
; [else-branch: 582 | !(pf2_4@133@01)]
(assert (not pf2_4@133@01))
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not pf2_4@133@01))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@133@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 583 | !(pf2_4@133@01) | live]
; [else-branch: 583 | pf2_4@133@01 | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 583 | !(pf2_4@133@01)]
(assert (not pf2_4@133@01))
; [then-branch: 584 | False | dead]
; [else-branch: 584 | True | live]
(push) ; 48
; [else-branch: 584 | True]
(pop) ; 48
; [eval] !pf0_4
(push) ; 48
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 585 | True | live]
; [else-branch: 585 | False | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 585 | True]
; [then-branch: 586 | pf1_4@132@01 | dead]
; [else-branch: 586 | !(pf1_4@132@01) | live]
(push) ; 49
; [else-branch: 586 | !(pf1_4@132@01)]
(pop) ; 49
; [eval] !pf1_4
(push) ; 49
(set-option :rlimit 16000)
(assert (not pf1_4@132@01))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 587 | !(pf1_4@132@01) | live]
; [else-branch: 587 | pf1_4@132@01 | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 587 | !(pf1_4@132@01)]
; [then-branch: 588 | pf2_4@133@01 | dead]
; [else-branch: 588 | !(pf2_4@133@01) | live]
(push) ; 50
; [else-branch: 588 | !(pf2_4@133@01)]
(pop) ; 50
; [eval] !pf2_4
(push) ; 50
(set-option :rlimit 16000)
(assert (not pf2_4@133@01))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 589 | !(pf2_4@133@01) | live]
; [else-branch: 589 | pf2_4@133@01 | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 589 | !(pf2_4@133@01)]
; [then-branch: 590 | False | dead]
; [else-branch: 590 | True | live]
(push) ; 51
; [else-branch: 590 | True]
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 591 | True | live]
; [else-branch: 591 | False | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 591 | True]
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@112@01)))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 592 | pf1_2@112@01 | dead]
; [else-branch: 592 | !(pf1_2@112@01) | live]
(set-option :rlimit 0)
(push) ; 52
; [else-branch: 592 | !(pf1_2@112@01)]
(assert (not pf1_2@112@01))
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not pf1_2@112@01))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@112@01)))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 593 | !(pf1_2@112@01) | live]
; [else-branch: 593 | pf1_2@112@01 | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 593 | !(pf1_2@112@01)]
(assert (not pf1_2@112@01))
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@113@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 594 | pf2_2@113@01 | dead]
; [else-branch: 594 | !(pf2_2@113@01) | live]
(set-option :rlimit 0)
(push) ; 53
; [else-branch: 594 | !(pf2_2@113@01)]
(assert (not pf2_2@113@01))
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not pf2_2@113@01))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@113@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 595 | !(pf2_2@113@01) | live]
; [else-branch: 595 | pf2_2@113@01 | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 595 | !(pf2_2@113@01)]
(assert (not pf2_2@113@01))
; [then-branch: 596 | False | dead]
; [else-branch: 596 | True | live]
(push) ; 54
; [else-branch: 596 | True]
(pop) ; 54
; [eval] !pf0_2
(push) ; 54
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 597 | True | live]
; [else-branch: 597 | False | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 597 | True]
; [then-branch: 598 | pf1_2@112@01 | dead]
; [else-branch: 598 | !(pf1_2@112@01) | live]
(push) ; 55
; [else-branch: 598 | !(pf1_2@112@01)]
(pop) ; 55
; [eval] !pf1_2
(push) ; 55
(set-option :rlimit 16000)
(assert (not pf1_2@112@01))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 599 | !(pf1_2@112@01) | live]
; [else-branch: 599 | pf1_2@112@01 | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 599 | !(pf1_2@112@01)]
; [then-branch: 600 | pf2_2@113@01 | dead]
; [else-branch: 600 | !(pf2_2@113@01) | live]
(push) ; 56
; [else-branch: 600 | !(pf2_2@113@01)]
(pop) ; 56
; [eval] !pf2_2
(push) ; 56
(set-option :rlimit 16000)
(assert (not pf2_2@113@01))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 601 | !(pf2_2@113@01) | live]
; [else-branch: 601 | pf2_2@113@01 | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 601 | !(pf2_2@113@01)]
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 602 | p0@12@01 | live]
; [else-branch: 602 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 602 | p0@12@01]
(assert p0@12@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 603 | p1@13@01 | live]
; [else-branch: 603 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 603 | p1@13@01]
(assert p1@13@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p1@13@01)
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 604 | p2@14@01 | live]
; [else-branch: 604 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 604 | p2@14@01]
(assert p2@14@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p2@14@01)
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 605 | p0@12@01 | live]
; [else-branch: 605 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 605 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 606 | False | live]
; [else-branch: 606 | True | live]
(push) ; 60
; [then-branch: 606 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 606 | True]
(push) ; 61
; [then-branch: 607 | !(p0@12@01) | live]
; [else-branch: 607 | p0@12@01 | live]
(push) ; 62
; [then-branch: 607 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 607 | p0@12@01]
(push) ; 63
; [then-branch: 608 | !(p1@13@01) | live]
; [else-branch: 608 | p1@13@01 | live]
(push) ; 64
; [then-branch: 608 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 608 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 609 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 609 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 609 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 610 | False | dead]
; [else-branch: 610 | True | live]
(push) ; 62
; [else-branch: 610 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 611 | p1@13@01 | live]
; [else-branch: 611 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 611 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 612 | False | live]
; [else-branch: 612 | True | live]
(push) ; 60
; [then-branch: 612 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 612 | True]
(push) ; 61
; [then-branch: 613 | !(p0@12@01) | live]
; [else-branch: 613 | p0@12@01 | live]
(push) ; 62
; [then-branch: 613 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 613 | p0@12@01]
(push) ; 63
; [then-branch: 614 | !(p1@13@01) | live]
; [else-branch: 614 | p1@13@01 | live]
(push) ; 64
; [then-branch: 614 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 614 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 615 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 615 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 615 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 616 | False | dead]
; [else-branch: 616 | True | live]
(push) ; 62
; [else-branch: 616 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p2@14@01)))
(assert p1@13@01)
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 617 | p2@14@01 | live]
; [else-branch: 617 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 617 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 618 | False | live]
; [else-branch: 618 | True | live]
(push) ; 60
; [then-branch: 618 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 618 | True]
(push) ; 61
; [then-branch: 619 | !(p0@12@01) | live]
; [else-branch: 619 | p0@12@01 | live]
(push) ; 62
; [then-branch: 619 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 619 | p0@12@01]
(assert p0@12@01)
(push) ; 63
; [then-branch: 620 | !(p1@13@01) | live]
; [else-branch: 620 | p1@13@01 | live]
(push) ; 64
; [then-branch: 620 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 620 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 621 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 621 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 621 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 622 | False | dead]
; [else-branch: 622 | True | live]
(push) ; 62
; [else-branch: 622 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01)))
(assert p2@14@01)
(pop) ; 56
(pop) ; 55
(pop) ; 54
(pop) ; 53
(pop) ; 52
(pop) ; 51
(pop) ; 50
(pop) ; 49
(pop) ; 48
(pop) ; 47
(pop) ; 46
(pop) ; 45
(pop) ; 44
(pop) ; 43
(pop) ; 42
(pop) ; 41
(pop) ; 40
(pop) ; 39
(pop) ; 38
; [eval] !pt2_6
; [then-branch: 623 | !(pt2_6@143@01) | dead]
; [else-branch: 623 | pt2_6@143@01 | live]
(push) ; 38
; [else-branch: 623 | pt2_6@143@01]
(pop) ; 38
(pop) ; 37
; [eval] !pt1_6
; [then-branch: 624 | !(pt1_6@142@01) | dead]
; [else-branch: 624 | pt1_6@142@01 | live]
(push) ; 37
; [else-branch: 624 | pt1_6@142@01]
(pop) ; 37
(pop) ; 36
(pop) ; 35
; [eval] !pt2_6
(push) ; 35
(set-option :rlimit 16000)
(assert (not pt2_6@143@01))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 625 | !(pt2_6@143@01) | dead]
; [else-branch: 625 | pt2_6@143@01 | live]
(set-option :rlimit 0)
(push) ; 35
; [else-branch: 625 | pt2_6@143@01]
(assert pt2_6@143@01)
(pop) ; 35
(pop) ; 34
(push) ; 34
; [else-branch: 560 | !(pt1_6@142@01)]
(assert (not pt1_6@142@01))
(pop) ; 34
; [eval] !pt1_6
(push) ; 34
(set-option :rlimit 16000)
(assert (not pt1_6@142@01))
(check-sat)
; unknown
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 34
(set-option :rlimit 16000)
(assert (not (not pt1_6@142@01)))
(check-sat)
; unknown
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 626 | !(pt1_6@142@01) | live]
; [else-branch: 626 | pt1_6@142@01 | live]
(set-option :rlimit 0)
(push) ; 34
; [then-branch: 626 | !(pt1_6@142@01)]
(assert (not pt1_6@142@01))
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@143@01)))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 627 | pt2_6@143@01 | dead]
; [else-branch: 627 | !(pt2_6@143@01) | live]
(set-option :rlimit 0)
(push) ; 35
; [else-branch: 627 | !(pt2_6@143@01)]
(assert (not pt2_6@143@01))
(pop) ; 35
; [eval] !pt2_6
(push) ; 35
(set-option :rlimit 16000)
(assert (not pt2_6@143@01))
(check-sat)
; unknown
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@143@01)))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 628 | !(pt2_6@143@01) | live]
; [else-branch: 628 | pt2_6@143@01 | dead]
(set-option :rlimit 0)
(push) ; 35
; [then-branch: 628 | !(pt2_6@143@01)]
(assert (not pt2_6@143@01))
; [then-branch: 629 | False | dead]
; [else-branch: 629 | True | live]
(push) ; 36
; [else-branch: 629 | True]
(pop) ; 36
; [eval] !pt0_6
(push) ; 36
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 36
; 0.00s
; (get-info :all-statistics)
; [then-branch: 630 | True | live]
; [else-branch: 630 | False | dead]
(set-option :rlimit 0)
(push) ; 36
; [then-branch: 630 | True]
; [then-branch: 631 | pt1_6@142@01 | dead]
; [else-branch: 631 | !(pt1_6@142@01) | live]
(push) ; 37
; [else-branch: 631 | !(pt1_6@142@01)]
(pop) ; 37
; [eval] !pt1_6
(push) ; 37
(set-option :rlimit 16000)
(assert (not pt1_6@142@01))
(check-sat)
; unknown
(pop) ; 37
; 0.00s
; (get-info :all-statistics)
; [then-branch: 632 | !(pt1_6@142@01) | live]
; [else-branch: 632 | pt1_6@142@01 | dead]
(set-option :rlimit 0)
(push) ; 37
; [then-branch: 632 | !(pt1_6@142@01)]
; [then-branch: 633 | pt2_6@143@01 | dead]
; [else-branch: 633 | !(pt2_6@143@01) | live]
(push) ; 38
; [else-branch: 633 | !(pt2_6@143@01)]
(pop) ; 38
; [eval] !pt2_6
(push) ; 38
(set-option :rlimit 16000)
(assert (not pt2_6@143@01))
(check-sat)
; unknown
(pop) ; 38
; 0.00s
; (get-info :all-statistics)
; [then-branch: 634 | !(pt2_6@143@01) | live]
; [else-branch: 634 | pt2_6@143@01 | dead]
(set-option :rlimit 0)
(push) ; 38
; [then-branch: 634 | !(pt2_6@143@01)]
; [then-branch: 635 | False | dead]
; [else-branch: 635 | True | live]
(push) ; 39
; [else-branch: 635 | True]
(pop) ; 39
; [eval] !pf0_6
(push) ; 39
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 636 | True | live]
; [else-branch: 636 | False | dead]
(set-option :rlimit 0)
(push) ; 39
; [then-branch: 636 | True]
(push) ; 40
(set-option :rlimit 16000)
(assert (not (not pf1_6@144@01)))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 40
(set-option :rlimit 16000)
(assert (not pf1_6@144@01))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 637 | pf1_6@144@01 | live]
; [else-branch: 637 | !(pf1_6@144@01) | live]
(set-option :rlimit 0)
(push) ; 40
; [then-branch: 637 | pf1_6@144@01]
(assert pf1_6@144@01)
; [exec]
; res_0 := -1
; [eval] -1
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@145@01)))
(check-sat)
; unknown
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 41
(set-option :rlimit 16000)
(assert (not pf2_6@145@01))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 638 | pf2_6@145@01 | live]
; [else-branch: 638 | !(pf2_6@145@01) | dead]
(set-option :rlimit 0)
(push) ; 41
; [then-branch: 638 | pf2_6@145@01]
(assert pf2_6@145@01)
; [exec]
; res_1 := -1
; [eval] -1
; [then-branch: 639 | False | dead]
; [else-branch: 639 | True | live]
(push) ; 42
; [else-branch: 639 | True]
(pop) ; 42
; [eval] !pf0_6
(push) ; 42
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 42
; 0.00s
; (get-info :all-statistics)
; [then-branch: 640 | True | live]
; [else-branch: 640 | False | dead]
(set-option :rlimit 0)
(push) ; 42
; [then-branch: 640 | True]
(push) ; 43
(set-option :rlimit 16000)
(assert (not (not pf1_6@144@01)))
(check-sat)
; unknown
(pop) ; 43
; 0.00s
; (get-info :all-statistics)
; [then-branch: 641 | pf1_6@144@01 | live]
; [else-branch: 641 | !(pf1_6@144@01) | dead]
(set-option :rlimit 0)
(push) ; 43
; [then-branch: 641 | pf1_6@144@01]
; [exec]
; returned_0 := true
(push) ; 44
(set-option :rlimit 16000)
(assert (not (not pf2_6@145@01)))
(check-sat)
; unknown
(pop) ; 44
; 0.00s
; (get-info :all-statistics)
; [then-branch: 642 | pf2_6@145@01 | live]
; [else-branch: 642 | !(pf2_6@145@01) | dead]
(set-option :rlimit 0)
(push) ; 44
; [then-branch: 642 | pf2_6@145@01]
; [exec]
; returned_1 := true
; [then-branch: 643 | False | dead]
; [else-branch: 643 | True | live]
(push) ; 45
; [else-branch: 643 | True]
(pop) ; 45
; [eval] !pf0_4
(push) ; 45
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 644 | True | live]
; [else-branch: 644 | False | dead]
(set-option :rlimit 0)
(push) ; 45
; [then-branch: 644 | True]
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@132@01)))
(check-sat)
; unsat
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 645 | pf1_4@132@01 | dead]
; [else-branch: 645 | !(pf1_4@132@01) | live]
(set-option :rlimit 0)
(push) ; 46
; [else-branch: 645 | !(pf1_4@132@01)]
(assert (not pf1_4@132@01))
(pop) ; 46
; [eval] !pf1_4
(push) ; 46
(set-option :rlimit 16000)
(assert (not pf1_4@132@01))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@132@01)))
(check-sat)
; unsat
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 646 | !(pf1_4@132@01) | live]
; [else-branch: 646 | pf1_4@132@01 | dead]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 646 | !(pf1_4@132@01)]
(assert (not pf1_4@132@01))
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@133@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 647 | pf2_4@133@01 | dead]
; [else-branch: 647 | !(pf2_4@133@01) | live]
(set-option :rlimit 0)
(push) ; 47
; [else-branch: 647 | !(pf2_4@133@01)]
(assert (not pf2_4@133@01))
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not pf2_4@133@01))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@133@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 648 | !(pf2_4@133@01) | live]
; [else-branch: 648 | pf2_4@133@01 | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 648 | !(pf2_4@133@01)]
(assert (not pf2_4@133@01))
; [then-branch: 649 | False | dead]
; [else-branch: 649 | True | live]
(push) ; 48
; [else-branch: 649 | True]
(pop) ; 48
; [eval] !pf0_4
(push) ; 48
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 650 | True | live]
; [else-branch: 650 | False | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 650 | True]
; [then-branch: 651 | pf1_4@132@01 | dead]
; [else-branch: 651 | !(pf1_4@132@01) | live]
(push) ; 49
; [else-branch: 651 | !(pf1_4@132@01)]
(pop) ; 49
; [eval] !pf1_4
(push) ; 49
(set-option :rlimit 16000)
(assert (not pf1_4@132@01))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 652 | !(pf1_4@132@01) | live]
; [else-branch: 652 | pf1_4@132@01 | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 652 | !(pf1_4@132@01)]
; [then-branch: 653 | pf2_4@133@01 | dead]
; [else-branch: 653 | !(pf2_4@133@01) | live]
(push) ; 50
; [else-branch: 653 | !(pf2_4@133@01)]
(pop) ; 50
; [eval] !pf2_4
(push) ; 50
(set-option :rlimit 16000)
(assert (not pf2_4@133@01))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 654 | !(pf2_4@133@01) | live]
; [else-branch: 654 | pf2_4@133@01 | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 654 | !(pf2_4@133@01)]
; [then-branch: 655 | False | dead]
; [else-branch: 655 | True | live]
(push) ; 51
; [else-branch: 655 | True]
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 656 | True | live]
; [else-branch: 656 | False | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 656 | True]
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@112@01)))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 657 | pf1_2@112@01 | dead]
; [else-branch: 657 | !(pf1_2@112@01) | live]
(set-option :rlimit 0)
(push) ; 52
; [else-branch: 657 | !(pf1_2@112@01)]
(assert (not pf1_2@112@01))
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not pf1_2@112@01))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@112@01)))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 658 | !(pf1_2@112@01) | live]
; [else-branch: 658 | pf1_2@112@01 | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 658 | !(pf1_2@112@01)]
(assert (not pf1_2@112@01))
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@113@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 659 | pf2_2@113@01 | dead]
; [else-branch: 659 | !(pf2_2@113@01) | live]
(set-option :rlimit 0)
(push) ; 53
; [else-branch: 659 | !(pf2_2@113@01)]
(assert (not pf2_2@113@01))
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not pf2_2@113@01))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@113@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 660 | !(pf2_2@113@01) | live]
; [else-branch: 660 | pf2_2@113@01 | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 660 | !(pf2_2@113@01)]
(assert (not pf2_2@113@01))
; [then-branch: 661 | False | dead]
; [else-branch: 661 | True | live]
(push) ; 54
; [else-branch: 661 | True]
(pop) ; 54
; [eval] !pf0_2
(push) ; 54
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 662 | True | live]
; [else-branch: 662 | False | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 662 | True]
; [then-branch: 663 | pf1_2@112@01 | dead]
; [else-branch: 663 | !(pf1_2@112@01) | live]
(push) ; 55
; [else-branch: 663 | !(pf1_2@112@01)]
(pop) ; 55
; [eval] !pf1_2
(push) ; 55
(set-option :rlimit 16000)
(assert (not pf1_2@112@01))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 664 | !(pf1_2@112@01) | live]
; [else-branch: 664 | pf1_2@112@01 | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 664 | !(pf1_2@112@01)]
; [then-branch: 665 | pf2_2@113@01 | dead]
; [else-branch: 665 | !(pf2_2@113@01) | live]
(push) ; 56
; [else-branch: 665 | !(pf2_2@113@01)]
(pop) ; 56
; [eval] !pf2_2
(push) ; 56
(set-option :rlimit 16000)
(assert (not pf2_2@113@01))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 666 | !(pf2_2@113@01) | live]
; [else-branch: 666 | pf2_2@113@01 | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 666 | !(pf2_2@113@01)]
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 667 | p0@12@01 | live]
; [else-branch: 667 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 667 | p0@12@01]
(assert p0@12@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 668 | p1@13@01 | live]
; [else-branch: 668 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 668 | p1@13@01]
(assert p1@13@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p1@13@01)
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 669 | p2@14@01 | live]
; [else-branch: 669 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 669 | p2@14@01]
(assert p2@14@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p2@14@01)
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 670 | p0@12@01 | live]
; [else-branch: 670 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 670 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 671 | False | live]
; [else-branch: 671 | True | live]
(push) ; 60
; [then-branch: 671 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 671 | True]
(push) ; 61
; [then-branch: 672 | !(p0@12@01) | live]
; [else-branch: 672 | p0@12@01 | live]
(push) ; 62
; [then-branch: 672 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 672 | p0@12@01]
(push) ; 63
; [then-branch: 673 | !(p1@13@01) | live]
; [else-branch: 673 | p1@13@01 | live]
(push) ; 64
; [then-branch: 673 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 673 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 674 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 674 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 674 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 675 | False | dead]
; [else-branch: 675 | True | live]
(push) ; 62
; [else-branch: 675 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 676 | p1@13@01 | live]
; [else-branch: 676 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 676 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 677 | False | live]
; [else-branch: 677 | True | live]
(push) ; 60
; [then-branch: 677 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 677 | True]
(push) ; 61
; [then-branch: 678 | !(p0@12@01) | live]
; [else-branch: 678 | p0@12@01 | live]
(push) ; 62
; [then-branch: 678 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 678 | p0@12@01]
(push) ; 63
; [then-branch: 679 | !(p1@13@01) | live]
; [else-branch: 679 | p1@13@01 | live]
(push) ; 64
; [then-branch: 679 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 679 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 680 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 680 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 680 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 681 | False | dead]
; [else-branch: 681 | True | live]
(push) ; 62
; [else-branch: 681 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p2@14@01)))
(assert p1@13@01)
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 682 | p2@14@01 | live]
; [else-branch: 682 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 682 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 683 | False | live]
; [else-branch: 683 | True | live]
(push) ; 60
; [then-branch: 683 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 683 | True]
(push) ; 61
; [then-branch: 684 | !(p0@12@01) | live]
; [else-branch: 684 | p0@12@01 | live]
(push) ; 62
; [then-branch: 684 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 684 | p0@12@01]
(assert p0@12@01)
(push) ; 63
; [then-branch: 685 | !(p1@13@01) | live]
; [else-branch: 685 | p1@13@01 | live]
(push) ; 64
; [then-branch: 685 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 685 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 686 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 686 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 686 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 687 | False | dead]
; [else-branch: 687 | True | live]
(push) ; 62
; [else-branch: 687 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01)))
(assert p2@14@01)
(pop) ; 56
(pop) ; 55
(pop) ; 54
(pop) ; 53
(pop) ; 52
(pop) ; 51
(pop) ; 50
(pop) ; 49
(pop) ; 48
(pop) ; 47
(pop) ; 46
(pop) ; 45
(pop) ; 44
; [eval] !pf2_6
; [then-branch: 688 | !(pf2_6@145@01) | dead]
; [else-branch: 688 | pf2_6@145@01 | live]
(push) ; 44
; [else-branch: 688 | pf2_6@145@01]
(pop) ; 44
(pop) ; 43
; [eval] !pf1_6
; [then-branch: 689 | !(pf1_6@144@01) | dead]
; [else-branch: 689 | pf1_6@144@01 | live]
(push) ; 43
; [else-branch: 689 | pf1_6@144@01]
(pop) ; 43
(pop) ; 42
(pop) ; 41
; [eval] !pf2_6
(push) ; 41
(set-option :rlimit 16000)
(assert (not pf2_6@145@01))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 690 | !(pf2_6@145@01) | dead]
; [else-branch: 690 | pf2_6@145@01 | live]
(set-option :rlimit 0)
(push) ; 41
; [else-branch: 690 | pf2_6@145@01]
(assert pf2_6@145@01)
(pop) ; 41
(pop) ; 40
(push) ; 40
; [else-branch: 637 | !(pf1_6@144@01)]
(assert (not pf1_6@144@01))
(pop) ; 40
; [eval] !pf1_6
(push) ; 40
(set-option :rlimit 16000)
(assert (not pf1_6@144@01))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 40
(set-option :rlimit 16000)
(assert (not (not pf1_6@144@01)))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 691 | !(pf1_6@144@01) | live]
; [else-branch: 691 | pf1_6@144@01 | live]
(set-option :rlimit 0)
(push) ; 40
; [then-branch: 691 | !(pf1_6@144@01)]
(assert (not pf1_6@144@01))
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@145@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 692 | pf2_6@145@01 | dead]
; [else-branch: 692 | !(pf2_6@145@01) | live]
(set-option :rlimit 0)
(push) ; 41
; [else-branch: 692 | !(pf2_6@145@01)]
(assert (not pf2_6@145@01))
(pop) ; 41
; [eval] !pf2_6
(push) ; 41
(set-option :rlimit 16000)
(assert (not pf2_6@145@01))
(check-sat)
; unknown
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@145@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 693 | !(pf2_6@145@01) | live]
; [else-branch: 693 | pf2_6@145@01 | dead]
(set-option :rlimit 0)
(push) ; 41
; [then-branch: 693 | !(pf2_6@145@01)]
(assert (not pf2_6@145@01))
; [then-branch: 694 | False | dead]
; [else-branch: 694 | True | live]
(push) ; 42
; [else-branch: 694 | True]
(pop) ; 42
; [eval] !pf0_6
(push) ; 42
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 42
; 0.00s
; (get-info :all-statistics)
; [then-branch: 695 | True | live]
; [else-branch: 695 | False | dead]
(set-option :rlimit 0)
(push) ; 42
; [then-branch: 695 | True]
; [then-branch: 696 | pf1_6@144@01 | dead]
; [else-branch: 696 | !(pf1_6@144@01) | live]
(push) ; 43
; [else-branch: 696 | !(pf1_6@144@01)]
(pop) ; 43
; [eval] !pf1_6
(push) ; 43
(set-option :rlimit 16000)
(assert (not pf1_6@144@01))
(check-sat)
; unknown
(pop) ; 43
; 0.00s
; (get-info :all-statistics)
; [then-branch: 697 | !(pf1_6@144@01) | live]
; [else-branch: 697 | pf1_6@144@01 | dead]
(set-option :rlimit 0)
(push) ; 43
; [then-branch: 697 | !(pf1_6@144@01)]
; [then-branch: 698 | pf2_6@145@01 | dead]
; [else-branch: 698 | !(pf2_6@145@01) | live]
(push) ; 44
; [else-branch: 698 | !(pf2_6@145@01)]
(pop) ; 44
; [eval] !pf2_6
(push) ; 44
(set-option :rlimit 16000)
(assert (not pf2_6@145@01))
(check-sat)
; unknown
(pop) ; 44
; 0.00s
; (get-info :all-statistics)
; [then-branch: 699 | !(pf2_6@145@01) | live]
; [else-branch: 699 | pf2_6@145@01 | dead]
(set-option :rlimit 0)
(push) ; 44
; [then-branch: 699 | !(pf2_6@145@01)]
; [then-branch: 700 | False | dead]
; [else-branch: 700 | True | live]
(push) ; 45
; [else-branch: 700 | True]
(pop) ; 45
; [eval] !pf0_4
(push) ; 45
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 701 | True | live]
; [else-branch: 701 | False | dead]
(set-option :rlimit 0)
(push) ; 45
; [then-branch: 701 | True]
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@132@01)))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 46
(set-option :rlimit 16000)
(assert (not pf1_4@132@01))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 702 | pf1_4@132@01 | live]
; [else-branch: 702 | !(pf1_4@132@01) | live]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 702 | pf1_4@132@01]
(assert pf1_4@132@01)
; [exec]
; res_0 := -1
; [eval] -1
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@133@01)))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 47
(set-option :rlimit 16000)
(assert (not pf2_4@133@01))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 703 | pf2_4@133@01 | live]
; [else-branch: 703 | !(pf2_4@133@01) | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 703 | pf2_4@133@01]
(assert pf2_4@133@01)
; [exec]
; res_1 := -1
; [eval] -1
; [then-branch: 704 | False | dead]
; [else-branch: 704 | True | live]
(push) ; 48
; [else-branch: 704 | True]
(pop) ; 48
; [eval] !pf0_4
(push) ; 48
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 705 | True | live]
; [else-branch: 705 | False | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 705 | True]
(push) ; 49
(set-option :rlimit 16000)
(assert (not (not pf1_4@132@01)))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 706 | pf1_4@132@01 | live]
; [else-branch: 706 | !(pf1_4@132@01) | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 706 | pf1_4@132@01]
; [exec]
; returned_0 := true
(push) ; 50
(set-option :rlimit 16000)
(assert (not (not pf2_4@133@01)))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 707 | pf2_4@133@01 | live]
; [else-branch: 707 | !(pf2_4@133@01) | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 707 | pf2_4@133@01]
; [exec]
; returned_1 := true
; [then-branch: 708 | False | dead]
; [else-branch: 708 | True | live]
(push) ; 51
; [else-branch: 708 | True]
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 709 | True | live]
; [else-branch: 709 | False | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 709 | True]
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@112@01)))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 710 | pf1_2@112@01 | dead]
; [else-branch: 710 | !(pf1_2@112@01) | live]
(set-option :rlimit 0)
(push) ; 52
; [else-branch: 710 | !(pf1_2@112@01)]
(assert (not pf1_2@112@01))
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not pf1_2@112@01))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@112@01)))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 711 | !(pf1_2@112@01) | live]
; [else-branch: 711 | pf1_2@112@01 | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 711 | !(pf1_2@112@01)]
(assert (not pf1_2@112@01))
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@113@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 712 | pf2_2@113@01 | dead]
; [else-branch: 712 | !(pf2_2@113@01) | live]
(set-option :rlimit 0)
(push) ; 53
; [else-branch: 712 | !(pf2_2@113@01)]
(assert (not pf2_2@113@01))
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not pf2_2@113@01))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@113@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 713 | !(pf2_2@113@01) | live]
; [else-branch: 713 | pf2_2@113@01 | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 713 | !(pf2_2@113@01)]
(assert (not pf2_2@113@01))
; [then-branch: 714 | False | dead]
; [else-branch: 714 | True | live]
(push) ; 54
; [else-branch: 714 | True]
(pop) ; 54
; [eval] !pf0_2
(push) ; 54
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 715 | True | live]
; [else-branch: 715 | False | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 715 | True]
; [then-branch: 716 | pf1_2@112@01 | dead]
; [else-branch: 716 | !(pf1_2@112@01) | live]
(push) ; 55
; [else-branch: 716 | !(pf1_2@112@01)]
(pop) ; 55
; [eval] !pf1_2
(push) ; 55
(set-option :rlimit 16000)
(assert (not pf1_2@112@01))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 717 | !(pf1_2@112@01) | live]
; [else-branch: 717 | pf1_2@112@01 | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 717 | !(pf1_2@112@01)]
; [then-branch: 718 | pf2_2@113@01 | dead]
; [else-branch: 718 | !(pf2_2@113@01) | live]
(push) ; 56
; [else-branch: 718 | !(pf2_2@113@01)]
(pop) ; 56
; [eval] !pf2_2
(push) ; 56
(set-option :rlimit 16000)
(assert (not pf2_2@113@01))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 719 | !(pf2_2@113@01) | live]
; [else-branch: 719 | pf2_2@113@01 | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 719 | !(pf2_2@113@01)]
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 720 | p0@12@01 | live]
; [else-branch: 720 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 720 | p0@12@01]
(assert p0@12@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 721 | p1@13@01 | live]
; [else-branch: 721 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 721 | p1@13@01]
(assert p1@13@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p1@13@01)
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 722 | p2@14@01 | live]
; [else-branch: 722 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 722 | p2@14@01]
(assert p2@14@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p2@14@01)
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 723 | p0@12@01 | live]
; [else-branch: 723 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 723 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 724 | False | live]
; [else-branch: 724 | True | live]
(push) ; 60
; [then-branch: 724 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 724 | True]
(push) ; 61
; [then-branch: 725 | !(p0@12@01) | live]
; [else-branch: 725 | p0@12@01 | live]
(push) ; 62
; [then-branch: 725 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 725 | p0@12@01]
(push) ; 63
; [then-branch: 726 | !(p1@13@01) | live]
; [else-branch: 726 | p1@13@01 | live]
(push) ; 64
; [then-branch: 726 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 726 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 727 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 727 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 727 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 728 | False | dead]
; [else-branch: 728 | True | live]
(push) ; 62
; [else-branch: 728 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 729 | p1@13@01 | live]
; [else-branch: 729 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 729 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 730 | False | live]
; [else-branch: 730 | True | live]
(push) ; 60
; [then-branch: 730 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 730 | True]
(push) ; 61
; [then-branch: 731 | !(p0@12@01) | live]
; [else-branch: 731 | p0@12@01 | live]
(push) ; 62
; [then-branch: 731 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 731 | p0@12@01]
(push) ; 63
; [then-branch: 732 | !(p1@13@01) | live]
; [else-branch: 732 | p1@13@01 | live]
(push) ; 64
; [then-branch: 732 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 732 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 733 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 733 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 733 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 734 | False | dead]
; [else-branch: 734 | True | live]
(push) ; 62
; [else-branch: 734 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p2@14@01)))
(assert p1@13@01)
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 735 | p2@14@01 | live]
; [else-branch: 735 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 735 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 736 | False | live]
; [else-branch: 736 | True | live]
(push) ; 60
; [then-branch: 736 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 736 | True]
(push) ; 61
; [then-branch: 737 | !(p0@12@01) | live]
; [else-branch: 737 | p0@12@01 | live]
(push) ; 62
; [then-branch: 737 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 737 | p0@12@01]
(assert p0@12@01)
(push) ; 63
; [then-branch: 738 | !(p1@13@01) | live]
; [else-branch: 738 | p1@13@01 | live]
(push) ; 64
; [then-branch: 738 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 738 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 739 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 739 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 739 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 740 | False | dead]
; [else-branch: 740 | True | live]
(push) ; 62
; [else-branch: 740 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01)))
(assert p2@14@01)
(pop) ; 56
(pop) ; 55
(pop) ; 54
(pop) ; 53
(pop) ; 52
(pop) ; 51
(pop) ; 50
; [eval] !pf2_4
; [then-branch: 741 | !(pf2_4@133@01) | dead]
; [else-branch: 741 | pf2_4@133@01 | live]
(push) ; 50
; [else-branch: 741 | pf2_4@133@01]
(pop) ; 50
(pop) ; 49
; [eval] !pf1_4
; [then-branch: 742 | !(pf1_4@132@01) | dead]
; [else-branch: 742 | pf1_4@132@01 | live]
(push) ; 49
; [else-branch: 742 | pf1_4@132@01]
(pop) ; 49
(pop) ; 48
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not pf2_4@133@01))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 743 | !(pf2_4@133@01) | dead]
; [else-branch: 743 | pf2_4@133@01 | live]
(set-option :rlimit 0)
(push) ; 47
; [else-branch: 743 | pf2_4@133@01]
(assert pf2_4@133@01)
(pop) ; 47
(pop) ; 46
(push) ; 46
; [else-branch: 702 | !(pf1_4@132@01)]
(assert (not pf1_4@132@01))
(pop) ; 46
; [eval] !pf1_4
(push) ; 46
(set-option :rlimit 16000)
(assert (not pf1_4@132@01))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@132@01)))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 744 | !(pf1_4@132@01) | live]
; [else-branch: 744 | pf1_4@132@01 | live]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 744 | !(pf1_4@132@01)]
(assert (not pf1_4@132@01))
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@133@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 745 | pf2_4@133@01 | dead]
; [else-branch: 745 | !(pf2_4@133@01) | live]
(set-option :rlimit 0)
(push) ; 47
; [else-branch: 745 | !(pf2_4@133@01)]
(assert (not pf2_4@133@01))
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not pf2_4@133@01))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@133@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 746 | !(pf2_4@133@01) | live]
; [else-branch: 746 | pf2_4@133@01 | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 746 | !(pf2_4@133@01)]
(assert (not pf2_4@133@01))
; [then-branch: 747 | False | dead]
; [else-branch: 747 | True | live]
(push) ; 48
; [else-branch: 747 | True]
(pop) ; 48
; [eval] !pf0_4
(push) ; 48
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 748 | True | live]
; [else-branch: 748 | False | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 748 | True]
; [then-branch: 749 | pf1_4@132@01 | dead]
; [else-branch: 749 | !(pf1_4@132@01) | live]
(push) ; 49
; [else-branch: 749 | !(pf1_4@132@01)]
(pop) ; 49
; [eval] !pf1_4
(push) ; 49
(set-option :rlimit 16000)
(assert (not pf1_4@132@01))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 750 | !(pf1_4@132@01) | live]
; [else-branch: 750 | pf1_4@132@01 | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 750 | !(pf1_4@132@01)]
; [then-branch: 751 | pf2_4@133@01 | dead]
; [else-branch: 751 | !(pf2_4@133@01) | live]
(push) ; 50
; [else-branch: 751 | !(pf2_4@133@01)]
(pop) ; 50
; [eval] !pf2_4
(push) ; 50
(set-option :rlimit 16000)
(assert (not pf2_4@133@01))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 752 | !(pf2_4@133@01) | live]
; [else-branch: 752 | pf2_4@133@01 | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 752 | !(pf2_4@133@01)]
; [then-branch: 753 | False | dead]
; [else-branch: 753 | True | live]
(push) ; 51
; [else-branch: 753 | True]
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 754 | True | live]
; [else-branch: 754 | False | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 754 | True]
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@112@01)))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 52
(set-option :rlimit 16000)
(assert (not pf1_2@112@01))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 755 | pf1_2@112@01 | live]
; [else-branch: 755 | !(pf1_2@112@01) | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 755 | pf1_2@112@01]
(assert pf1_2@112@01)
; [exec]
; res_0 := -1
; [eval] -1
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@113@01)))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 53
(set-option :rlimit 16000)
(assert (not pf2_2@113@01))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 756 | pf2_2@113@01 | live]
; [else-branch: 756 | !(pf2_2@113@01) | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 756 | pf2_2@113@01]
(assert pf2_2@113@01)
; [exec]
; res_1 := -1
; [eval] -1
; [then-branch: 757 | False | dead]
; [else-branch: 757 | True | live]
(push) ; 54
; [else-branch: 757 | True]
(pop) ; 54
; [eval] !pf0_2
(push) ; 54
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 758 | True | live]
; [else-branch: 758 | False | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 758 | True]
(push) ; 55
(set-option :rlimit 16000)
(assert (not (not pf1_2@112@01)))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 759 | pf1_2@112@01 | live]
; [else-branch: 759 | !(pf1_2@112@01) | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 759 | pf1_2@112@01]
; [exec]
; returned_0 := true
(push) ; 56
(set-option :rlimit 16000)
(assert (not (not pf2_2@113@01)))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 760 | pf2_2@113@01 | live]
; [else-branch: 760 | !(pf2_2@113@01) | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 760 | pf2_2@113@01]
; [exec]
; returned_1 := true
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 761 | p0@12@01 | live]
; [else-branch: 761 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 761 | p0@12@01]
(assert p0@12@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 762 | p1@13@01 | live]
; [else-branch: 762 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 762 | p1@13@01]
(assert p1@13@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p1@13@01)
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 763 | p2@14@01 | live]
; [else-branch: 763 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 763 | p2@14@01]
(assert p2@14@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p2@14@01)
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 764 | p0@12@01 | live]
; [else-branch: 764 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 764 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 765 | False | live]
; [else-branch: 765 | True | live]
(push) ; 60
; [then-branch: 765 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 765 | True]
(push) ; 61
; [then-branch: 766 | !(p0@12@01) | live]
; [else-branch: 766 | p0@12@01 | live]
(push) ; 62
; [then-branch: 766 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 766 | p0@12@01]
(push) ; 63
; [then-branch: 767 | !(p1@13@01) | live]
; [else-branch: 767 | p1@13@01 | live]
(push) ; 64
; [then-branch: 767 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 767 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 768 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 768 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 768 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 769 | False | dead]
; [else-branch: 769 | True | live]
(push) ; 62
; [else-branch: 769 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 770 | p1@13@01 | live]
; [else-branch: 770 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 770 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 771 | False | live]
; [else-branch: 771 | True | live]
(push) ; 60
; [then-branch: 771 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 771 | True]
(push) ; 61
; [then-branch: 772 | !(p0@12@01) | live]
; [else-branch: 772 | p0@12@01 | live]
(push) ; 62
; [then-branch: 772 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 772 | p0@12@01]
(push) ; 63
; [then-branch: 773 | !(p1@13@01) | live]
; [else-branch: 773 | p1@13@01 | live]
(push) ; 64
; [then-branch: 773 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 773 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 774 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 774 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 774 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 775 | False | dead]
; [else-branch: 775 | True | live]
(push) ; 62
; [else-branch: 775 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p2@14@01)))
(assert p1@13@01)
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 776 | p2@14@01 | live]
; [else-branch: 776 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 776 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 777 | False | live]
; [else-branch: 777 | True | live]
(push) ; 60
; [then-branch: 777 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 777 | True]
(push) ; 61
; [then-branch: 778 | !(p0@12@01) | live]
; [else-branch: 778 | p0@12@01 | live]
(push) ; 62
; [then-branch: 778 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 778 | p0@12@01]
(assert p0@12@01)
(push) ; 63
; [then-branch: 779 | !(p1@13@01) | live]
; [else-branch: 779 | p1@13@01 | live]
(push) ; 64
; [then-branch: 779 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 779 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 780 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 780 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 780 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 781 | False | dead]
; [else-branch: 781 | True | live]
(push) ; 62
; [else-branch: 781 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01)))
(assert p2@14@01)
(pop) ; 56
; [eval] !pf2_2
; [then-branch: 782 | !(pf2_2@113@01) | dead]
; [else-branch: 782 | pf2_2@113@01 | live]
(push) ; 56
; [else-branch: 782 | pf2_2@113@01]
(pop) ; 56
(pop) ; 55
; [eval] !pf1_2
; [then-branch: 783 | !(pf1_2@112@01) | dead]
; [else-branch: 783 | pf1_2@112@01 | live]
(push) ; 55
; [else-branch: 783 | pf1_2@112@01]
(pop) ; 55
(pop) ; 54
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not pf2_2@113@01))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 784 | !(pf2_2@113@01) | dead]
; [else-branch: 784 | pf2_2@113@01 | live]
(set-option :rlimit 0)
(push) ; 53
; [else-branch: 784 | pf2_2@113@01]
(assert pf2_2@113@01)
(pop) ; 53
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not pf1_2@112@01))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 785 | !(pf1_2@112@01) | dead]
; [else-branch: 785 | pf1_2@112@01 | live]
(set-option :rlimit 0)
(push) ; 52
; [else-branch: 785 | pf1_2@112@01]
(assert pf1_2@112@01)
(pop) ; 52
(pop) ; 51
(pop) ; 50
(pop) ; 49
(pop) ; 48
(pop) ; 47
(pop) ; 46
(push) ; 46
; [else-branch: 744 | pf1_4@132@01]
(assert pf1_4@132@01)
(pop) ; 46
(pop) ; 45
(pop) ; 44
(pop) ; 43
(pop) ; 42
(pop) ; 41
(pop) ; 40
(push) ; 40
; [else-branch: 691 | pf1_6@144@01]
(assert pf1_6@144@01)
(pop) ; 40
(pop) ; 39
(pop) ; 38
(pop) ; 37
(pop) ; 36
(pop) ; 35
(pop) ; 34
(push) ; 34
; [else-branch: 626 | pt1_6@142@01]
(assert pt1_6@142@01)
(pop) ; 34
(pop) ; 33
(pop) ; 32
(pop) ; 31
(pop) ; 30
(pop) ; 29
(pop) ; 28
(push) ; 28
; [else-branch: 545 | pt1_5@134@01]
(assert pt1_5@134@01)
(pop) ; 28
(pop) ; 27
(pop) ; 26
(pop) ; 25
(pop) ; 24
(pop) ; 23
(pop) ; 22
(push) ; 22
; [else-branch: 444 | pt1_3@114@01]
(assert pt1_3@114@01)
(pop) ; 22
(pop) ; 21
(pop) ; 20
(pop) ; 19
(pop) ; 18
(pop) ; 17
(pop) ; 16
(push) ; 16
; [else-branch: 323 | pt1_1@86@01]
(assert pt1_1@86@01)
(pop) ; 16
(pop) ; 15
(pop) ; 14
(pop) ; 13
(pop) ; 12
; [eval] !pt0
; [then-branch: 786 | !(pt0@80@01) | dead]
; [else-branch: 786 | pt0@80@01 | live]
(push) ; 12
; [else-branch: 786 | pt0@80@01]
(pop) ; 12
(pop) ; 11
(pop) ; 10
(push) ; 10
; [else-branch: 181 | pt1@81@01]
(assert pt1@81@01)
(pop) ; 10
(pop) ; 9
(push) ; 9
; [else-branch: 60 | !(pt0@80@01)]
(assert (not pt0@80@01))
(pop) ; 9
; [eval] !pt0
(push) ; 9
(set-option :rlimit 16000)
(assert (not pt0@80@01))
(check-sat)
; unknown
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 9
(set-option :rlimit 16000)
(assert (not (not pt0@80@01)))
(check-sat)
; unknown
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
; [then-branch: 787 | !(pt0@80@01) | live]
; [else-branch: 787 | pt0@80@01 | live]
(set-option :rlimit 0)
(push) ; 9
; [then-branch: 787 | !(pt0@80@01)]
(assert (not pt0@80@01))
(push) ; 10
(set-option :rlimit 16000)
(assert (not (not pt1@81@01)))
(check-sat)
; unknown
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 10
(set-option :rlimit 16000)
(assert (not pt1@81@01))
(check-sat)
; unknown
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
; [then-branch: 788 | pt1@81@01 | live]
; [else-branch: 788 | !(pt1@81@01) | live]
(set-option :rlimit 0)
(push) ; 10
; [then-branch: 788 | pt1@81@01]
(assert pt1@81@01)
; [exec]
; res_0 := 0
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not pt2@82@01)))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 789 | pt2@82@01 | dead]
; [else-branch: 789 | !(pt2@82@01) | live]
(set-option :rlimit 0)
(push) ; 11
; [else-branch: 789 | !(pt2@82@01)]
(assert (not pt2@82@01))
(pop) ; 11
; [eval] !pt2
(push) ; 11
(set-option :rlimit 16000)
(assert (not pt2@82@01))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not pt2@82@01)))
(check-sat)
; unsat
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 790 | !(pt2@82@01) | live]
; [else-branch: 790 | pt2@82@01 | dead]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 790 | !(pt2@82@01)]
(assert (not pt2@82@01))
; [then-branch: 791 | pt0@80@01 | dead]
; [else-branch: 791 | !(pt0@80@01) | live]
(push) ; 12
; [else-branch: 791 | !(pt0@80@01)]
(pop) ; 12
; [eval] !pt0
(push) ; 12
(set-option :rlimit 16000)
(assert (not pt0@80@01))
(check-sat)
; unknown
(pop) ; 12
; 0.00s
; (get-info :all-statistics)
; [then-branch: 792 | !(pt0@80@01) | live]
; [else-branch: 792 | pt0@80@01 | dead]
(set-option :rlimit 0)
(push) ; 12
; [then-branch: 792 | !(pt0@80@01)]
(push) ; 13
(set-option :rlimit 16000)
(assert (not (not pt1@81@01)))
(check-sat)
; unknown
(pop) ; 13
; 0.00s
; (get-info :all-statistics)
; [then-branch: 793 | pt1@81@01 | live]
; [else-branch: 793 | !(pt1@81@01) | dead]
(set-option :rlimit 0)
(push) ; 13
; [then-branch: 793 | pt1@81@01]
; [exec]
; returned_0 := true
; [then-branch: 794 | pt2@82@01 | dead]
; [else-branch: 794 | !(pt2@82@01) | live]
(push) ; 14
; [else-branch: 794 | !(pt2@82@01)]
(pop) ; 14
; [eval] !pt2
(push) ; 14
(set-option :rlimit 16000)
(assert (not pt2@82@01))
(check-sat)
; unknown
(pop) ; 14
; 0.00s
; (get-info :all-statistics)
; [then-branch: 795 | !(pt2@82@01) | live]
; [else-branch: 795 | pt2@82@01 | dead]
(set-option :rlimit 0)
(push) ; 14
; [then-branch: 795 | !(pt2@82@01)]
; [exec]
; pt0_0 := p0 && !returned
; [eval] p0 && !returned
(push) ; 15
; [then-branch: 796 | !(p0@12@01) | live]
; [else-branch: 796 | p0@12@01 | live]
(push) ; 16
; [then-branch: 796 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 16
(push) ; 16
; [else-branch: 796 | p0@12@01]
(assert p0@12@01)
; [eval] !returned
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pt1_0 := p1 && !returned_0
; [eval] p1 && !returned_0
(push) ; 15
; [then-branch: 797 | !(p1@13@01) | live]
; [else-branch: 797 | p1@13@01 | live]
(push) ; 16
; [then-branch: 797 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 16
(push) ; 16
; [else-branch: 797 | p1@13@01]
(assert p1@13@01)
; [eval] !returned_0
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pt2_0 := p2 && !returned_1
; [eval] p2 && !returned_1
(push) ; 15
; [then-branch: 798 | !(p2@14@01) | live]
; [else-branch: 798 | p2@14@01 | live]
(push) ; 16
; [then-branch: 798 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 16
(push) ; 16
; [else-branch: 798 | p2@14@01]
(assert p2@14@01)
; [eval] !returned_1
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pf0_0 := p0 && !!returned
; [eval] p0 && !!returned
(push) ; 15
; [then-branch: 799 | !(p0@12@01) | live]
; [else-branch: 799 | p0@12@01 | live]
(push) ; 16
; [then-branch: 799 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 16
(push) ; 16
; [else-branch: 799 | p0@12@01]
(assert p0@12@01)
; [eval] !!returned
; [eval] !returned
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pf1_0 := p1 && !!returned_0
; [eval] p1 && !!returned_0
(push) ; 15
; [then-branch: 800 | !(p1@13@01) | live]
; [else-branch: 800 | p1@13@01 | live]
(push) ; 16
; [then-branch: 800 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 16
(push) ; 16
; [else-branch: 800 | p1@13@01]
(assert p1@13@01)
; [eval] !!returned_0
; [eval] !returned_0
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pf2_0 := p2 && !!returned_1
; [eval] p2 && !!returned_1
(push) ; 15
; [then-branch: 801 | !(p2@14@01) | live]
; [else-branch: 801 | p2@14@01 | live]
(push) ; 16
; [then-branch: 801 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 16
(push) ; 16
; [else-branch: 801 | p2@14@01]
(assert p2@14@01)
; [eval] !!returned_1
; [eval] !returned_1
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pt0_1 := pt0_0 && getCardSet(o1) < getCardSet(o2)
; [eval] pt0_0 && getCardSet(o1) < getCardSet(o2)
(push) ; 15
; [then-branch: 802 | !(p0@12@01) | live]
; [else-branch: 802 | p0@12@01 | live]
(push) ; 16
; [then-branch: 802 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 16
(push) ; 16
; [else-branch: 802 | p0@12@01]
(assert p0@12@01)
; [eval] getCardSet(o1) < getCardSet(o2)
; [eval] getCardSet(o1)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o1@15@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1@15@01))
; [eval] getCardSet(o2)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    p0@12@01
    (getCardSet%precondition $Snap.unit o1@15@01)
    (getCardSet%precondition $Snap.unit o2@18@01))))
(declare-const pt0_1@146@01 Bool)
(assert (=
  pt0_1@146@01
  (and
    p0@12@01
    (< (getCardSet $Snap.unit o1@15@01) (getCardSet $Snap.unit o2@18@01)))))
; [exec]
; pt1_1 := pt1_0 && getCardSet(o1_0) < getCardSet(o2_0)
; [eval] pt1_0 && getCardSet(o1_0) < getCardSet(o2_0)
; [exec]
; pt2_1 := pt2_0 && getCardSet(o1_1) < getCardSet(o2_1)
; [eval] pt2_0 && getCardSet(o1_1) < getCardSet(o2_1)
(push) ; 15
; [then-branch: 803 | !(p2@14@01) | live]
; [else-branch: 803 | p2@14@01 | live]
(push) ; 16
; [then-branch: 803 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 16
(push) ; 16
; [else-branch: 803 | p2@14@01]
(assert p2@14@01)
; [eval] getCardSet(o1_1) < getCardSet(o2_1)
; [eval] getCardSet(o1_1)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
; [eval] getCardSet(o2_1)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (getCardSet%precondition $Snap.unit o1_1@17@01)
    (getCardSet%precondition $Snap.unit o2_1@20@01))))
(declare-const pt2_1@147@01 Bool)
(assert (=
  pt2_1@147@01
  (and
    p2@14@01
    (< (getCardSet $Snap.unit o1_1@17@01) (getCardSet $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_1 := pt0_0 && !(getCardSet(o1) < getCardSet(o2))
; [eval] pt0_0 && !(getCardSet(o1) < getCardSet(o2))
(push) ; 15
; [then-branch: 804 | !(p0@12@01) | live]
; [else-branch: 804 | p0@12@01 | live]
(push) ; 16
; [then-branch: 804 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 16
(push) ; 16
; [else-branch: 804 | p0@12@01]
(assert p0@12@01)
; [eval] !(getCardSet(o1) < getCardSet(o2))
; [eval] getCardSet(o1) < getCardSet(o2)
; [eval] getCardSet(o1)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o1@15@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1@15@01))
; [eval] getCardSet(o2)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
(declare-const pf0_1@148@01 Bool)
(assert (=
  pf0_1@148@01
  (and
    p0@12@01
    (not (< (getCardSet $Snap.unit o1@15@01) (getCardSet $Snap.unit o2@18@01))))))
; [exec]
; pf1_1 := pt1_0 && !(getCardSet(o1_0) < getCardSet(o2_0))
; [eval] pt1_0 && !(getCardSet(o1_0) < getCardSet(o2_0))
; [exec]
; pf2_1 := pt2_0 && !(getCardSet(o1_1) < getCardSet(o2_1))
; [eval] pt2_0 && !(getCardSet(o1_1) < getCardSet(o2_1))
(push) ; 15
; [then-branch: 805 | !(p2@14@01) | live]
; [else-branch: 805 | p2@14@01 | live]
(push) ; 16
; [then-branch: 805 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 16
(push) ; 16
; [else-branch: 805 | p2@14@01]
(assert p2@14@01)
; [eval] !(getCardSet(o1_1) < getCardSet(o2_1))
; [eval] getCardSet(o1_1) < getCardSet(o2_1)
; [eval] getCardSet(o1_1)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
; [eval] getCardSet(o2_1)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
(declare-const pf2_1@149@01 Bool)
(assert (=
  pf2_1@149@01
  (and
    p2@14@01
    (not
      (< (getCardSet $Snap.unit o1_1@17@01) (getCardSet $Snap.unit o2_1@20@01))))))
(push) ; 15
(set-option :rlimit 16000)
(assert (not (not pt0_1@146@01)))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 16000)
(assert (not pt0_1@146@01))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
; [then-branch: 806 | pt0_1@146@01 | live]
; [else-branch: 806 | !(pt0_1@146@01) | live]
(set-option :rlimit 0)
(push) ; 15
; [then-branch: 806 | pt0_1@146@01]
(assert pt0_1@146@01)
; [exec]
; res := -1
; [eval] -1
; [then-branch: 807 | False | dead]
; [else-branch: 807 | True | live]
(push) ; 16
; [else-branch: 807 | True]
(pop) ; 16
; [eval] !pt1_1
(push) ; 16
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [then-branch: 808 | True | live]
; [else-branch: 808 | False | dead]
(set-option :rlimit 0)
(push) ; 16
; [then-branch: 808 | True]
(push) ; 17
(set-option :rlimit 16000)
(assert (not (not pt2_1@147@01)))
(check-sat)
; unknown
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 17
(set-option :rlimit 16000)
(assert (not pt2_1@147@01))
(check-sat)
; unsat
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
; [then-branch: 809 | pt2_1@147@01 | live]
; [else-branch: 809 | !(pt2_1@147@01) | dead]
(set-option :rlimit 0)
(push) ; 17
; [then-branch: 809 | pt2_1@147@01]
(assert pt2_1@147@01)
; [exec]
; res_1 := -1
; [eval] -1
(push) ; 18
(set-option :rlimit 16000)
(assert (not (not pt0_1@146@01)))
(check-sat)
; unknown
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
; [then-branch: 810 | pt0_1@146@01 | live]
; [else-branch: 810 | !(pt0_1@146@01) | dead]
(set-option :rlimit 0)
(push) ; 18
; [then-branch: 810 | pt0_1@146@01]
; [exec]
; returned := true
; [then-branch: 811 | False | dead]
; [else-branch: 811 | True | live]
(push) ; 19
; [else-branch: 811 | True]
(pop) ; 19
; [eval] !pt1_1
(push) ; 19
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 812 | True | live]
; [else-branch: 812 | False | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 812 | True]
(push) ; 20
(set-option :rlimit 16000)
(assert (not (not pt2_1@147@01)))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 813 | pt2_1@147@01 | live]
; [else-branch: 813 | !(pt2_1@147@01) | dead]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 813 | pt2_1@147@01]
; [exec]
; returned_1 := true
; [exec]
; pt0_2 := pf0_1 && getCardSet(o1) == getCardSet(o2)
; [eval] pf0_1 && getCardSet(o1) == getCardSet(o2)
(push) ; 21
; [then-branch: 814 | !(pf0_1@148@01) | live]
; [else-branch: 814 | pf0_1@148@01 | live]
(push) ; 22
; [then-branch: 814 | !(pf0_1@148@01)]
(assert (not pf0_1@148@01))
(pop) ; 22
(push) ; 22
; [else-branch: 814 | pf0_1@148@01]
(assert pf0_1@148@01)
; [eval] getCardSet(o1) == getCardSet(o2)
; [eval] getCardSet(o1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1@15@01))
; [eval] getCardSet(o2)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_1@148@01
  (and
    pf0_1@148@01
    (getCardSet%precondition $Snap.unit o1@15@01)
    (getCardSet%precondition $Snap.unit o2@18@01))))
(assert (or pf0_1@148@01 (not pf0_1@148@01)))
(declare-const pt0_2@150@01 Bool)
(assert (=
  pt0_2@150@01
  (and
    pf0_1@148@01
    (= (getCardSet $Snap.unit o1@15@01) (getCardSet $Snap.unit o2@18@01)))))
; [exec]
; pt1_2 := pf1_1 && getCardSet(o1_0) == getCardSet(o2_0)
; [eval] pf1_1 && getCardSet(o1_0) == getCardSet(o2_0)
; [exec]
; pt2_2 := pf2_1 && getCardSet(o1_1) == getCardSet(o2_1)
; [eval] pf2_1 && getCardSet(o1_1) == getCardSet(o2_1)
(push) ; 21
; [then-branch: 815 | !(pf2_1@149@01) | live]
; [else-branch: 815 | pf2_1@149@01 | live]
(push) ; 22
; [then-branch: 815 | !(pf2_1@149@01)]
(assert (not pf2_1@149@01))
(pop) ; 22
(push) ; 22
; [else-branch: 815 | pf2_1@149@01]
(assert pf2_1@149@01)
; [eval] getCardSet(o1_1) == getCardSet(o2_1)
; [eval] getCardSet(o1_1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
; [eval] getCardSet(o2_1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_1@149@01
  (and
    pf2_1@149@01
    (getCardSet%precondition $Snap.unit o1_1@17@01)
    (getCardSet%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_1@149@01 (not pf2_1@149@01)))
(declare-const pt2_2@151@01 Bool)
(assert (=
  pt2_2@151@01
  (and
    pf2_1@149@01
    (= (getCardSet $Snap.unit o1_1@17@01) (getCardSet $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_2 := pf0_1 && !(getCardSet(o1) == getCardSet(o2))
; [eval] pf0_1 && !(getCardSet(o1) == getCardSet(o2))
(push) ; 21
; [then-branch: 816 | !(pf0_1@148@01) | live]
; [else-branch: 816 | pf0_1@148@01 | live]
(push) ; 22
; [then-branch: 816 | !(pf0_1@148@01)]
(assert (not pf0_1@148@01))
(pop) ; 22
(push) ; 22
; [else-branch: 816 | pf0_1@148@01]
(assert pf0_1@148@01)
; [eval] !(getCardSet(o1) == getCardSet(o2))
; [eval] getCardSet(o1) == getCardSet(o2)
; [eval] getCardSet(o1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1@15@01))
; [eval] getCardSet(o2)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf0_2@152@01 Bool)
(assert (=
  pf0_2@152@01
  (and
    pf0_1@148@01
    (not (= (getCardSet $Snap.unit o1@15@01) (getCardSet $Snap.unit o2@18@01))))))
; [exec]
; pf1_2 := pf1_1 && !(getCardSet(o1_0) == getCardSet(o2_0))
; [eval] pf1_1 && !(getCardSet(o1_0) == getCardSet(o2_0))
; [exec]
; pf2_2 := pf2_1 && !(getCardSet(o1_1) == getCardSet(o2_1))
; [eval] pf2_1 && !(getCardSet(o1_1) == getCardSet(o2_1))
(push) ; 21
; [then-branch: 817 | !(pf2_1@149@01) | live]
; [else-branch: 817 | pf2_1@149@01 | live]
(push) ; 22
; [then-branch: 817 | !(pf2_1@149@01)]
(assert (not pf2_1@149@01))
(pop) ; 22
(push) ; 22
; [else-branch: 817 | pf2_1@149@01]
(assert pf2_1@149@01)
; [eval] !(getCardSet(o1_1) == getCardSet(o2_1))
; [eval] getCardSet(o1_1) == getCardSet(o2_1)
; [eval] getCardSet(o1_1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
; [eval] getCardSet(o2_1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf2_2@153@01 Bool)
(assert (=
  pf2_2@153@01
  (and
    pf2_1@149@01
    (not
      (= (getCardSet $Snap.unit o1_1@17@01) (getCardSet $Snap.unit o2_1@20@01))))))
; [exec]
; pt0_3 := pt0_2 && getCardRarity(o1) < getCardRarity(o2)
; [eval] pt0_2 && getCardRarity(o1) < getCardRarity(o2)
(push) ; 21
; [then-branch: 818 | !(pt0_2@150@01) | live]
; [else-branch: 818 | pt0_2@150@01 | live]
(push) ; 22
; [then-branch: 818 | !(pt0_2@150@01)]
(assert (not pt0_2@150@01))
(pop) ; 22
(push) ; 22
; [else-branch: 818 | pt0_2@150@01]
(assert pt0_2@150@01)
; [eval] getCardRarity(o1) < getCardRarity(o2)
; [eval] getCardRarity(o1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
; [eval] getCardRarity(o2)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pt0_2@150@01
  (and
    pt0_2@150@01
    (getCardRarity%precondition $Snap.unit o1@15@01)
    (getCardRarity%precondition $Snap.unit o2@18@01))))
(assert (or pt0_2@150@01 (not pt0_2@150@01)))
(declare-const pt0_3@154@01 Bool)
(assert (=
  pt0_3@154@01
  (and
    pt0_2@150@01
    (< (getCardRarity $Snap.unit o1@15@01) (getCardRarity $Snap.unit o2@18@01)))))
; [exec]
; pt1_3 := pt1_2 && getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] pt1_2 && getCardRarity(o1_0) < getCardRarity(o2_0)
; [exec]
; pt2_3 := pt2_2 && getCardRarity(o1_1) < getCardRarity(o2_1)
; [eval] pt2_2 && getCardRarity(o1_1) < getCardRarity(o2_1)
(push) ; 21
; [then-branch: 819 | !(pt2_2@151@01) | live]
; [else-branch: 819 | pt2_2@151@01 | live]
(push) ; 22
; [then-branch: 819 | !(pt2_2@151@01)]
(assert (not pt2_2@151@01))
(pop) ; 22
(push) ; 22
; [else-branch: 819 | pt2_2@151@01]
(assert pt2_2@151@01)
; [eval] getCardRarity(o1_1) < getCardRarity(o2_1)
; [eval] getCardRarity(o1_1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_1@17@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_1@17@01))
; [eval] getCardRarity(o2_1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_1@20@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_1@20@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pt2_2@151@01
  (and
    pt2_2@151@01
    (getCardRarity%precondition $Snap.unit o1_1@17@01)
    (getCardRarity%precondition $Snap.unit o2_1@20@01))))
(assert (or pt2_2@151@01 (not pt2_2@151@01)))
(declare-const pt2_3@155@01 Bool)
(assert (=
  pt2_3@155@01
  (and
    pt2_2@151@01
    (<
      (getCardRarity $Snap.unit o1_1@17@01)
      (getCardRarity $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_3 := pt0_2 && !(getCardRarity(o1) < getCardRarity(o2))
; [eval] pt0_2 && !(getCardRarity(o1) < getCardRarity(o2))
(push) ; 21
; [then-branch: 820 | !(pt0_2@150@01) | live]
; [else-branch: 820 | pt0_2@150@01 | live]
(push) ; 22
; [then-branch: 820 | !(pt0_2@150@01)]
(assert (not pt0_2@150@01))
(pop) ; 22
(push) ; 22
; [else-branch: 820 | pt0_2@150@01]
(assert pt0_2@150@01)
; [eval] !(getCardRarity(o1) < getCardRarity(o2))
; [eval] getCardRarity(o1) < getCardRarity(o2)
; [eval] getCardRarity(o1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
; [eval] getCardRarity(o2)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf0_3@156@01 Bool)
(assert (=
  pf0_3@156@01
  (and
    pt0_2@150@01
    (not
      (< (getCardRarity $Snap.unit o1@15@01) (getCardRarity $Snap.unit o2@18@01))))))
; [exec]
; pf1_3 := pt1_2 && !(getCardRarity(o1_0) < getCardRarity(o2_0))
; [eval] pt1_2 && !(getCardRarity(o1_0) < getCardRarity(o2_0))
; [exec]
; pf2_3 := pt2_2 && !(getCardRarity(o1_1) < getCardRarity(o2_1))
; [eval] pt2_2 && !(getCardRarity(o1_1) < getCardRarity(o2_1))
(push) ; 21
; [then-branch: 821 | !(pt2_2@151@01) | live]
; [else-branch: 821 | pt2_2@151@01 | live]
(push) ; 22
; [then-branch: 821 | !(pt2_2@151@01)]
(assert (not pt2_2@151@01))
(pop) ; 22
(push) ; 22
; [else-branch: 821 | pt2_2@151@01]
(assert pt2_2@151@01)
; [eval] !(getCardRarity(o1_1) < getCardRarity(o2_1))
; [eval] getCardRarity(o1_1) < getCardRarity(o2_1)
; [eval] getCardRarity(o1_1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_1@17@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_1@17@01))
; [eval] getCardRarity(o2_1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_1@20@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_1@20@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf2_3@157@01 Bool)
(assert (=
  pf2_3@157@01
  (and
    pt2_2@151@01
    (not
      (<
        (getCardRarity $Snap.unit o1_1@17@01)
        (getCardRarity $Snap.unit o2_1@20@01))))))
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt0_3@154@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 822 | pt0_3@154@01 | dead]
; [else-branch: 822 | !(pt0_3@154@01) | live]
(set-option :rlimit 0)
(push) ; 21
; [else-branch: 822 | !(pt0_3@154@01)]
(assert (not pt0_3@154@01))
(pop) ; 21
; [eval] !pt0_3
(push) ; 21
(set-option :rlimit 16000)
(assert (not pt0_3@154@01))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt0_3@154@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 823 | !(pt0_3@154@01) | live]
; [else-branch: 823 | pt0_3@154@01 | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 823 | !(pt0_3@154@01)]
(assert (not pt0_3@154@01))
; [then-branch: 824 | False | dead]
; [else-branch: 824 | True | live]
(push) ; 22
; [else-branch: 824 | True]
(pop) ; 22
; [eval] !pt1_3
(push) ; 22
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 825 | True | live]
; [else-branch: 825 | False | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 825 | True]
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not pt2_3@155@01)))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 826 | pt2_3@155@01 | dead]
; [else-branch: 826 | !(pt2_3@155@01) | live]
(set-option :rlimit 0)
(push) ; 23
; [else-branch: 826 | !(pt2_3@155@01)]
(assert (not pt2_3@155@01))
(pop) ; 23
; [eval] !pt2_3
(push) ; 23
(set-option :rlimit 16000)
(assert (not pt2_3@155@01))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not pt2_3@155@01)))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 827 | !(pt2_3@155@01) | live]
; [else-branch: 827 | pt2_3@155@01 | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 827 | !(pt2_3@155@01)]
(assert (not pt2_3@155@01))
; [then-branch: 828 | pt0_3@154@01 | dead]
; [else-branch: 828 | !(pt0_3@154@01) | live]
(push) ; 24
; [else-branch: 828 | !(pt0_3@154@01)]
(pop) ; 24
; [eval] !pt0_3
(push) ; 24
(set-option :rlimit 16000)
(assert (not pt0_3@154@01))
(check-sat)
; unknown
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
; [then-branch: 829 | !(pt0_3@154@01) | live]
; [else-branch: 829 | pt0_3@154@01 | dead]
(set-option :rlimit 0)
(push) ; 24
; [then-branch: 829 | !(pt0_3@154@01)]
; [then-branch: 830 | False | dead]
; [else-branch: 830 | True | live]
(push) ; 25
; [else-branch: 830 | True]
(pop) ; 25
; [eval] !pt1_3
(push) ; 25
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 831 | True | live]
; [else-branch: 831 | False | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 831 | True]
; [then-branch: 832 | pt2_3@155@01 | dead]
; [else-branch: 832 | !(pt2_3@155@01) | live]
(push) ; 26
; [else-branch: 832 | !(pt2_3@155@01)]
(pop) ; 26
; [eval] !pt2_3
(push) ; 26
(set-option :rlimit 16000)
(assert (not pt2_3@155@01))
(check-sat)
; unknown
(pop) ; 26
; 0.00s
; (get-info :all-statistics)
; [then-branch: 833 | !(pt2_3@155@01) | live]
; [else-branch: 833 | pt2_3@155@01 | dead]
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 833 | !(pt2_3@155@01)]
; [exec]
; pt0_4 := pf0_3 && getCardId(o1) == getCardId(o2)
; [eval] pf0_3 && getCardId(o1) == getCardId(o2)
(push) ; 27
; [then-branch: 834 | !(pf0_3@156@01) | live]
; [else-branch: 834 | pf0_3@156@01 | live]
(push) ; 28
; [then-branch: 834 | !(pf0_3@156@01)]
(assert (not pf0_3@156@01))
(pop) ; 28
(push) ; 28
; [else-branch: 834 | pf0_3@156@01]
(assert pf0_3@156@01)
; [eval] getCardId(o1) == getCardId(o2)
; [eval] getCardId(o1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1@15@01))
; [eval] getCardId(o2)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_3@156@01
  (and
    pf0_3@156@01
    (getCardId%precondition $Snap.unit o1@15@01)
    (getCardId%precondition $Snap.unit o2@18@01))))
(assert (or pf0_3@156@01 (not pf0_3@156@01)))
(declare-const pt0_4@158@01 Bool)
(assert (=
  pt0_4@158@01
  (and
    pf0_3@156@01
    (= (getCardId $Snap.unit o1@15@01) (getCardId $Snap.unit o2@18@01)))))
; [exec]
; pt1_4 := pf1_3 && getCardId(o1_0) == getCardId(o2_0)
; [eval] pf1_3 && getCardId(o1_0) == getCardId(o2_0)
; [exec]
; pt2_4 := pf2_3 && getCardId(o1_1) == getCardId(o2_1)
; [eval] pf2_3 && getCardId(o1_1) == getCardId(o2_1)
(push) ; 27
; [then-branch: 835 | !(pf2_3@157@01) | live]
; [else-branch: 835 | pf2_3@157@01 | live]
(push) ; 28
; [then-branch: 835 | !(pf2_3@157@01)]
(assert (not pf2_3@157@01))
(pop) ; 28
(push) ; 28
; [else-branch: 835 | pf2_3@157@01]
(assert pf2_3@157@01)
; [eval] getCardId(o1_1) == getCardId(o2_1)
; [eval] getCardId(o1_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
; [eval] getCardId(o2_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_3@157@01
  (and
    pf2_3@157@01
    (getCardId%precondition $Snap.unit o1_1@17@01)
    (getCardId%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_3@157@01 (not pf2_3@157@01)))
(declare-const pt2_4@159@01 Bool)
(assert (=
  pt2_4@159@01
  (and
    pf2_3@157@01
    (= (getCardId $Snap.unit o1_1@17@01) (getCardId $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_4 := pf0_3 && !(getCardId(o1) == getCardId(o2))
; [eval] pf0_3 && !(getCardId(o1) == getCardId(o2))
(push) ; 27
; [then-branch: 836 | !(pf0_3@156@01) | live]
; [else-branch: 836 | pf0_3@156@01 | live]
(push) ; 28
; [then-branch: 836 | !(pf0_3@156@01)]
(assert (not pf0_3@156@01))
(pop) ; 28
(push) ; 28
; [else-branch: 836 | pf0_3@156@01]
(assert pf0_3@156@01)
; [eval] !(getCardId(o1) == getCardId(o2))
; [eval] getCardId(o1) == getCardId(o2)
; [eval] getCardId(o1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1@15@01))
; [eval] getCardId(o2)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf0_4@160@01 Bool)
(assert (=
  pf0_4@160@01
  (and
    pf0_3@156@01
    (not (= (getCardId $Snap.unit o1@15@01) (getCardId $Snap.unit o2@18@01))))))
; [exec]
; pf1_4 := pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
; [eval] pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
; [exec]
; pf2_4 := pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
; [eval] pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
(push) ; 27
; [then-branch: 837 | !(pf2_3@157@01) | live]
; [else-branch: 837 | pf2_3@157@01 | live]
(push) ; 28
; [then-branch: 837 | !(pf2_3@157@01)]
(assert (not pf2_3@157@01))
(pop) ; 28
(push) ; 28
; [else-branch: 837 | pf2_3@157@01]
(assert pf2_3@157@01)
; [eval] !(getCardId(o1_1) == getCardId(o2_1))
; [eval] getCardId(o1_1) == getCardId(o2_1)
; [eval] getCardId(o1_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
; [eval] getCardId(o2_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf2_4@161@01 Bool)
(assert (=
  pf2_4@161@01
  (and
    pf2_3@157@01
    (not (= (getCardId $Snap.unit o1_1@17@01) (getCardId $Snap.unit o2_1@20@01))))))
; [exec]
; pt0_5 := pt0_4 && cardType(o1) > cardType(o2)
; [eval] pt0_4 && cardType(o1) > cardType(o2)
(push) ; 27
; [then-branch: 838 | !(pt0_4@158@01) | live]
; [else-branch: 838 | pt0_4@158@01 | live]
(push) ; 28
; [then-branch: 838 | !(pt0_4@158@01)]
(assert (not pt0_4@158@01))
(pop) ; 28
(push) ; 28
; [else-branch: 838 | pt0_4@158@01]
(assert pt0_4@158@01)
; [eval] cardType(o1) > cardType(o2)
; [eval] cardType(o1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt0_4@158@01
  (and
    pt0_4@158@01
    (cardType%precondition $Snap.unit o1@15@01)
    (cardType%precondition $Snap.unit o2@18@01))))
(assert (or pt0_4@158@01 (not pt0_4@158@01)))
(declare-const pt0_5@162@01 Bool)
(assert (=
  pt0_5@162@01
  (and
    pt0_4@158@01
    (> (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01)))))
; [exec]
; pt1_5 := pt1_4 && cardType(o1_0) > cardType(o2_0)
; [eval] pt1_4 && cardType(o1_0) > cardType(o2_0)
; [exec]
; pt2_5 := pt2_4 && cardType(o1_1) > cardType(o2_1)
; [eval] pt2_4 && cardType(o1_1) > cardType(o2_1)
(push) ; 27
; [then-branch: 839 | !(pt2_4@159@01) | live]
; [else-branch: 839 | pt2_4@159@01 | live]
(push) ; 28
; [then-branch: 839 | !(pt2_4@159@01)]
(assert (not pt2_4@159@01))
(pop) ; 28
(push) ; 28
; [else-branch: 839 | pt2_4@159@01]
(assert pt2_4@159@01)
; [eval] cardType(o1_1) > cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt2_4@159@01
  (and
    pt2_4@159@01
    (cardType%precondition $Snap.unit o1_1@17@01)
    (cardType%precondition $Snap.unit o2_1@20@01))))
(assert (or pt2_4@159@01 (not pt2_4@159@01)))
(declare-const pt2_5@163@01 Bool)
(assert (=
  pt2_5@163@01
  (and
    pt2_4@159@01
    (> (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_5 := pt0_4 && !(cardType(o1) > cardType(o2))
; [eval] pt0_4 && !(cardType(o1) > cardType(o2))
(push) ; 27
; [then-branch: 840 | !(pt0_4@158@01) | live]
; [else-branch: 840 | pt0_4@158@01 | live]
(push) ; 28
; [then-branch: 840 | !(pt0_4@158@01)]
(assert (not pt0_4@158@01))
(pop) ; 28
(push) ; 28
; [else-branch: 840 | pt0_4@158@01]
(assert pt0_4@158@01)
; [eval] !(cardType(o1) > cardType(o2))
; [eval] cardType(o1) > cardType(o2)
; [eval] cardType(o1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf0_5@164@01 Bool)
(assert (=
  pf0_5@164@01
  (and
    pt0_4@158@01
    (not (> (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01))))))
; [exec]
; pf1_5 := pt1_4 && !(cardType(o1_0) > cardType(o2_0))
; [eval] pt1_4 && !(cardType(o1_0) > cardType(o2_0))
; [exec]
; pf2_5 := pt2_4 && !(cardType(o1_1) > cardType(o2_1))
; [eval] pt2_4 && !(cardType(o1_1) > cardType(o2_1))
(push) ; 27
; [then-branch: 841 | !(pt2_4@159@01) | live]
; [else-branch: 841 | pt2_4@159@01 | live]
(push) ; 28
; [then-branch: 841 | !(pt2_4@159@01)]
(assert (not pt2_4@159@01))
(pop) ; 28
(push) ; 28
; [else-branch: 841 | pt2_4@159@01]
(assert pt2_4@159@01)
; [eval] !(cardType(o1_1) > cardType(o2_1))
; [eval] cardType(o1_1) > cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf2_5@165@01 Bool)
(assert (=
  pf2_5@165@01
  (and
    pt2_4@159@01
    (not (> (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01))))))
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not pt0_5@162@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 842 | pt0_5@162@01 | dead]
; [else-branch: 842 | !(pt0_5@162@01) | live]
(set-option :rlimit 0)
(push) ; 27
; [else-branch: 842 | !(pt0_5@162@01)]
(assert (not pt0_5@162@01))
(pop) ; 27
; [eval] !pt0_5
(push) ; 27
(set-option :rlimit 16000)
(assert (not pt0_5@162@01))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not pt0_5@162@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 843 | !(pt0_5@162@01) | live]
; [else-branch: 843 | pt0_5@162@01 | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 843 | !(pt0_5@162@01)]
(assert (not pt0_5@162@01))
; [then-branch: 844 | False | dead]
; [else-branch: 844 | True | live]
(push) ; 28
; [else-branch: 844 | True]
(pop) ; 28
; [eval] !pt1_5
(push) ; 28
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 845 | True | live]
; [else-branch: 845 | False | dead]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 845 | True]
(push) ; 29
(set-option :rlimit 16000)
(assert (not (not pt2_5@163@01)))
(check-sat)
; unsat
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 846 | pt2_5@163@01 | dead]
; [else-branch: 846 | !(pt2_5@163@01) | live]
(set-option :rlimit 0)
(push) ; 29
; [else-branch: 846 | !(pt2_5@163@01)]
(assert (not pt2_5@163@01))
(pop) ; 29
; [eval] !pt2_5
(push) ; 29
(set-option :rlimit 16000)
(assert (not pt2_5@163@01))
(check-sat)
; unknown
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 29
(set-option :rlimit 16000)
(assert (not (not pt2_5@163@01)))
(check-sat)
; unsat
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 847 | !(pt2_5@163@01) | live]
; [else-branch: 847 | pt2_5@163@01 | dead]
(set-option :rlimit 0)
(push) ; 29
; [then-branch: 847 | !(pt2_5@163@01)]
(assert (not pt2_5@163@01))
; [then-branch: 848 | pt0_5@162@01 | dead]
; [else-branch: 848 | !(pt0_5@162@01) | live]
(push) ; 30
; [else-branch: 848 | !(pt0_5@162@01)]
(pop) ; 30
; [eval] !pt0_5
(push) ; 30
(set-option :rlimit 16000)
(assert (not pt0_5@162@01))
(check-sat)
; unknown
(pop) ; 30
; 0.00s
; (get-info :all-statistics)
; [then-branch: 849 | !(pt0_5@162@01) | live]
; [else-branch: 849 | pt0_5@162@01 | dead]
(set-option :rlimit 0)
(push) ; 30
; [then-branch: 849 | !(pt0_5@162@01)]
; [then-branch: 850 | False | dead]
; [else-branch: 850 | True | live]
(push) ; 31
; [else-branch: 850 | True]
(pop) ; 31
; [eval] !pt1_5
(push) ; 31
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 31
; 0.00s
; (get-info :all-statistics)
; [then-branch: 851 | True | live]
; [else-branch: 851 | False | dead]
(set-option :rlimit 0)
(push) ; 31
; [then-branch: 851 | True]
; [then-branch: 852 | pt2_5@163@01 | dead]
; [else-branch: 852 | !(pt2_5@163@01) | live]
(push) ; 32
; [else-branch: 852 | !(pt2_5@163@01)]
(pop) ; 32
; [eval] !pt2_5
(push) ; 32
(set-option :rlimit 16000)
(assert (not pt2_5@163@01))
(check-sat)
; unknown
(pop) ; 32
; 0.00s
; (get-info :all-statistics)
; [then-branch: 853 | !(pt2_5@163@01) | live]
; [else-branch: 853 | pt2_5@163@01 | dead]
(set-option :rlimit 0)
(push) ; 32
; [then-branch: 853 | !(pt2_5@163@01)]
; [exec]
; pt0_6 := pf0_5 && cardType(o1) == cardType(o2)
; [eval] pf0_5 && cardType(o1) == cardType(o2)
(push) ; 33
; [then-branch: 854 | !(pf0_5@164@01) | live]
; [else-branch: 854 | pf0_5@164@01 | live]
(push) ; 34
; [then-branch: 854 | !(pf0_5@164@01)]
(assert (not pf0_5@164@01))
(pop) ; 34
(push) ; 34
; [else-branch: 854 | pf0_5@164@01]
(assert pf0_5@164@01)
; [eval] cardType(o1) == cardType(o2)
; [eval] cardType(o1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_5@164@01
  (and
    pf0_5@164@01
    (cardType%precondition $Snap.unit o1@15@01)
    (cardType%precondition $Snap.unit o2@18@01))))
(assert (or pf0_5@164@01 (not pf0_5@164@01)))
(declare-const pt0_6@166@01 Bool)
(assert (=
  pt0_6@166@01
  (and
    pf0_5@164@01
    (= (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01)))))
; [exec]
; pt1_6 := pf1_5 && cardType(o1_0) == cardType(o2_0)
; [eval] pf1_5 && cardType(o1_0) == cardType(o2_0)
; [exec]
; pt2_6 := pf2_5 && cardType(o1_1) == cardType(o2_1)
; [eval] pf2_5 && cardType(o1_1) == cardType(o2_1)
(push) ; 33
; [then-branch: 855 | !(pf2_5@165@01) | live]
; [else-branch: 855 | pf2_5@165@01 | live]
(push) ; 34
; [then-branch: 855 | !(pf2_5@165@01)]
(assert (not pf2_5@165@01))
(pop) ; 34
(push) ; 34
; [else-branch: 855 | pf2_5@165@01]
(assert pf2_5@165@01)
; [eval] cardType(o1_1) == cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_5@165@01
  (and
    pf2_5@165@01
    (cardType%precondition $Snap.unit o1_1@17@01)
    (cardType%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_5@165@01 (not pf2_5@165@01)))
(declare-const pt2_6@167@01 Bool)
(assert (=
  pt2_6@167@01
  (and
    pf2_5@165@01
    (= (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_6 := pf0_5 && !(cardType(o1) == cardType(o2))
; [eval] pf0_5 && !(cardType(o1) == cardType(o2))
(push) ; 33
; [then-branch: 856 | !(pf0_5@164@01) | live]
; [else-branch: 856 | pf0_5@164@01 | live]
(push) ; 34
; [then-branch: 856 | !(pf0_5@164@01)]
(assert (not pf0_5@164@01))
(pop) ; 34
(push) ; 34
; [else-branch: 856 | pf0_5@164@01]
(assert pf0_5@164@01)
; [eval] !(cardType(o1) == cardType(o2))
; [eval] cardType(o1) == cardType(o2)
; [eval] cardType(o1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf0_6@168@01 Bool)
(assert (=
  pf0_6@168@01
  (and
    pf0_5@164@01
    (not (= (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01))))))
; [exec]
; pf1_6 := pf1_5 && !(cardType(o1_0) == cardType(o2_0))
; [eval] pf1_5 && !(cardType(o1_0) == cardType(o2_0))
; [exec]
; pf2_6 := pf2_5 && !(cardType(o1_1) == cardType(o2_1))
; [eval] pf2_5 && !(cardType(o1_1) == cardType(o2_1))
(push) ; 33
; [then-branch: 857 | !(pf2_5@165@01) | live]
; [else-branch: 857 | pf2_5@165@01 | live]
(push) ; 34
; [then-branch: 857 | !(pf2_5@165@01)]
(assert (not pf2_5@165@01))
(pop) ; 34
(push) ; 34
; [else-branch: 857 | pf2_5@165@01]
(assert pf2_5@165@01)
; [eval] !(cardType(o1_1) == cardType(o2_1))
; [eval] cardType(o1_1) == cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf2_6@169@01 Bool)
(assert (=
  pf2_6@169@01
  (and
    pf2_5@165@01
    (not (= (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01))))))
(push) ; 33
(set-option :rlimit 16000)
(assert (not (not pt0_6@166@01)))
(check-sat)
; unsat
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 858 | pt0_6@166@01 | dead]
; [else-branch: 858 | !(pt0_6@166@01) | live]
(set-option :rlimit 0)
(push) ; 33
; [else-branch: 858 | !(pt0_6@166@01)]
(assert (not pt0_6@166@01))
(pop) ; 33
; [eval] !pt0_6
(push) ; 33
(set-option :rlimit 16000)
(assert (not pt0_6@166@01))
(check-sat)
; unknown
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 33
(set-option :rlimit 16000)
(assert (not (not pt0_6@166@01)))
(check-sat)
; unsat
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 859 | !(pt0_6@166@01) | live]
; [else-branch: 859 | pt0_6@166@01 | dead]
(set-option :rlimit 0)
(push) ; 33
; [then-branch: 859 | !(pt0_6@166@01)]
(assert (not pt0_6@166@01))
; [then-branch: 860 | False | dead]
; [else-branch: 860 | True | live]
(push) ; 34
; [else-branch: 860 | True]
(pop) ; 34
; [eval] !pt1_6
(push) ; 34
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 861 | True | live]
; [else-branch: 861 | False | dead]
(set-option :rlimit 0)
(push) ; 34
; [then-branch: 861 | True]
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@167@01)))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 862 | pt2_6@167@01 | dead]
; [else-branch: 862 | !(pt2_6@167@01) | live]
(set-option :rlimit 0)
(push) ; 35
; [else-branch: 862 | !(pt2_6@167@01)]
(assert (not pt2_6@167@01))
(pop) ; 35
; [eval] !pt2_6
(push) ; 35
(set-option :rlimit 16000)
(assert (not pt2_6@167@01))
(check-sat)
; unknown
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@167@01)))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 863 | !(pt2_6@167@01) | live]
; [else-branch: 863 | pt2_6@167@01 | dead]
(set-option :rlimit 0)
(push) ; 35
; [then-branch: 863 | !(pt2_6@167@01)]
(assert (not pt2_6@167@01))
; [then-branch: 864 | pt0_6@166@01 | dead]
; [else-branch: 864 | !(pt0_6@166@01) | live]
(push) ; 36
; [else-branch: 864 | !(pt0_6@166@01)]
(pop) ; 36
; [eval] !pt0_6
(push) ; 36
(set-option :rlimit 16000)
(assert (not pt0_6@166@01))
(check-sat)
; unknown
(pop) ; 36
; 0.00s
; (get-info :all-statistics)
; [then-branch: 865 | !(pt0_6@166@01) | live]
; [else-branch: 865 | pt0_6@166@01 | dead]
(set-option :rlimit 0)
(push) ; 36
; [then-branch: 865 | !(pt0_6@166@01)]
; [then-branch: 866 | False | dead]
; [else-branch: 866 | True | live]
(push) ; 37
; [else-branch: 866 | True]
(pop) ; 37
; [eval] !pt1_6
(push) ; 37
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 37
; 0.00s
; (get-info :all-statistics)
; [then-branch: 867 | True | live]
; [else-branch: 867 | False | dead]
(set-option :rlimit 0)
(push) ; 37
; [then-branch: 867 | True]
; [then-branch: 868 | pt2_6@167@01 | dead]
; [else-branch: 868 | !(pt2_6@167@01) | live]
(push) ; 38
; [else-branch: 868 | !(pt2_6@167@01)]
(pop) ; 38
; [eval] !pt2_6
(push) ; 38
(set-option :rlimit 16000)
(assert (not pt2_6@167@01))
(check-sat)
; unknown
(pop) ; 38
; 0.00s
; (get-info :all-statistics)
; [then-branch: 869 | !(pt2_6@167@01) | live]
; [else-branch: 869 | pt2_6@167@01 | dead]
(set-option :rlimit 0)
(push) ; 38
; [then-branch: 869 | !(pt2_6@167@01)]
(push) ; 39
(set-option :rlimit 16000)
(assert (not (not pf0_6@168@01)))
(check-sat)
; unsat
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 870 | pf0_6@168@01 | dead]
; [else-branch: 870 | !(pf0_6@168@01) | live]
(set-option :rlimit 0)
(push) ; 39
; [else-branch: 870 | !(pf0_6@168@01)]
(assert (not pf0_6@168@01))
(pop) ; 39
; [eval] !pf0_6
(push) ; 39
(set-option :rlimit 16000)
(assert (not pf0_6@168@01))
(check-sat)
; unknown
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 39
(set-option :rlimit 16000)
(assert (not (not pf0_6@168@01)))
(check-sat)
; unsat
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 871 | !(pf0_6@168@01) | live]
; [else-branch: 871 | pf0_6@168@01 | dead]
(set-option :rlimit 0)
(push) ; 39
; [then-branch: 871 | !(pf0_6@168@01)]
(assert (not pf0_6@168@01))
; [then-branch: 872 | False | dead]
; [else-branch: 872 | True | live]
(push) ; 40
; [else-branch: 872 | True]
(pop) ; 40
; [eval] !pf1_6
(push) ; 40
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 873 | True | live]
; [else-branch: 873 | False | dead]
(set-option :rlimit 0)
(push) ; 40
; [then-branch: 873 | True]
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@169@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 874 | pf2_6@169@01 | dead]
; [else-branch: 874 | !(pf2_6@169@01) | live]
(set-option :rlimit 0)
(push) ; 41
; [else-branch: 874 | !(pf2_6@169@01)]
(assert (not pf2_6@169@01))
(pop) ; 41
; [eval] !pf2_6
(push) ; 41
(set-option :rlimit 16000)
(assert (not pf2_6@169@01))
(check-sat)
; unknown
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@169@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 875 | !(pf2_6@169@01) | live]
; [else-branch: 875 | pf2_6@169@01 | dead]
(set-option :rlimit 0)
(push) ; 41
; [then-branch: 875 | !(pf2_6@169@01)]
(assert (not pf2_6@169@01))
; [then-branch: 876 | pf0_6@168@01 | dead]
; [else-branch: 876 | !(pf0_6@168@01) | live]
(push) ; 42
; [else-branch: 876 | !(pf0_6@168@01)]
(pop) ; 42
; [eval] !pf0_6
(push) ; 42
(set-option :rlimit 16000)
(assert (not pf0_6@168@01))
(check-sat)
; unknown
(pop) ; 42
; 0.00s
; (get-info :all-statistics)
; [then-branch: 877 | !(pf0_6@168@01) | live]
; [else-branch: 877 | pf0_6@168@01 | dead]
(set-option :rlimit 0)
(push) ; 42
; [then-branch: 877 | !(pf0_6@168@01)]
; [then-branch: 878 | False | dead]
; [else-branch: 878 | True | live]
(push) ; 43
; [else-branch: 878 | True]
(pop) ; 43
; [eval] !pf1_6
(push) ; 43
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 43
; 0.00s
; (get-info :all-statistics)
; [then-branch: 879 | True | live]
; [else-branch: 879 | False | dead]
(set-option :rlimit 0)
(push) ; 43
; [then-branch: 879 | True]
; [then-branch: 880 | pf2_6@169@01 | dead]
; [else-branch: 880 | !(pf2_6@169@01) | live]
(push) ; 44
; [else-branch: 880 | !(pf2_6@169@01)]
(pop) ; 44
; [eval] !pf2_6
(push) ; 44
(set-option :rlimit 16000)
(assert (not pf2_6@169@01))
(check-sat)
; unknown
(pop) ; 44
; 0.00s
; (get-info :all-statistics)
; [then-branch: 881 | !(pf2_6@169@01) | live]
; [else-branch: 881 | pf2_6@169@01 | dead]
(set-option :rlimit 0)
(push) ; 44
; [then-branch: 881 | !(pf2_6@169@01)]
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@160@01)))
(check-sat)
; unsat
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 882 | pf0_4@160@01 | dead]
; [else-branch: 882 | !(pf0_4@160@01) | live]
(set-option :rlimit 0)
(push) ; 45
; [else-branch: 882 | !(pf0_4@160@01)]
(assert (not pf0_4@160@01))
(pop) ; 45
; [eval] !pf0_4
(push) ; 45
(set-option :rlimit 16000)
(assert (not pf0_4@160@01))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@160@01)))
(check-sat)
; unsat
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 883 | !(pf0_4@160@01) | live]
; [else-branch: 883 | pf0_4@160@01 | dead]
(set-option :rlimit 0)
(push) ; 45
; [then-branch: 883 | !(pf0_4@160@01)]
(assert (not pf0_4@160@01))
; [then-branch: 884 | False | dead]
; [else-branch: 884 | True | live]
(push) ; 46
; [else-branch: 884 | True]
(pop) ; 46
; [eval] !pf1_4
(push) ; 46
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 885 | True | live]
; [else-branch: 885 | False | dead]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 885 | True]
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@161@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 886 | pf2_4@161@01 | dead]
; [else-branch: 886 | !(pf2_4@161@01) | live]
(set-option :rlimit 0)
(push) ; 47
; [else-branch: 886 | !(pf2_4@161@01)]
(assert (not pf2_4@161@01))
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not pf2_4@161@01))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@161@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 887 | !(pf2_4@161@01) | live]
; [else-branch: 887 | pf2_4@161@01 | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 887 | !(pf2_4@161@01)]
(assert (not pf2_4@161@01))
; [then-branch: 888 | pf0_4@160@01 | dead]
; [else-branch: 888 | !(pf0_4@160@01) | live]
(push) ; 48
; [else-branch: 888 | !(pf0_4@160@01)]
(pop) ; 48
; [eval] !pf0_4
(push) ; 48
(set-option :rlimit 16000)
(assert (not pf0_4@160@01))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 889 | !(pf0_4@160@01) | live]
; [else-branch: 889 | pf0_4@160@01 | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 889 | !(pf0_4@160@01)]
; [then-branch: 890 | False | dead]
; [else-branch: 890 | True | live]
(push) ; 49
; [else-branch: 890 | True]
(pop) ; 49
; [eval] !pf1_4
(push) ; 49
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 891 | True | live]
; [else-branch: 891 | False | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 891 | True]
; [then-branch: 892 | pf2_4@161@01 | dead]
; [else-branch: 892 | !(pf2_4@161@01) | live]
(push) ; 50
; [else-branch: 892 | !(pf2_4@161@01)]
(pop) ; 50
; [eval] !pf2_4
(push) ; 50
(set-option :rlimit 16000)
(assert (not pf2_4@161@01))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 893 | !(pf2_4@161@01) | live]
; [else-branch: 893 | pf2_4@161@01 | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 893 | !(pf2_4@161@01)]
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@152@01)))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 894 | pf0_2@152@01 | dead]
; [else-branch: 894 | !(pf0_2@152@01) | live]
(set-option :rlimit 0)
(push) ; 51
; [else-branch: 894 | !(pf0_2@152@01)]
(assert (not pf0_2@152@01))
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not pf0_2@152@01))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@152@01)))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 895 | !(pf0_2@152@01) | live]
; [else-branch: 895 | pf0_2@152@01 | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 895 | !(pf0_2@152@01)]
(assert (not pf0_2@152@01))
; [then-branch: 896 | False | dead]
; [else-branch: 896 | True | live]
(push) ; 52
; [else-branch: 896 | True]
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 897 | True | live]
; [else-branch: 897 | False | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 897 | True]
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@153@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 898 | pf2_2@153@01 | dead]
; [else-branch: 898 | !(pf2_2@153@01) | live]
(set-option :rlimit 0)
(push) ; 53
; [else-branch: 898 | !(pf2_2@153@01)]
(assert (not pf2_2@153@01))
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not pf2_2@153@01))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@153@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 899 | !(pf2_2@153@01) | live]
; [else-branch: 899 | pf2_2@153@01 | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 899 | !(pf2_2@153@01)]
(assert (not pf2_2@153@01))
; [then-branch: 900 | pf0_2@152@01 | dead]
; [else-branch: 900 | !(pf0_2@152@01) | live]
(push) ; 54
; [else-branch: 900 | !(pf0_2@152@01)]
(pop) ; 54
; [eval] !pf0_2
(push) ; 54
(set-option :rlimit 16000)
(assert (not pf0_2@152@01))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 901 | !(pf0_2@152@01) | live]
; [else-branch: 901 | pf0_2@152@01 | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 901 | !(pf0_2@152@01)]
; [then-branch: 902 | False | dead]
; [else-branch: 902 | True | live]
(push) ; 55
; [else-branch: 902 | True]
(pop) ; 55
; [eval] !pf1_2
(push) ; 55
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 903 | True | live]
; [else-branch: 903 | False | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 903 | True]
; [then-branch: 904 | pf2_2@153@01 | dead]
; [else-branch: 904 | !(pf2_2@153@01) | live]
(push) ; 56
; [else-branch: 904 | !(pf2_2@153@01)]
(pop) ; 56
; [eval] !pf2_2
(push) ; 56
(set-option :rlimit 16000)
(assert (not pf2_2@153@01))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 905 | !(pf2_2@153@01) | live]
; [else-branch: 905 | pf2_2@153@01 | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 905 | !(pf2_2@153@01)]
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 906 | p0@12@01 | live]
; [else-branch: 906 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 906 | p0@12@01]
(assert p0@12@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 907 | p1@13@01 | live]
; [else-branch: 907 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 907 | p1@13@01]
(assert p1@13@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p1@13@01)
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 908 | p2@14@01 | live]
; [else-branch: 908 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 908 | p2@14@01]
(assert p2@14@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p2@14@01)
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 909 | p0@12@01 | live]
; [else-branch: 909 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 909 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 910 | False | live]
; [else-branch: 910 | True | live]
(push) ; 60
; [then-branch: 910 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 910 | True]
(push) ; 61
; [then-branch: 911 | !(p0@12@01) | live]
; [else-branch: 911 | p0@12@01 | live]
(push) ; 62
; [then-branch: 911 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 911 | p0@12@01]
(push) ; 63
; [then-branch: 912 | !(p1@13@01) | live]
; [else-branch: 912 | p1@13@01 | live]
(push) ; 64
; [then-branch: 912 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 912 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 913 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 913 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 913 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 914 | False | dead]
; [else-branch: 914 | True | live]
(push) ; 62
; [else-branch: 914 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 915 | p1@13@01 | live]
; [else-branch: 915 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 915 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 916 | False | live]
; [else-branch: 916 | True | live]
(push) ; 60
; [then-branch: 916 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 916 | True]
(push) ; 61
; [then-branch: 917 | !(p0@12@01) | live]
; [else-branch: 917 | p0@12@01 | live]
(push) ; 62
; [then-branch: 917 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 917 | p0@12@01]
(push) ; 63
; [then-branch: 918 | !(p1@13@01) | live]
; [else-branch: 918 | p1@13@01 | live]
(push) ; 64
; [then-branch: 918 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 918 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 919 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 919 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 919 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 920 | False | dead]
; [else-branch: 920 | True | live]
(push) ; 62
; [else-branch: 920 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p2@14@01)))
(assert p1@13@01)
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 921 | p2@14@01 | live]
; [else-branch: 921 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 921 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 922 | False | live]
; [else-branch: 922 | True | live]
(push) ; 60
; [then-branch: 922 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 922 | True]
(push) ; 61
; [then-branch: 923 | !(p0@12@01) | live]
; [else-branch: 923 | p0@12@01 | live]
(push) ; 62
; [then-branch: 923 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 923 | p0@12@01]
(assert p0@12@01)
(push) ; 63
; [then-branch: 924 | !(p1@13@01) | live]
; [else-branch: 924 | p1@13@01 | live]
(push) ; 64
; [then-branch: 924 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 924 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 925 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 925 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 925 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 926 | False | dead]
; [else-branch: 926 | True | live]
(push) ; 62
; [else-branch: 926 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01)))
(assert p2@14@01)
(pop) ; 56
(pop) ; 55
(pop) ; 54
(pop) ; 53
(pop) ; 52
(pop) ; 51
(pop) ; 50
(pop) ; 49
(pop) ; 48
(pop) ; 47
(pop) ; 46
(pop) ; 45
(pop) ; 44
(pop) ; 43
(pop) ; 42
(pop) ; 41
(pop) ; 40
(pop) ; 39
(pop) ; 38
(pop) ; 37
(pop) ; 36
(pop) ; 35
(pop) ; 34
(pop) ; 33
(pop) ; 32
(pop) ; 31
(pop) ; 30
(pop) ; 29
(pop) ; 28
(pop) ; 27
(pop) ; 26
(pop) ; 25
(pop) ; 24
(pop) ; 23
(pop) ; 22
(pop) ; 21
(pop) ; 20
; [eval] !pt2_1
; [then-branch: 927 | !(pt2_1@147@01) | dead]
; [else-branch: 927 | pt2_1@147@01 | live]
(push) ; 20
; [else-branch: 927 | pt2_1@147@01]
(pop) ; 20
(pop) ; 19
(pop) ; 18
; [eval] !pt0_1
; [then-branch: 928 | !(pt0_1@146@01) | dead]
; [else-branch: 928 | pt0_1@146@01 | live]
(push) ; 18
; [else-branch: 928 | pt0_1@146@01]
(pop) ; 18
(pop) ; 17
; [eval] !pt2_1
(push) ; 17
(set-option :rlimit 16000)
(assert (not pt2_1@147@01))
(check-sat)
; unsat
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
; [then-branch: 929 | !(pt2_1@147@01) | dead]
; [else-branch: 929 | pt2_1@147@01 | live]
(set-option :rlimit 0)
(push) ; 17
; [else-branch: 929 | pt2_1@147@01]
(assert pt2_1@147@01)
(pop) ; 17
(pop) ; 16
(pop) ; 15
(push) ; 15
; [else-branch: 806 | !(pt0_1@146@01)]
(assert (not pt0_1@146@01))
(pop) ; 15
; [eval] !pt0_1
(push) ; 15
(set-option :rlimit 16000)
(assert (not pt0_1@146@01))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 16000)
(assert (not (not pt0_1@146@01)))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
; [then-branch: 930 | !(pt0_1@146@01) | live]
; [else-branch: 930 | pt0_1@146@01 | live]
(set-option :rlimit 0)
(push) ; 15
; [then-branch: 930 | !(pt0_1@146@01)]
(assert (not pt0_1@146@01))
; [then-branch: 931 | False | dead]
; [else-branch: 931 | True | live]
(push) ; 16
; [else-branch: 931 | True]
(pop) ; 16
; [eval] !pt1_1
(push) ; 16
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [then-branch: 932 | True | live]
; [else-branch: 932 | False | dead]
(set-option :rlimit 0)
(push) ; 16
; [then-branch: 932 | True]
(push) ; 17
(set-option :rlimit 16000)
(assert (not (not pt2_1@147@01)))
(check-sat)
; unsat
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
; [then-branch: 933 | pt2_1@147@01 | dead]
; [else-branch: 933 | !(pt2_1@147@01) | live]
(set-option :rlimit 0)
(push) ; 17
; [else-branch: 933 | !(pt2_1@147@01)]
(assert (not pt2_1@147@01))
(pop) ; 17
; [eval] !pt2_1
(push) ; 17
(set-option :rlimit 16000)
(assert (not pt2_1@147@01))
(check-sat)
; unknown
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 17
(set-option :rlimit 16000)
(assert (not (not pt2_1@147@01)))
(check-sat)
; unsat
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
; [then-branch: 934 | !(pt2_1@147@01) | live]
; [else-branch: 934 | pt2_1@147@01 | dead]
(set-option :rlimit 0)
(push) ; 17
; [then-branch: 934 | !(pt2_1@147@01)]
(assert (not pt2_1@147@01))
; [then-branch: 935 | pt0_1@146@01 | dead]
; [else-branch: 935 | !(pt0_1@146@01) | live]
(push) ; 18
; [else-branch: 935 | !(pt0_1@146@01)]
(pop) ; 18
; [eval] !pt0_1
(push) ; 18
(set-option :rlimit 16000)
(assert (not pt0_1@146@01))
(check-sat)
; unknown
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
; [then-branch: 936 | !(pt0_1@146@01) | live]
; [else-branch: 936 | pt0_1@146@01 | dead]
(set-option :rlimit 0)
(push) ; 18
; [then-branch: 936 | !(pt0_1@146@01)]
; [then-branch: 937 | False | dead]
; [else-branch: 937 | True | live]
(push) ; 19
; [else-branch: 937 | True]
(pop) ; 19
; [eval] !pt1_1
(push) ; 19
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 938 | True | live]
; [else-branch: 938 | False | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 938 | True]
; [then-branch: 939 | pt2_1@147@01 | dead]
; [else-branch: 939 | !(pt2_1@147@01) | live]
(push) ; 20
; [else-branch: 939 | !(pt2_1@147@01)]
(pop) ; 20
; [eval] !pt2_1
(push) ; 20
(set-option :rlimit 16000)
(assert (not pt2_1@147@01))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 940 | !(pt2_1@147@01) | live]
; [else-branch: 940 | pt2_1@147@01 | dead]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 940 | !(pt2_1@147@01)]
; [exec]
; pt0_2 := pf0_1 && getCardSet(o1) == getCardSet(o2)
; [eval] pf0_1 && getCardSet(o1) == getCardSet(o2)
(push) ; 21
; [then-branch: 941 | !(pf0_1@148@01) | live]
; [else-branch: 941 | pf0_1@148@01 | live]
(push) ; 22
; [then-branch: 941 | !(pf0_1@148@01)]
(assert (not pf0_1@148@01))
(pop) ; 22
(push) ; 22
; [else-branch: 941 | pf0_1@148@01]
(assert pf0_1@148@01)
; [eval] getCardSet(o1) == getCardSet(o2)
; [eval] getCardSet(o1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1@15@01))
; [eval] getCardSet(o2)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_1@148@01
  (and
    pf0_1@148@01
    (getCardSet%precondition $Snap.unit o1@15@01)
    (getCardSet%precondition $Snap.unit o2@18@01))))
(assert (or pf0_1@148@01 (not pf0_1@148@01)))
(declare-const pt0_2@170@01 Bool)
(assert (=
  pt0_2@170@01
  (and
    pf0_1@148@01
    (= (getCardSet $Snap.unit o1@15@01) (getCardSet $Snap.unit o2@18@01)))))
; [exec]
; pt1_2 := pf1_1 && getCardSet(o1_0) == getCardSet(o2_0)
; [eval] pf1_1 && getCardSet(o1_0) == getCardSet(o2_0)
; [exec]
; pt2_2 := pf2_1 && getCardSet(o1_1) == getCardSet(o2_1)
; [eval] pf2_1 && getCardSet(o1_1) == getCardSet(o2_1)
(push) ; 21
; [then-branch: 942 | !(pf2_1@149@01) | live]
; [else-branch: 942 | pf2_1@149@01 | live]
(push) ; 22
; [then-branch: 942 | !(pf2_1@149@01)]
(assert (not pf2_1@149@01))
(pop) ; 22
(push) ; 22
; [else-branch: 942 | pf2_1@149@01]
(assert pf2_1@149@01)
; [eval] getCardSet(o1_1) == getCardSet(o2_1)
; [eval] getCardSet(o1_1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
; [eval] getCardSet(o2_1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_1@149@01
  (and
    pf2_1@149@01
    (getCardSet%precondition $Snap.unit o1_1@17@01)
    (getCardSet%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_1@149@01 (not pf2_1@149@01)))
(declare-const pt2_2@171@01 Bool)
(assert (=
  pt2_2@171@01
  (and
    pf2_1@149@01
    (= (getCardSet $Snap.unit o1_1@17@01) (getCardSet $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_2 := pf0_1 && !(getCardSet(o1) == getCardSet(o2))
; [eval] pf0_1 && !(getCardSet(o1) == getCardSet(o2))
(push) ; 21
; [then-branch: 943 | !(pf0_1@148@01) | live]
; [else-branch: 943 | pf0_1@148@01 | live]
(push) ; 22
; [then-branch: 943 | !(pf0_1@148@01)]
(assert (not pf0_1@148@01))
(pop) ; 22
(push) ; 22
; [else-branch: 943 | pf0_1@148@01]
(assert pf0_1@148@01)
; [eval] !(getCardSet(o1) == getCardSet(o2))
; [eval] getCardSet(o1) == getCardSet(o2)
; [eval] getCardSet(o1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1@15@01))
; [eval] getCardSet(o2)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf0_2@172@01 Bool)
(assert (=
  pf0_2@172@01
  (and
    pf0_1@148@01
    (not (= (getCardSet $Snap.unit o1@15@01) (getCardSet $Snap.unit o2@18@01))))))
; [exec]
; pf1_2 := pf1_1 && !(getCardSet(o1_0) == getCardSet(o2_0))
; [eval] pf1_1 && !(getCardSet(o1_0) == getCardSet(o2_0))
; [exec]
; pf2_2 := pf2_1 && !(getCardSet(o1_1) == getCardSet(o2_1))
; [eval] pf2_1 && !(getCardSet(o1_1) == getCardSet(o2_1))
(push) ; 21
; [then-branch: 944 | !(pf2_1@149@01) | live]
; [else-branch: 944 | pf2_1@149@01 | live]
(push) ; 22
; [then-branch: 944 | !(pf2_1@149@01)]
(assert (not pf2_1@149@01))
(pop) ; 22
(push) ; 22
; [else-branch: 944 | pf2_1@149@01]
(assert pf2_1@149@01)
; [eval] !(getCardSet(o1_1) == getCardSet(o2_1))
; [eval] getCardSet(o1_1) == getCardSet(o2_1)
; [eval] getCardSet(o1_1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_1@17@01))
; [eval] getCardSet(o2_1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_1@20@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf2_2@173@01 Bool)
(assert (=
  pf2_2@173@01
  (and
    pf2_1@149@01
    (not
      (= (getCardSet $Snap.unit o1_1@17@01) (getCardSet $Snap.unit o2_1@20@01))))))
; [exec]
; pt0_3 := pt0_2 && getCardRarity(o1) < getCardRarity(o2)
; [eval] pt0_2 && getCardRarity(o1) < getCardRarity(o2)
(push) ; 21
; [then-branch: 945 | !(pt0_2@170@01) | live]
; [else-branch: 945 | pt0_2@170@01 | live]
(push) ; 22
; [then-branch: 945 | !(pt0_2@170@01)]
(assert (not pt0_2@170@01))
(pop) ; 22
(push) ; 22
; [else-branch: 945 | pt0_2@170@01]
(assert pt0_2@170@01)
; [eval] getCardRarity(o1) < getCardRarity(o2)
; [eval] getCardRarity(o1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
; [eval] getCardRarity(o2)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pt0_2@170@01
  (and
    pt0_2@170@01
    (getCardRarity%precondition $Snap.unit o1@15@01)
    (getCardRarity%precondition $Snap.unit o2@18@01))))
(assert (or pt0_2@170@01 (not pt0_2@170@01)))
(declare-const pt0_3@174@01 Bool)
(assert (=
  pt0_3@174@01
  (and
    pt0_2@170@01
    (< (getCardRarity $Snap.unit o1@15@01) (getCardRarity $Snap.unit o2@18@01)))))
; [exec]
; pt1_3 := pt1_2 && getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] pt1_2 && getCardRarity(o1_0) < getCardRarity(o2_0)
; [exec]
; pt2_3 := pt2_2 && getCardRarity(o1_1) < getCardRarity(o2_1)
; [eval] pt2_2 && getCardRarity(o1_1) < getCardRarity(o2_1)
(push) ; 21
; [then-branch: 946 | !(pt2_2@171@01) | live]
; [else-branch: 946 | pt2_2@171@01 | live]
(push) ; 22
; [then-branch: 946 | !(pt2_2@171@01)]
(assert (not pt2_2@171@01))
(pop) ; 22
(push) ; 22
; [else-branch: 946 | pt2_2@171@01]
(assert pt2_2@171@01)
; [eval] getCardRarity(o1_1) < getCardRarity(o2_1)
; [eval] getCardRarity(o1_1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_1@17@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_1@17@01))
; [eval] getCardRarity(o2_1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_1@20@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_1@20@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pt2_2@171@01
  (and
    pt2_2@171@01
    (getCardRarity%precondition $Snap.unit o1_1@17@01)
    (getCardRarity%precondition $Snap.unit o2_1@20@01))))
(assert (or pt2_2@171@01 (not pt2_2@171@01)))
(declare-const pt2_3@175@01 Bool)
(assert (=
  pt2_3@175@01
  (and
    pt2_2@171@01
    (<
      (getCardRarity $Snap.unit o1_1@17@01)
      (getCardRarity $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_3 := pt0_2 && !(getCardRarity(o1) < getCardRarity(o2))
; [eval] pt0_2 && !(getCardRarity(o1) < getCardRarity(o2))
(push) ; 21
; [then-branch: 947 | !(pt0_2@170@01) | live]
; [else-branch: 947 | pt0_2@170@01 | live]
(push) ; 22
; [then-branch: 947 | !(pt0_2@170@01)]
(assert (not pt0_2@170@01))
(pop) ; 22
(push) ; 22
; [else-branch: 947 | pt0_2@170@01]
(assert pt0_2@170@01)
; [eval] !(getCardRarity(o1) < getCardRarity(o2))
; [eval] getCardRarity(o1) < getCardRarity(o2)
; [eval] getCardRarity(o1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
; [eval] getCardRarity(o2)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf0_3@176@01 Bool)
(assert (=
  pf0_3@176@01
  (and
    pt0_2@170@01
    (not
      (< (getCardRarity $Snap.unit o1@15@01) (getCardRarity $Snap.unit o2@18@01))))))
; [exec]
; pf1_3 := pt1_2 && !(getCardRarity(o1_0) < getCardRarity(o2_0))
; [eval] pt1_2 && !(getCardRarity(o1_0) < getCardRarity(o2_0))
; [exec]
; pf2_3 := pt2_2 && !(getCardRarity(o1_1) < getCardRarity(o2_1))
; [eval] pt2_2 && !(getCardRarity(o1_1) < getCardRarity(o2_1))
(push) ; 21
; [then-branch: 948 | !(pt2_2@171@01) | live]
; [else-branch: 948 | pt2_2@171@01 | live]
(push) ; 22
; [then-branch: 948 | !(pt2_2@171@01)]
(assert (not pt2_2@171@01))
(pop) ; 22
(push) ; 22
; [else-branch: 948 | pt2_2@171@01]
(assert pt2_2@171@01)
; [eval] !(getCardRarity(o1_1) < getCardRarity(o2_1))
; [eval] getCardRarity(o1_1) < getCardRarity(o2_1)
; [eval] getCardRarity(o1_1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_1@17@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_1@17@01))
; [eval] getCardRarity(o2_1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_1@20@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_1@20@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf2_3@177@01 Bool)
(assert (=
  pf2_3@177@01
  (and
    pt2_2@171@01
    (not
      (<
        (getCardRarity $Snap.unit o1_1@17@01)
        (getCardRarity $Snap.unit o2_1@20@01))))))
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt0_3@174@01)))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not pt0_3@174@01))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 949 | pt0_3@174@01 | live]
; [else-branch: 949 | !(pt0_3@174@01) | live]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 949 | pt0_3@174@01]
(assert pt0_3@174@01)
; [exec]
; res := 1
; [then-branch: 950 | False | dead]
; [else-branch: 950 | True | live]
(push) ; 22
; [else-branch: 950 | True]
(pop) ; 22
; [eval] !pt1_3
(push) ; 22
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 951 | True | live]
; [else-branch: 951 | False | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 951 | True]
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not pt2_3@175@01)))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 23
(set-option :rlimit 16000)
(assert (not pt2_3@175@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 952 | pt2_3@175@01 | live]
; [else-branch: 952 | !(pt2_3@175@01) | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 952 | pt2_3@175@01]
(assert pt2_3@175@01)
; [exec]
; res_1 := 1
(push) ; 24
(set-option :rlimit 16000)
(assert (not (not pt0_3@174@01)))
(check-sat)
; unknown
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
; [then-branch: 953 | pt0_3@174@01 | live]
; [else-branch: 953 | !(pt0_3@174@01) | dead]
(set-option :rlimit 0)
(push) ; 24
; [then-branch: 953 | pt0_3@174@01]
; [exec]
; returned := true
; [then-branch: 954 | False | dead]
; [else-branch: 954 | True | live]
(push) ; 25
; [else-branch: 954 | True]
(pop) ; 25
; [eval] !pt1_3
(push) ; 25
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 955 | True | live]
; [else-branch: 955 | False | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 955 | True]
(push) ; 26
(set-option :rlimit 16000)
(assert (not (not pt2_3@175@01)))
(check-sat)
; unknown
(pop) ; 26
; 0.00s
; (get-info :all-statistics)
; [then-branch: 956 | pt2_3@175@01 | live]
; [else-branch: 956 | !(pt2_3@175@01) | dead]
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 956 | pt2_3@175@01]
; [exec]
; returned_1 := true
; [exec]
; pt0_4 := pf0_3 && getCardId(o1) == getCardId(o2)
; [eval] pf0_3 && getCardId(o1) == getCardId(o2)
(push) ; 27
; [then-branch: 957 | !(pf0_3@176@01) | live]
; [else-branch: 957 | pf0_3@176@01 | live]
(push) ; 28
; [then-branch: 957 | !(pf0_3@176@01)]
(assert (not pf0_3@176@01))
(pop) ; 28
(push) ; 28
; [else-branch: 957 | pf0_3@176@01]
(assert pf0_3@176@01)
; [eval] getCardId(o1) == getCardId(o2)
; [eval] getCardId(o1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1@15@01))
; [eval] getCardId(o2)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_3@176@01
  (and
    pf0_3@176@01
    (getCardId%precondition $Snap.unit o1@15@01)
    (getCardId%precondition $Snap.unit o2@18@01))))
(assert (or pf0_3@176@01 (not pf0_3@176@01)))
(declare-const pt0_4@178@01 Bool)
(assert (=
  pt0_4@178@01
  (and
    pf0_3@176@01
    (= (getCardId $Snap.unit o1@15@01) (getCardId $Snap.unit o2@18@01)))))
; [exec]
; pt1_4 := pf1_3 && getCardId(o1_0) == getCardId(o2_0)
; [eval] pf1_3 && getCardId(o1_0) == getCardId(o2_0)
; [exec]
; pt2_4 := pf2_3 && getCardId(o1_1) == getCardId(o2_1)
; [eval] pf2_3 && getCardId(o1_1) == getCardId(o2_1)
(push) ; 27
; [then-branch: 958 | !(pf2_3@177@01) | live]
; [else-branch: 958 | pf2_3@177@01 | live]
(push) ; 28
; [then-branch: 958 | !(pf2_3@177@01)]
(assert (not pf2_3@177@01))
(pop) ; 28
(push) ; 28
; [else-branch: 958 | pf2_3@177@01]
(assert pf2_3@177@01)
; [eval] getCardId(o1_1) == getCardId(o2_1)
; [eval] getCardId(o1_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
; [eval] getCardId(o2_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_3@177@01
  (and
    pf2_3@177@01
    (getCardId%precondition $Snap.unit o1_1@17@01)
    (getCardId%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_3@177@01 (not pf2_3@177@01)))
(declare-const pt2_4@179@01 Bool)
(assert (=
  pt2_4@179@01
  (and
    pf2_3@177@01
    (= (getCardId $Snap.unit o1_1@17@01) (getCardId $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_4 := pf0_3 && !(getCardId(o1) == getCardId(o2))
; [eval] pf0_3 && !(getCardId(o1) == getCardId(o2))
(push) ; 27
; [then-branch: 959 | !(pf0_3@176@01) | live]
; [else-branch: 959 | pf0_3@176@01 | live]
(push) ; 28
; [then-branch: 959 | !(pf0_3@176@01)]
(assert (not pf0_3@176@01))
(pop) ; 28
(push) ; 28
; [else-branch: 959 | pf0_3@176@01]
(assert pf0_3@176@01)
; [eval] !(getCardId(o1) == getCardId(o2))
; [eval] getCardId(o1) == getCardId(o2)
; [eval] getCardId(o1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1@15@01))
; [eval] getCardId(o2)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf0_4@180@01 Bool)
(assert (=
  pf0_4@180@01
  (and
    pf0_3@176@01
    (not (= (getCardId $Snap.unit o1@15@01) (getCardId $Snap.unit o2@18@01))))))
; [exec]
; pf1_4 := pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
; [eval] pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
; [exec]
; pf2_4 := pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
; [eval] pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
(push) ; 27
; [then-branch: 960 | !(pf2_3@177@01) | live]
; [else-branch: 960 | pf2_3@177@01 | live]
(push) ; 28
; [then-branch: 960 | !(pf2_3@177@01)]
(assert (not pf2_3@177@01))
(pop) ; 28
(push) ; 28
; [else-branch: 960 | pf2_3@177@01]
(assert pf2_3@177@01)
; [eval] !(getCardId(o1_1) == getCardId(o2_1))
; [eval] getCardId(o1_1) == getCardId(o2_1)
; [eval] getCardId(o1_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
; [eval] getCardId(o2_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf2_4@181@01 Bool)
(assert (=
  pf2_4@181@01
  (and
    pf2_3@177@01
    (not (= (getCardId $Snap.unit o1_1@17@01) (getCardId $Snap.unit o2_1@20@01))))))
; [exec]
; pt0_5 := pt0_4 && cardType(o1) > cardType(o2)
; [eval] pt0_4 && cardType(o1) > cardType(o2)
(push) ; 27
; [then-branch: 961 | !(pt0_4@178@01) | live]
; [else-branch: 961 | pt0_4@178@01 | live]
(push) ; 28
; [then-branch: 961 | !(pt0_4@178@01)]
(assert (not pt0_4@178@01))
(pop) ; 28
(push) ; 28
; [else-branch: 961 | pt0_4@178@01]
(assert pt0_4@178@01)
; [eval] cardType(o1) > cardType(o2)
; [eval] cardType(o1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt0_4@178@01
  (and
    pt0_4@178@01
    (cardType%precondition $Snap.unit o1@15@01)
    (cardType%precondition $Snap.unit o2@18@01))))
(assert (or pt0_4@178@01 (not pt0_4@178@01)))
(declare-const pt0_5@182@01 Bool)
(assert (=
  pt0_5@182@01
  (and
    pt0_4@178@01
    (> (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01)))))
; [exec]
; pt1_5 := pt1_4 && cardType(o1_0) > cardType(o2_0)
; [eval] pt1_4 && cardType(o1_0) > cardType(o2_0)
; [exec]
; pt2_5 := pt2_4 && cardType(o1_1) > cardType(o2_1)
; [eval] pt2_4 && cardType(o1_1) > cardType(o2_1)
(push) ; 27
; [then-branch: 962 | !(pt2_4@179@01) | live]
; [else-branch: 962 | pt2_4@179@01 | live]
(push) ; 28
; [then-branch: 962 | !(pt2_4@179@01)]
(assert (not pt2_4@179@01))
(pop) ; 28
(push) ; 28
; [else-branch: 962 | pt2_4@179@01]
(assert pt2_4@179@01)
; [eval] cardType(o1_1) > cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt2_4@179@01
  (and
    pt2_4@179@01
    (cardType%precondition $Snap.unit o1_1@17@01)
    (cardType%precondition $Snap.unit o2_1@20@01))))
(assert (or pt2_4@179@01 (not pt2_4@179@01)))
(declare-const pt2_5@183@01 Bool)
(assert (=
  pt2_5@183@01
  (and
    pt2_4@179@01
    (> (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_5 := pt0_4 && !(cardType(o1) > cardType(o2))
; [eval] pt0_4 && !(cardType(o1) > cardType(o2))
(push) ; 27
; [then-branch: 963 | !(pt0_4@178@01) | live]
; [else-branch: 963 | pt0_4@178@01 | live]
(push) ; 28
; [then-branch: 963 | !(pt0_4@178@01)]
(assert (not pt0_4@178@01))
(pop) ; 28
(push) ; 28
; [else-branch: 963 | pt0_4@178@01]
(assert pt0_4@178@01)
; [eval] !(cardType(o1) > cardType(o2))
; [eval] cardType(o1) > cardType(o2)
; [eval] cardType(o1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf0_5@184@01 Bool)
(assert (=
  pf0_5@184@01
  (and
    pt0_4@178@01
    (not (> (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01))))))
; [exec]
; pf1_5 := pt1_4 && !(cardType(o1_0) > cardType(o2_0))
; [eval] pt1_4 && !(cardType(o1_0) > cardType(o2_0))
; [exec]
; pf2_5 := pt2_4 && !(cardType(o1_1) > cardType(o2_1))
; [eval] pt2_4 && !(cardType(o1_1) > cardType(o2_1))
(push) ; 27
; [then-branch: 964 | !(pt2_4@179@01) | live]
; [else-branch: 964 | pt2_4@179@01 | live]
(push) ; 28
; [then-branch: 964 | !(pt2_4@179@01)]
(assert (not pt2_4@179@01))
(pop) ; 28
(push) ; 28
; [else-branch: 964 | pt2_4@179@01]
(assert pt2_4@179@01)
; [eval] !(cardType(o1_1) > cardType(o2_1))
; [eval] cardType(o1_1) > cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf2_5@185@01 Bool)
(assert (=
  pf2_5@185@01
  (and
    pt2_4@179@01
    (not (> (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01))))))
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not pt0_5@182@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 965 | pt0_5@182@01 | dead]
; [else-branch: 965 | !(pt0_5@182@01) | live]
(set-option :rlimit 0)
(push) ; 27
; [else-branch: 965 | !(pt0_5@182@01)]
(assert (not pt0_5@182@01))
(pop) ; 27
; [eval] !pt0_5
(push) ; 27
(set-option :rlimit 16000)
(assert (not pt0_5@182@01))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not pt0_5@182@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 966 | !(pt0_5@182@01) | live]
; [else-branch: 966 | pt0_5@182@01 | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 966 | !(pt0_5@182@01)]
(assert (not pt0_5@182@01))
; [then-branch: 967 | False | dead]
; [else-branch: 967 | True | live]
(push) ; 28
; [else-branch: 967 | True]
(pop) ; 28
; [eval] !pt1_5
(push) ; 28
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 968 | True | live]
; [else-branch: 968 | False | dead]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 968 | True]
(push) ; 29
(set-option :rlimit 16000)
(assert (not (not pt2_5@183@01)))
(check-sat)
; unsat
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 969 | pt2_5@183@01 | dead]
; [else-branch: 969 | !(pt2_5@183@01) | live]
(set-option :rlimit 0)
(push) ; 29
; [else-branch: 969 | !(pt2_5@183@01)]
(assert (not pt2_5@183@01))
(pop) ; 29
; [eval] !pt2_5
(push) ; 29
(set-option :rlimit 16000)
(assert (not pt2_5@183@01))
(check-sat)
; unknown
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 29
(set-option :rlimit 16000)
(assert (not (not pt2_5@183@01)))
(check-sat)
; unsat
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 970 | !(pt2_5@183@01) | live]
; [else-branch: 970 | pt2_5@183@01 | dead]
(set-option :rlimit 0)
(push) ; 29
; [then-branch: 970 | !(pt2_5@183@01)]
(assert (not pt2_5@183@01))
; [then-branch: 971 | pt0_5@182@01 | dead]
; [else-branch: 971 | !(pt0_5@182@01) | live]
(push) ; 30
; [else-branch: 971 | !(pt0_5@182@01)]
(pop) ; 30
; [eval] !pt0_5
(push) ; 30
(set-option :rlimit 16000)
(assert (not pt0_5@182@01))
(check-sat)
; unknown
(pop) ; 30
; 0.00s
; (get-info :all-statistics)
; [then-branch: 972 | !(pt0_5@182@01) | live]
; [else-branch: 972 | pt0_5@182@01 | dead]
(set-option :rlimit 0)
(push) ; 30
; [then-branch: 972 | !(pt0_5@182@01)]
; [then-branch: 973 | False | dead]
; [else-branch: 973 | True | live]
(push) ; 31
; [else-branch: 973 | True]
(pop) ; 31
; [eval] !pt1_5
(push) ; 31
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 31
; 0.00s
; (get-info :all-statistics)
; [then-branch: 974 | True | live]
; [else-branch: 974 | False | dead]
(set-option :rlimit 0)
(push) ; 31
; [then-branch: 974 | True]
; [then-branch: 975 | pt2_5@183@01 | dead]
; [else-branch: 975 | !(pt2_5@183@01) | live]
(push) ; 32
; [else-branch: 975 | !(pt2_5@183@01)]
(pop) ; 32
; [eval] !pt2_5
(push) ; 32
(set-option :rlimit 16000)
(assert (not pt2_5@183@01))
(check-sat)
; unknown
(pop) ; 32
; 0.00s
; (get-info :all-statistics)
; [then-branch: 976 | !(pt2_5@183@01) | live]
; [else-branch: 976 | pt2_5@183@01 | dead]
(set-option :rlimit 0)
(push) ; 32
; [then-branch: 976 | !(pt2_5@183@01)]
; [exec]
; pt0_6 := pf0_5 && cardType(o1) == cardType(o2)
; [eval] pf0_5 && cardType(o1) == cardType(o2)
(push) ; 33
; [then-branch: 977 | !(pf0_5@184@01) | live]
; [else-branch: 977 | pf0_5@184@01 | live]
(push) ; 34
; [then-branch: 977 | !(pf0_5@184@01)]
(assert (not pf0_5@184@01))
(pop) ; 34
(push) ; 34
; [else-branch: 977 | pf0_5@184@01]
(assert pf0_5@184@01)
; [eval] cardType(o1) == cardType(o2)
; [eval] cardType(o1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_5@184@01
  (and
    pf0_5@184@01
    (cardType%precondition $Snap.unit o1@15@01)
    (cardType%precondition $Snap.unit o2@18@01))))
(assert (or pf0_5@184@01 (not pf0_5@184@01)))
(declare-const pt0_6@186@01 Bool)
(assert (=
  pt0_6@186@01
  (and
    pf0_5@184@01
    (= (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01)))))
; [exec]
; pt1_6 := pf1_5 && cardType(o1_0) == cardType(o2_0)
; [eval] pf1_5 && cardType(o1_0) == cardType(o2_0)
; [exec]
; pt2_6 := pf2_5 && cardType(o1_1) == cardType(o2_1)
; [eval] pf2_5 && cardType(o1_1) == cardType(o2_1)
(push) ; 33
; [then-branch: 978 | !(pf2_5@185@01) | live]
; [else-branch: 978 | pf2_5@185@01 | live]
(push) ; 34
; [then-branch: 978 | !(pf2_5@185@01)]
(assert (not pf2_5@185@01))
(pop) ; 34
(push) ; 34
; [else-branch: 978 | pf2_5@185@01]
(assert pf2_5@185@01)
; [eval] cardType(o1_1) == cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_5@185@01
  (and
    pf2_5@185@01
    (cardType%precondition $Snap.unit o1_1@17@01)
    (cardType%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_5@185@01 (not pf2_5@185@01)))
(declare-const pt2_6@187@01 Bool)
(assert (=
  pt2_6@187@01
  (and
    pf2_5@185@01
    (= (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_6 := pf0_5 && !(cardType(o1) == cardType(o2))
; [eval] pf0_5 && !(cardType(o1) == cardType(o2))
(push) ; 33
; [then-branch: 979 | !(pf0_5@184@01) | live]
; [else-branch: 979 | pf0_5@184@01 | live]
(push) ; 34
; [then-branch: 979 | !(pf0_5@184@01)]
(assert (not pf0_5@184@01))
(pop) ; 34
(push) ; 34
; [else-branch: 979 | pf0_5@184@01]
(assert pf0_5@184@01)
; [eval] !(cardType(o1) == cardType(o2))
; [eval] cardType(o1) == cardType(o2)
; [eval] cardType(o1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf0_6@188@01 Bool)
(assert (=
  pf0_6@188@01
  (and
    pf0_5@184@01
    (not (= (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01))))))
; [exec]
; pf1_6 := pf1_5 && !(cardType(o1_0) == cardType(o2_0))
; [eval] pf1_5 && !(cardType(o1_0) == cardType(o2_0))
; [exec]
; pf2_6 := pf2_5 && !(cardType(o1_1) == cardType(o2_1))
; [eval] pf2_5 && !(cardType(o1_1) == cardType(o2_1))
(push) ; 33
; [then-branch: 980 | !(pf2_5@185@01) | live]
; [else-branch: 980 | pf2_5@185@01 | live]
(push) ; 34
; [then-branch: 980 | !(pf2_5@185@01)]
(assert (not pf2_5@185@01))
(pop) ; 34
(push) ; 34
; [else-branch: 980 | pf2_5@185@01]
(assert pf2_5@185@01)
; [eval] !(cardType(o1_1) == cardType(o2_1))
; [eval] cardType(o1_1) == cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf2_6@189@01 Bool)
(assert (=
  pf2_6@189@01
  (and
    pf2_5@185@01
    (not (= (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01))))))
(push) ; 33
(set-option :rlimit 16000)
(assert (not (not pt0_6@186@01)))
(check-sat)
; unsat
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 981 | pt0_6@186@01 | dead]
; [else-branch: 981 | !(pt0_6@186@01) | live]
(set-option :rlimit 0)
(push) ; 33
; [else-branch: 981 | !(pt0_6@186@01)]
(assert (not pt0_6@186@01))
(pop) ; 33
; [eval] !pt0_6
(push) ; 33
(set-option :rlimit 16000)
(assert (not pt0_6@186@01))
(check-sat)
; unknown
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 33
(set-option :rlimit 16000)
(assert (not (not pt0_6@186@01)))
(check-sat)
; unsat
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 982 | !(pt0_6@186@01) | live]
; [else-branch: 982 | pt0_6@186@01 | dead]
(set-option :rlimit 0)
(push) ; 33
; [then-branch: 982 | !(pt0_6@186@01)]
(assert (not pt0_6@186@01))
; [then-branch: 983 | False | dead]
; [else-branch: 983 | True | live]
(push) ; 34
; [else-branch: 983 | True]
(pop) ; 34
; [eval] !pt1_6
(push) ; 34
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 984 | True | live]
; [else-branch: 984 | False | dead]
(set-option :rlimit 0)
(push) ; 34
; [then-branch: 984 | True]
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@187@01)))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 985 | pt2_6@187@01 | dead]
; [else-branch: 985 | !(pt2_6@187@01) | live]
(set-option :rlimit 0)
(push) ; 35
; [else-branch: 985 | !(pt2_6@187@01)]
(assert (not pt2_6@187@01))
(pop) ; 35
; [eval] !pt2_6
(push) ; 35
(set-option :rlimit 16000)
(assert (not pt2_6@187@01))
(check-sat)
; unknown
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@187@01)))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 986 | !(pt2_6@187@01) | live]
; [else-branch: 986 | pt2_6@187@01 | dead]
(set-option :rlimit 0)
(push) ; 35
; [then-branch: 986 | !(pt2_6@187@01)]
(assert (not pt2_6@187@01))
; [then-branch: 987 | pt0_6@186@01 | dead]
; [else-branch: 987 | !(pt0_6@186@01) | live]
(push) ; 36
; [else-branch: 987 | !(pt0_6@186@01)]
(pop) ; 36
; [eval] !pt0_6
(push) ; 36
(set-option :rlimit 16000)
(assert (not pt0_6@186@01))
(check-sat)
; unknown
(pop) ; 36
; 0.00s
; (get-info :all-statistics)
; [then-branch: 988 | !(pt0_6@186@01) | live]
; [else-branch: 988 | pt0_6@186@01 | dead]
(set-option :rlimit 0)
(push) ; 36
; [then-branch: 988 | !(pt0_6@186@01)]
; [then-branch: 989 | False | dead]
; [else-branch: 989 | True | live]
(push) ; 37
; [else-branch: 989 | True]
(pop) ; 37
; [eval] !pt1_6
(push) ; 37
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 37
; 0.00s
; (get-info :all-statistics)
; [then-branch: 990 | True | live]
; [else-branch: 990 | False | dead]
(set-option :rlimit 0)
(push) ; 37
; [then-branch: 990 | True]
; [then-branch: 991 | pt2_6@187@01 | dead]
; [else-branch: 991 | !(pt2_6@187@01) | live]
(push) ; 38
; [else-branch: 991 | !(pt2_6@187@01)]
(pop) ; 38
; [eval] !pt2_6
(push) ; 38
(set-option :rlimit 16000)
(assert (not pt2_6@187@01))
(check-sat)
; unknown
(pop) ; 38
; 0.00s
; (get-info :all-statistics)
; [then-branch: 992 | !(pt2_6@187@01) | live]
; [else-branch: 992 | pt2_6@187@01 | dead]
(set-option :rlimit 0)
(push) ; 38
; [then-branch: 992 | !(pt2_6@187@01)]
(push) ; 39
(set-option :rlimit 16000)
(assert (not (not pf0_6@188@01)))
(check-sat)
; unsat
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 993 | pf0_6@188@01 | dead]
; [else-branch: 993 | !(pf0_6@188@01) | live]
(set-option :rlimit 0)
(push) ; 39
; [else-branch: 993 | !(pf0_6@188@01)]
(assert (not pf0_6@188@01))
(pop) ; 39
; [eval] !pf0_6
(push) ; 39
(set-option :rlimit 16000)
(assert (not pf0_6@188@01))
(check-sat)
; unknown
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 39
(set-option :rlimit 16000)
(assert (not (not pf0_6@188@01)))
(check-sat)
; unsat
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 994 | !(pf0_6@188@01) | live]
; [else-branch: 994 | pf0_6@188@01 | dead]
(set-option :rlimit 0)
(push) ; 39
; [then-branch: 994 | !(pf0_6@188@01)]
(assert (not pf0_6@188@01))
; [then-branch: 995 | False | dead]
; [else-branch: 995 | True | live]
(push) ; 40
; [else-branch: 995 | True]
(pop) ; 40
; [eval] !pf1_6
(push) ; 40
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 996 | True | live]
; [else-branch: 996 | False | dead]
(set-option :rlimit 0)
(push) ; 40
; [then-branch: 996 | True]
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@189@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 997 | pf2_6@189@01 | dead]
; [else-branch: 997 | !(pf2_6@189@01) | live]
(set-option :rlimit 0)
(push) ; 41
; [else-branch: 997 | !(pf2_6@189@01)]
(assert (not pf2_6@189@01))
(pop) ; 41
; [eval] !pf2_6
(push) ; 41
(set-option :rlimit 16000)
(assert (not pf2_6@189@01))
(check-sat)
; unknown
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@189@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 998 | !(pf2_6@189@01) | live]
; [else-branch: 998 | pf2_6@189@01 | dead]
(set-option :rlimit 0)
(push) ; 41
; [then-branch: 998 | !(pf2_6@189@01)]
(assert (not pf2_6@189@01))
; [then-branch: 999 | pf0_6@188@01 | dead]
; [else-branch: 999 | !(pf0_6@188@01) | live]
(push) ; 42
; [else-branch: 999 | !(pf0_6@188@01)]
(pop) ; 42
; [eval] !pf0_6
(push) ; 42
(set-option :rlimit 16000)
(assert (not pf0_6@188@01))
(check-sat)
; unknown
(pop) ; 42
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1000 | !(pf0_6@188@01) | live]
; [else-branch: 1000 | pf0_6@188@01 | dead]
(set-option :rlimit 0)
(push) ; 42
; [then-branch: 1000 | !(pf0_6@188@01)]
; [then-branch: 1001 | False | dead]
; [else-branch: 1001 | True | live]
(push) ; 43
; [else-branch: 1001 | True]
(pop) ; 43
; [eval] !pf1_6
(push) ; 43
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 43
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1002 | True | live]
; [else-branch: 1002 | False | dead]
(set-option :rlimit 0)
(push) ; 43
; [then-branch: 1002 | True]
; [then-branch: 1003 | pf2_6@189@01 | dead]
; [else-branch: 1003 | !(pf2_6@189@01) | live]
(push) ; 44
; [else-branch: 1003 | !(pf2_6@189@01)]
(pop) ; 44
; [eval] !pf2_6
(push) ; 44
(set-option :rlimit 16000)
(assert (not pf2_6@189@01))
(check-sat)
; unknown
(pop) ; 44
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1004 | !(pf2_6@189@01) | live]
; [else-branch: 1004 | pf2_6@189@01 | dead]
(set-option :rlimit 0)
(push) ; 44
; [then-branch: 1004 | !(pf2_6@189@01)]
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@180@01)))
(check-sat)
; unsat
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1005 | pf0_4@180@01 | dead]
; [else-branch: 1005 | !(pf0_4@180@01) | live]
(set-option :rlimit 0)
(push) ; 45
; [else-branch: 1005 | !(pf0_4@180@01)]
(assert (not pf0_4@180@01))
(pop) ; 45
; [eval] !pf0_4
(push) ; 45
(set-option :rlimit 16000)
(assert (not pf0_4@180@01))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@180@01)))
(check-sat)
; unsat
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1006 | !(pf0_4@180@01) | live]
; [else-branch: 1006 | pf0_4@180@01 | dead]
(set-option :rlimit 0)
(push) ; 45
; [then-branch: 1006 | !(pf0_4@180@01)]
(assert (not pf0_4@180@01))
; [then-branch: 1007 | False | dead]
; [else-branch: 1007 | True | live]
(push) ; 46
; [else-branch: 1007 | True]
(pop) ; 46
; [eval] !pf1_4
(push) ; 46
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1008 | True | live]
; [else-branch: 1008 | False | dead]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 1008 | True]
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@181@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1009 | pf2_4@181@01 | dead]
; [else-branch: 1009 | !(pf2_4@181@01) | live]
(set-option :rlimit 0)
(push) ; 47
; [else-branch: 1009 | !(pf2_4@181@01)]
(assert (not pf2_4@181@01))
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not pf2_4@181@01))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@181@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1010 | !(pf2_4@181@01) | live]
; [else-branch: 1010 | pf2_4@181@01 | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 1010 | !(pf2_4@181@01)]
(assert (not pf2_4@181@01))
; [then-branch: 1011 | pf0_4@180@01 | dead]
; [else-branch: 1011 | !(pf0_4@180@01) | live]
(push) ; 48
; [else-branch: 1011 | !(pf0_4@180@01)]
(pop) ; 48
; [eval] !pf0_4
(push) ; 48
(set-option :rlimit 16000)
(assert (not pf0_4@180@01))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1012 | !(pf0_4@180@01) | live]
; [else-branch: 1012 | pf0_4@180@01 | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 1012 | !(pf0_4@180@01)]
; [then-branch: 1013 | False | dead]
; [else-branch: 1013 | True | live]
(push) ; 49
; [else-branch: 1013 | True]
(pop) ; 49
; [eval] !pf1_4
(push) ; 49
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1014 | True | live]
; [else-branch: 1014 | False | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 1014 | True]
; [then-branch: 1015 | pf2_4@181@01 | dead]
; [else-branch: 1015 | !(pf2_4@181@01) | live]
(push) ; 50
; [else-branch: 1015 | !(pf2_4@181@01)]
(pop) ; 50
; [eval] !pf2_4
(push) ; 50
(set-option :rlimit 16000)
(assert (not pf2_4@181@01))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1016 | !(pf2_4@181@01) | live]
; [else-branch: 1016 | pf2_4@181@01 | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 1016 | !(pf2_4@181@01)]
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@172@01)))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1017 | pf0_2@172@01 | dead]
; [else-branch: 1017 | !(pf0_2@172@01) | live]
(set-option :rlimit 0)
(push) ; 51
; [else-branch: 1017 | !(pf0_2@172@01)]
(assert (not pf0_2@172@01))
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not pf0_2@172@01))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@172@01)))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1018 | !(pf0_2@172@01) | live]
; [else-branch: 1018 | pf0_2@172@01 | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 1018 | !(pf0_2@172@01)]
(assert (not pf0_2@172@01))
; [then-branch: 1019 | False | dead]
; [else-branch: 1019 | True | live]
(push) ; 52
; [else-branch: 1019 | True]
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1020 | True | live]
; [else-branch: 1020 | False | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 1020 | True]
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@173@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1021 | pf2_2@173@01 | dead]
; [else-branch: 1021 | !(pf2_2@173@01) | live]
(set-option :rlimit 0)
(push) ; 53
; [else-branch: 1021 | !(pf2_2@173@01)]
(assert (not pf2_2@173@01))
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not pf2_2@173@01))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@173@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1022 | !(pf2_2@173@01) | live]
; [else-branch: 1022 | pf2_2@173@01 | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 1022 | !(pf2_2@173@01)]
(assert (not pf2_2@173@01))
; [then-branch: 1023 | pf0_2@172@01 | dead]
; [else-branch: 1023 | !(pf0_2@172@01) | live]
(push) ; 54
; [else-branch: 1023 | !(pf0_2@172@01)]
(pop) ; 54
; [eval] !pf0_2
(push) ; 54
(set-option :rlimit 16000)
(assert (not pf0_2@172@01))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1024 | !(pf0_2@172@01) | live]
; [else-branch: 1024 | pf0_2@172@01 | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 1024 | !(pf0_2@172@01)]
; [then-branch: 1025 | False | dead]
; [else-branch: 1025 | True | live]
(push) ; 55
; [else-branch: 1025 | True]
(pop) ; 55
; [eval] !pf1_2
(push) ; 55
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1026 | True | live]
; [else-branch: 1026 | False | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 1026 | True]
; [then-branch: 1027 | pf2_2@173@01 | dead]
; [else-branch: 1027 | !(pf2_2@173@01) | live]
(push) ; 56
; [else-branch: 1027 | !(pf2_2@173@01)]
(pop) ; 56
; [eval] !pf2_2
(push) ; 56
(set-option :rlimit 16000)
(assert (not pf2_2@173@01))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1028 | !(pf2_2@173@01) | live]
; [else-branch: 1028 | pf2_2@173@01 | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 1028 | !(pf2_2@173@01)]
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1029 | p0@12@01 | live]
; [else-branch: 1029 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1029 | p0@12@01]
(assert p0@12@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1030 | p1@13@01 | live]
; [else-branch: 1030 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1030 | p1@13@01]
(assert p1@13@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p1@13@01)
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1031 | p2@14@01 | live]
; [else-branch: 1031 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1031 | p2@14@01]
(assert p2@14@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p2@14@01)
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1032 | p0@12@01 | live]
; [else-branch: 1032 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1032 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1033 | False | live]
; [else-branch: 1033 | True | live]
(push) ; 60
; [then-branch: 1033 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1033 | True]
(push) ; 61
; [then-branch: 1034 | !(p0@12@01) | live]
; [else-branch: 1034 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1034 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1034 | p0@12@01]
(push) ; 63
; [then-branch: 1035 | !(p1@13@01) | live]
; [else-branch: 1035 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1035 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1035 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1036 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1036 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1036 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1037 | False | live]
; [else-branch: 1037 | True | live]
(push) ; 62
; [then-branch: 1037 | False]
(assert false)
(pop) ; 62
(push) ; 62
; [else-branch: 1037 | True]
; [eval] res_0 > 0
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(push) ; 61
; [then-branch: 1038 | False | dead]
; [else-branch: 1038 | True | live]
(push) ; 62
; [else-branch: 1038 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1039 | p1@13@01 | live]
; [else-branch: 1039 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1039 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1040 | False | live]
; [else-branch: 1040 | True | live]
(push) ; 60
; [then-branch: 1040 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1040 | True]
(push) ; 61
; [then-branch: 1041 | !(p0@12@01) | live]
; [else-branch: 1041 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1041 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1041 | p0@12@01]
(push) ; 63
; [then-branch: 1042 | !(p1@13@01) | live]
; [else-branch: 1042 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1042 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1042 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1043 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1043 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1043 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1044 | False | live]
; [else-branch: 1044 | True | live]
(push) ; 62
; [then-branch: 1044 | False]
(assert false)
(pop) ; 62
(push) ; 62
; [else-branch: 1044 | True]
; [eval] res_0 > 0
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(push) ; 61
; [then-branch: 1045 | False | dead]
; [else-branch: 1045 | True | live]
(push) ; 62
; [else-branch: 1045 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p2@14@01)))
(assert p1@13@01)
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1046 | p2@14@01 | live]
; [else-branch: 1046 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1046 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1047 | False | live]
; [else-branch: 1047 | True | live]
(push) ; 60
; [then-branch: 1047 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1047 | True]
(push) ; 61
; [then-branch: 1048 | !(p0@12@01) | live]
; [else-branch: 1048 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1048 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1048 | p0@12@01]
(assert p0@12@01)
(push) ; 63
; [then-branch: 1049 | !(p1@13@01) | live]
; [else-branch: 1049 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1049 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1049 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1050 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1050 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1050 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1051 | False | live]
; [else-branch: 1051 | True | live]
(push) ; 62
; [then-branch: 1051 | False]
(assert false)
(pop) ; 62
(push) ; 62
; [else-branch: 1051 | True]
; [eval] res_0 > 0
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(push) ; 61
; [then-branch: 1052 | False | dead]
; [else-branch: 1052 | True | live]
(push) ; 62
; [else-branch: 1052 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01)))
(assert p2@14@01)
(pop) ; 56
(pop) ; 55
(pop) ; 54
(pop) ; 53
(pop) ; 52
(pop) ; 51
(pop) ; 50
(pop) ; 49
(pop) ; 48
(pop) ; 47
(pop) ; 46
(pop) ; 45
(pop) ; 44
(pop) ; 43
(pop) ; 42
(pop) ; 41
(pop) ; 40
(pop) ; 39
(pop) ; 38
(pop) ; 37
(pop) ; 36
(pop) ; 35
(pop) ; 34
(pop) ; 33
(pop) ; 32
(pop) ; 31
(pop) ; 30
(pop) ; 29
(pop) ; 28
(pop) ; 27
(pop) ; 26
; [eval] !pt2_3
; [then-branch: 1053 | !(pt2_3@175@01) | dead]
; [else-branch: 1053 | pt2_3@175@01 | live]
(push) ; 26
; [else-branch: 1053 | pt2_3@175@01]
(pop) ; 26
(pop) ; 25
(pop) ; 24
; [eval] !pt0_3
; [then-branch: 1054 | !(pt0_3@174@01) | dead]
; [else-branch: 1054 | pt0_3@174@01 | live]
(push) ; 24
; [else-branch: 1054 | pt0_3@174@01]
(pop) ; 24
(pop) ; 23
; [eval] !pt2_3
(push) ; 23
(set-option :rlimit 16000)
(assert (not pt2_3@175@01))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1055 | !(pt2_3@175@01) | dead]
; [else-branch: 1055 | pt2_3@175@01 | live]
(set-option :rlimit 0)
(push) ; 23
; [else-branch: 1055 | pt2_3@175@01]
(assert pt2_3@175@01)
(pop) ; 23
(pop) ; 22
(pop) ; 21
(push) ; 21
; [else-branch: 949 | !(pt0_3@174@01)]
(assert (not pt0_3@174@01))
(pop) ; 21
; [eval] !pt0_3
(push) ; 21
(set-option :rlimit 16000)
(assert (not pt0_3@174@01))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt0_3@174@01)))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1056 | !(pt0_3@174@01) | live]
; [else-branch: 1056 | pt0_3@174@01 | live]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 1056 | !(pt0_3@174@01)]
(assert (not pt0_3@174@01))
; [then-branch: 1057 | False | dead]
; [else-branch: 1057 | True | live]
(push) ; 22
; [else-branch: 1057 | True]
(pop) ; 22
; [eval] !pt1_3
(push) ; 22
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1058 | True | live]
; [else-branch: 1058 | False | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 1058 | True]
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not pt2_3@175@01)))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1059 | pt2_3@175@01 | dead]
; [else-branch: 1059 | !(pt2_3@175@01) | live]
(set-option :rlimit 0)
(push) ; 23
; [else-branch: 1059 | !(pt2_3@175@01)]
(assert (not pt2_3@175@01))
(pop) ; 23
; [eval] !pt2_3
(push) ; 23
(set-option :rlimit 16000)
(assert (not pt2_3@175@01))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 23
(set-option :rlimit 16000)
(assert (not (not pt2_3@175@01)))
(check-sat)
; unsat
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1060 | !(pt2_3@175@01) | live]
; [else-branch: 1060 | pt2_3@175@01 | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 1060 | !(pt2_3@175@01)]
(assert (not pt2_3@175@01))
; [then-branch: 1061 | pt0_3@174@01 | dead]
; [else-branch: 1061 | !(pt0_3@174@01) | live]
(push) ; 24
; [else-branch: 1061 | !(pt0_3@174@01)]
(pop) ; 24
; [eval] !pt0_3
(push) ; 24
(set-option :rlimit 16000)
(assert (not pt0_3@174@01))
(check-sat)
; unknown
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1062 | !(pt0_3@174@01) | live]
; [else-branch: 1062 | pt0_3@174@01 | dead]
(set-option :rlimit 0)
(push) ; 24
; [then-branch: 1062 | !(pt0_3@174@01)]
; [then-branch: 1063 | False | dead]
; [else-branch: 1063 | True | live]
(push) ; 25
; [else-branch: 1063 | True]
(pop) ; 25
; [eval] !pt1_3
(push) ; 25
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1064 | True | live]
; [else-branch: 1064 | False | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 1064 | True]
; [then-branch: 1065 | pt2_3@175@01 | dead]
; [else-branch: 1065 | !(pt2_3@175@01) | live]
(push) ; 26
; [else-branch: 1065 | !(pt2_3@175@01)]
(pop) ; 26
; [eval] !pt2_3
(push) ; 26
(set-option :rlimit 16000)
(assert (not pt2_3@175@01))
(check-sat)
; unknown
(pop) ; 26
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1066 | !(pt2_3@175@01) | live]
; [else-branch: 1066 | pt2_3@175@01 | dead]
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 1066 | !(pt2_3@175@01)]
; [exec]
; pt0_4 := pf0_3 && getCardId(o1) == getCardId(o2)
; [eval] pf0_3 && getCardId(o1) == getCardId(o2)
(push) ; 27
; [then-branch: 1067 | !(pf0_3@176@01) | live]
; [else-branch: 1067 | pf0_3@176@01 | live]
(push) ; 28
; [then-branch: 1067 | !(pf0_3@176@01)]
(assert (not pf0_3@176@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1067 | pf0_3@176@01]
(assert pf0_3@176@01)
; [eval] getCardId(o1) == getCardId(o2)
; [eval] getCardId(o1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1@15@01))
; [eval] getCardId(o2)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_3@176@01
  (and
    pf0_3@176@01
    (getCardId%precondition $Snap.unit o1@15@01)
    (getCardId%precondition $Snap.unit o2@18@01))))
(assert (or pf0_3@176@01 (not pf0_3@176@01)))
(declare-const pt0_4@190@01 Bool)
(assert (=
  pt0_4@190@01
  (and
    pf0_3@176@01
    (= (getCardId $Snap.unit o1@15@01) (getCardId $Snap.unit o2@18@01)))))
; [exec]
; pt1_4 := pf1_3 && getCardId(o1_0) == getCardId(o2_0)
; [eval] pf1_3 && getCardId(o1_0) == getCardId(o2_0)
; [exec]
; pt2_4 := pf2_3 && getCardId(o1_1) == getCardId(o2_1)
; [eval] pf2_3 && getCardId(o1_1) == getCardId(o2_1)
(push) ; 27
; [then-branch: 1068 | !(pf2_3@177@01) | live]
; [else-branch: 1068 | pf2_3@177@01 | live]
(push) ; 28
; [then-branch: 1068 | !(pf2_3@177@01)]
(assert (not pf2_3@177@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1068 | pf2_3@177@01]
(assert pf2_3@177@01)
; [eval] getCardId(o1_1) == getCardId(o2_1)
; [eval] getCardId(o1_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
; [eval] getCardId(o2_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_3@177@01
  (and
    pf2_3@177@01
    (getCardId%precondition $Snap.unit o1_1@17@01)
    (getCardId%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_3@177@01 (not pf2_3@177@01)))
(declare-const pt2_4@191@01 Bool)
(assert (=
  pt2_4@191@01
  (and
    pf2_3@177@01
    (= (getCardId $Snap.unit o1_1@17@01) (getCardId $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_4 := pf0_3 && !(getCardId(o1) == getCardId(o2))
; [eval] pf0_3 && !(getCardId(o1) == getCardId(o2))
(push) ; 27
; [then-branch: 1069 | !(pf0_3@176@01) | live]
; [else-branch: 1069 | pf0_3@176@01 | live]
(push) ; 28
; [then-branch: 1069 | !(pf0_3@176@01)]
(assert (not pf0_3@176@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1069 | pf0_3@176@01]
(assert pf0_3@176@01)
; [eval] !(getCardId(o1) == getCardId(o2))
; [eval] getCardId(o1) == getCardId(o2)
; [eval] getCardId(o1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1@15@01))
; [eval] getCardId(o2)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf0_4@192@01 Bool)
(assert (=
  pf0_4@192@01
  (and
    pf0_3@176@01
    (not (= (getCardId $Snap.unit o1@15@01) (getCardId $Snap.unit o2@18@01))))))
; [exec]
; pf1_4 := pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
; [eval] pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
; [exec]
; pf2_4 := pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
; [eval] pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
(push) ; 27
; [then-branch: 1070 | !(pf2_3@177@01) | live]
; [else-branch: 1070 | pf2_3@177@01 | live]
(push) ; 28
; [then-branch: 1070 | !(pf2_3@177@01)]
(assert (not pf2_3@177@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1070 | pf2_3@177@01]
(assert pf2_3@177@01)
; [eval] !(getCardId(o1_1) == getCardId(o2_1))
; [eval] getCardId(o1_1) == getCardId(o2_1)
; [eval] getCardId(o1_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_1@17@01))
; [eval] getCardId(o2_1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf2_4@193@01 Bool)
(assert (=
  pf2_4@193@01
  (and
    pf2_3@177@01
    (not (= (getCardId $Snap.unit o1_1@17@01) (getCardId $Snap.unit o2_1@20@01))))))
; [exec]
; pt0_5 := pt0_4 && cardType(o1) > cardType(o2)
; [eval] pt0_4 && cardType(o1) > cardType(o2)
(push) ; 27
; [then-branch: 1071 | !(pt0_4@190@01) | live]
; [else-branch: 1071 | pt0_4@190@01 | live]
(push) ; 28
; [then-branch: 1071 | !(pt0_4@190@01)]
(assert (not pt0_4@190@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1071 | pt0_4@190@01]
(assert pt0_4@190@01)
; [eval] cardType(o1) > cardType(o2)
; [eval] cardType(o1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt0_4@190@01
  (and
    pt0_4@190@01
    (cardType%precondition $Snap.unit o1@15@01)
    (cardType%precondition $Snap.unit o2@18@01))))
(assert (or pt0_4@190@01 (not pt0_4@190@01)))
(declare-const pt0_5@194@01 Bool)
(assert (=
  pt0_5@194@01
  (and
    pt0_4@190@01
    (> (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01)))))
; [exec]
; pt1_5 := pt1_4 && cardType(o1_0) > cardType(o2_0)
; [eval] pt1_4 && cardType(o1_0) > cardType(o2_0)
; [exec]
; pt2_5 := pt2_4 && cardType(o1_1) > cardType(o2_1)
; [eval] pt2_4 && cardType(o1_1) > cardType(o2_1)
(push) ; 27
; [then-branch: 1072 | !(pt2_4@191@01) | live]
; [else-branch: 1072 | pt2_4@191@01 | live]
(push) ; 28
; [then-branch: 1072 | !(pt2_4@191@01)]
(assert (not pt2_4@191@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1072 | pt2_4@191@01]
(assert pt2_4@191@01)
; [eval] cardType(o1_1) > cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt2_4@191@01
  (and
    pt2_4@191@01
    (cardType%precondition $Snap.unit o1_1@17@01)
    (cardType%precondition $Snap.unit o2_1@20@01))))
(assert (or pt2_4@191@01 (not pt2_4@191@01)))
(declare-const pt2_5@195@01 Bool)
(assert (=
  pt2_5@195@01
  (and
    pt2_4@191@01
    (> (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_5 := pt0_4 && !(cardType(o1) > cardType(o2))
; [eval] pt0_4 && !(cardType(o1) > cardType(o2))
(push) ; 27
; [then-branch: 1073 | !(pt0_4@190@01) | live]
; [else-branch: 1073 | pt0_4@190@01 | live]
(push) ; 28
; [then-branch: 1073 | !(pt0_4@190@01)]
(assert (not pt0_4@190@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1073 | pt0_4@190@01]
(assert pt0_4@190@01)
; [eval] !(cardType(o1) > cardType(o2))
; [eval] cardType(o1) > cardType(o2)
; [eval] cardType(o1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf0_5@196@01 Bool)
(assert (=
  pf0_5@196@01
  (and
    pt0_4@190@01
    (not (> (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01))))))
; [exec]
; pf1_5 := pt1_4 && !(cardType(o1_0) > cardType(o2_0))
; [eval] pt1_4 && !(cardType(o1_0) > cardType(o2_0))
; [exec]
; pf2_5 := pt2_4 && !(cardType(o1_1) > cardType(o2_1))
; [eval] pt2_4 && !(cardType(o1_1) > cardType(o2_1))
(push) ; 27
; [then-branch: 1074 | !(pt2_4@191@01) | live]
; [else-branch: 1074 | pt2_4@191@01 | live]
(push) ; 28
; [then-branch: 1074 | !(pt2_4@191@01)]
(assert (not pt2_4@191@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1074 | pt2_4@191@01]
(assert pt2_4@191@01)
; [eval] !(cardType(o1_1) > cardType(o2_1))
; [eval] cardType(o1_1) > cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf2_5@197@01 Bool)
(assert (=
  pf2_5@197@01
  (and
    pt2_4@191@01
    (not (> (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01))))))
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not pt0_5@194@01)))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 27
(set-option :rlimit 16000)
(assert (not pt0_5@194@01))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1075 | pt0_5@194@01 | live]
; [else-branch: 1075 | !(pt0_5@194@01) | live]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 1075 | pt0_5@194@01]
(assert pt0_5@194@01)
; [exec]
; res := 1
; [then-branch: 1076 | False | dead]
; [else-branch: 1076 | True | live]
(push) ; 28
; [else-branch: 1076 | True]
(pop) ; 28
; [eval] !pt1_5
(push) ; 28
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1077 | True | live]
; [else-branch: 1077 | False | dead]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 1077 | True]
(push) ; 29
(set-option :rlimit 16000)
(assert (not (not pt2_5@195@01)))
(check-sat)
; unknown
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 29
(set-option :rlimit 16000)
(assert (not pt2_5@195@01))
(check-sat)
; unsat
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1078 | pt2_5@195@01 | live]
; [else-branch: 1078 | !(pt2_5@195@01) | dead]
(set-option :rlimit 0)
(push) ; 29
; [then-branch: 1078 | pt2_5@195@01]
(assert pt2_5@195@01)
; [exec]
; res_1 := 1
(push) ; 30
(set-option :rlimit 16000)
(assert (not (not pt0_5@194@01)))
(check-sat)
; unknown
(pop) ; 30
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1079 | pt0_5@194@01 | live]
; [else-branch: 1079 | !(pt0_5@194@01) | dead]
(set-option :rlimit 0)
(push) ; 30
; [then-branch: 1079 | pt0_5@194@01]
; [exec]
; returned := true
; [then-branch: 1080 | False | dead]
; [else-branch: 1080 | True | live]
(push) ; 31
; [else-branch: 1080 | True]
(pop) ; 31
; [eval] !pt1_5
(push) ; 31
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 31
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1081 | True | live]
; [else-branch: 1081 | False | dead]
(set-option :rlimit 0)
(push) ; 31
; [then-branch: 1081 | True]
(push) ; 32
(set-option :rlimit 16000)
(assert (not (not pt2_5@195@01)))
(check-sat)
; unknown
(pop) ; 32
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1082 | pt2_5@195@01 | live]
; [else-branch: 1082 | !(pt2_5@195@01) | dead]
(set-option :rlimit 0)
(push) ; 32
; [then-branch: 1082 | pt2_5@195@01]
; [exec]
; returned_1 := true
; [exec]
; pt0_6 := pf0_5 && cardType(o1) == cardType(o2)
; [eval] pf0_5 && cardType(o1) == cardType(o2)
(push) ; 33
; [then-branch: 1083 | !(pf0_5@196@01) | live]
; [else-branch: 1083 | pf0_5@196@01 | live]
(push) ; 34
; [then-branch: 1083 | !(pf0_5@196@01)]
(assert (not pf0_5@196@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1083 | pf0_5@196@01]
(assert pf0_5@196@01)
; [eval] cardType(o1) == cardType(o2)
; [eval] cardType(o1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_5@196@01
  (and
    pf0_5@196@01
    (cardType%precondition $Snap.unit o1@15@01)
    (cardType%precondition $Snap.unit o2@18@01))))
(assert (or pf0_5@196@01 (not pf0_5@196@01)))
(declare-const pt0_6@198@01 Bool)
(assert (=
  pt0_6@198@01
  (and
    pf0_5@196@01
    (= (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01)))))
; [exec]
; pt1_6 := pf1_5 && cardType(o1_0) == cardType(o2_0)
; [eval] pf1_5 && cardType(o1_0) == cardType(o2_0)
; [exec]
; pt2_6 := pf2_5 && cardType(o1_1) == cardType(o2_1)
; [eval] pf2_5 && cardType(o1_1) == cardType(o2_1)
(push) ; 33
; [then-branch: 1084 | !(pf2_5@197@01) | live]
; [else-branch: 1084 | pf2_5@197@01 | live]
(push) ; 34
; [then-branch: 1084 | !(pf2_5@197@01)]
(assert (not pf2_5@197@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1084 | pf2_5@197@01]
(assert pf2_5@197@01)
; [eval] cardType(o1_1) == cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_5@197@01
  (and
    pf2_5@197@01
    (cardType%precondition $Snap.unit o1_1@17@01)
    (cardType%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_5@197@01 (not pf2_5@197@01)))
(declare-const pt2_6@199@01 Bool)
(assert (=
  pt2_6@199@01
  (and
    pf2_5@197@01
    (= (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_6 := pf0_5 && !(cardType(o1) == cardType(o2))
; [eval] pf0_5 && !(cardType(o1) == cardType(o2))
(push) ; 33
; [then-branch: 1085 | !(pf0_5@196@01) | live]
; [else-branch: 1085 | pf0_5@196@01 | live]
(push) ; 34
; [then-branch: 1085 | !(pf0_5@196@01)]
(assert (not pf0_5@196@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1085 | pf0_5@196@01]
(assert pf0_5@196@01)
; [eval] !(cardType(o1) == cardType(o2))
; [eval] cardType(o1) == cardType(o2)
; [eval] cardType(o1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf0_6@200@01 Bool)
(assert (=
  pf0_6@200@01
  (and
    pf0_5@196@01
    (not (= (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01))))))
; [exec]
; pf1_6 := pf1_5 && !(cardType(o1_0) == cardType(o2_0))
; [eval] pf1_5 && !(cardType(o1_0) == cardType(o2_0))
; [exec]
; pf2_6 := pf2_5 && !(cardType(o1_1) == cardType(o2_1))
; [eval] pf2_5 && !(cardType(o1_1) == cardType(o2_1))
(push) ; 33
; [then-branch: 1086 | !(pf2_5@197@01) | live]
; [else-branch: 1086 | pf2_5@197@01 | live]
(push) ; 34
; [then-branch: 1086 | !(pf2_5@197@01)]
(assert (not pf2_5@197@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1086 | pf2_5@197@01]
(assert pf2_5@197@01)
; [eval] !(cardType(o1_1) == cardType(o2_1))
; [eval] cardType(o1_1) == cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf2_6@201@01 Bool)
(assert (=
  pf2_6@201@01
  (and
    pf2_5@197@01
    (not (= (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01))))))
(push) ; 33
(set-option :rlimit 16000)
(assert (not (not pt0_6@198@01)))
(check-sat)
; unsat
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1087 | pt0_6@198@01 | dead]
; [else-branch: 1087 | !(pt0_6@198@01) | live]
(set-option :rlimit 0)
(push) ; 33
; [else-branch: 1087 | !(pt0_6@198@01)]
(assert (not pt0_6@198@01))
(pop) ; 33
; [eval] !pt0_6
(push) ; 33
(set-option :rlimit 16000)
(assert (not pt0_6@198@01))
(check-sat)
; unknown
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 33
(set-option :rlimit 16000)
(assert (not (not pt0_6@198@01)))
(check-sat)
; unsat
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1088 | !(pt0_6@198@01) | live]
; [else-branch: 1088 | pt0_6@198@01 | dead]
(set-option :rlimit 0)
(push) ; 33
; [then-branch: 1088 | !(pt0_6@198@01)]
(assert (not pt0_6@198@01))
; [then-branch: 1089 | False | dead]
; [else-branch: 1089 | True | live]
(push) ; 34
; [else-branch: 1089 | True]
(pop) ; 34
; [eval] !pt1_6
(push) ; 34
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1090 | True | live]
; [else-branch: 1090 | False | dead]
(set-option :rlimit 0)
(push) ; 34
; [then-branch: 1090 | True]
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@199@01)))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1091 | pt2_6@199@01 | dead]
; [else-branch: 1091 | !(pt2_6@199@01) | live]
(set-option :rlimit 0)
(push) ; 35
; [else-branch: 1091 | !(pt2_6@199@01)]
(assert (not pt2_6@199@01))
(pop) ; 35
; [eval] !pt2_6
(push) ; 35
(set-option :rlimit 16000)
(assert (not pt2_6@199@01))
(check-sat)
; unknown
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@199@01)))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1092 | !(pt2_6@199@01) | live]
; [else-branch: 1092 | pt2_6@199@01 | dead]
(set-option :rlimit 0)
(push) ; 35
; [then-branch: 1092 | !(pt2_6@199@01)]
(assert (not pt2_6@199@01))
; [then-branch: 1093 | pt0_6@198@01 | dead]
; [else-branch: 1093 | !(pt0_6@198@01) | live]
(push) ; 36
; [else-branch: 1093 | !(pt0_6@198@01)]
(pop) ; 36
; [eval] !pt0_6
(push) ; 36
(set-option :rlimit 16000)
(assert (not pt0_6@198@01))
(check-sat)
; unknown
(pop) ; 36
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1094 | !(pt0_6@198@01) | live]
; [else-branch: 1094 | pt0_6@198@01 | dead]
(set-option :rlimit 0)
(push) ; 36
; [then-branch: 1094 | !(pt0_6@198@01)]
; [then-branch: 1095 | False | dead]
; [else-branch: 1095 | True | live]
(push) ; 37
; [else-branch: 1095 | True]
(pop) ; 37
; [eval] !pt1_6
(push) ; 37
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 37
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1096 | True | live]
; [else-branch: 1096 | False | dead]
(set-option :rlimit 0)
(push) ; 37
; [then-branch: 1096 | True]
; [then-branch: 1097 | pt2_6@199@01 | dead]
; [else-branch: 1097 | !(pt2_6@199@01) | live]
(push) ; 38
; [else-branch: 1097 | !(pt2_6@199@01)]
(pop) ; 38
; [eval] !pt2_6
(push) ; 38
(set-option :rlimit 16000)
(assert (not pt2_6@199@01))
(check-sat)
; unknown
(pop) ; 38
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1098 | !(pt2_6@199@01) | live]
; [else-branch: 1098 | pt2_6@199@01 | dead]
(set-option :rlimit 0)
(push) ; 38
; [then-branch: 1098 | !(pt2_6@199@01)]
(push) ; 39
(set-option :rlimit 16000)
(assert (not (not pf0_6@200@01)))
(check-sat)
; unsat
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1099 | pf0_6@200@01 | dead]
; [else-branch: 1099 | !(pf0_6@200@01) | live]
(set-option :rlimit 0)
(push) ; 39
; [else-branch: 1099 | !(pf0_6@200@01)]
(assert (not pf0_6@200@01))
(pop) ; 39
; [eval] !pf0_6
(push) ; 39
(set-option :rlimit 16000)
(assert (not pf0_6@200@01))
(check-sat)
; unknown
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 39
(set-option :rlimit 16000)
(assert (not (not pf0_6@200@01)))
(check-sat)
; unsat
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1100 | !(pf0_6@200@01) | live]
; [else-branch: 1100 | pf0_6@200@01 | dead]
(set-option :rlimit 0)
(push) ; 39
; [then-branch: 1100 | !(pf0_6@200@01)]
(assert (not pf0_6@200@01))
; [then-branch: 1101 | False | dead]
; [else-branch: 1101 | True | live]
(push) ; 40
; [else-branch: 1101 | True]
(pop) ; 40
; [eval] !pf1_6
(push) ; 40
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1102 | True | live]
; [else-branch: 1102 | False | dead]
(set-option :rlimit 0)
(push) ; 40
; [then-branch: 1102 | True]
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@201@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1103 | pf2_6@201@01 | dead]
; [else-branch: 1103 | !(pf2_6@201@01) | live]
(set-option :rlimit 0)
(push) ; 41
; [else-branch: 1103 | !(pf2_6@201@01)]
(assert (not pf2_6@201@01))
(pop) ; 41
; [eval] !pf2_6
(push) ; 41
(set-option :rlimit 16000)
(assert (not pf2_6@201@01))
(check-sat)
; unknown
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@201@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1104 | !(pf2_6@201@01) | live]
; [else-branch: 1104 | pf2_6@201@01 | dead]
(set-option :rlimit 0)
(push) ; 41
; [then-branch: 1104 | !(pf2_6@201@01)]
(assert (not pf2_6@201@01))
; [then-branch: 1105 | pf0_6@200@01 | dead]
; [else-branch: 1105 | !(pf0_6@200@01) | live]
(push) ; 42
; [else-branch: 1105 | !(pf0_6@200@01)]
(pop) ; 42
; [eval] !pf0_6
(push) ; 42
(set-option :rlimit 16000)
(assert (not pf0_6@200@01))
(check-sat)
; unknown
(pop) ; 42
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1106 | !(pf0_6@200@01) | live]
; [else-branch: 1106 | pf0_6@200@01 | dead]
(set-option :rlimit 0)
(push) ; 42
; [then-branch: 1106 | !(pf0_6@200@01)]
; [then-branch: 1107 | False | dead]
; [else-branch: 1107 | True | live]
(push) ; 43
; [else-branch: 1107 | True]
(pop) ; 43
; [eval] !pf1_6
(push) ; 43
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 43
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1108 | True | live]
; [else-branch: 1108 | False | dead]
(set-option :rlimit 0)
(push) ; 43
; [then-branch: 1108 | True]
; [then-branch: 1109 | pf2_6@201@01 | dead]
; [else-branch: 1109 | !(pf2_6@201@01) | live]
(push) ; 44
; [else-branch: 1109 | !(pf2_6@201@01)]
(pop) ; 44
; [eval] !pf2_6
(push) ; 44
(set-option :rlimit 16000)
(assert (not pf2_6@201@01))
(check-sat)
; unknown
(pop) ; 44
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1110 | !(pf2_6@201@01) | live]
; [else-branch: 1110 | pf2_6@201@01 | dead]
(set-option :rlimit 0)
(push) ; 44
; [then-branch: 1110 | !(pf2_6@201@01)]
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@192@01)))
(check-sat)
; unsat
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1111 | pf0_4@192@01 | dead]
; [else-branch: 1111 | !(pf0_4@192@01) | live]
(set-option :rlimit 0)
(push) ; 45
; [else-branch: 1111 | !(pf0_4@192@01)]
(assert (not pf0_4@192@01))
(pop) ; 45
; [eval] !pf0_4
(push) ; 45
(set-option :rlimit 16000)
(assert (not pf0_4@192@01))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@192@01)))
(check-sat)
; unsat
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1112 | !(pf0_4@192@01) | live]
; [else-branch: 1112 | pf0_4@192@01 | dead]
(set-option :rlimit 0)
(push) ; 45
; [then-branch: 1112 | !(pf0_4@192@01)]
(assert (not pf0_4@192@01))
; [then-branch: 1113 | False | dead]
; [else-branch: 1113 | True | live]
(push) ; 46
; [else-branch: 1113 | True]
(pop) ; 46
; [eval] !pf1_4
(push) ; 46
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1114 | True | live]
; [else-branch: 1114 | False | dead]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 1114 | True]
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@193@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1115 | pf2_4@193@01 | dead]
; [else-branch: 1115 | !(pf2_4@193@01) | live]
(set-option :rlimit 0)
(push) ; 47
; [else-branch: 1115 | !(pf2_4@193@01)]
(assert (not pf2_4@193@01))
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not pf2_4@193@01))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@193@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1116 | !(pf2_4@193@01) | live]
; [else-branch: 1116 | pf2_4@193@01 | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 1116 | !(pf2_4@193@01)]
(assert (not pf2_4@193@01))
; [then-branch: 1117 | pf0_4@192@01 | dead]
; [else-branch: 1117 | !(pf0_4@192@01) | live]
(push) ; 48
; [else-branch: 1117 | !(pf0_4@192@01)]
(pop) ; 48
; [eval] !pf0_4
(push) ; 48
(set-option :rlimit 16000)
(assert (not pf0_4@192@01))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1118 | !(pf0_4@192@01) | live]
; [else-branch: 1118 | pf0_4@192@01 | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 1118 | !(pf0_4@192@01)]
; [then-branch: 1119 | False | dead]
; [else-branch: 1119 | True | live]
(push) ; 49
; [else-branch: 1119 | True]
(pop) ; 49
; [eval] !pf1_4
(push) ; 49
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1120 | True | live]
; [else-branch: 1120 | False | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 1120 | True]
; [then-branch: 1121 | pf2_4@193@01 | dead]
; [else-branch: 1121 | !(pf2_4@193@01) | live]
(push) ; 50
; [else-branch: 1121 | !(pf2_4@193@01)]
(pop) ; 50
; [eval] !pf2_4
(push) ; 50
(set-option :rlimit 16000)
(assert (not pf2_4@193@01))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1122 | !(pf2_4@193@01) | live]
; [else-branch: 1122 | pf2_4@193@01 | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 1122 | !(pf2_4@193@01)]
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@172@01)))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1123 | pf0_2@172@01 | dead]
; [else-branch: 1123 | !(pf0_2@172@01) | live]
(set-option :rlimit 0)
(push) ; 51
; [else-branch: 1123 | !(pf0_2@172@01)]
(assert (not pf0_2@172@01))
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not pf0_2@172@01))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@172@01)))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1124 | !(pf0_2@172@01) | live]
; [else-branch: 1124 | pf0_2@172@01 | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 1124 | !(pf0_2@172@01)]
(assert (not pf0_2@172@01))
; [then-branch: 1125 | False | dead]
; [else-branch: 1125 | True | live]
(push) ; 52
; [else-branch: 1125 | True]
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1126 | True | live]
; [else-branch: 1126 | False | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 1126 | True]
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@173@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1127 | pf2_2@173@01 | dead]
; [else-branch: 1127 | !(pf2_2@173@01) | live]
(set-option :rlimit 0)
(push) ; 53
; [else-branch: 1127 | !(pf2_2@173@01)]
(assert (not pf2_2@173@01))
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not pf2_2@173@01))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@173@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1128 | !(pf2_2@173@01) | live]
; [else-branch: 1128 | pf2_2@173@01 | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 1128 | !(pf2_2@173@01)]
(assert (not pf2_2@173@01))
; [then-branch: 1129 | pf0_2@172@01 | dead]
; [else-branch: 1129 | !(pf0_2@172@01) | live]
(push) ; 54
; [else-branch: 1129 | !(pf0_2@172@01)]
(pop) ; 54
; [eval] !pf0_2
(push) ; 54
(set-option :rlimit 16000)
(assert (not pf0_2@172@01))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1130 | !(pf0_2@172@01) | live]
; [else-branch: 1130 | pf0_2@172@01 | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 1130 | !(pf0_2@172@01)]
; [then-branch: 1131 | False | dead]
; [else-branch: 1131 | True | live]
(push) ; 55
; [else-branch: 1131 | True]
(pop) ; 55
; [eval] !pf1_2
(push) ; 55
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1132 | True | live]
; [else-branch: 1132 | False | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 1132 | True]
; [then-branch: 1133 | pf2_2@173@01 | dead]
; [else-branch: 1133 | !(pf2_2@173@01) | live]
(push) ; 56
; [else-branch: 1133 | !(pf2_2@173@01)]
(pop) ; 56
; [eval] !pf2_2
(push) ; 56
(set-option :rlimit 16000)
(assert (not pf2_2@173@01))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1134 | !(pf2_2@173@01) | live]
; [else-branch: 1134 | pf2_2@173@01 | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 1134 | !(pf2_2@173@01)]
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1135 | p0@12@01 | live]
; [else-branch: 1135 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1135 | p0@12@01]
(assert p0@12@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1136 | p1@13@01 | live]
; [else-branch: 1136 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1136 | p1@13@01]
(assert p1@13@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p1@13@01)
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1137 | p2@14@01 | live]
; [else-branch: 1137 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1137 | p2@14@01]
(assert p2@14@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p2@14@01)
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1138 | p0@12@01 | live]
; [else-branch: 1138 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1138 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1139 | False | live]
; [else-branch: 1139 | True | live]
(push) ; 60
; [then-branch: 1139 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1139 | True]
(push) ; 61
; [then-branch: 1140 | !(p0@12@01) | live]
; [else-branch: 1140 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1140 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1140 | p0@12@01]
(push) ; 63
; [then-branch: 1141 | !(p1@13@01) | live]
; [else-branch: 1141 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1141 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1141 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1142 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1142 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1142 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1143 | False | live]
; [else-branch: 1143 | True | live]
(push) ; 62
; [then-branch: 1143 | False]
(assert false)
(pop) ; 62
(push) ; 62
; [else-branch: 1143 | True]
; [eval] res_0 > 0
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(push) ; 61
; [then-branch: 1144 | False | dead]
; [else-branch: 1144 | True | live]
(push) ; 62
; [else-branch: 1144 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1145 | p1@13@01 | live]
; [else-branch: 1145 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1145 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1146 | False | live]
; [else-branch: 1146 | True | live]
(push) ; 60
; [then-branch: 1146 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1146 | True]
(push) ; 61
; [then-branch: 1147 | !(p0@12@01) | live]
; [else-branch: 1147 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1147 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1147 | p0@12@01]
(push) ; 63
; [then-branch: 1148 | !(p1@13@01) | live]
; [else-branch: 1148 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1148 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1148 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1149 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1149 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1149 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1150 | False | live]
; [else-branch: 1150 | True | live]
(push) ; 62
; [then-branch: 1150 | False]
(assert false)
(pop) ; 62
(push) ; 62
; [else-branch: 1150 | True]
; [eval] res_0 > 0
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(push) ; 61
; [then-branch: 1151 | False | dead]
; [else-branch: 1151 | True | live]
(push) ; 62
; [else-branch: 1151 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p2@14@01)))
(assert p1@13@01)
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1152 | p2@14@01 | live]
; [else-branch: 1152 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1152 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1153 | False | live]
; [else-branch: 1153 | True | live]
(push) ; 60
; [then-branch: 1153 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1153 | True]
(push) ; 61
; [then-branch: 1154 | !(p0@12@01) | live]
; [else-branch: 1154 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1154 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1154 | p0@12@01]
(assert p0@12@01)
(push) ; 63
; [then-branch: 1155 | !(p1@13@01) | live]
; [else-branch: 1155 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1155 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1155 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1156 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1156 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1156 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1157 | False | live]
; [else-branch: 1157 | True | live]
(push) ; 62
; [then-branch: 1157 | False]
(assert false)
(pop) ; 62
(push) ; 62
; [else-branch: 1157 | True]
; [eval] res_0 > 0
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(push) ; 61
; [then-branch: 1158 | False | dead]
; [else-branch: 1158 | True | live]
(push) ; 62
; [else-branch: 1158 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01)))
(assert p2@14@01)
(pop) ; 56
(pop) ; 55
(pop) ; 54
(pop) ; 53
(pop) ; 52
(pop) ; 51
(pop) ; 50
(pop) ; 49
(pop) ; 48
(pop) ; 47
(pop) ; 46
(pop) ; 45
(pop) ; 44
(pop) ; 43
(pop) ; 42
(pop) ; 41
(pop) ; 40
(pop) ; 39
(pop) ; 38
(pop) ; 37
(pop) ; 36
(pop) ; 35
(pop) ; 34
(pop) ; 33
(pop) ; 32
; [eval] !pt2_5
; [then-branch: 1159 | !(pt2_5@195@01) | dead]
; [else-branch: 1159 | pt2_5@195@01 | live]
(push) ; 32
; [else-branch: 1159 | pt2_5@195@01]
(pop) ; 32
(pop) ; 31
(pop) ; 30
; [eval] !pt0_5
; [then-branch: 1160 | !(pt0_5@194@01) | dead]
; [else-branch: 1160 | pt0_5@194@01 | live]
(push) ; 30
; [else-branch: 1160 | pt0_5@194@01]
(pop) ; 30
(pop) ; 29
; [eval] !pt2_5
(push) ; 29
(set-option :rlimit 16000)
(assert (not pt2_5@195@01))
(check-sat)
; unsat
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1161 | !(pt2_5@195@01) | dead]
; [else-branch: 1161 | pt2_5@195@01 | live]
(set-option :rlimit 0)
(push) ; 29
; [else-branch: 1161 | pt2_5@195@01]
(assert pt2_5@195@01)
(pop) ; 29
(pop) ; 28
(pop) ; 27
(push) ; 27
; [else-branch: 1075 | !(pt0_5@194@01)]
(assert (not pt0_5@194@01))
(pop) ; 27
; [eval] !pt0_5
(push) ; 27
(set-option :rlimit 16000)
(assert (not pt0_5@194@01))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not pt0_5@194@01)))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1162 | !(pt0_5@194@01) | live]
; [else-branch: 1162 | pt0_5@194@01 | live]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 1162 | !(pt0_5@194@01)]
(assert (not pt0_5@194@01))
; [then-branch: 1163 | False | dead]
; [else-branch: 1163 | True | live]
(push) ; 28
; [else-branch: 1163 | True]
(pop) ; 28
; [eval] !pt1_5
(push) ; 28
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1164 | True | live]
; [else-branch: 1164 | False | dead]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 1164 | True]
(push) ; 29
(set-option :rlimit 16000)
(assert (not (not pt2_5@195@01)))
(check-sat)
; unsat
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1165 | pt2_5@195@01 | dead]
; [else-branch: 1165 | !(pt2_5@195@01) | live]
(set-option :rlimit 0)
(push) ; 29
; [else-branch: 1165 | !(pt2_5@195@01)]
(assert (not pt2_5@195@01))
(pop) ; 29
; [eval] !pt2_5
(push) ; 29
(set-option :rlimit 16000)
(assert (not pt2_5@195@01))
(check-sat)
; unknown
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 29
(set-option :rlimit 16000)
(assert (not (not pt2_5@195@01)))
(check-sat)
; unsat
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1166 | !(pt2_5@195@01) | live]
; [else-branch: 1166 | pt2_5@195@01 | dead]
(set-option :rlimit 0)
(push) ; 29
; [then-branch: 1166 | !(pt2_5@195@01)]
(assert (not pt2_5@195@01))
; [then-branch: 1167 | pt0_5@194@01 | dead]
; [else-branch: 1167 | !(pt0_5@194@01) | live]
(push) ; 30
; [else-branch: 1167 | !(pt0_5@194@01)]
(pop) ; 30
; [eval] !pt0_5
(push) ; 30
(set-option :rlimit 16000)
(assert (not pt0_5@194@01))
(check-sat)
; unknown
(pop) ; 30
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1168 | !(pt0_5@194@01) | live]
; [else-branch: 1168 | pt0_5@194@01 | dead]
(set-option :rlimit 0)
(push) ; 30
; [then-branch: 1168 | !(pt0_5@194@01)]
; [then-branch: 1169 | False | dead]
; [else-branch: 1169 | True | live]
(push) ; 31
; [else-branch: 1169 | True]
(pop) ; 31
; [eval] !pt1_5
(push) ; 31
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 31
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1170 | True | live]
; [else-branch: 1170 | False | dead]
(set-option :rlimit 0)
(push) ; 31
; [then-branch: 1170 | True]
; [then-branch: 1171 | pt2_5@195@01 | dead]
; [else-branch: 1171 | !(pt2_5@195@01) | live]
(push) ; 32
; [else-branch: 1171 | !(pt2_5@195@01)]
(pop) ; 32
; [eval] !pt2_5
(push) ; 32
(set-option :rlimit 16000)
(assert (not pt2_5@195@01))
(check-sat)
; unknown
(pop) ; 32
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1172 | !(pt2_5@195@01) | live]
; [else-branch: 1172 | pt2_5@195@01 | dead]
(set-option :rlimit 0)
(push) ; 32
; [then-branch: 1172 | !(pt2_5@195@01)]
; [exec]
; pt0_6 := pf0_5 && cardType(o1) == cardType(o2)
; [eval] pf0_5 && cardType(o1) == cardType(o2)
(push) ; 33
; [then-branch: 1173 | !(pf0_5@196@01) | live]
; [else-branch: 1173 | pf0_5@196@01 | live]
(push) ; 34
; [then-branch: 1173 | !(pf0_5@196@01)]
(assert (not pf0_5@196@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1173 | pf0_5@196@01]
(assert pf0_5@196@01)
; [eval] cardType(o1) == cardType(o2)
; [eval] cardType(o1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_5@196@01
  (and
    pf0_5@196@01
    (cardType%precondition $Snap.unit o1@15@01)
    (cardType%precondition $Snap.unit o2@18@01))))
(assert (or pf0_5@196@01 (not pf0_5@196@01)))
(declare-const pt0_6@202@01 Bool)
(assert (=
  pt0_6@202@01
  (and
    pf0_5@196@01
    (= (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01)))))
; [exec]
; pt1_6 := pf1_5 && cardType(o1_0) == cardType(o2_0)
; [eval] pf1_5 && cardType(o1_0) == cardType(o2_0)
; [exec]
; pt2_6 := pf2_5 && cardType(o1_1) == cardType(o2_1)
; [eval] pf2_5 && cardType(o1_1) == cardType(o2_1)
(push) ; 33
; [then-branch: 1174 | !(pf2_5@197@01) | live]
; [else-branch: 1174 | pf2_5@197@01 | live]
(push) ; 34
; [then-branch: 1174 | !(pf2_5@197@01)]
(assert (not pf2_5@197@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1174 | pf2_5@197@01]
(assert pf2_5@197@01)
; [eval] cardType(o1_1) == cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf2_5@197@01
  (and
    pf2_5@197@01
    (cardType%precondition $Snap.unit o1_1@17@01)
    (cardType%precondition $Snap.unit o2_1@20@01))))
(assert (or pf2_5@197@01 (not pf2_5@197@01)))
(declare-const pt2_6@203@01 Bool)
(assert (=
  pt2_6@203@01
  (and
    pf2_5@197@01
    (= (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01)))))
; [exec]
; pf0_6 := pf0_5 && !(cardType(o1) == cardType(o2))
; [eval] pf0_5 && !(cardType(o1) == cardType(o2))
(push) ; 33
; [then-branch: 1175 | !(pf0_5@196@01) | live]
; [else-branch: 1175 | pf0_5@196@01 | live]
(push) ; 34
; [then-branch: 1175 | !(pf0_5@196@01)]
(assert (not pf0_5@196@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1175 | pf0_5@196@01]
(assert pf0_5@196@01)
; [eval] !(cardType(o1) == cardType(o2))
; [eval] cardType(o1) == cardType(o2)
; [eval] cardType(o1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf0_6@204@01 Bool)
(assert (=
  pf0_6@204@01
  (and
    pf0_5@196@01
    (not (= (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01))))))
; [exec]
; pf1_6 := pf1_5 && !(cardType(o1_0) == cardType(o2_0))
; [eval] pf1_5 && !(cardType(o1_0) == cardType(o2_0))
; [exec]
; pf2_6 := pf2_5 && !(cardType(o1_1) == cardType(o2_1))
; [eval] pf2_5 && !(cardType(o1_1) == cardType(o2_1))
(push) ; 33
; [then-branch: 1176 | !(pf2_5@197@01) | live]
; [else-branch: 1176 | pf2_5@197@01 | live]
(push) ; 34
; [then-branch: 1176 | !(pf2_5@197@01)]
(assert (not pf2_5@197@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1176 | pf2_5@197@01]
(assert pf2_5@197@01)
; [eval] !(cardType(o1_1) == cardType(o2_1))
; [eval] cardType(o1_1) == cardType(o2_1)
; [eval] cardType(o1_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_1@17@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_1@17@01))
; [eval] cardType(o2_1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_1@20@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf2_6@205@01 Bool)
(assert (=
  pf2_6@205@01
  (and
    pf2_5@197@01
    (not (= (cardType $Snap.unit o1_1@17@01) (cardType $Snap.unit o2_1@20@01))))))
(push) ; 33
(set-option :rlimit 16000)
(assert (not (not pt0_6@202@01)))
(check-sat)
; unknown
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 33
(set-option :rlimit 16000)
(assert (not pt0_6@202@01))
(check-sat)
; unknown
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1177 | pt0_6@202@01 | live]
; [else-branch: 1177 | !(pt0_6@202@01) | live]
(set-option :rlimit 0)
(push) ; 33
; [then-branch: 1177 | pt0_6@202@01]
(assert pt0_6@202@01)
; [exec]
; res := 0
; [then-branch: 1178 | False | dead]
; [else-branch: 1178 | True | live]
(push) ; 34
; [else-branch: 1178 | True]
(pop) ; 34
; [eval] !pt1_6
(push) ; 34
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1179 | True | live]
; [else-branch: 1179 | False | dead]
(set-option :rlimit 0)
(push) ; 34
; [then-branch: 1179 | True]
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@203@01)))
(check-sat)
; unknown
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 35
(set-option :rlimit 16000)
(assert (not pt2_6@203@01))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1180 | pt2_6@203@01 | live]
; [else-branch: 1180 | !(pt2_6@203@01) | dead]
(set-option :rlimit 0)
(push) ; 35
; [then-branch: 1180 | pt2_6@203@01]
(assert pt2_6@203@01)
; [exec]
; res_1 := 0
(push) ; 36
(set-option :rlimit 16000)
(assert (not (not pt0_6@202@01)))
(check-sat)
; unknown
(pop) ; 36
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1181 | pt0_6@202@01 | live]
; [else-branch: 1181 | !(pt0_6@202@01) | dead]
(set-option :rlimit 0)
(push) ; 36
; [then-branch: 1181 | pt0_6@202@01]
; [exec]
; returned := true
; [then-branch: 1182 | False | dead]
; [else-branch: 1182 | True | live]
(push) ; 37
; [else-branch: 1182 | True]
(pop) ; 37
; [eval] !pt1_6
(push) ; 37
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 37
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1183 | True | live]
; [else-branch: 1183 | False | dead]
(set-option :rlimit 0)
(push) ; 37
; [then-branch: 1183 | True]
(push) ; 38
(set-option :rlimit 16000)
(assert (not (not pt2_6@203@01)))
(check-sat)
; unknown
(pop) ; 38
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1184 | pt2_6@203@01 | live]
; [else-branch: 1184 | !(pt2_6@203@01) | dead]
(set-option :rlimit 0)
(push) ; 38
; [then-branch: 1184 | pt2_6@203@01]
; [exec]
; returned_1 := true
(push) ; 39
(set-option :rlimit 16000)
(assert (not (not pf0_6@204@01)))
(check-sat)
; unsat
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1185 | pf0_6@204@01 | dead]
; [else-branch: 1185 | !(pf0_6@204@01) | live]
(set-option :rlimit 0)
(push) ; 39
; [else-branch: 1185 | !(pf0_6@204@01)]
(assert (not pf0_6@204@01))
(pop) ; 39
; [eval] !pf0_6
(push) ; 39
(set-option :rlimit 16000)
(assert (not pf0_6@204@01))
(check-sat)
; unknown
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 39
(set-option :rlimit 16000)
(assert (not (not pf0_6@204@01)))
(check-sat)
; unsat
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1186 | !(pf0_6@204@01) | live]
; [else-branch: 1186 | pf0_6@204@01 | dead]
(set-option :rlimit 0)
(push) ; 39
; [then-branch: 1186 | !(pf0_6@204@01)]
(assert (not pf0_6@204@01))
; [then-branch: 1187 | False | dead]
; [else-branch: 1187 | True | live]
(push) ; 40
; [else-branch: 1187 | True]
(pop) ; 40
; [eval] !pf1_6
(push) ; 40
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1188 | True | live]
; [else-branch: 1188 | False | dead]
(set-option :rlimit 0)
(push) ; 40
; [then-branch: 1188 | True]
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@205@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1189 | pf2_6@205@01 | dead]
; [else-branch: 1189 | !(pf2_6@205@01) | live]
(set-option :rlimit 0)
(push) ; 41
; [else-branch: 1189 | !(pf2_6@205@01)]
(assert (not pf2_6@205@01))
(pop) ; 41
; [eval] !pf2_6
(push) ; 41
(set-option :rlimit 16000)
(assert (not pf2_6@205@01))
(check-sat)
; unknown
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@205@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1190 | !(pf2_6@205@01) | live]
; [else-branch: 1190 | pf2_6@205@01 | dead]
(set-option :rlimit 0)
(push) ; 41
; [then-branch: 1190 | !(pf2_6@205@01)]
(assert (not pf2_6@205@01))
; [then-branch: 1191 | pf0_6@204@01 | dead]
; [else-branch: 1191 | !(pf0_6@204@01) | live]
(push) ; 42
; [else-branch: 1191 | !(pf0_6@204@01)]
(pop) ; 42
; [eval] !pf0_6
(push) ; 42
(set-option :rlimit 16000)
(assert (not pf0_6@204@01))
(check-sat)
; unknown
(pop) ; 42
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1192 | !(pf0_6@204@01) | live]
; [else-branch: 1192 | pf0_6@204@01 | dead]
(set-option :rlimit 0)
(push) ; 42
; [then-branch: 1192 | !(pf0_6@204@01)]
; [then-branch: 1193 | False | dead]
; [else-branch: 1193 | True | live]
(push) ; 43
; [else-branch: 1193 | True]
(pop) ; 43
; [eval] !pf1_6
(push) ; 43
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 43
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1194 | True | live]
; [else-branch: 1194 | False | dead]
(set-option :rlimit 0)
(push) ; 43
; [then-branch: 1194 | True]
; [then-branch: 1195 | pf2_6@205@01 | dead]
; [else-branch: 1195 | !(pf2_6@205@01) | live]
(push) ; 44
; [else-branch: 1195 | !(pf2_6@205@01)]
(pop) ; 44
; [eval] !pf2_6
(push) ; 44
(set-option :rlimit 16000)
(assert (not pf2_6@205@01))
(check-sat)
; unknown
(pop) ; 44
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1196 | !(pf2_6@205@01) | live]
; [else-branch: 1196 | pf2_6@205@01 | dead]
(set-option :rlimit 0)
(push) ; 44
; [then-branch: 1196 | !(pf2_6@205@01)]
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@192@01)))
(check-sat)
; unsat
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1197 | pf0_4@192@01 | dead]
; [else-branch: 1197 | !(pf0_4@192@01) | live]
(set-option :rlimit 0)
(push) ; 45
; [else-branch: 1197 | !(pf0_4@192@01)]
(assert (not pf0_4@192@01))
(pop) ; 45
; [eval] !pf0_4
(push) ; 45
(set-option :rlimit 16000)
(assert (not pf0_4@192@01))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@192@01)))
(check-sat)
; unsat
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1198 | !(pf0_4@192@01) | live]
; [else-branch: 1198 | pf0_4@192@01 | dead]
(set-option :rlimit 0)
(push) ; 45
; [then-branch: 1198 | !(pf0_4@192@01)]
(assert (not pf0_4@192@01))
; [then-branch: 1199 | False | dead]
; [else-branch: 1199 | True | live]
(push) ; 46
; [else-branch: 1199 | True]
(pop) ; 46
; [eval] !pf1_4
(push) ; 46
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1200 | True | live]
; [else-branch: 1200 | False | dead]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 1200 | True]
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@193@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1201 | pf2_4@193@01 | dead]
; [else-branch: 1201 | !(pf2_4@193@01) | live]
(set-option :rlimit 0)
(push) ; 47
; [else-branch: 1201 | !(pf2_4@193@01)]
(assert (not pf2_4@193@01))
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not pf2_4@193@01))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@193@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1202 | !(pf2_4@193@01) | live]
; [else-branch: 1202 | pf2_4@193@01 | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 1202 | !(pf2_4@193@01)]
(assert (not pf2_4@193@01))
; [then-branch: 1203 | pf0_4@192@01 | dead]
; [else-branch: 1203 | !(pf0_4@192@01) | live]
(push) ; 48
; [else-branch: 1203 | !(pf0_4@192@01)]
(pop) ; 48
; [eval] !pf0_4
(push) ; 48
(set-option :rlimit 16000)
(assert (not pf0_4@192@01))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1204 | !(pf0_4@192@01) | live]
; [else-branch: 1204 | pf0_4@192@01 | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 1204 | !(pf0_4@192@01)]
; [then-branch: 1205 | False | dead]
; [else-branch: 1205 | True | live]
(push) ; 49
; [else-branch: 1205 | True]
(pop) ; 49
; [eval] !pf1_4
(push) ; 49
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1206 | True | live]
; [else-branch: 1206 | False | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 1206 | True]
; [then-branch: 1207 | pf2_4@193@01 | dead]
; [else-branch: 1207 | !(pf2_4@193@01) | live]
(push) ; 50
; [else-branch: 1207 | !(pf2_4@193@01)]
(pop) ; 50
; [eval] !pf2_4
(push) ; 50
(set-option :rlimit 16000)
(assert (not pf2_4@193@01))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1208 | !(pf2_4@193@01) | live]
; [else-branch: 1208 | pf2_4@193@01 | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 1208 | !(pf2_4@193@01)]
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@172@01)))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1209 | pf0_2@172@01 | dead]
; [else-branch: 1209 | !(pf0_2@172@01) | live]
(set-option :rlimit 0)
(push) ; 51
; [else-branch: 1209 | !(pf0_2@172@01)]
(assert (not pf0_2@172@01))
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not pf0_2@172@01))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@172@01)))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1210 | !(pf0_2@172@01) | live]
; [else-branch: 1210 | pf0_2@172@01 | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 1210 | !(pf0_2@172@01)]
(assert (not pf0_2@172@01))
; [then-branch: 1211 | False | dead]
; [else-branch: 1211 | True | live]
(push) ; 52
; [else-branch: 1211 | True]
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1212 | True | live]
; [else-branch: 1212 | False | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 1212 | True]
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@173@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1213 | pf2_2@173@01 | dead]
; [else-branch: 1213 | !(pf2_2@173@01) | live]
(set-option :rlimit 0)
(push) ; 53
; [else-branch: 1213 | !(pf2_2@173@01)]
(assert (not pf2_2@173@01))
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not pf2_2@173@01))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@173@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1214 | !(pf2_2@173@01) | live]
; [else-branch: 1214 | pf2_2@173@01 | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 1214 | !(pf2_2@173@01)]
(assert (not pf2_2@173@01))
; [then-branch: 1215 | pf0_2@172@01 | dead]
; [else-branch: 1215 | !(pf0_2@172@01) | live]
(push) ; 54
; [else-branch: 1215 | !(pf0_2@172@01)]
(pop) ; 54
; [eval] !pf0_2
(push) ; 54
(set-option :rlimit 16000)
(assert (not pf0_2@172@01))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1216 | !(pf0_2@172@01) | live]
; [else-branch: 1216 | pf0_2@172@01 | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 1216 | !(pf0_2@172@01)]
; [then-branch: 1217 | False | dead]
; [else-branch: 1217 | True | live]
(push) ; 55
; [else-branch: 1217 | True]
(pop) ; 55
; [eval] !pf1_2
(push) ; 55
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1218 | True | live]
; [else-branch: 1218 | False | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 1218 | True]
; [then-branch: 1219 | pf2_2@173@01 | dead]
; [else-branch: 1219 | !(pf2_2@173@01) | live]
(push) ; 56
; [else-branch: 1219 | !(pf2_2@173@01)]
(pop) ; 56
; [eval] !pf2_2
(push) ; 56
(set-option :rlimit 16000)
(assert (not pf2_2@173@01))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1220 | !(pf2_2@173@01) | live]
; [else-branch: 1220 | pf2_2@173@01 | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 1220 | !(pf2_2@173@01)]
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1221 | p0@12@01 | live]
; [else-branch: 1221 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1221 | p0@12@01]
(assert p0@12@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1222 | p1@13@01 | live]
; [else-branch: 1222 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1222 | p1@13@01]
(assert p1@13@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p1@13@01)
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1223 | p2@14@01 | live]
; [else-branch: 1223 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1223 | p2@14@01]
(assert p2@14@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p2@14@01)
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1224 | p0@12@01 | live]
; [else-branch: 1224 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1224 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1225 | False | live]
; [else-branch: 1225 | True | live]
(push) ; 60
; [then-branch: 1225 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1225 | True]
(push) ; 61
; [then-branch: 1226 | !(p0@12@01) | live]
; [else-branch: 1226 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1226 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1226 | p0@12@01]
(push) ; 63
; [then-branch: 1227 | !(p1@13@01) | live]
; [else-branch: 1227 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1227 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1227 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1228 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1228 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1228 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1229 | False | dead]
; [else-branch: 1229 | True | live]
(push) ; 62
; [else-branch: 1229 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1230 | p1@13@01 | live]
; [else-branch: 1230 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1230 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1231 | False | live]
; [else-branch: 1231 | True | live]
(push) ; 60
; [then-branch: 1231 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1231 | True]
(push) ; 61
; [then-branch: 1232 | !(p0@12@01) | live]
; [else-branch: 1232 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1232 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1232 | p0@12@01]
(push) ; 63
; [then-branch: 1233 | !(p1@13@01) | live]
; [else-branch: 1233 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1233 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1233 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1234 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1234 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1234 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1235 | False | dead]
; [else-branch: 1235 | True | live]
(push) ; 62
; [else-branch: 1235 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p2@14@01)))
(assert p1@13@01)
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1236 | p2@14@01 | live]
; [else-branch: 1236 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1236 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1237 | False | live]
; [else-branch: 1237 | True | live]
(push) ; 60
; [then-branch: 1237 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1237 | True]
(push) ; 61
; [then-branch: 1238 | !(p0@12@01) | live]
; [else-branch: 1238 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1238 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1238 | p0@12@01]
(assert p0@12@01)
(push) ; 63
; [then-branch: 1239 | !(p1@13@01) | live]
; [else-branch: 1239 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1239 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1239 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1240 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1240 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1240 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1241 | False | dead]
; [else-branch: 1241 | True | live]
(push) ; 62
; [else-branch: 1241 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01)))
(assert p2@14@01)
(pop) ; 56
(pop) ; 55
(pop) ; 54
(pop) ; 53
(pop) ; 52
(pop) ; 51
(pop) ; 50
(pop) ; 49
(pop) ; 48
(pop) ; 47
(pop) ; 46
(pop) ; 45
(pop) ; 44
(pop) ; 43
(pop) ; 42
(pop) ; 41
(pop) ; 40
(pop) ; 39
(pop) ; 38
; [eval] !pt2_6
; [then-branch: 1242 | !(pt2_6@203@01) | dead]
; [else-branch: 1242 | pt2_6@203@01 | live]
(push) ; 38
; [else-branch: 1242 | pt2_6@203@01]
(pop) ; 38
(pop) ; 37
(pop) ; 36
; [eval] !pt0_6
; [then-branch: 1243 | !(pt0_6@202@01) | dead]
; [else-branch: 1243 | pt0_6@202@01 | live]
(push) ; 36
; [else-branch: 1243 | pt0_6@202@01]
(pop) ; 36
(pop) ; 35
; [eval] !pt2_6
(push) ; 35
(set-option :rlimit 16000)
(assert (not pt2_6@203@01))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1244 | !(pt2_6@203@01) | dead]
; [else-branch: 1244 | pt2_6@203@01 | live]
(set-option :rlimit 0)
(push) ; 35
; [else-branch: 1244 | pt2_6@203@01]
(assert pt2_6@203@01)
(pop) ; 35
(pop) ; 34
(pop) ; 33
(push) ; 33
; [else-branch: 1177 | !(pt0_6@202@01)]
(assert (not pt0_6@202@01))
(pop) ; 33
; [eval] !pt0_6
(push) ; 33
(set-option :rlimit 16000)
(assert (not pt0_6@202@01))
(check-sat)
; unknown
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 33
(set-option :rlimit 16000)
(assert (not (not pt0_6@202@01)))
(check-sat)
; unknown
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1245 | !(pt0_6@202@01) | live]
; [else-branch: 1245 | pt0_6@202@01 | live]
(set-option :rlimit 0)
(push) ; 33
; [then-branch: 1245 | !(pt0_6@202@01)]
(assert (not pt0_6@202@01))
; [then-branch: 1246 | False | dead]
; [else-branch: 1246 | True | live]
(push) ; 34
; [else-branch: 1246 | True]
(pop) ; 34
; [eval] !pt1_6
(push) ; 34
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1247 | True | live]
; [else-branch: 1247 | False | dead]
(set-option :rlimit 0)
(push) ; 34
; [then-branch: 1247 | True]
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@203@01)))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1248 | pt2_6@203@01 | dead]
; [else-branch: 1248 | !(pt2_6@203@01) | live]
(set-option :rlimit 0)
(push) ; 35
; [else-branch: 1248 | !(pt2_6@203@01)]
(assert (not pt2_6@203@01))
(pop) ; 35
; [eval] !pt2_6
(push) ; 35
(set-option :rlimit 16000)
(assert (not pt2_6@203@01))
(check-sat)
; unknown
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 35
(set-option :rlimit 16000)
(assert (not (not pt2_6@203@01)))
(check-sat)
; unsat
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1249 | !(pt2_6@203@01) | live]
; [else-branch: 1249 | pt2_6@203@01 | dead]
(set-option :rlimit 0)
(push) ; 35
; [then-branch: 1249 | !(pt2_6@203@01)]
(assert (not pt2_6@203@01))
; [then-branch: 1250 | pt0_6@202@01 | dead]
; [else-branch: 1250 | !(pt0_6@202@01) | live]
(push) ; 36
; [else-branch: 1250 | !(pt0_6@202@01)]
(pop) ; 36
; [eval] !pt0_6
(push) ; 36
(set-option :rlimit 16000)
(assert (not pt0_6@202@01))
(check-sat)
; unknown
(pop) ; 36
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1251 | !(pt0_6@202@01) | live]
; [else-branch: 1251 | pt0_6@202@01 | dead]
(set-option :rlimit 0)
(push) ; 36
; [then-branch: 1251 | !(pt0_6@202@01)]
; [then-branch: 1252 | False | dead]
; [else-branch: 1252 | True | live]
(push) ; 37
; [else-branch: 1252 | True]
(pop) ; 37
; [eval] !pt1_6
(push) ; 37
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 37
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1253 | True | live]
; [else-branch: 1253 | False | dead]
(set-option :rlimit 0)
(push) ; 37
; [then-branch: 1253 | True]
; [then-branch: 1254 | pt2_6@203@01 | dead]
; [else-branch: 1254 | !(pt2_6@203@01) | live]
(push) ; 38
; [else-branch: 1254 | !(pt2_6@203@01)]
(pop) ; 38
; [eval] !pt2_6
(push) ; 38
(set-option :rlimit 16000)
(assert (not pt2_6@203@01))
(check-sat)
; unknown
(pop) ; 38
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1255 | !(pt2_6@203@01) | live]
; [else-branch: 1255 | pt2_6@203@01 | dead]
(set-option :rlimit 0)
(push) ; 38
; [then-branch: 1255 | !(pt2_6@203@01)]
(push) ; 39
(set-option :rlimit 16000)
(assert (not (not pf0_6@204@01)))
(check-sat)
; unknown
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 39
(set-option :rlimit 16000)
(assert (not pf0_6@204@01))
(check-sat)
; unknown
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1256 | pf0_6@204@01 | live]
; [else-branch: 1256 | !(pf0_6@204@01) | live]
(set-option :rlimit 0)
(push) ; 39
; [then-branch: 1256 | pf0_6@204@01]
(assert pf0_6@204@01)
; [exec]
; res := -1
; [eval] -1
; [then-branch: 1257 | False | dead]
; [else-branch: 1257 | True | live]
(push) ; 40
; [else-branch: 1257 | True]
(pop) ; 40
; [eval] !pf1_6
(push) ; 40
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1258 | True | live]
; [else-branch: 1258 | False | dead]
(set-option :rlimit 0)
(push) ; 40
; [then-branch: 1258 | True]
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@205@01)))
(check-sat)
; unknown
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 41
(set-option :rlimit 16000)
(assert (not pf2_6@205@01))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1259 | pf2_6@205@01 | live]
; [else-branch: 1259 | !(pf2_6@205@01) | dead]
(set-option :rlimit 0)
(push) ; 41
; [then-branch: 1259 | pf2_6@205@01]
(assert pf2_6@205@01)
; [exec]
; res_1 := -1
; [eval] -1
(push) ; 42
(set-option :rlimit 16000)
(assert (not (not pf0_6@204@01)))
(check-sat)
; unknown
(pop) ; 42
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1260 | pf0_6@204@01 | live]
; [else-branch: 1260 | !(pf0_6@204@01) | dead]
(set-option :rlimit 0)
(push) ; 42
; [then-branch: 1260 | pf0_6@204@01]
; [exec]
; returned := true
; [then-branch: 1261 | False | dead]
; [else-branch: 1261 | True | live]
(push) ; 43
; [else-branch: 1261 | True]
(pop) ; 43
; [eval] !pf1_6
(push) ; 43
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 43
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1262 | True | live]
; [else-branch: 1262 | False | dead]
(set-option :rlimit 0)
(push) ; 43
; [then-branch: 1262 | True]
(push) ; 44
(set-option :rlimit 16000)
(assert (not (not pf2_6@205@01)))
(check-sat)
; unknown
(pop) ; 44
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1263 | pf2_6@205@01 | live]
; [else-branch: 1263 | !(pf2_6@205@01) | dead]
(set-option :rlimit 0)
(push) ; 44
; [then-branch: 1263 | pf2_6@205@01]
; [exec]
; returned_1 := true
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@192@01)))
(check-sat)
; unsat
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1264 | pf0_4@192@01 | dead]
; [else-branch: 1264 | !(pf0_4@192@01) | live]
(set-option :rlimit 0)
(push) ; 45
; [else-branch: 1264 | !(pf0_4@192@01)]
(assert (not pf0_4@192@01))
(pop) ; 45
; [eval] !pf0_4
(push) ; 45
(set-option :rlimit 16000)
(assert (not pf0_4@192@01))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@192@01)))
(check-sat)
; unsat
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1265 | !(pf0_4@192@01) | live]
; [else-branch: 1265 | pf0_4@192@01 | dead]
(set-option :rlimit 0)
(push) ; 45
; [then-branch: 1265 | !(pf0_4@192@01)]
(assert (not pf0_4@192@01))
; [then-branch: 1266 | False | dead]
; [else-branch: 1266 | True | live]
(push) ; 46
; [else-branch: 1266 | True]
(pop) ; 46
; [eval] !pf1_4
(push) ; 46
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1267 | True | live]
; [else-branch: 1267 | False | dead]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 1267 | True]
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@193@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1268 | pf2_4@193@01 | dead]
; [else-branch: 1268 | !(pf2_4@193@01) | live]
(set-option :rlimit 0)
(push) ; 47
; [else-branch: 1268 | !(pf2_4@193@01)]
(assert (not pf2_4@193@01))
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not pf2_4@193@01))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@193@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1269 | !(pf2_4@193@01) | live]
; [else-branch: 1269 | pf2_4@193@01 | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 1269 | !(pf2_4@193@01)]
(assert (not pf2_4@193@01))
; [then-branch: 1270 | pf0_4@192@01 | dead]
; [else-branch: 1270 | !(pf0_4@192@01) | live]
(push) ; 48
; [else-branch: 1270 | !(pf0_4@192@01)]
(pop) ; 48
; [eval] !pf0_4
(push) ; 48
(set-option :rlimit 16000)
(assert (not pf0_4@192@01))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1271 | !(pf0_4@192@01) | live]
; [else-branch: 1271 | pf0_4@192@01 | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 1271 | !(pf0_4@192@01)]
; [then-branch: 1272 | False | dead]
; [else-branch: 1272 | True | live]
(push) ; 49
; [else-branch: 1272 | True]
(pop) ; 49
; [eval] !pf1_4
(push) ; 49
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1273 | True | live]
; [else-branch: 1273 | False | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 1273 | True]
; [then-branch: 1274 | pf2_4@193@01 | dead]
; [else-branch: 1274 | !(pf2_4@193@01) | live]
(push) ; 50
; [else-branch: 1274 | !(pf2_4@193@01)]
(pop) ; 50
; [eval] !pf2_4
(push) ; 50
(set-option :rlimit 16000)
(assert (not pf2_4@193@01))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1275 | !(pf2_4@193@01) | live]
; [else-branch: 1275 | pf2_4@193@01 | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 1275 | !(pf2_4@193@01)]
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@172@01)))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1276 | pf0_2@172@01 | dead]
; [else-branch: 1276 | !(pf0_2@172@01) | live]
(set-option :rlimit 0)
(push) ; 51
; [else-branch: 1276 | !(pf0_2@172@01)]
(assert (not pf0_2@172@01))
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not pf0_2@172@01))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@172@01)))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1277 | !(pf0_2@172@01) | live]
; [else-branch: 1277 | pf0_2@172@01 | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 1277 | !(pf0_2@172@01)]
(assert (not pf0_2@172@01))
; [then-branch: 1278 | False | dead]
; [else-branch: 1278 | True | live]
(push) ; 52
; [else-branch: 1278 | True]
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1279 | True | live]
; [else-branch: 1279 | False | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 1279 | True]
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@173@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1280 | pf2_2@173@01 | dead]
; [else-branch: 1280 | !(pf2_2@173@01) | live]
(set-option :rlimit 0)
(push) ; 53
; [else-branch: 1280 | !(pf2_2@173@01)]
(assert (not pf2_2@173@01))
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not pf2_2@173@01))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@173@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1281 | !(pf2_2@173@01) | live]
; [else-branch: 1281 | pf2_2@173@01 | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 1281 | !(pf2_2@173@01)]
(assert (not pf2_2@173@01))
; [then-branch: 1282 | pf0_2@172@01 | dead]
; [else-branch: 1282 | !(pf0_2@172@01) | live]
(push) ; 54
; [else-branch: 1282 | !(pf0_2@172@01)]
(pop) ; 54
; [eval] !pf0_2
(push) ; 54
(set-option :rlimit 16000)
(assert (not pf0_2@172@01))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1283 | !(pf0_2@172@01) | live]
; [else-branch: 1283 | pf0_2@172@01 | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 1283 | !(pf0_2@172@01)]
; [then-branch: 1284 | False | dead]
; [else-branch: 1284 | True | live]
(push) ; 55
; [else-branch: 1284 | True]
(pop) ; 55
; [eval] !pf1_2
(push) ; 55
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1285 | True | live]
; [else-branch: 1285 | False | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 1285 | True]
; [then-branch: 1286 | pf2_2@173@01 | dead]
; [else-branch: 1286 | !(pf2_2@173@01) | live]
(push) ; 56
; [else-branch: 1286 | !(pf2_2@173@01)]
(pop) ; 56
; [eval] !pf2_2
(push) ; 56
(set-option :rlimit 16000)
(assert (not pf2_2@173@01))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1287 | !(pf2_2@173@01) | live]
; [else-branch: 1287 | pf2_2@173@01 | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 1287 | !(pf2_2@173@01)]
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1288 | p0@12@01 | live]
; [else-branch: 1288 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1288 | p0@12@01]
(assert p0@12@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1289 | p1@13@01 | live]
; [else-branch: 1289 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1289 | p1@13@01]
(assert p1@13@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p1@13@01)
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1290 | p2@14@01 | live]
; [else-branch: 1290 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1290 | p2@14@01]
(assert p2@14@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p2@14@01)
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1291 | p0@12@01 | live]
; [else-branch: 1291 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1291 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1292 | False | live]
; [else-branch: 1292 | True | live]
(push) ; 60
; [then-branch: 1292 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1292 | True]
(push) ; 61
; [then-branch: 1293 | !(p0@12@01) | live]
; [else-branch: 1293 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1293 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1293 | p0@12@01]
(push) ; 63
; [then-branch: 1294 | !(p1@13@01) | live]
; [else-branch: 1294 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1294 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1294 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1295 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1295 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1295 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1296 | False | dead]
; [else-branch: 1296 | True | live]
(push) ; 62
; [else-branch: 1296 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1297 | p1@13@01 | live]
; [else-branch: 1297 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1297 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1298 | False | live]
; [else-branch: 1298 | True | live]
(push) ; 60
; [then-branch: 1298 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1298 | True]
(push) ; 61
; [then-branch: 1299 | !(p0@12@01) | live]
; [else-branch: 1299 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1299 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1299 | p0@12@01]
(push) ; 63
; [then-branch: 1300 | !(p1@13@01) | live]
; [else-branch: 1300 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1300 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1300 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1301 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1301 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1301 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1302 | False | dead]
; [else-branch: 1302 | True | live]
(push) ; 62
; [else-branch: 1302 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p2@14@01)))
(assert p1@13@01)
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1303 | p2@14@01 | live]
; [else-branch: 1303 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1303 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1304 | False | live]
; [else-branch: 1304 | True | live]
(push) ; 60
; [then-branch: 1304 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1304 | True]
(push) ; 61
; [then-branch: 1305 | !(p0@12@01) | live]
; [else-branch: 1305 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1305 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1305 | p0@12@01]
(assert p0@12@01)
(push) ; 63
; [then-branch: 1306 | !(p1@13@01) | live]
; [else-branch: 1306 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1306 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1306 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1307 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1307 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1307 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1308 | False | dead]
; [else-branch: 1308 | True | live]
(push) ; 62
; [else-branch: 1308 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01)))
(assert p2@14@01)
(pop) ; 56
(pop) ; 55
(pop) ; 54
(pop) ; 53
(pop) ; 52
(pop) ; 51
(pop) ; 50
(pop) ; 49
(pop) ; 48
(pop) ; 47
(pop) ; 46
(pop) ; 45
(pop) ; 44
; [eval] !pf2_6
; [then-branch: 1309 | !(pf2_6@205@01) | dead]
; [else-branch: 1309 | pf2_6@205@01 | live]
(push) ; 44
; [else-branch: 1309 | pf2_6@205@01]
(pop) ; 44
(pop) ; 43
(pop) ; 42
; [eval] !pf0_6
; [then-branch: 1310 | !(pf0_6@204@01) | dead]
; [else-branch: 1310 | pf0_6@204@01 | live]
(push) ; 42
; [else-branch: 1310 | pf0_6@204@01]
(pop) ; 42
(pop) ; 41
; [eval] !pf2_6
(push) ; 41
(set-option :rlimit 16000)
(assert (not pf2_6@205@01))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1311 | !(pf2_6@205@01) | dead]
; [else-branch: 1311 | pf2_6@205@01 | live]
(set-option :rlimit 0)
(push) ; 41
; [else-branch: 1311 | pf2_6@205@01]
(assert pf2_6@205@01)
(pop) ; 41
(pop) ; 40
(pop) ; 39
(push) ; 39
; [else-branch: 1256 | !(pf0_6@204@01)]
(assert (not pf0_6@204@01))
(pop) ; 39
; [eval] !pf0_6
(push) ; 39
(set-option :rlimit 16000)
(assert (not pf0_6@204@01))
(check-sat)
; unknown
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 39
(set-option :rlimit 16000)
(assert (not (not pf0_6@204@01)))
(check-sat)
; unknown
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1312 | !(pf0_6@204@01) | live]
; [else-branch: 1312 | pf0_6@204@01 | live]
(set-option :rlimit 0)
(push) ; 39
; [then-branch: 1312 | !(pf0_6@204@01)]
(assert (not pf0_6@204@01))
; [then-branch: 1313 | False | dead]
; [else-branch: 1313 | True | live]
(push) ; 40
; [else-branch: 1313 | True]
(pop) ; 40
; [eval] !pf1_6
(push) ; 40
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1314 | True | live]
; [else-branch: 1314 | False | dead]
(set-option :rlimit 0)
(push) ; 40
; [then-branch: 1314 | True]
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@205@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1315 | pf2_6@205@01 | dead]
; [else-branch: 1315 | !(pf2_6@205@01) | live]
(set-option :rlimit 0)
(push) ; 41
; [else-branch: 1315 | !(pf2_6@205@01)]
(assert (not pf2_6@205@01))
(pop) ; 41
; [eval] !pf2_6
(push) ; 41
(set-option :rlimit 16000)
(assert (not pf2_6@205@01))
(check-sat)
; unknown
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 41
(set-option :rlimit 16000)
(assert (not (not pf2_6@205@01)))
(check-sat)
; unsat
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1316 | !(pf2_6@205@01) | live]
; [else-branch: 1316 | pf2_6@205@01 | dead]
(set-option :rlimit 0)
(push) ; 41
; [then-branch: 1316 | !(pf2_6@205@01)]
(assert (not pf2_6@205@01))
; [then-branch: 1317 | pf0_6@204@01 | dead]
; [else-branch: 1317 | !(pf0_6@204@01) | live]
(push) ; 42
; [else-branch: 1317 | !(pf0_6@204@01)]
(pop) ; 42
; [eval] !pf0_6
(push) ; 42
(set-option :rlimit 16000)
(assert (not pf0_6@204@01))
(check-sat)
; unknown
(pop) ; 42
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1318 | !(pf0_6@204@01) | live]
; [else-branch: 1318 | pf0_6@204@01 | dead]
(set-option :rlimit 0)
(push) ; 42
; [then-branch: 1318 | !(pf0_6@204@01)]
; [then-branch: 1319 | False | dead]
; [else-branch: 1319 | True | live]
(push) ; 43
; [else-branch: 1319 | True]
(pop) ; 43
; [eval] !pf1_6
(push) ; 43
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 43
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1320 | True | live]
; [else-branch: 1320 | False | dead]
(set-option :rlimit 0)
(push) ; 43
; [then-branch: 1320 | True]
; [then-branch: 1321 | pf2_6@205@01 | dead]
; [else-branch: 1321 | !(pf2_6@205@01) | live]
(push) ; 44
; [else-branch: 1321 | !(pf2_6@205@01)]
(pop) ; 44
; [eval] !pf2_6
(push) ; 44
(set-option :rlimit 16000)
(assert (not pf2_6@205@01))
(check-sat)
; unknown
(pop) ; 44
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1322 | !(pf2_6@205@01) | live]
; [else-branch: 1322 | pf2_6@205@01 | dead]
(set-option :rlimit 0)
(push) ; 44
; [then-branch: 1322 | !(pf2_6@205@01)]
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@192@01)))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 45
(set-option :rlimit 16000)
(assert (not pf0_4@192@01))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1323 | pf0_4@192@01 | live]
; [else-branch: 1323 | !(pf0_4@192@01) | live]
(set-option :rlimit 0)
(push) ; 45
; [then-branch: 1323 | pf0_4@192@01]
(assert pf0_4@192@01)
; [exec]
; res := -1
; [eval] -1
; [then-branch: 1324 | False | dead]
; [else-branch: 1324 | True | live]
(push) ; 46
; [else-branch: 1324 | True]
(pop) ; 46
; [eval] !pf1_4
(push) ; 46
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1325 | True | live]
; [else-branch: 1325 | False | dead]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 1325 | True]
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@193@01)))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 47
(set-option :rlimit 16000)
(assert (not pf2_4@193@01))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1326 | pf2_4@193@01 | live]
; [else-branch: 1326 | !(pf2_4@193@01) | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 1326 | pf2_4@193@01]
(assert pf2_4@193@01)
; [exec]
; res_1 := -1
; [eval] -1
(push) ; 48
(set-option :rlimit 16000)
(assert (not (not pf0_4@192@01)))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1327 | pf0_4@192@01 | live]
; [else-branch: 1327 | !(pf0_4@192@01) | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 1327 | pf0_4@192@01]
; [exec]
; returned := true
; [then-branch: 1328 | False | dead]
; [else-branch: 1328 | True | live]
(push) ; 49
; [else-branch: 1328 | True]
(pop) ; 49
; [eval] !pf1_4
(push) ; 49
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1329 | True | live]
; [else-branch: 1329 | False | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 1329 | True]
(push) ; 50
(set-option :rlimit 16000)
(assert (not (not pf2_4@193@01)))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1330 | pf2_4@193@01 | live]
; [else-branch: 1330 | !(pf2_4@193@01) | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 1330 | pf2_4@193@01]
; [exec]
; returned_1 := true
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@172@01)))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1331 | pf0_2@172@01 | dead]
; [else-branch: 1331 | !(pf0_2@172@01) | live]
(set-option :rlimit 0)
(push) ; 51
; [else-branch: 1331 | !(pf0_2@172@01)]
(assert (not pf0_2@172@01))
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not pf0_2@172@01))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@172@01)))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1332 | !(pf0_2@172@01) | live]
; [else-branch: 1332 | pf0_2@172@01 | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 1332 | !(pf0_2@172@01)]
(assert (not pf0_2@172@01))
; [then-branch: 1333 | False | dead]
; [else-branch: 1333 | True | live]
(push) ; 52
; [else-branch: 1333 | True]
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1334 | True | live]
; [else-branch: 1334 | False | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 1334 | True]
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@173@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1335 | pf2_2@173@01 | dead]
; [else-branch: 1335 | !(pf2_2@173@01) | live]
(set-option :rlimit 0)
(push) ; 53
; [else-branch: 1335 | !(pf2_2@173@01)]
(assert (not pf2_2@173@01))
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not pf2_2@173@01))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@173@01)))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1336 | !(pf2_2@173@01) | live]
; [else-branch: 1336 | pf2_2@173@01 | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 1336 | !(pf2_2@173@01)]
(assert (not pf2_2@173@01))
; [then-branch: 1337 | pf0_2@172@01 | dead]
; [else-branch: 1337 | !(pf0_2@172@01) | live]
(push) ; 54
; [else-branch: 1337 | !(pf0_2@172@01)]
(pop) ; 54
; [eval] !pf0_2
(push) ; 54
(set-option :rlimit 16000)
(assert (not pf0_2@172@01))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1338 | !(pf0_2@172@01) | live]
; [else-branch: 1338 | pf0_2@172@01 | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 1338 | !(pf0_2@172@01)]
; [then-branch: 1339 | False | dead]
; [else-branch: 1339 | True | live]
(push) ; 55
; [else-branch: 1339 | True]
(pop) ; 55
; [eval] !pf1_2
(push) ; 55
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1340 | True | live]
; [else-branch: 1340 | False | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 1340 | True]
; [then-branch: 1341 | pf2_2@173@01 | dead]
; [else-branch: 1341 | !(pf2_2@173@01) | live]
(push) ; 56
; [else-branch: 1341 | !(pf2_2@173@01)]
(pop) ; 56
; [eval] !pf2_2
(push) ; 56
(set-option :rlimit 16000)
(assert (not pf2_2@173@01))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1342 | !(pf2_2@173@01) | live]
; [else-branch: 1342 | pf2_2@173@01 | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 1342 | !(pf2_2@173@01)]
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1343 | p0@12@01 | live]
; [else-branch: 1343 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1343 | p0@12@01]
(assert p0@12@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1344 | p1@13@01 | live]
; [else-branch: 1344 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1344 | p1@13@01]
(assert p1@13@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p1@13@01)
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1345 | p2@14@01 | live]
; [else-branch: 1345 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1345 | p2@14@01]
(assert p2@14@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p2@14@01)
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1346 | p0@12@01 | live]
; [else-branch: 1346 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1346 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1347 | False | live]
; [else-branch: 1347 | True | live]
(push) ; 60
; [then-branch: 1347 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1347 | True]
(push) ; 61
; [then-branch: 1348 | !(p0@12@01) | live]
; [else-branch: 1348 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1348 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1348 | p0@12@01]
(push) ; 63
; [then-branch: 1349 | !(p1@13@01) | live]
; [else-branch: 1349 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1349 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1349 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1350 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1350 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1350 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1351 | False | dead]
; [else-branch: 1351 | True | live]
(push) ; 62
; [else-branch: 1351 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1352 | p1@13@01 | live]
; [else-branch: 1352 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1352 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1353 | False | live]
; [else-branch: 1353 | True | live]
(push) ; 60
; [then-branch: 1353 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1353 | True]
(push) ; 61
; [then-branch: 1354 | !(p0@12@01) | live]
; [else-branch: 1354 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1354 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1354 | p0@12@01]
(push) ; 63
; [then-branch: 1355 | !(p1@13@01) | live]
; [else-branch: 1355 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1355 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1355 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1356 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1356 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1356 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1357 | False | dead]
; [else-branch: 1357 | True | live]
(push) ; 62
; [else-branch: 1357 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p2@14@01)))
(assert p1@13@01)
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1358 | p2@14@01 | live]
; [else-branch: 1358 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1358 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1359 | False | live]
; [else-branch: 1359 | True | live]
(push) ; 60
; [then-branch: 1359 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1359 | True]
(push) ; 61
; [then-branch: 1360 | !(p0@12@01) | live]
; [else-branch: 1360 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1360 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1360 | p0@12@01]
(assert p0@12@01)
(push) ; 63
; [then-branch: 1361 | !(p1@13@01) | live]
; [else-branch: 1361 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1361 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1361 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1362 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1362 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1362 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1363 | False | dead]
; [else-branch: 1363 | True | live]
(push) ; 62
; [else-branch: 1363 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01)))
(assert p2@14@01)
(pop) ; 56
(pop) ; 55
(pop) ; 54
(pop) ; 53
(pop) ; 52
(pop) ; 51
(pop) ; 50
; [eval] !pf2_4
; [then-branch: 1364 | !(pf2_4@193@01) | dead]
; [else-branch: 1364 | pf2_4@193@01 | live]
(push) ; 50
; [else-branch: 1364 | pf2_4@193@01]
(pop) ; 50
(pop) ; 49
(pop) ; 48
; [eval] !pf0_4
; [then-branch: 1365 | !(pf0_4@192@01) | dead]
; [else-branch: 1365 | pf0_4@192@01 | live]
(push) ; 48
; [else-branch: 1365 | pf0_4@192@01]
(pop) ; 48
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not pf2_4@193@01))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1366 | !(pf2_4@193@01) | dead]
; [else-branch: 1366 | pf2_4@193@01 | live]
(set-option :rlimit 0)
(push) ; 47
; [else-branch: 1366 | pf2_4@193@01]
(assert pf2_4@193@01)
(pop) ; 47
(pop) ; 46
(pop) ; 45
(push) ; 45
; [else-branch: 1323 | !(pf0_4@192@01)]
(assert (not pf0_4@192@01))
(pop) ; 45
; [eval] !pf0_4
(push) ; 45
(set-option :rlimit 16000)
(assert (not pf0_4@192@01))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@192@01)))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1367 | !(pf0_4@192@01) | live]
; [else-branch: 1367 | pf0_4@192@01 | live]
(set-option :rlimit 0)
(push) ; 45
; [then-branch: 1367 | !(pf0_4@192@01)]
(assert (not pf0_4@192@01))
; [then-branch: 1368 | False | dead]
; [else-branch: 1368 | True | live]
(push) ; 46
; [else-branch: 1368 | True]
(pop) ; 46
; [eval] !pf1_4
(push) ; 46
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1369 | True | live]
; [else-branch: 1369 | False | dead]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 1369 | True]
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@193@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1370 | pf2_4@193@01 | dead]
; [else-branch: 1370 | !(pf2_4@193@01) | live]
(set-option :rlimit 0)
(push) ; 47
; [else-branch: 1370 | !(pf2_4@193@01)]
(assert (not pf2_4@193@01))
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not pf2_4@193@01))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 47
(set-option :rlimit 16000)
(assert (not (not pf2_4@193@01)))
(check-sat)
; unsat
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1371 | !(pf2_4@193@01) | live]
; [else-branch: 1371 | pf2_4@193@01 | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 1371 | !(pf2_4@193@01)]
(assert (not pf2_4@193@01))
; [then-branch: 1372 | pf0_4@192@01 | dead]
; [else-branch: 1372 | !(pf0_4@192@01) | live]
(push) ; 48
; [else-branch: 1372 | !(pf0_4@192@01)]
(pop) ; 48
; [eval] !pf0_4
(push) ; 48
(set-option :rlimit 16000)
(assert (not pf0_4@192@01))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1373 | !(pf0_4@192@01) | live]
; [else-branch: 1373 | pf0_4@192@01 | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 1373 | !(pf0_4@192@01)]
; [then-branch: 1374 | False | dead]
; [else-branch: 1374 | True | live]
(push) ; 49
; [else-branch: 1374 | True]
(pop) ; 49
; [eval] !pf1_4
(push) ; 49
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1375 | True | live]
; [else-branch: 1375 | False | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 1375 | True]
; [then-branch: 1376 | pf2_4@193@01 | dead]
; [else-branch: 1376 | !(pf2_4@193@01) | live]
(push) ; 50
; [else-branch: 1376 | !(pf2_4@193@01)]
(pop) ; 50
; [eval] !pf2_4
(push) ; 50
(set-option :rlimit 16000)
(assert (not pf2_4@193@01))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1377 | !(pf2_4@193@01) | live]
; [else-branch: 1377 | pf2_4@193@01 | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 1377 | !(pf2_4@193@01)]
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@172@01)))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 51
(set-option :rlimit 16000)
(assert (not pf0_2@172@01))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1378 | pf0_2@172@01 | live]
; [else-branch: 1378 | !(pf0_2@172@01) | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 1378 | pf0_2@172@01]
(assert pf0_2@172@01)
; [exec]
; res := -1
; [eval] -1
; [then-branch: 1379 | False | dead]
; [else-branch: 1379 | True | live]
(push) ; 52
; [else-branch: 1379 | True]
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1380 | True | live]
; [else-branch: 1380 | False | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 1380 | True]
(push) ; 53
(set-option :rlimit 16000)
(assert (not (not pf2_2@173@01)))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 53
(set-option :rlimit 16000)
(assert (not pf2_2@173@01))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1381 | pf2_2@173@01 | live]
; [else-branch: 1381 | !(pf2_2@173@01) | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 1381 | pf2_2@173@01]
(assert pf2_2@173@01)
; [exec]
; res_1 := -1
; [eval] -1
(push) ; 54
(set-option :rlimit 16000)
(assert (not (not pf0_2@172@01)))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1382 | pf0_2@172@01 | live]
; [else-branch: 1382 | !(pf0_2@172@01) | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 1382 | pf0_2@172@01]
; [exec]
; returned := true
; [then-branch: 1383 | False | dead]
; [else-branch: 1383 | True | live]
(push) ; 55
; [else-branch: 1383 | True]
(pop) ; 55
; [eval] !pf1_2
(push) ; 55
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1384 | True | live]
; [else-branch: 1384 | False | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 1384 | True]
(push) ; 56
(set-option :rlimit 16000)
(assert (not (not pf2_2@173@01)))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1385 | pf2_2@173@01 | live]
; [else-branch: 1385 | !(pf2_2@173@01) | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 1385 | pf2_2@173@01]
; [exec]
; returned_1 := true
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1386 | p0@12@01 | live]
; [else-branch: 1386 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1386 | p0@12@01]
(assert p0@12@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1387 | p1@13@01 | live]
; [else-branch: 1387 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1387 | p1@13@01]
(assert p1@13@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p1@13@01)
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1388 | p2@14@01 | live]
; [else-branch: 1388 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1388 | p2@14@01]
(assert p2@14@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p2@14@01)
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1389 | p0@12@01 | live]
; [else-branch: 1389 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1389 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1390 | False | live]
; [else-branch: 1390 | True | live]
(push) ; 60
; [then-branch: 1390 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1390 | True]
(push) ; 61
; [then-branch: 1391 | !(p0@12@01) | live]
; [else-branch: 1391 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1391 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1391 | p0@12@01]
(push) ; 63
; [then-branch: 1392 | !(p1@13@01) | live]
; [else-branch: 1392 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1392 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1392 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1393 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1393 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1393 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1394 | False | dead]
; [else-branch: 1394 | True | live]
(push) ; 62
; [else-branch: 1394 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1395 | p1@13@01 | live]
; [else-branch: 1395 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1395 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1396 | False | live]
; [else-branch: 1396 | True | live]
(push) ; 60
; [then-branch: 1396 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1396 | True]
(push) ; 61
; [then-branch: 1397 | !(p0@12@01) | live]
; [else-branch: 1397 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1397 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1397 | p0@12@01]
(push) ; 63
; [then-branch: 1398 | !(p1@13@01) | live]
; [else-branch: 1398 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1398 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1398 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1399 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1399 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1399 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1400 | False | dead]
; [else-branch: 1400 | True | live]
(push) ; 62
; [else-branch: 1400 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p2@14@01)))
(assert p1@13@01)
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1401 | p2@14@01 | live]
; [else-branch: 1401 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1401 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1402 | False | live]
; [else-branch: 1402 | True | live]
(push) ; 60
; [then-branch: 1402 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1402 | True]
(push) ; 61
; [then-branch: 1403 | !(p0@12@01) | live]
; [else-branch: 1403 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1403 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1403 | p0@12@01]
(assert p0@12@01)
(push) ; 63
; [then-branch: 1404 | !(p1@13@01) | live]
; [else-branch: 1404 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1404 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1404 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1405 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1405 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1405 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1406 | False | dead]
; [else-branch: 1406 | True | live]
(push) ; 62
; [else-branch: 1406 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01)))
(assert p2@14@01)
(pop) ; 56
; [eval] !pf2_2
; [then-branch: 1407 | !(pf2_2@173@01) | dead]
; [else-branch: 1407 | pf2_2@173@01 | live]
(push) ; 56
; [else-branch: 1407 | pf2_2@173@01]
(pop) ; 56
(pop) ; 55
(pop) ; 54
; [eval] !pf0_2
; [then-branch: 1408 | !(pf0_2@172@01) | dead]
; [else-branch: 1408 | pf0_2@172@01 | live]
(push) ; 54
; [else-branch: 1408 | pf0_2@172@01]
(pop) ; 54
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not pf2_2@173@01))
(check-sat)
; unsat
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1409 | !(pf2_2@173@01) | dead]
; [else-branch: 1409 | pf2_2@173@01 | live]
(set-option :rlimit 0)
(push) ; 53
; [else-branch: 1409 | pf2_2@173@01]
(assert pf2_2@173@01)
(pop) ; 53
(pop) ; 52
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not pf0_2@172@01))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1410 | !(pf0_2@172@01) | dead]
; [else-branch: 1410 | pf0_2@172@01 | live]
(set-option :rlimit 0)
(push) ; 51
; [else-branch: 1410 | pf0_2@172@01]
(assert pf0_2@172@01)
(pop) ; 51
(pop) ; 50
(pop) ; 49
(pop) ; 48
(pop) ; 47
(pop) ; 46
(pop) ; 45
(push) ; 45
; [else-branch: 1367 | pf0_4@192@01]
(assert pf0_4@192@01)
(pop) ; 45
(pop) ; 44
(pop) ; 43
(pop) ; 42
(pop) ; 41
(pop) ; 40
(pop) ; 39
(push) ; 39
; [else-branch: 1312 | pf0_6@204@01]
(assert pf0_6@204@01)
(pop) ; 39
(pop) ; 38
(pop) ; 37
(pop) ; 36
(pop) ; 35
(pop) ; 34
(pop) ; 33
(push) ; 33
; [else-branch: 1245 | pt0_6@202@01]
(assert pt0_6@202@01)
(pop) ; 33
(pop) ; 32
(pop) ; 31
(pop) ; 30
(pop) ; 29
(pop) ; 28
(pop) ; 27
(push) ; 27
; [else-branch: 1162 | pt0_5@194@01]
(assert pt0_5@194@01)
(pop) ; 27
(pop) ; 26
(pop) ; 25
(pop) ; 24
(pop) ; 23
(pop) ; 22
(pop) ; 21
(push) ; 21
; [else-branch: 1056 | pt0_3@174@01]
(assert pt0_3@174@01)
(pop) ; 21
(pop) ; 20
(pop) ; 19
(pop) ; 18
(pop) ; 17
(pop) ; 16
(pop) ; 15
(push) ; 15
; [else-branch: 930 | pt0_1@146@01]
(assert pt0_1@146@01)
(pop) ; 15
(pop) ; 14
(pop) ; 13
; [eval] !pt1
; [then-branch: 1411 | !(pt1@81@01) | dead]
; [else-branch: 1411 | pt1@81@01 | live]
(push) ; 13
; [else-branch: 1411 | pt1@81@01]
(pop) ; 13
(pop) ; 12
(pop) ; 11
(pop) ; 10
(push) ; 10
; [else-branch: 788 | !(pt1@81@01)]
(assert (not pt1@81@01))
(pop) ; 10
; [eval] !pt1
(push) ; 10
(set-option :rlimit 16000)
(assert (not pt1@81@01))
(check-sat)
; unknown
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 10
(set-option :rlimit 16000)
(assert (not (not pt1@81@01)))
(check-sat)
; unknown
(pop) ; 10
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1412 | !(pt1@81@01) | live]
; [else-branch: 1412 | pt1@81@01 | live]
(set-option :rlimit 0)
(push) ; 10
; [then-branch: 1412 | !(pt1@81@01)]
(assert (not pt1@81@01))
(push) ; 11
(set-option :rlimit 16000)
(assert (not (not pt2@82@01)))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 11
(set-option :rlimit 16000)
(assert (not pt2@82@01))
(check-sat)
; unknown
(pop) ; 11
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1413 | pt2@82@01 | live]
; [else-branch: 1413 | !(pt2@82@01) | live]
(set-option :rlimit 0)
(push) ; 11
; [then-branch: 1413 | pt2@82@01]
(assert pt2@82@01)
; [exec]
; res_1 := 0
; [then-branch: 1414 | pt0@80@01 | dead]
; [else-branch: 1414 | !(pt0@80@01) | live]
(push) ; 12
; [else-branch: 1414 | !(pt0@80@01)]
(pop) ; 12
; [eval] !pt0
(push) ; 12
(set-option :rlimit 16000)
(assert (not pt0@80@01))
(check-sat)
; unknown
(pop) ; 12
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1415 | !(pt0@80@01) | live]
; [else-branch: 1415 | pt0@80@01 | dead]
(set-option :rlimit 0)
(push) ; 12
; [then-branch: 1415 | !(pt0@80@01)]
; [then-branch: 1416 | pt1@81@01 | dead]
; [else-branch: 1416 | !(pt1@81@01) | live]
(push) ; 13
; [else-branch: 1416 | !(pt1@81@01)]
(pop) ; 13
; [eval] !pt1
(push) ; 13
(set-option :rlimit 16000)
(assert (not pt1@81@01))
(check-sat)
; unknown
(pop) ; 13
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1417 | !(pt1@81@01) | live]
; [else-branch: 1417 | pt1@81@01 | dead]
(set-option :rlimit 0)
(push) ; 13
; [then-branch: 1417 | !(pt1@81@01)]
(push) ; 14
(set-option :rlimit 16000)
(assert (not (not pt2@82@01)))
(check-sat)
; unknown
(pop) ; 14
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1418 | pt2@82@01 | live]
; [else-branch: 1418 | !(pt2@82@01) | dead]
(set-option :rlimit 0)
(push) ; 14
; [then-branch: 1418 | pt2@82@01]
; [exec]
; returned_1 := true
; [exec]
; pt0_0 := p0 && !returned
; [eval] p0 && !returned
(push) ; 15
; [then-branch: 1419 | !(p0@12@01) | live]
; [else-branch: 1419 | p0@12@01 | live]
(push) ; 16
; [then-branch: 1419 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 16
(push) ; 16
; [else-branch: 1419 | p0@12@01]
(assert p0@12@01)
; [eval] !returned
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pt1_0 := p1 && !returned_0
; [eval] p1 && !returned_0
(push) ; 15
; [then-branch: 1420 | !(p1@13@01) | live]
; [else-branch: 1420 | p1@13@01 | live]
(push) ; 16
; [then-branch: 1420 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 16
(push) ; 16
; [else-branch: 1420 | p1@13@01]
(assert p1@13@01)
; [eval] !returned_0
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pt2_0 := p2 && !returned_1
; [eval] p2 && !returned_1
(push) ; 15
; [then-branch: 1421 | !(p2@14@01) | live]
; [else-branch: 1421 | p2@14@01 | live]
(push) ; 16
; [then-branch: 1421 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 16
(push) ; 16
; [else-branch: 1421 | p2@14@01]
(assert p2@14@01)
; [eval] !returned_1
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pf0_0 := p0 && !!returned
; [eval] p0 && !!returned
(push) ; 15
; [then-branch: 1422 | !(p0@12@01) | live]
; [else-branch: 1422 | p0@12@01 | live]
(push) ; 16
; [then-branch: 1422 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 16
(push) ; 16
; [else-branch: 1422 | p0@12@01]
(assert p0@12@01)
; [eval] !!returned
; [eval] !returned
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pf1_0 := p1 && !!returned_0
; [eval] p1 && !!returned_0
(push) ; 15
; [then-branch: 1423 | !(p1@13@01) | live]
; [else-branch: 1423 | p1@13@01 | live]
(push) ; 16
; [then-branch: 1423 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 16
(push) ; 16
; [else-branch: 1423 | p1@13@01]
(assert p1@13@01)
; [eval] !!returned_0
; [eval] !returned_0
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pf2_0 := p2 && !!returned_1
; [eval] p2 && !!returned_1
(push) ; 15
; [then-branch: 1424 | !(p2@14@01) | live]
; [else-branch: 1424 | p2@14@01 | live]
(push) ; 16
; [then-branch: 1424 | !(p2@14@01)]
(assert (not p2@14@01))
(pop) ; 16
(push) ; 16
; [else-branch: 1424 | p2@14@01]
(assert p2@14@01)
; [eval] !!returned_1
; [eval] !returned_1
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
; [exec]
; pt0_1 := pt0_0 && getCardSet(o1) < getCardSet(o2)
; [eval] pt0_0 && getCardSet(o1) < getCardSet(o2)
(push) ; 15
; [then-branch: 1425 | !(p0@12@01) | live]
; [else-branch: 1425 | p0@12@01 | live]
(push) ; 16
; [then-branch: 1425 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 16
(push) ; 16
; [else-branch: 1425 | p0@12@01]
(assert p0@12@01)
; [eval] getCardSet(o1) < getCardSet(o2)
; [eval] getCardSet(o1)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o1@15@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1@15@01))
; [eval] getCardSet(o2)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    p0@12@01
    (getCardSet%precondition $Snap.unit o1@15@01)
    (getCardSet%precondition $Snap.unit o2@18@01))))
(declare-const pt0_1@206@01 Bool)
(assert (=
  pt0_1@206@01
  (and
    p0@12@01
    (< (getCardSet $Snap.unit o1@15@01) (getCardSet $Snap.unit o2@18@01)))))
; [exec]
; pt1_1 := pt1_0 && getCardSet(o1_0) < getCardSet(o2_0)
; [eval] pt1_0 && getCardSet(o1_0) < getCardSet(o2_0)
(push) ; 15
; [then-branch: 1426 | !(p1@13@01) | live]
; [else-branch: 1426 | p1@13@01 | live]
(push) ; 16
; [then-branch: 1426 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 16
(push) ; 16
; [else-branch: 1426 | p1@13@01]
(assert p1@13@01)
; [eval] getCardSet(o1_0) < getCardSet(o2_0)
; [eval] getCardSet(o1_0)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
; [eval] getCardSet(o2_0)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (getCardSet%precondition $Snap.unit o1_0@16@01)
    (getCardSet%precondition $Snap.unit o2_0@19@01))))
(declare-const pt1_1@207@01 Bool)
(assert (=
  pt1_1@207@01
  (and
    p1@13@01
    (< (getCardSet $Snap.unit o1_0@16@01) (getCardSet $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_1 := pt2_0 && getCardSet(o1_1) < getCardSet(o2_1)
; [eval] pt2_0 && getCardSet(o1_1) < getCardSet(o2_1)
; [exec]
; pf0_1 := pt0_0 && !(getCardSet(o1) < getCardSet(o2))
; [eval] pt0_0 && !(getCardSet(o1) < getCardSet(o2))
(push) ; 15
; [then-branch: 1427 | !(p0@12@01) | live]
; [else-branch: 1427 | p0@12@01 | live]
(push) ; 16
; [then-branch: 1427 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 16
(push) ; 16
; [else-branch: 1427 | p0@12@01]
(assert p0@12@01)
; [eval] !(getCardSet(o1) < getCardSet(o2))
; [eval] getCardSet(o1) < getCardSet(o2)
; [eval] getCardSet(o1)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o1@15@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1@15@01))
; [eval] getCardSet(o2)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
(declare-const pf0_1@208@01 Bool)
(assert (=
  pf0_1@208@01
  (and
    p0@12@01
    (not (< (getCardSet $Snap.unit o1@15@01) (getCardSet $Snap.unit o2@18@01))))))
; [exec]
; pf1_1 := pt1_0 && !(getCardSet(o1_0) < getCardSet(o2_0))
; [eval] pt1_0 && !(getCardSet(o1_0) < getCardSet(o2_0))
(push) ; 15
; [then-branch: 1428 | !(p1@13@01) | live]
; [else-branch: 1428 | p1@13@01 | live]
(push) ; 16
; [then-branch: 1428 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 16
(push) ; 16
; [else-branch: 1428 | p1@13@01]
(assert p1@13@01)
; [eval] !(getCardSet(o1_0) < getCardSet(o2_0))
; [eval] getCardSet(o1_0) < getCardSet(o2_0)
; [eval] getCardSet(o1_0)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
; [eval] getCardSet(o2_0)
(push) ; 17
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 17
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 16
(pop) ; 15
; Joined path conditions
; Joined path conditions
(declare-const pf1_1@209@01 Bool)
(assert (=
  pf1_1@209@01
  (and
    p1@13@01
    (not
      (< (getCardSet $Snap.unit o1_0@16@01) (getCardSet $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_1 := pt2_0 && !(getCardSet(o1_1) < getCardSet(o2_1))
; [eval] pt2_0 && !(getCardSet(o1_1) < getCardSet(o2_1))
(push) ; 15
(set-option :rlimit 16000)
(assert (not (not pt0_1@206@01)))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 16000)
(assert (not pt0_1@206@01))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1429 | pt0_1@206@01 | live]
; [else-branch: 1429 | !(pt0_1@206@01) | live]
(set-option :rlimit 0)
(push) ; 15
; [then-branch: 1429 | pt0_1@206@01]
(assert pt0_1@206@01)
; [exec]
; res := -1
; [eval] -1
(push) ; 16
(set-option :rlimit 16000)
(assert (not (not pt1_1@207@01)))
(check-sat)
; unsat
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1430 | pt1_1@207@01 | dead]
; [else-branch: 1430 | !(pt1_1@207@01) | live]
(set-option :rlimit 0)
(push) ; 16
; [else-branch: 1430 | !(pt1_1@207@01)]
(assert (not pt1_1@207@01))
(pop) ; 16
; [eval] !pt1_1
(push) ; 16
(set-option :rlimit 16000)
(assert (not pt1_1@207@01))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 16000)
(assert (not (not pt1_1@207@01)))
(check-sat)
; unsat
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1431 | !(pt1_1@207@01) | live]
; [else-branch: 1431 | pt1_1@207@01 | dead]
(set-option :rlimit 0)
(push) ; 16
; [then-branch: 1431 | !(pt1_1@207@01)]
(assert (not pt1_1@207@01))
; [then-branch: 1432 | False | dead]
; [else-branch: 1432 | True | live]
(push) ; 17
; [else-branch: 1432 | True]
(pop) ; 17
; [eval] !pt2_1
(push) ; 17
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1433 | True | live]
; [else-branch: 1433 | False | dead]
(set-option :rlimit 0)
(push) ; 17
; [then-branch: 1433 | True]
(push) ; 18
(set-option :rlimit 16000)
(assert (not (not pt0_1@206@01)))
(check-sat)
; unknown
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1434 | pt0_1@206@01 | live]
; [else-branch: 1434 | !(pt0_1@206@01) | dead]
(set-option :rlimit 0)
(push) ; 18
; [then-branch: 1434 | pt0_1@206@01]
; [exec]
; returned := true
; [then-branch: 1435 | pt1_1@207@01 | dead]
; [else-branch: 1435 | !(pt1_1@207@01) | live]
(push) ; 19
; [else-branch: 1435 | !(pt1_1@207@01)]
(pop) ; 19
; [eval] !pt1_1
(push) ; 19
(set-option :rlimit 16000)
(assert (not pt1_1@207@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1436 | !(pt1_1@207@01) | live]
; [else-branch: 1436 | pt1_1@207@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 1436 | !(pt1_1@207@01)]
; [then-branch: 1437 | False | dead]
; [else-branch: 1437 | True | live]
(push) ; 20
; [else-branch: 1437 | True]
(pop) ; 20
; [eval] !pt2_1
(push) ; 20
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1438 | True | live]
; [else-branch: 1438 | False | dead]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 1438 | True]
; [exec]
; pt0_2 := pf0_1 && getCardSet(o1) == getCardSet(o2)
; [eval] pf0_1 && getCardSet(o1) == getCardSet(o2)
(push) ; 21
; [then-branch: 1439 | !(pf0_1@208@01) | live]
; [else-branch: 1439 | pf0_1@208@01 | live]
(push) ; 22
; [then-branch: 1439 | !(pf0_1@208@01)]
(assert (not pf0_1@208@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1439 | pf0_1@208@01]
(assert pf0_1@208@01)
; [eval] getCardSet(o1) == getCardSet(o2)
; [eval] getCardSet(o1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1@15@01))
; [eval] getCardSet(o2)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_1@208@01
  (and
    pf0_1@208@01
    (getCardSet%precondition $Snap.unit o1@15@01)
    (getCardSet%precondition $Snap.unit o2@18@01))))
(assert (or pf0_1@208@01 (not pf0_1@208@01)))
(declare-const pt0_2@210@01 Bool)
(assert (=
  pt0_2@210@01
  (and
    pf0_1@208@01
    (= (getCardSet $Snap.unit o1@15@01) (getCardSet $Snap.unit o2@18@01)))))
; [exec]
; pt1_2 := pf1_1 && getCardSet(o1_0) == getCardSet(o2_0)
; [eval] pf1_1 && getCardSet(o1_0) == getCardSet(o2_0)
(push) ; 21
; [then-branch: 1440 | !(pf1_1@209@01) | live]
; [else-branch: 1440 | pf1_1@209@01 | live]
(push) ; 22
; [then-branch: 1440 | !(pf1_1@209@01)]
(assert (not pf1_1@209@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1440 | pf1_1@209@01]
(assert pf1_1@209@01)
; [eval] getCardSet(o1_0) == getCardSet(o2_0)
; [eval] getCardSet(o1_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
; [eval] getCardSet(o2_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_1@209@01
  (and
    pf1_1@209@01
    (getCardSet%precondition $Snap.unit o1_0@16@01)
    (getCardSet%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_1@209@01 (not pf1_1@209@01)))
(declare-const pt1_2@211@01 Bool)
(assert (=
  pt1_2@211@01
  (and
    pf1_1@209@01
    (= (getCardSet $Snap.unit o1_0@16@01) (getCardSet $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_2 := pf2_1 && getCardSet(o1_1) == getCardSet(o2_1)
; [eval] pf2_1 && getCardSet(o1_1) == getCardSet(o2_1)
; [exec]
; pf0_2 := pf0_1 && !(getCardSet(o1) == getCardSet(o2))
; [eval] pf0_1 && !(getCardSet(o1) == getCardSet(o2))
(push) ; 21
; [then-branch: 1441 | !(pf0_1@208@01) | live]
; [else-branch: 1441 | pf0_1@208@01 | live]
(push) ; 22
; [then-branch: 1441 | !(pf0_1@208@01)]
(assert (not pf0_1@208@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1441 | pf0_1@208@01]
(assert pf0_1@208@01)
; [eval] !(getCardSet(o1) == getCardSet(o2))
; [eval] getCardSet(o1) == getCardSet(o2)
; [eval] getCardSet(o1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1@15@01))
; [eval] getCardSet(o2)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf0_2@212@01 Bool)
(assert (=
  pf0_2@212@01
  (and
    pf0_1@208@01
    (not (= (getCardSet $Snap.unit o1@15@01) (getCardSet $Snap.unit o2@18@01))))))
; [exec]
; pf1_2 := pf1_1 && !(getCardSet(o1_0) == getCardSet(o2_0))
; [eval] pf1_1 && !(getCardSet(o1_0) == getCardSet(o2_0))
(push) ; 21
; [then-branch: 1442 | !(pf1_1@209@01) | live]
; [else-branch: 1442 | pf1_1@209@01 | live]
(push) ; 22
; [then-branch: 1442 | !(pf1_1@209@01)]
(assert (not pf1_1@209@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1442 | pf1_1@209@01]
(assert pf1_1@209@01)
; [eval] !(getCardSet(o1_0) == getCardSet(o2_0))
; [eval] getCardSet(o1_0) == getCardSet(o2_0)
; [eval] getCardSet(o1_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
; [eval] getCardSet(o2_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf1_2@213@01 Bool)
(assert (=
  pf1_2@213@01
  (and
    pf1_1@209@01
    (not
      (= (getCardSet $Snap.unit o1_0@16@01) (getCardSet $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_2 := pf2_1 && !(getCardSet(o1_1) == getCardSet(o2_1))
; [eval] pf2_1 && !(getCardSet(o1_1) == getCardSet(o2_1))
; [exec]
; pt0_3 := pt0_2 && getCardRarity(o1) < getCardRarity(o2)
; [eval] pt0_2 && getCardRarity(o1) < getCardRarity(o2)
(push) ; 21
; [then-branch: 1443 | !(pt0_2@210@01) | live]
; [else-branch: 1443 | pt0_2@210@01 | live]
(push) ; 22
; [then-branch: 1443 | !(pt0_2@210@01)]
(assert (not pt0_2@210@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1443 | pt0_2@210@01]
(assert pt0_2@210@01)
; [eval] getCardRarity(o1) < getCardRarity(o2)
; [eval] getCardRarity(o1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
; [eval] getCardRarity(o2)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pt0_2@210@01
  (and
    pt0_2@210@01
    (getCardRarity%precondition $Snap.unit o1@15@01)
    (getCardRarity%precondition $Snap.unit o2@18@01))))
(assert (or pt0_2@210@01 (not pt0_2@210@01)))
(declare-const pt0_3@214@01 Bool)
(assert (=
  pt0_3@214@01
  (and
    pt0_2@210@01
    (< (getCardRarity $Snap.unit o1@15@01) (getCardRarity $Snap.unit o2@18@01)))))
; [exec]
; pt1_3 := pt1_2 && getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] pt1_2 && getCardRarity(o1_0) < getCardRarity(o2_0)
(push) ; 21
; [then-branch: 1444 | !(pt1_2@211@01) | live]
; [else-branch: 1444 | pt1_2@211@01 | live]
(push) ; 22
; [then-branch: 1444 | !(pt1_2@211@01)]
(assert (not pt1_2@211@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1444 | pt1_2@211@01]
(assert pt1_2@211@01)
; [eval] getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] getCardRarity(o1_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
; [eval] getCardRarity(o2_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pt1_2@211@01
  (and
    pt1_2@211@01
    (getCardRarity%precondition $Snap.unit o1_0@16@01)
    (getCardRarity%precondition $Snap.unit o2_0@19@01))))
(assert (or pt1_2@211@01 (not pt1_2@211@01)))
(declare-const pt1_3@215@01 Bool)
(assert (=
  pt1_3@215@01
  (and
    pt1_2@211@01
    (<
      (getCardRarity $Snap.unit o1_0@16@01)
      (getCardRarity $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_3 := pt2_2 && getCardRarity(o1_1) < getCardRarity(o2_1)
; [eval] pt2_2 && getCardRarity(o1_1) < getCardRarity(o2_1)
; [exec]
; pf0_3 := pt0_2 && !(getCardRarity(o1) < getCardRarity(o2))
; [eval] pt0_2 && !(getCardRarity(o1) < getCardRarity(o2))
(push) ; 21
; [then-branch: 1445 | !(pt0_2@210@01) | live]
; [else-branch: 1445 | pt0_2@210@01 | live]
(push) ; 22
; [then-branch: 1445 | !(pt0_2@210@01)]
(assert (not pt0_2@210@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1445 | pt0_2@210@01]
(assert pt0_2@210@01)
; [eval] !(getCardRarity(o1) < getCardRarity(o2))
; [eval] getCardRarity(o1) < getCardRarity(o2)
; [eval] getCardRarity(o1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
; [eval] getCardRarity(o2)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf0_3@216@01 Bool)
(assert (=
  pf0_3@216@01
  (and
    pt0_2@210@01
    (not
      (< (getCardRarity $Snap.unit o1@15@01) (getCardRarity $Snap.unit o2@18@01))))))
; [exec]
; pf1_3 := pt1_2 && !(getCardRarity(o1_0) < getCardRarity(o2_0))
; [eval] pt1_2 && !(getCardRarity(o1_0) < getCardRarity(o2_0))
(push) ; 21
; [then-branch: 1446 | !(pt1_2@211@01) | live]
; [else-branch: 1446 | pt1_2@211@01 | live]
(push) ; 22
; [then-branch: 1446 | !(pt1_2@211@01)]
(assert (not pt1_2@211@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1446 | pt1_2@211@01]
(assert pt1_2@211@01)
; [eval] !(getCardRarity(o1_0) < getCardRarity(o2_0))
; [eval] getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] getCardRarity(o1_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
; [eval] getCardRarity(o2_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf1_3@217@01 Bool)
(assert (=
  pf1_3@217@01
  (and
    pt1_2@211@01
    (not
      (<
        (getCardRarity $Snap.unit o1_0@16@01)
        (getCardRarity $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_3 := pt2_2 && !(getCardRarity(o1_1) < getCardRarity(o2_1))
; [eval] pt2_2 && !(getCardRarity(o1_1) < getCardRarity(o2_1))
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt0_3@214@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1447 | pt0_3@214@01 | dead]
; [else-branch: 1447 | !(pt0_3@214@01) | live]
(set-option :rlimit 0)
(push) ; 21
; [else-branch: 1447 | !(pt0_3@214@01)]
(assert (not pt0_3@214@01))
(pop) ; 21
; [eval] !pt0_3
(push) ; 21
(set-option :rlimit 16000)
(assert (not pt0_3@214@01))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt0_3@214@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1448 | !(pt0_3@214@01) | live]
; [else-branch: 1448 | pt0_3@214@01 | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 1448 | !(pt0_3@214@01)]
(assert (not pt0_3@214@01))
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not pt1_3@215@01)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1449 | pt1_3@215@01 | dead]
; [else-branch: 1449 | !(pt1_3@215@01) | live]
(set-option :rlimit 0)
(push) ; 22
; [else-branch: 1449 | !(pt1_3@215@01)]
(assert (not pt1_3@215@01))
(pop) ; 22
; [eval] !pt1_3
(push) ; 22
(set-option :rlimit 16000)
(assert (not pt1_3@215@01))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not pt1_3@215@01)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1450 | !(pt1_3@215@01) | live]
; [else-branch: 1450 | pt1_3@215@01 | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 1450 | !(pt1_3@215@01)]
(assert (not pt1_3@215@01))
; [then-branch: 1451 | False | dead]
; [else-branch: 1451 | True | live]
(push) ; 23
; [else-branch: 1451 | True]
(pop) ; 23
; [eval] !pt2_3
(push) ; 23
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1452 | True | live]
; [else-branch: 1452 | False | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 1452 | True]
; [then-branch: 1453 | pt0_3@214@01 | dead]
; [else-branch: 1453 | !(pt0_3@214@01) | live]
(push) ; 24
; [else-branch: 1453 | !(pt0_3@214@01)]
(pop) ; 24
; [eval] !pt0_3
(push) ; 24
(set-option :rlimit 16000)
(assert (not pt0_3@214@01))
(check-sat)
; unknown
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1454 | !(pt0_3@214@01) | live]
; [else-branch: 1454 | pt0_3@214@01 | dead]
(set-option :rlimit 0)
(push) ; 24
; [then-branch: 1454 | !(pt0_3@214@01)]
; [then-branch: 1455 | pt1_3@215@01 | dead]
; [else-branch: 1455 | !(pt1_3@215@01) | live]
(push) ; 25
; [else-branch: 1455 | !(pt1_3@215@01)]
(pop) ; 25
; [eval] !pt1_3
(push) ; 25
(set-option :rlimit 16000)
(assert (not pt1_3@215@01))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1456 | !(pt1_3@215@01) | live]
; [else-branch: 1456 | pt1_3@215@01 | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 1456 | !(pt1_3@215@01)]
; [then-branch: 1457 | False | dead]
; [else-branch: 1457 | True | live]
(push) ; 26
; [else-branch: 1457 | True]
(pop) ; 26
; [eval] !pt2_3
(push) ; 26
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 26
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1458 | True | live]
; [else-branch: 1458 | False | dead]
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 1458 | True]
; [exec]
; pt0_4 := pf0_3 && getCardId(o1) == getCardId(o2)
; [eval] pf0_3 && getCardId(o1) == getCardId(o2)
(push) ; 27
; [then-branch: 1459 | !(pf0_3@216@01) | live]
; [else-branch: 1459 | pf0_3@216@01 | live]
(push) ; 28
; [then-branch: 1459 | !(pf0_3@216@01)]
(assert (not pf0_3@216@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1459 | pf0_3@216@01]
(assert pf0_3@216@01)
; [eval] getCardId(o1) == getCardId(o2)
; [eval] getCardId(o1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1@15@01))
; [eval] getCardId(o2)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_3@216@01
  (and
    pf0_3@216@01
    (getCardId%precondition $Snap.unit o1@15@01)
    (getCardId%precondition $Snap.unit o2@18@01))))
(assert (or pf0_3@216@01 (not pf0_3@216@01)))
(declare-const pt0_4@218@01 Bool)
(assert (=
  pt0_4@218@01
  (and
    pf0_3@216@01
    (= (getCardId $Snap.unit o1@15@01) (getCardId $Snap.unit o2@18@01)))))
; [exec]
; pt1_4 := pf1_3 && getCardId(o1_0) == getCardId(o2_0)
; [eval] pf1_3 && getCardId(o1_0) == getCardId(o2_0)
(push) ; 27
; [then-branch: 1460 | !(pf1_3@217@01) | live]
; [else-branch: 1460 | pf1_3@217@01 | live]
(push) ; 28
; [then-branch: 1460 | !(pf1_3@217@01)]
(assert (not pf1_3@217@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1460 | pf1_3@217@01]
(assert pf1_3@217@01)
; [eval] getCardId(o1_0) == getCardId(o2_0)
; [eval] getCardId(o1_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
; [eval] getCardId(o2_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_3@217@01
  (and
    pf1_3@217@01
    (getCardId%precondition $Snap.unit o1_0@16@01)
    (getCardId%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_3@217@01 (not pf1_3@217@01)))
(declare-const pt1_4@219@01 Bool)
(assert (=
  pt1_4@219@01
  (and
    pf1_3@217@01
    (= (getCardId $Snap.unit o1_0@16@01) (getCardId $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_4 := pf2_3 && getCardId(o1_1) == getCardId(o2_1)
; [eval] pf2_3 && getCardId(o1_1) == getCardId(o2_1)
; [exec]
; pf0_4 := pf0_3 && !(getCardId(o1) == getCardId(o2))
; [eval] pf0_3 && !(getCardId(o1) == getCardId(o2))
(push) ; 27
; [then-branch: 1461 | !(pf0_3@216@01) | live]
; [else-branch: 1461 | pf0_3@216@01 | live]
(push) ; 28
; [then-branch: 1461 | !(pf0_3@216@01)]
(assert (not pf0_3@216@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1461 | pf0_3@216@01]
(assert pf0_3@216@01)
; [eval] !(getCardId(o1) == getCardId(o2))
; [eval] getCardId(o1) == getCardId(o2)
; [eval] getCardId(o1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1@15@01))
; [eval] getCardId(o2)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf0_4@220@01 Bool)
(assert (=
  pf0_4@220@01
  (and
    pf0_3@216@01
    (not (= (getCardId $Snap.unit o1@15@01) (getCardId $Snap.unit o2@18@01))))))
; [exec]
; pf1_4 := pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
; [eval] pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
(push) ; 27
; [then-branch: 1462 | !(pf1_3@217@01) | live]
; [else-branch: 1462 | pf1_3@217@01 | live]
(push) ; 28
; [then-branch: 1462 | !(pf1_3@217@01)]
(assert (not pf1_3@217@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1462 | pf1_3@217@01]
(assert pf1_3@217@01)
; [eval] !(getCardId(o1_0) == getCardId(o2_0))
; [eval] getCardId(o1_0) == getCardId(o2_0)
; [eval] getCardId(o1_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
; [eval] getCardId(o2_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf1_4@221@01 Bool)
(assert (=
  pf1_4@221@01
  (and
    pf1_3@217@01
    (not (= (getCardId $Snap.unit o1_0@16@01) (getCardId $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_4 := pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
; [eval] pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
; [exec]
; pt0_5 := pt0_4 && cardType(o1) > cardType(o2)
; [eval] pt0_4 && cardType(o1) > cardType(o2)
(push) ; 27
; [then-branch: 1463 | !(pt0_4@218@01) | live]
; [else-branch: 1463 | pt0_4@218@01 | live]
(push) ; 28
; [then-branch: 1463 | !(pt0_4@218@01)]
(assert (not pt0_4@218@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1463 | pt0_4@218@01]
(assert pt0_4@218@01)
; [eval] cardType(o1) > cardType(o2)
; [eval] cardType(o1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt0_4@218@01
  (and
    pt0_4@218@01
    (cardType%precondition $Snap.unit o1@15@01)
    (cardType%precondition $Snap.unit o2@18@01))))
(assert (or pt0_4@218@01 (not pt0_4@218@01)))
(declare-const pt0_5@222@01 Bool)
(assert (=
  pt0_5@222@01
  (and
    pt0_4@218@01
    (> (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01)))))
; [exec]
; pt1_5 := pt1_4 && cardType(o1_0) > cardType(o2_0)
; [eval] pt1_4 && cardType(o1_0) > cardType(o2_0)
(push) ; 27
; [then-branch: 1464 | !(pt1_4@219@01) | live]
; [else-branch: 1464 | pt1_4@219@01 | live]
(push) ; 28
; [then-branch: 1464 | !(pt1_4@219@01)]
(assert (not pt1_4@219@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1464 | pt1_4@219@01]
(assert pt1_4@219@01)
; [eval] cardType(o1_0) > cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt1_4@219@01
  (and
    pt1_4@219@01
    (cardType%precondition $Snap.unit o1_0@16@01)
    (cardType%precondition $Snap.unit o2_0@19@01))))
(assert (or pt1_4@219@01 (not pt1_4@219@01)))
(declare-const pt1_5@223@01 Bool)
(assert (=
  pt1_5@223@01
  (and
    pt1_4@219@01
    (> (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_5 := pt2_4 && cardType(o1_1) > cardType(o2_1)
; [eval] pt2_4 && cardType(o1_1) > cardType(o2_1)
; [exec]
; pf0_5 := pt0_4 && !(cardType(o1) > cardType(o2))
; [eval] pt0_4 && !(cardType(o1) > cardType(o2))
(push) ; 27
; [then-branch: 1465 | !(pt0_4@218@01) | live]
; [else-branch: 1465 | pt0_4@218@01 | live]
(push) ; 28
; [then-branch: 1465 | !(pt0_4@218@01)]
(assert (not pt0_4@218@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1465 | pt0_4@218@01]
(assert pt0_4@218@01)
; [eval] !(cardType(o1) > cardType(o2))
; [eval] cardType(o1) > cardType(o2)
; [eval] cardType(o1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf0_5@224@01 Bool)
(assert (=
  pf0_5@224@01
  (and
    pt0_4@218@01
    (not (> (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01))))))
; [exec]
; pf1_5 := pt1_4 && !(cardType(o1_0) > cardType(o2_0))
; [eval] pt1_4 && !(cardType(o1_0) > cardType(o2_0))
(push) ; 27
; [then-branch: 1466 | !(pt1_4@219@01) | live]
; [else-branch: 1466 | pt1_4@219@01 | live]
(push) ; 28
; [then-branch: 1466 | !(pt1_4@219@01)]
(assert (not pt1_4@219@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1466 | pt1_4@219@01]
(assert pt1_4@219@01)
; [eval] !(cardType(o1_0) > cardType(o2_0))
; [eval] cardType(o1_0) > cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf1_5@225@01 Bool)
(assert (=
  pf1_5@225@01
  (and
    pt1_4@219@01
    (not (> (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_5 := pt2_4 && !(cardType(o1_1) > cardType(o2_1))
; [eval] pt2_4 && !(cardType(o1_1) > cardType(o2_1))
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not pt0_5@222@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1467 | pt0_5@222@01 | dead]
; [else-branch: 1467 | !(pt0_5@222@01) | live]
(set-option :rlimit 0)
(push) ; 27
; [else-branch: 1467 | !(pt0_5@222@01)]
(assert (not pt0_5@222@01))
(pop) ; 27
; [eval] !pt0_5
(push) ; 27
(set-option :rlimit 16000)
(assert (not pt0_5@222@01))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not pt0_5@222@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1468 | !(pt0_5@222@01) | live]
; [else-branch: 1468 | pt0_5@222@01 | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 1468 | !(pt0_5@222@01)]
(assert (not pt0_5@222@01))
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not pt1_5@223@01)))
(check-sat)
; unsat
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1469 | pt1_5@223@01 | dead]
; [else-branch: 1469 | !(pt1_5@223@01) | live]
(set-option :rlimit 0)
(push) ; 28
; [else-branch: 1469 | !(pt1_5@223@01)]
(assert (not pt1_5@223@01))
(pop) ; 28
; [eval] !pt1_5
(push) ; 28
(set-option :rlimit 16000)
(assert (not pt1_5@223@01))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not pt1_5@223@01)))
(check-sat)
; unsat
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1470 | !(pt1_5@223@01) | live]
; [else-branch: 1470 | pt1_5@223@01 | dead]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 1470 | !(pt1_5@223@01)]
(assert (not pt1_5@223@01))
; [then-branch: 1471 | False | dead]
; [else-branch: 1471 | True | live]
(push) ; 29
; [else-branch: 1471 | True]
(pop) ; 29
; [eval] !pt2_5
(push) ; 29
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1472 | True | live]
; [else-branch: 1472 | False | dead]
(set-option :rlimit 0)
(push) ; 29
; [then-branch: 1472 | True]
; [then-branch: 1473 | pt0_5@222@01 | dead]
; [else-branch: 1473 | !(pt0_5@222@01) | live]
(push) ; 30
; [else-branch: 1473 | !(pt0_5@222@01)]
(pop) ; 30
; [eval] !pt0_5
(push) ; 30
(set-option :rlimit 16000)
(assert (not pt0_5@222@01))
(check-sat)
; unknown
(pop) ; 30
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1474 | !(pt0_5@222@01) | live]
; [else-branch: 1474 | pt0_5@222@01 | dead]
(set-option :rlimit 0)
(push) ; 30
; [then-branch: 1474 | !(pt0_5@222@01)]
; [then-branch: 1475 | pt1_5@223@01 | dead]
; [else-branch: 1475 | !(pt1_5@223@01) | live]
(push) ; 31
; [else-branch: 1475 | !(pt1_5@223@01)]
(pop) ; 31
; [eval] !pt1_5
(push) ; 31
(set-option :rlimit 16000)
(assert (not pt1_5@223@01))
(check-sat)
; unknown
(pop) ; 31
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1476 | !(pt1_5@223@01) | live]
; [else-branch: 1476 | pt1_5@223@01 | dead]
(set-option :rlimit 0)
(push) ; 31
; [then-branch: 1476 | !(pt1_5@223@01)]
; [then-branch: 1477 | False | dead]
; [else-branch: 1477 | True | live]
(push) ; 32
; [else-branch: 1477 | True]
(pop) ; 32
; [eval] !pt2_5
(push) ; 32
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 32
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1478 | True | live]
; [else-branch: 1478 | False | dead]
(set-option :rlimit 0)
(push) ; 32
; [then-branch: 1478 | True]
; [exec]
; pt0_6 := pf0_5 && cardType(o1) == cardType(o2)
; [eval] pf0_5 && cardType(o1) == cardType(o2)
(push) ; 33
; [then-branch: 1479 | !(pf0_5@224@01) | live]
; [else-branch: 1479 | pf0_5@224@01 | live]
(push) ; 34
; [then-branch: 1479 | !(pf0_5@224@01)]
(assert (not pf0_5@224@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1479 | pf0_5@224@01]
(assert pf0_5@224@01)
; [eval] cardType(o1) == cardType(o2)
; [eval] cardType(o1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_5@224@01
  (and
    pf0_5@224@01
    (cardType%precondition $Snap.unit o1@15@01)
    (cardType%precondition $Snap.unit o2@18@01))))
(assert (or pf0_5@224@01 (not pf0_5@224@01)))
(declare-const pt0_6@226@01 Bool)
(assert (=
  pt0_6@226@01
  (and
    pf0_5@224@01
    (= (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01)))))
; [exec]
; pt1_6 := pf1_5 && cardType(o1_0) == cardType(o2_0)
; [eval] pf1_5 && cardType(o1_0) == cardType(o2_0)
(push) ; 33
; [then-branch: 1480 | !(pf1_5@225@01) | live]
; [else-branch: 1480 | pf1_5@225@01 | live]
(push) ; 34
; [then-branch: 1480 | !(pf1_5@225@01)]
(assert (not pf1_5@225@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1480 | pf1_5@225@01]
(assert pf1_5@225@01)
; [eval] cardType(o1_0) == cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_5@225@01
  (and
    pf1_5@225@01
    (cardType%precondition $Snap.unit o1_0@16@01)
    (cardType%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_5@225@01 (not pf1_5@225@01)))
(declare-const pt1_6@227@01 Bool)
(assert (=
  pt1_6@227@01
  (and
    pf1_5@225@01
    (= (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_6 := pf2_5 && cardType(o1_1) == cardType(o2_1)
; [eval] pf2_5 && cardType(o1_1) == cardType(o2_1)
; [exec]
; pf0_6 := pf0_5 && !(cardType(o1) == cardType(o2))
; [eval] pf0_5 && !(cardType(o1) == cardType(o2))
(push) ; 33
; [then-branch: 1481 | !(pf0_5@224@01) | live]
; [else-branch: 1481 | pf0_5@224@01 | live]
(push) ; 34
; [then-branch: 1481 | !(pf0_5@224@01)]
(assert (not pf0_5@224@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1481 | pf0_5@224@01]
(assert pf0_5@224@01)
; [eval] !(cardType(o1) == cardType(o2))
; [eval] cardType(o1) == cardType(o2)
; [eval] cardType(o1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf0_6@228@01 Bool)
(assert (=
  pf0_6@228@01
  (and
    pf0_5@224@01
    (not (= (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01))))))
; [exec]
; pf1_6 := pf1_5 && !(cardType(o1_0) == cardType(o2_0))
; [eval] pf1_5 && !(cardType(o1_0) == cardType(o2_0))
(push) ; 33
; [then-branch: 1482 | !(pf1_5@225@01) | live]
; [else-branch: 1482 | pf1_5@225@01 | live]
(push) ; 34
; [then-branch: 1482 | !(pf1_5@225@01)]
(assert (not pf1_5@225@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1482 | pf1_5@225@01]
(assert pf1_5@225@01)
; [eval] !(cardType(o1_0) == cardType(o2_0))
; [eval] cardType(o1_0) == cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf1_6@229@01 Bool)
(assert (=
  pf1_6@229@01
  (and
    pf1_5@225@01
    (not (= (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_6 := pf2_5 && !(cardType(o1_1) == cardType(o2_1))
; [eval] pf2_5 && !(cardType(o1_1) == cardType(o2_1))
(push) ; 33
(set-option :rlimit 16000)
(assert (not (not pt0_6@226@01)))
(check-sat)
; unsat
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1483 | pt0_6@226@01 | dead]
; [else-branch: 1483 | !(pt0_6@226@01) | live]
(set-option :rlimit 0)
(push) ; 33
; [else-branch: 1483 | !(pt0_6@226@01)]
(assert (not pt0_6@226@01))
(pop) ; 33
; [eval] !pt0_6
(push) ; 33
(set-option :rlimit 16000)
(assert (not pt0_6@226@01))
(check-sat)
; unknown
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 33
(set-option :rlimit 16000)
(assert (not (not pt0_6@226@01)))
(check-sat)
; unsat
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1484 | !(pt0_6@226@01) | live]
; [else-branch: 1484 | pt0_6@226@01 | dead]
(set-option :rlimit 0)
(push) ; 33
; [then-branch: 1484 | !(pt0_6@226@01)]
(assert (not pt0_6@226@01))
(push) ; 34
(set-option :rlimit 16000)
(assert (not (not pt1_6@227@01)))
(check-sat)
; unsat
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1485 | pt1_6@227@01 | dead]
; [else-branch: 1485 | !(pt1_6@227@01) | live]
(set-option :rlimit 0)
(push) ; 34
; [else-branch: 1485 | !(pt1_6@227@01)]
(assert (not pt1_6@227@01))
(pop) ; 34
; [eval] !pt1_6
(push) ; 34
(set-option :rlimit 16000)
(assert (not pt1_6@227@01))
(check-sat)
; unknown
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 34
(set-option :rlimit 16000)
(assert (not (not pt1_6@227@01)))
(check-sat)
; unsat
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1486 | !(pt1_6@227@01) | live]
; [else-branch: 1486 | pt1_6@227@01 | dead]
(set-option :rlimit 0)
(push) ; 34
; [then-branch: 1486 | !(pt1_6@227@01)]
(assert (not pt1_6@227@01))
; [then-branch: 1487 | False | dead]
; [else-branch: 1487 | True | live]
(push) ; 35
; [else-branch: 1487 | True]
(pop) ; 35
; [eval] !pt2_6
(push) ; 35
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1488 | True | live]
; [else-branch: 1488 | False | dead]
(set-option :rlimit 0)
(push) ; 35
; [then-branch: 1488 | True]
; [then-branch: 1489 | pt0_6@226@01 | dead]
; [else-branch: 1489 | !(pt0_6@226@01) | live]
(push) ; 36
; [else-branch: 1489 | !(pt0_6@226@01)]
(pop) ; 36
; [eval] !pt0_6
(push) ; 36
(set-option :rlimit 16000)
(assert (not pt0_6@226@01))
(check-sat)
; unknown
(pop) ; 36
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1490 | !(pt0_6@226@01) | live]
; [else-branch: 1490 | pt0_6@226@01 | dead]
(set-option :rlimit 0)
(push) ; 36
; [then-branch: 1490 | !(pt0_6@226@01)]
; [then-branch: 1491 | pt1_6@227@01 | dead]
; [else-branch: 1491 | !(pt1_6@227@01) | live]
(push) ; 37
; [else-branch: 1491 | !(pt1_6@227@01)]
(pop) ; 37
; [eval] !pt1_6
(push) ; 37
(set-option :rlimit 16000)
(assert (not pt1_6@227@01))
(check-sat)
; unknown
(pop) ; 37
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1492 | !(pt1_6@227@01) | live]
; [else-branch: 1492 | pt1_6@227@01 | dead]
(set-option :rlimit 0)
(push) ; 37
; [then-branch: 1492 | !(pt1_6@227@01)]
; [then-branch: 1493 | False | dead]
; [else-branch: 1493 | True | live]
(push) ; 38
; [else-branch: 1493 | True]
(pop) ; 38
; [eval] !pt2_6
(push) ; 38
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 38
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1494 | True | live]
; [else-branch: 1494 | False | dead]
(set-option :rlimit 0)
(push) ; 38
; [then-branch: 1494 | True]
(push) ; 39
(set-option :rlimit 16000)
(assert (not (not pf0_6@228@01)))
(check-sat)
; unsat
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1495 | pf0_6@228@01 | dead]
; [else-branch: 1495 | !(pf0_6@228@01) | live]
(set-option :rlimit 0)
(push) ; 39
; [else-branch: 1495 | !(pf0_6@228@01)]
(assert (not pf0_6@228@01))
(pop) ; 39
; [eval] !pf0_6
(push) ; 39
(set-option :rlimit 16000)
(assert (not pf0_6@228@01))
(check-sat)
; unknown
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 39
(set-option :rlimit 16000)
(assert (not (not pf0_6@228@01)))
(check-sat)
; unsat
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1496 | !(pf0_6@228@01) | live]
; [else-branch: 1496 | pf0_6@228@01 | dead]
(set-option :rlimit 0)
(push) ; 39
; [then-branch: 1496 | !(pf0_6@228@01)]
(assert (not pf0_6@228@01))
(push) ; 40
(set-option :rlimit 16000)
(assert (not (not pf1_6@229@01)))
(check-sat)
; unsat
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1497 | pf1_6@229@01 | dead]
; [else-branch: 1497 | !(pf1_6@229@01) | live]
(set-option :rlimit 0)
(push) ; 40
; [else-branch: 1497 | !(pf1_6@229@01)]
(assert (not pf1_6@229@01))
(pop) ; 40
; [eval] !pf1_6
(push) ; 40
(set-option :rlimit 16000)
(assert (not pf1_6@229@01))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 40
(set-option :rlimit 16000)
(assert (not (not pf1_6@229@01)))
(check-sat)
; unsat
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1498 | !(pf1_6@229@01) | live]
; [else-branch: 1498 | pf1_6@229@01 | dead]
(set-option :rlimit 0)
(push) ; 40
; [then-branch: 1498 | !(pf1_6@229@01)]
(assert (not pf1_6@229@01))
; [then-branch: 1499 | False | dead]
; [else-branch: 1499 | True | live]
(push) ; 41
; [else-branch: 1499 | True]
(pop) ; 41
; [eval] !pf2_6
(push) ; 41
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1500 | True | live]
; [else-branch: 1500 | False | dead]
(set-option :rlimit 0)
(push) ; 41
; [then-branch: 1500 | True]
; [then-branch: 1501 | pf0_6@228@01 | dead]
; [else-branch: 1501 | !(pf0_6@228@01) | live]
(push) ; 42
; [else-branch: 1501 | !(pf0_6@228@01)]
(pop) ; 42
; [eval] !pf0_6
(push) ; 42
(set-option :rlimit 16000)
(assert (not pf0_6@228@01))
(check-sat)
; unknown
(pop) ; 42
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1502 | !(pf0_6@228@01) | live]
; [else-branch: 1502 | pf0_6@228@01 | dead]
(set-option :rlimit 0)
(push) ; 42
; [then-branch: 1502 | !(pf0_6@228@01)]
; [then-branch: 1503 | pf1_6@229@01 | dead]
; [else-branch: 1503 | !(pf1_6@229@01) | live]
(push) ; 43
; [else-branch: 1503 | !(pf1_6@229@01)]
(pop) ; 43
; [eval] !pf1_6
(push) ; 43
(set-option :rlimit 16000)
(assert (not pf1_6@229@01))
(check-sat)
; unknown
(pop) ; 43
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1504 | !(pf1_6@229@01) | live]
; [else-branch: 1504 | pf1_6@229@01 | dead]
(set-option :rlimit 0)
(push) ; 43
; [then-branch: 1504 | !(pf1_6@229@01)]
; [then-branch: 1505 | False | dead]
; [else-branch: 1505 | True | live]
(push) ; 44
; [else-branch: 1505 | True]
(pop) ; 44
; [eval] !pf2_6
(push) ; 44
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 44
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1506 | True | live]
; [else-branch: 1506 | False | dead]
(set-option :rlimit 0)
(push) ; 44
; [then-branch: 1506 | True]
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@220@01)))
(check-sat)
; unsat
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1507 | pf0_4@220@01 | dead]
; [else-branch: 1507 | !(pf0_4@220@01) | live]
(set-option :rlimit 0)
(push) ; 45
; [else-branch: 1507 | !(pf0_4@220@01)]
(assert (not pf0_4@220@01))
(pop) ; 45
; [eval] !pf0_4
(push) ; 45
(set-option :rlimit 16000)
(assert (not pf0_4@220@01))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@220@01)))
(check-sat)
; unsat
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1508 | !(pf0_4@220@01) | live]
; [else-branch: 1508 | pf0_4@220@01 | dead]
(set-option :rlimit 0)
(push) ; 45
; [then-branch: 1508 | !(pf0_4@220@01)]
(assert (not pf0_4@220@01))
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@221@01)))
(check-sat)
; unsat
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1509 | pf1_4@221@01 | dead]
; [else-branch: 1509 | !(pf1_4@221@01) | live]
(set-option :rlimit 0)
(push) ; 46
; [else-branch: 1509 | !(pf1_4@221@01)]
(assert (not pf1_4@221@01))
(pop) ; 46
; [eval] !pf1_4
(push) ; 46
(set-option :rlimit 16000)
(assert (not pf1_4@221@01))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@221@01)))
(check-sat)
; unsat
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1510 | !(pf1_4@221@01) | live]
; [else-branch: 1510 | pf1_4@221@01 | dead]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 1510 | !(pf1_4@221@01)]
(assert (not pf1_4@221@01))
; [then-branch: 1511 | False | dead]
; [else-branch: 1511 | True | live]
(push) ; 47
; [else-branch: 1511 | True]
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1512 | True | live]
; [else-branch: 1512 | False | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 1512 | True]
; [then-branch: 1513 | pf0_4@220@01 | dead]
; [else-branch: 1513 | !(pf0_4@220@01) | live]
(push) ; 48
; [else-branch: 1513 | !(pf0_4@220@01)]
(pop) ; 48
; [eval] !pf0_4
(push) ; 48
(set-option :rlimit 16000)
(assert (not pf0_4@220@01))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1514 | !(pf0_4@220@01) | live]
; [else-branch: 1514 | pf0_4@220@01 | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 1514 | !(pf0_4@220@01)]
; [then-branch: 1515 | pf1_4@221@01 | dead]
; [else-branch: 1515 | !(pf1_4@221@01) | live]
(push) ; 49
; [else-branch: 1515 | !(pf1_4@221@01)]
(pop) ; 49
; [eval] !pf1_4
(push) ; 49
(set-option :rlimit 16000)
(assert (not pf1_4@221@01))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1516 | !(pf1_4@221@01) | live]
; [else-branch: 1516 | pf1_4@221@01 | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 1516 | !(pf1_4@221@01)]
; [then-branch: 1517 | False | dead]
; [else-branch: 1517 | True | live]
(push) ; 50
; [else-branch: 1517 | True]
(pop) ; 50
; [eval] !pf2_4
(push) ; 50
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1518 | True | live]
; [else-branch: 1518 | False | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 1518 | True]
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@212@01)))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1519 | pf0_2@212@01 | dead]
; [else-branch: 1519 | !(pf0_2@212@01) | live]
(set-option :rlimit 0)
(push) ; 51
; [else-branch: 1519 | !(pf0_2@212@01)]
(assert (not pf0_2@212@01))
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not pf0_2@212@01))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@212@01)))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1520 | !(pf0_2@212@01) | live]
; [else-branch: 1520 | pf0_2@212@01 | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 1520 | !(pf0_2@212@01)]
(assert (not pf0_2@212@01))
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@213@01)))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 52
(set-option :rlimit 16000)
(assert (not pf1_2@213@01))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1521 | pf1_2@213@01 | live]
; [else-branch: 1521 | !(pf1_2@213@01) | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 1521 | pf1_2@213@01]
(assert pf1_2@213@01)
; [exec]
; res_0 := -1
; [eval] -1
; [then-branch: 1522 | False | dead]
; [else-branch: 1522 | True | live]
(push) ; 53
; [else-branch: 1522 | True]
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1523 | True | live]
; [else-branch: 1523 | False | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 1523 | True]
; [then-branch: 1524 | pf0_2@212@01 | dead]
; [else-branch: 1524 | !(pf0_2@212@01) | live]
(push) ; 54
; [else-branch: 1524 | !(pf0_2@212@01)]
(pop) ; 54
; [eval] !pf0_2
(push) ; 54
(set-option :rlimit 16000)
(assert (not pf0_2@212@01))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1525 | !(pf0_2@212@01) | live]
; [else-branch: 1525 | pf0_2@212@01 | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 1525 | !(pf0_2@212@01)]
(push) ; 55
(set-option :rlimit 16000)
(assert (not (not pf1_2@213@01)))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1526 | pf1_2@213@01 | live]
; [else-branch: 1526 | !(pf1_2@213@01) | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 1526 | pf1_2@213@01]
; [exec]
; returned_0 := true
; [then-branch: 1527 | False | dead]
; [else-branch: 1527 | True | live]
(push) ; 56
; [else-branch: 1527 | True]
(pop) ; 56
; [eval] !pf2_2
(push) ; 56
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1528 | True | live]
; [else-branch: 1528 | False | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 1528 | True]
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1529 | p0@12@01 | live]
; [else-branch: 1529 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1529 | p0@12@01]
(assert p0@12@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1530 | p1@13@01 | live]
; [else-branch: 1530 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1530 | p1@13@01]
(assert p1@13@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p1@13@01)
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1531 | p2@14@01 | live]
; [else-branch: 1531 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1531 | p2@14@01]
(assert p2@14@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p2@14@01)
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1532 | p0@12@01 | live]
; [else-branch: 1532 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1532 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1533 | False | live]
; [else-branch: 1533 | True | live]
(push) ; 60
; [then-branch: 1533 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1533 | True]
(push) ; 61
; [then-branch: 1534 | !(p0@12@01) | live]
; [else-branch: 1534 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1534 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1534 | p0@12@01]
(push) ; 63
; [then-branch: 1535 | !(p1@13@01) | live]
; [else-branch: 1535 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1535 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1535 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1536 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1536 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1536 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1537 | False | dead]
; [else-branch: 1537 | True | live]
(push) ; 62
; [else-branch: 1537 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1538 | p1@13@01 | live]
; [else-branch: 1538 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1538 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1539 | False | live]
; [else-branch: 1539 | True | live]
(push) ; 60
; [then-branch: 1539 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1539 | True]
(push) ; 61
; [then-branch: 1540 | !(p0@12@01) | live]
; [else-branch: 1540 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1540 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1540 | p0@12@01]
(push) ; 63
; [then-branch: 1541 | !(p1@13@01) | live]
; [else-branch: 1541 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1541 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1541 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1542 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1542 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1542 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1543 | False | dead]
; [else-branch: 1543 | True | live]
(push) ; 62
; [else-branch: 1543 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p2@14@01)))
(assert p1@13@01)
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1544 | p2@14@01 | live]
; [else-branch: 1544 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1544 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1545 | False | live]
; [else-branch: 1545 | True | live]
(push) ; 60
; [then-branch: 1545 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1545 | True]
(push) ; 61
; [then-branch: 1546 | !(p0@12@01) | live]
; [else-branch: 1546 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1546 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1546 | p0@12@01]
(assert p0@12@01)
(push) ; 63
; [then-branch: 1547 | !(p1@13@01) | live]
; [else-branch: 1547 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1547 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1547 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1548 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1548 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1548 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1549 | False | dead]
; [else-branch: 1549 | True | live]
(push) ; 62
; [else-branch: 1549 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01)))
(assert p2@14@01)
(pop) ; 56
(pop) ; 55
; [eval] !pf1_2
; [then-branch: 1550 | !(pf1_2@213@01) | dead]
; [else-branch: 1550 | pf1_2@213@01 | live]
(push) ; 55
; [else-branch: 1550 | pf1_2@213@01]
(pop) ; 55
(pop) ; 54
(pop) ; 53
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not pf1_2@213@01))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1551 | !(pf1_2@213@01) | dead]
; [else-branch: 1551 | pf1_2@213@01 | live]
(set-option :rlimit 0)
(push) ; 52
; [else-branch: 1551 | pf1_2@213@01]
(assert pf1_2@213@01)
(pop) ; 52
(pop) ; 51
(pop) ; 50
(pop) ; 49
(pop) ; 48
(pop) ; 47
(pop) ; 46
(pop) ; 45
(pop) ; 44
(pop) ; 43
(pop) ; 42
(pop) ; 41
(pop) ; 40
(pop) ; 39
(pop) ; 38
(pop) ; 37
(pop) ; 36
(pop) ; 35
(pop) ; 34
(pop) ; 33
(pop) ; 32
(pop) ; 31
(pop) ; 30
(pop) ; 29
(pop) ; 28
(pop) ; 27
(pop) ; 26
(pop) ; 25
(pop) ; 24
(pop) ; 23
(pop) ; 22
(pop) ; 21
(pop) ; 20
(pop) ; 19
(pop) ; 18
; [eval] !pt0_1
; [then-branch: 1552 | !(pt0_1@206@01) | dead]
; [else-branch: 1552 | pt0_1@206@01 | live]
(push) ; 18
; [else-branch: 1552 | pt0_1@206@01]
(pop) ; 18
(pop) ; 17
(pop) ; 16
(pop) ; 15
(push) ; 15
; [else-branch: 1429 | !(pt0_1@206@01)]
(assert (not pt0_1@206@01))
(pop) ; 15
; [eval] !pt0_1
(push) ; 15
(set-option :rlimit 16000)
(assert (not pt0_1@206@01))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 15
(set-option :rlimit 16000)
(assert (not (not pt0_1@206@01)))
(check-sat)
; unknown
(pop) ; 15
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1553 | !(pt0_1@206@01) | live]
; [else-branch: 1553 | pt0_1@206@01 | live]
(set-option :rlimit 0)
(push) ; 15
; [then-branch: 1553 | !(pt0_1@206@01)]
(assert (not pt0_1@206@01))
(push) ; 16
(set-option :rlimit 16000)
(assert (not (not pt1_1@207@01)))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 16000)
(assert (not pt1_1@207@01))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1554 | pt1_1@207@01 | live]
; [else-branch: 1554 | !(pt1_1@207@01) | live]
(set-option :rlimit 0)
(push) ; 16
; [then-branch: 1554 | pt1_1@207@01]
(assert pt1_1@207@01)
; [exec]
; res_0 := -1
; [eval] -1
; [then-branch: 1555 | False | dead]
; [else-branch: 1555 | True | live]
(push) ; 17
; [else-branch: 1555 | True]
(pop) ; 17
; [eval] !pt2_1
(push) ; 17
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1556 | True | live]
; [else-branch: 1556 | False | dead]
(set-option :rlimit 0)
(push) ; 17
; [then-branch: 1556 | True]
; [then-branch: 1557 | pt0_1@206@01 | dead]
; [else-branch: 1557 | !(pt0_1@206@01) | live]
(push) ; 18
; [else-branch: 1557 | !(pt0_1@206@01)]
(pop) ; 18
; [eval] !pt0_1
(push) ; 18
(set-option :rlimit 16000)
(assert (not pt0_1@206@01))
(check-sat)
; unknown
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1558 | !(pt0_1@206@01) | live]
; [else-branch: 1558 | pt0_1@206@01 | dead]
(set-option :rlimit 0)
(push) ; 18
; [then-branch: 1558 | !(pt0_1@206@01)]
(push) ; 19
(set-option :rlimit 16000)
(assert (not (not pt1_1@207@01)))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1559 | pt1_1@207@01 | live]
; [else-branch: 1559 | !(pt1_1@207@01) | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 1559 | pt1_1@207@01]
; [exec]
; returned_0 := true
; [then-branch: 1560 | False | dead]
; [else-branch: 1560 | True | live]
(push) ; 20
; [else-branch: 1560 | True]
(pop) ; 20
; [eval] !pt2_1
(push) ; 20
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1561 | True | live]
; [else-branch: 1561 | False | dead]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 1561 | True]
; [exec]
; pt0_2 := pf0_1 && getCardSet(o1) == getCardSet(o2)
; [eval] pf0_1 && getCardSet(o1) == getCardSet(o2)
(push) ; 21
; [then-branch: 1562 | !(pf0_1@208@01) | live]
; [else-branch: 1562 | pf0_1@208@01 | live]
(push) ; 22
; [then-branch: 1562 | !(pf0_1@208@01)]
(assert (not pf0_1@208@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1562 | pf0_1@208@01]
(assert pf0_1@208@01)
; [eval] getCardSet(o1) == getCardSet(o2)
; [eval] getCardSet(o1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1@15@01))
; [eval] getCardSet(o2)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_1@208@01
  (and
    pf0_1@208@01
    (getCardSet%precondition $Snap.unit o1@15@01)
    (getCardSet%precondition $Snap.unit o2@18@01))))
(assert (or pf0_1@208@01 (not pf0_1@208@01)))
(declare-const pt0_2@230@01 Bool)
(assert (=
  pt0_2@230@01
  (and
    pf0_1@208@01
    (= (getCardSet $Snap.unit o1@15@01) (getCardSet $Snap.unit o2@18@01)))))
; [exec]
; pt1_2 := pf1_1 && getCardSet(o1_0) == getCardSet(o2_0)
; [eval] pf1_1 && getCardSet(o1_0) == getCardSet(o2_0)
(push) ; 21
; [then-branch: 1563 | !(pf1_1@209@01) | live]
; [else-branch: 1563 | pf1_1@209@01 | live]
(push) ; 22
; [then-branch: 1563 | !(pf1_1@209@01)]
(assert (not pf1_1@209@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1563 | pf1_1@209@01]
(assert pf1_1@209@01)
; [eval] getCardSet(o1_0) == getCardSet(o2_0)
; [eval] getCardSet(o1_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
; [eval] getCardSet(o2_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_1@209@01
  (and
    pf1_1@209@01
    (getCardSet%precondition $Snap.unit o1_0@16@01)
    (getCardSet%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_1@209@01 (not pf1_1@209@01)))
(declare-const pt1_2@231@01 Bool)
(assert (=
  pt1_2@231@01
  (and
    pf1_1@209@01
    (= (getCardSet $Snap.unit o1_0@16@01) (getCardSet $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_2 := pf2_1 && getCardSet(o1_1) == getCardSet(o2_1)
; [eval] pf2_1 && getCardSet(o1_1) == getCardSet(o2_1)
; [exec]
; pf0_2 := pf0_1 && !(getCardSet(o1) == getCardSet(o2))
; [eval] pf0_1 && !(getCardSet(o1) == getCardSet(o2))
(push) ; 21
; [then-branch: 1564 | !(pf0_1@208@01) | live]
; [else-branch: 1564 | pf0_1@208@01 | live]
(push) ; 22
; [then-branch: 1564 | !(pf0_1@208@01)]
(assert (not pf0_1@208@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1564 | pf0_1@208@01]
(assert pf0_1@208@01)
; [eval] !(getCardSet(o1) == getCardSet(o2))
; [eval] getCardSet(o1) == getCardSet(o2)
; [eval] getCardSet(o1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1@15@01))
; [eval] getCardSet(o2)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf0_2@232@01 Bool)
(assert (=
  pf0_2@232@01
  (and
    pf0_1@208@01
    (not (= (getCardSet $Snap.unit o1@15@01) (getCardSet $Snap.unit o2@18@01))))))
; [exec]
; pf1_2 := pf1_1 && !(getCardSet(o1_0) == getCardSet(o2_0))
; [eval] pf1_1 && !(getCardSet(o1_0) == getCardSet(o2_0))
(push) ; 21
; [then-branch: 1565 | !(pf1_1@209@01) | live]
; [else-branch: 1565 | pf1_1@209@01 | live]
(push) ; 22
; [then-branch: 1565 | !(pf1_1@209@01)]
(assert (not pf1_1@209@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1565 | pf1_1@209@01]
(assert pf1_1@209@01)
; [eval] !(getCardSet(o1_0) == getCardSet(o2_0))
; [eval] getCardSet(o1_0) == getCardSet(o2_0)
; [eval] getCardSet(o1_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
; [eval] getCardSet(o2_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf1_2@233@01 Bool)
(assert (=
  pf1_2@233@01
  (and
    pf1_1@209@01
    (not
      (= (getCardSet $Snap.unit o1_0@16@01) (getCardSet $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_2 := pf2_1 && !(getCardSet(o1_1) == getCardSet(o2_1))
; [eval] pf2_1 && !(getCardSet(o1_1) == getCardSet(o2_1))
; [exec]
; pt0_3 := pt0_2 && getCardRarity(o1) < getCardRarity(o2)
; [eval] pt0_2 && getCardRarity(o1) < getCardRarity(o2)
(push) ; 21
; [then-branch: 1566 | !(pt0_2@230@01) | live]
; [else-branch: 1566 | pt0_2@230@01 | live]
(push) ; 22
; [then-branch: 1566 | !(pt0_2@230@01)]
(assert (not pt0_2@230@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1566 | pt0_2@230@01]
(assert pt0_2@230@01)
; [eval] getCardRarity(o1) < getCardRarity(o2)
; [eval] getCardRarity(o1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
; [eval] getCardRarity(o2)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pt0_2@230@01
  (and
    pt0_2@230@01
    (getCardRarity%precondition $Snap.unit o1@15@01)
    (getCardRarity%precondition $Snap.unit o2@18@01))))
(assert (or pt0_2@230@01 (not pt0_2@230@01)))
(declare-const pt0_3@234@01 Bool)
(assert (=
  pt0_3@234@01
  (and
    pt0_2@230@01
    (< (getCardRarity $Snap.unit o1@15@01) (getCardRarity $Snap.unit o2@18@01)))))
; [exec]
; pt1_3 := pt1_2 && getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] pt1_2 && getCardRarity(o1_0) < getCardRarity(o2_0)
(push) ; 21
; [then-branch: 1567 | !(pt1_2@231@01) | live]
; [else-branch: 1567 | pt1_2@231@01 | live]
(push) ; 22
; [then-branch: 1567 | !(pt1_2@231@01)]
(assert (not pt1_2@231@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1567 | pt1_2@231@01]
(assert pt1_2@231@01)
; [eval] getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] getCardRarity(o1_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
; [eval] getCardRarity(o2_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pt1_2@231@01
  (and
    pt1_2@231@01
    (getCardRarity%precondition $Snap.unit o1_0@16@01)
    (getCardRarity%precondition $Snap.unit o2_0@19@01))))
(assert (or pt1_2@231@01 (not pt1_2@231@01)))
(declare-const pt1_3@235@01 Bool)
(assert (=
  pt1_3@235@01
  (and
    pt1_2@231@01
    (<
      (getCardRarity $Snap.unit o1_0@16@01)
      (getCardRarity $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_3 := pt2_2 && getCardRarity(o1_1) < getCardRarity(o2_1)
; [eval] pt2_2 && getCardRarity(o1_1) < getCardRarity(o2_1)
; [exec]
; pf0_3 := pt0_2 && !(getCardRarity(o1) < getCardRarity(o2))
; [eval] pt0_2 && !(getCardRarity(o1) < getCardRarity(o2))
(push) ; 21
; [then-branch: 1568 | !(pt0_2@230@01) | live]
; [else-branch: 1568 | pt0_2@230@01 | live]
(push) ; 22
; [then-branch: 1568 | !(pt0_2@230@01)]
(assert (not pt0_2@230@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1568 | pt0_2@230@01]
(assert pt0_2@230@01)
; [eval] !(getCardRarity(o1) < getCardRarity(o2))
; [eval] getCardRarity(o1) < getCardRarity(o2)
; [eval] getCardRarity(o1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
; [eval] getCardRarity(o2)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf0_3@236@01 Bool)
(assert (=
  pf0_3@236@01
  (and
    pt0_2@230@01
    (not
      (< (getCardRarity $Snap.unit o1@15@01) (getCardRarity $Snap.unit o2@18@01))))))
; [exec]
; pf1_3 := pt1_2 && !(getCardRarity(o1_0) < getCardRarity(o2_0))
; [eval] pt1_2 && !(getCardRarity(o1_0) < getCardRarity(o2_0))
(push) ; 21
; [then-branch: 1569 | !(pt1_2@231@01) | live]
; [else-branch: 1569 | pt1_2@231@01 | live]
(push) ; 22
; [then-branch: 1569 | !(pt1_2@231@01)]
(assert (not pt1_2@231@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1569 | pt1_2@231@01]
(assert pt1_2@231@01)
; [eval] !(getCardRarity(o1_0) < getCardRarity(o2_0))
; [eval] getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] getCardRarity(o1_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
; [eval] getCardRarity(o2_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf1_3@237@01 Bool)
(assert (=
  pf1_3@237@01
  (and
    pt1_2@231@01
    (not
      (<
        (getCardRarity $Snap.unit o1_0@16@01)
        (getCardRarity $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_3 := pt2_2 && !(getCardRarity(o1_1) < getCardRarity(o2_1))
; [eval] pt2_2 && !(getCardRarity(o1_1) < getCardRarity(o2_1))
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt0_3@234@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1570 | pt0_3@234@01 | dead]
; [else-branch: 1570 | !(pt0_3@234@01) | live]
(set-option :rlimit 0)
(push) ; 21
; [else-branch: 1570 | !(pt0_3@234@01)]
(assert (not pt0_3@234@01))
(pop) ; 21
; [eval] !pt0_3
(push) ; 21
(set-option :rlimit 16000)
(assert (not pt0_3@234@01))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt0_3@234@01)))
(check-sat)
; unsat
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1571 | !(pt0_3@234@01) | live]
; [else-branch: 1571 | pt0_3@234@01 | dead]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 1571 | !(pt0_3@234@01)]
(assert (not pt0_3@234@01))
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not pt1_3@235@01)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1572 | pt1_3@235@01 | dead]
; [else-branch: 1572 | !(pt1_3@235@01) | live]
(set-option :rlimit 0)
(push) ; 22
; [else-branch: 1572 | !(pt1_3@235@01)]
(assert (not pt1_3@235@01))
(pop) ; 22
; [eval] !pt1_3
(push) ; 22
(set-option :rlimit 16000)
(assert (not pt1_3@235@01))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not pt1_3@235@01)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1573 | !(pt1_3@235@01) | live]
; [else-branch: 1573 | pt1_3@235@01 | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 1573 | !(pt1_3@235@01)]
(assert (not pt1_3@235@01))
; [then-branch: 1574 | False | dead]
; [else-branch: 1574 | True | live]
(push) ; 23
; [else-branch: 1574 | True]
(pop) ; 23
; [eval] !pt2_3
(push) ; 23
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1575 | True | live]
; [else-branch: 1575 | False | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 1575 | True]
; [then-branch: 1576 | pt0_3@234@01 | dead]
; [else-branch: 1576 | !(pt0_3@234@01) | live]
(push) ; 24
; [else-branch: 1576 | !(pt0_3@234@01)]
(pop) ; 24
; [eval] !pt0_3
(push) ; 24
(set-option :rlimit 16000)
(assert (not pt0_3@234@01))
(check-sat)
; unknown
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1577 | !(pt0_3@234@01) | live]
; [else-branch: 1577 | pt0_3@234@01 | dead]
(set-option :rlimit 0)
(push) ; 24
; [then-branch: 1577 | !(pt0_3@234@01)]
; [then-branch: 1578 | pt1_3@235@01 | dead]
; [else-branch: 1578 | !(pt1_3@235@01) | live]
(push) ; 25
; [else-branch: 1578 | !(pt1_3@235@01)]
(pop) ; 25
; [eval] !pt1_3
(push) ; 25
(set-option :rlimit 16000)
(assert (not pt1_3@235@01))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1579 | !(pt1_3@235@01) | live]
; [else-branch: 1579 | pt1_3@235@01 | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 1579 | !(pt1_3@235@01)]
; [then-branch: 1580 | False | dead]
; [else-branch: 1580 | True | live]
(push) ; 26
; [else-branch: 1580 | True]
(pop) ; 26
; [eval] !pt2_3
(push) ; 26
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 26
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1581 | True | live]
; [else-branch: 1581 | False | dead]
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 1581 | True]
; [exec]
; pt0_4 := pf0_3 && getCardId(o1) == getCardId(o2)
; [eval] pf0_3 && getCardId(o1) == getCardId(o2)
(push) ; 27
; [then-branch: 1582 | !(pf0_3@236@01) | live]
; [else-branch: 1582 | pf0_3@236@01 | live]
(push) ; 28
; [then-branch: 1582 | !(pf0_3@236@01)]
(assert (not pf0_3@236@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1582 | pf0_3@236@01]
(assert pf0_3@236@01)
; [eval] getCardId(o1) == getCardId(o2)
; [eval] getCardId(o1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1@15@01))
; [eval] getCardId(o2)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_3@236@01
  (and
    pf0_3@236@01
    (getCardId%precondition $Snap.unit o1@15@01)
    (getCardId%precondition $Snap.unit o2@18@01))))
(assert (or pf0_3@236@01 (not pf0_3@236@01)))
(declare-const pt0_4@238@01 Bool)
(assert (=
  pt0_4@238@01
  (and
    pf0_3@236@01
    (= (getCardId $Snap.unit o1@15@01) (getCardId $Snap.unit o2@18@01)))))
; [exec]
; pt1_4 := pf1_3 && getCardId(o1_0) == getCardId(o2_0)
; [eval] pf1_3 && getCardId(o1_0) == getCardId(o2_0)
(push) ; 27
; [then-branch: 1583 | !(pf1_3@237@01) | live]
; [else-branch: 1583 | pf1_3@237@01 | live]
(push) ; 28
; [then-branch: 1583 | !(pf1_3@237@01)]
(assert (not pf1_3@237@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1583 | pf1_3@237@01]
(assert pf1_3@237@01)
; [eval] getCardId(o1_0) == getCardId(o2_0)
; [eval] getCardId(o1_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
; [eval] getCardId(o2_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_3@237@01
  (and
    pf1_3@237@01
    (getCardId%precondition $Snap.unit o1_0@16@01)
    (getCardId%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_3@237@01 (not pf1_3@237@01)))
(declare-const pt1_4@239@01 Bool)
(assert (=
  pt1_4@239@01
  (and
    pf1_3@237@01
    (= (getCardId $Snap.unit o1_0@16@01) (getCardId $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_4 := pf2_3 && getCardId(o1_1) == getCardId(o2_1)
; [eval] pf2_3 && getCardId(o1_1) == getCardId(o2_1)
; [exec]
; pf0_4 := pf0_3 && !(getCardId(o1) == getCardId(o2))
; [eval] pf0_3 && !(getCardId(o1) == getCardId(o2))
(push) ; 27
; [then-branch: 1584 | !(pf0_3@236@01) | live]
; [else-branch: 1584 | pf0_3@236@01 | live]
(push) ; 28
; [then-branch: 1584 | !(pf0_3@236@01)]
(assert (not pf0_3@236@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1584 | pf0_3@236@01]
(assert pf0_3@236@01)
; [eval] !(getCardId(o1) == getCardId(o2))
; [eval] getCardId(o1) == getCardId(o2)
; [eval] getCardId(o1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1@15@01))
; [eval] getCardId(o2)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf0_4@240@01 Bool)
(assert (=
  pf0_4@240@01
  (and
    pf0_3@236@01
    (not (= (getCardId $Snap.unit o1@15@01) (getCardId $Snap.unit o2@18@01))))))
; [exec]
; pf1_4 := pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
; [eval] pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
(push) ; 27
; [then-branch: 1585 | !(pf1_3@237@01) | live]
; [else-branch: 1585 | pf1_3@237@01 | live]
(push) ; 28
; [then-branch: 1585 | !(pf1_3@237@01)]
(assert (not pf1_3@237@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1585 | pf1_3@237@01]
(assert pf1_3@237@01)
; [eval] !(getCardId(o1_0) == getCardId(o2_0))
; [eval] getCardId(o1_0) == getCardId(o2_0)
; [eval] getCardId(o1_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
; [eval] getCardId(o2_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf1_4@241@01 Bool)
(assert (=
  pf1_4@241@01
  (and
    pf1_3@237@01
    (not (= (getCardId $Snap.unit o1_0@16@01) (getCardId $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_4 := pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
; [eval] pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
; [exec]
; pt0_5 := pt0_4 && cardType(o1) > cardType(o2)
; [eval] pt0_4 && cardType(o1) > cardType(o2)
(push) ; 27
; [then-branch: 1586 | !(pt0_4@238@01) | live]
; [else-branch: 1586 | pt0_4@238@01 | live]
(push) ; 28
; [then-branch: 1586 | !(pt0_4@238@01)]
(assert (not pt0_4@238@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1586 | pt0_4@238@01]
(assert pt0_4@238@01)
; [eval] cardType(o1) > cardType(o2)
; [eval] cardType(o1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt0_4@238@01
  (and
    pt0_4@238@01
    (cardType%precondition $Snap.unit o1@15@01)
    (cardType%precondition $Snap.unit o2@18@01))))
(assert (or pt0_4@238@01 (not pt0_4@238@01)))
(declare-const pt0_5@242@01 Bool)
(assert (=
  pt0_5@242@01
  (and
    pt0_4@238@01
    (> (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01)))))
; [exec]
; pt1_5 := pt1_4 && cardType(o1_0) > cardType(o2_0)
; [eval] pt1_4 && cardType(o1_0) > cardType(o2_0)
(push) ; 27
; [then-branch: 1587 | !(pt1_4@239@01) | live]
; [else-branch: 1587 | pt1_4@239@01 | live]
(push) ; 28
; [then-branch: 1587 | !(pt1_4@239@01)]
(assert (not pt1_4@239@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1587 | pt1_4@239@01]
(assert pt1_4@239@01)
; [eval] cardType(o1_0) > cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt1_4@239@01
  (and
    pt1_4@239@01
    (cardType%precondition $Snap.unit o1_0@16@01)
    (cardType%precondition $Snap.unit o2_0@19@01))))
(assert (or pt1_4@239@01 (not pt1_4@239@01)))
(declare-const pt1_5@243@01 Bool)
(assert (=
  pt1_5@243@01
  (and
    pt1_4@239@01
    (> (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_5 := pt2_4 && cardType(o1_1) > cardType(o2_1)
; [eval] pt2_4 && cardType(o1_1) > cardType(o2_1)
; [exec]
; pf0_5 := pt0_4 && !(cardType(o1) > cardType(o2))
; [eval] pt0_4 && !(cardType(o1) > cardType(o2))
(push) ; 27
; [then-branch: 1588 | !(pt0_4@238@01) | live]
; [else-branch: 1588 | pt0_4@238@01 | live]
(push) ; 28
; [then-branch: 1588 | !(pt0_4@238@01)]
(assert (not pt0_4@238@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1588 | pt0_4@238@01]
(assert pt0_4@238@01)
; [eval] !(cardType(o1) > cardType(o2))
; [eval] cardType(o1) > cardType(o2)
; [eval] cardType(o1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf0_5@244@01 Bool)
(assert (=
  pf0_5@244@01
  (and
    pt0_4@238@01
    (not (> (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01))))))
; [exec]
; pf1_5 := pt1_4 && !(cardType(o1_0) > cardType(o2_0))
; [eval] pt1_4 && !(cardType(o1_0) > cardType(o2_0))
(push) ; 27
; [then-branch: 1589 | !(pt1_4@239@01) | live]
; [else-branch: 1589 | pt1_4@239@01 | live]
(push) ; 28
; [then-branch: 1589 | !(pt1_4@239@01)]
(assert (not pt1_4@239@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1589 | pt1_4@239@01]
(assert pt1_4@239@01)
; [eval] !(cardType(o1_0) > cardType(o2_0))
; [eval] cardType(o1_0) > cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf1_5@245@01 Bool)
(assert (=
  pf1_5@245@01
  (and
    pt1_4@239@01
    (not (> (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_5 := pt2_4 && !(cardType(o1_1) > cardType(o2_1))
; [eval] pt2_4 && !(cardType(o1_1) > cardType(o2_1))
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not pt0_5@242@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1590 | pt0_5@242@01 | dead]
; [else-branch: 1590 | !(pt0_5@242@01) | live]
(set-option :rlimit 0)
(push) ; 27
; [else-branch: 1590 | !(pt0_5@242@01)]
(assert (not pt0_5@242@01))
(pop) ; 27
; [eval] !pt0_5
(push) ; 27
(set-option :rlimit 16000)
(assert (not pt0_5@242@01))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not pt0_5@242@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1591 | !(pt0_5@242@01) | live]
; [else-branch: 1591 | pt0_5@242@01 | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 1591 | !(pt0_5@242@01)]
(assert (not pt0_5@242@01))
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not pt1_5@243@01)))
(check-sat)
; unsat
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1592 | pt1_5@243@01 | dead]
; [else-branch: 1592 | !(pt1_5@243@01) | live]
(set-option :rlimit 0)
(push) ; 28
; [else-branch: 1592 | !(pt1_5@243@01)]
(assert (not pt1_5@243@01))
(pop) ; 28
; [eval] !pt1_5
(push) ; 28
(set-option :rlimit 16000)
(assert (not pt1_5@243@01))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not pt1_5@243@01)))
(check-sat)
; unsat
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1593 | !(pt1_5@243@01) | live]
; [else-branch: 1593 | pt1_5@243@01 | dead]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 1593 | !(pt1_5@243@01)]
(assert (not pt1_5@243@01))
; [then-branch: 1594 | False | dead]
; [else-branch: 1594 | True | live]
(push) ; 29
; [else-branch: 1594 | True]
(pop) ; 29
; [eval] !pt2_5
(push) ; 29
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1595 | True | live]
; [else-branch: 1595 | False | dead]
(set-option :rlimit 0)
(push) ; 29
; [then-branch: 1595 | True]
; [then-branch: 1596 | pt0_5@242@01 | dead]
; [else-branch: 1596 | !(pt0_5@242@01) | live]
(push) ; 30
; [else-branch: 1596 | !(pt0_5@242@01)]
(pop) ; 30
; [eval] !pt0_5
(push) ; 30
(set-option :rlimit 16000)
(assert (not pt0_5@242@01))
(check-sat)
; unknown
(pop) ; 30
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1597 | !(pt0_5@242@01) | live]
; [else-branch: 1597 | pt0_5@242@01 | dead]
(set-option :rlimit 0)
(push) ; 30
; [then-branch: 1597 | !(pt0_5@242@01)]
; [then-branch: 1598 | pt1_5@243@01 | dead]
; [else-branch: 1598 | !(pt1_5@243@01) | live]
(push) ; 31
; [else-branch: 1598 | !(pt1_5@243@01)]
(pop) ; 31
; [eval] !pt1_5
(push) ; 31
(set-option :rlimit 16000)
(assert (not pt1_5@243@01))
(check-sat)
; unknown
(pop) ; 31
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1599 | !(pt1_5@243@01) | live]
; [else-branch: 1599 | pt1_5@243@01 | dead]
(set-option :rlimit 0)
(push) ; 31
; [then-branch: 1599 | !(pt1_5@243@01)]
; [then-branch: 1600 | False | dead]
; [else-branch: 1600 | True | live]
(push) ; 32
; [else-branch: 1600 | True]
(pop) ; 32
; [eval] !pt2_5
(push) ; 32
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 32
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1601 | True | live]
; [else-branch: 1601 | False | dead]
(set-option :rlimit 0)
(push) ; 32
; [then-branch: 1601 | True]
; [exec]
; pt0_6 := pf0_5 && cardType(o1) == cardType(o2)
; [eval] pf0_5 && cardType(o1) == cardType(o2)
(push) ; 33
; [then-branch: 1602 | !(pf0_5@244@01) | live]
; [else-branch: 1602 | pf0_5@244@01 | live]
(push) ; 34
; [then-branch: 1602 | !(pf0_5@244@01)]
(assert (not pf0_5@244@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1602 | pf0_5@244@01]
(assert pf0_5@244@01)
; [eval] cardType(o1) == cardType(o2)
; [eval] cardType(o1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_5@244@01
  (and
    pf0_5@244@01
    (cardType%precondition $Snap.unit o1@15@01)
    (cardType%precondition $Snap.unit o2@18@01))))
(assert (or pf0_5@244@01 (not pf0_5@244@01)))
(declare-const pt0_6@246@01 Bool)
(assert (=
  pt0_6@246@01
  (and
    pf0_5@244@01
    (= (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01)))))
; [exec]
; pt1_6 := pf1_5 && cardType(o1_0) == cardType(o2_0)
; [eval] pf1_5 && cardType(o1_0) == cardType(o2_0)
(push) ; 33
; [then-branch: 1603 | !(pf1_5@245@01) | live]
; [else-branch: 1603 | pf1_5@245@01 | live]
(push) ; 34
; [then-branch: 1603 | !(pf1_5@245@01)]
(assert (not pf1_5@245@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1603 | pf1_5@245@01]
(assert pf1_5@245@01)
; [eval] cardType(o1_0) == cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_5@245@01
  (and
    pf1_5@245@01
    (cardType%precondition $Snap.unit o1_0@16@01)
    (cardType%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_5@245@01 (not pf1_5@245@01)))
(declare-const pt1_6@247@01 Bool)
(assert (=
  pt1_6@247@01
  (and
    pf1_5@245@01
    (= (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_6 := pf2_5 && cardType(o1_1) == cardType(o2_1)
; [eval] pf2_5 && cardType(o1_1) == cardType(o2_1)
; [exec]
; pf0_6 := pf0_5 && !(cardType(o1) == cardType(o2))
; [eval] pf0_5 && !(cardType(o1) == cardType(o2))
(push) ; 33
; [then-branch: 1604 | !(pf0_5@244@01) | live]
; [else-branch: 1604 | pf0_5@244@01 | live]
(push) ; 34
; [then-branch: 1604 | !(pf0_5@244@01)]
(assert (not pf0_5@244@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1604 | pf0_5@244@01]
(assert pf0_5@244@01)
; [eval] !(cardType(o1) == cardType(o2))
; [eval] cardType(o1) == cardType(o2)
; [eval] cardType(o1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf0_6@248@01 Bool)
(assert (=
  pf0_6@248@01
  (and
    pf0_5@244@01
    (not (= (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01))))))
; [exec]
; pf1_6 := pf1_5 && !(cardType(o1_0) == cardType(o2_0))
; [eval] pf1_5 && !(cardType(o1_0) == cardType(o2_0))
(push) ; 33
; [then-branch: 1605 | !(pf1_5@245@01) | live]
; [else-branch: 1605 | pf1_5@245@01 | live]
(push) ; 34
; [then-branch: 1605 | !(pf1_5@245@01)]
(assert (not pf1_5@245@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1605 | pf1_5@245@01]
(assert pf1_5@245@01)
; [eval] !(cardType(o1_0) == cardType(o2_0))
; [eval] cardType(o1_0) == cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf1_6@249@01 Bool)
(assert (=
  pf1_6@249@01
  (and
    pf1_5@245@01
    (not (= (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_6 := pf2_5 && !(cardType(o1_1) == cardType(o2_1))
; [eval] pf2_5 && !(cardType(o1_1) == cardType(o2_1))
(push) ; 33
(set-option :rlimit 16000)
(assert (not (not pt0_6@246@01)))
(check-sat)
; unsat
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1606 | pt0_6@246@01 | dead]
; [else-branch: 1606 | !(pt0_6@246@01) | live]
(set-option :rlimit 0)
(push) ; 33
; [else-branch: 1606 | !(pt0_6@246@01)]
(assert (not pt0_6@246@01))
(pop) ; 33
; [eval] !pt0_6
(push) ; 33
(set-option :rlimit 16000)
(assert (not pt0_6@246@01))
(check-sat)
; unknown
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 33
(set-option :rlimit 16000)
(assert (not (not pt0_6@246@01)))
(check-sat)
; unsat
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1607 | !(pt0_6@246@01) | live]
; [else-branch: 1607 | pt0_6@246@01 | dead]
(set-option :rlimit 0)
(push) ; 33
; [then-branch: 1607 | !(pt0_6@246@01)]
(assert (not pt0_6@246@01))
(push) ; 34
(set-option :rlimit 16000)
(assert (not (not pt1_6@247@01)))
(check-sat)
; unsat
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1608 | pt1_6@247@01 | dead]
; [else-branch: 1608 | !(pt1_6@247@01) | live]
(set-option :rlimit 0)
(push) ; 34
; [else-branch: 1608 | !(pt1_6@247@01)]
(assert (not pt1_6@247@01))
(pop) ; 34
; [eval] !pt1_6
(push) ; 34
(set-option :rlimit 16000)
(assert (not pt1_6@247@01))
(check-sat)
; unknown
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 34
(set-option :rlimit 16000)
(assert (not (not pt1_6@247@01)))
(check-sat)
; unsat
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1609 | !(pt1_6@247@01) | live]
; [else-branch: 1609 | pt1_6@247@01 | dead]
(set-option :rlimit 0)
(push) ; 34
; [then-branch: 1609 | !(pt1_6@247@01)]
(assert (not pt1_6@247@01))
; [then-branch: 1610 | False | dead]
; [else-branch: 1610 | True | live]
(push) ; 35
; [else-branch: 1610 | True]
(pop) ; 35
; [eval] !pt2_6
(push) ; 35
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1611 | True | live]
; [else-branch: 1611 | False | dead]
(set-option :rlimit 0)
(push) ; 35
; [then-branch: 1611 | True]
; [then-branch: 1612 | pt0_6@246@01 | dead]
; [else-branch: 1612 | !(pt0_6@246@01) | live]
(push) ; 36
; [else-branch: 1612 | !(pt0_6@246@01)]
(pop) ; 36
; [eval] !pt0_6
(push) ; 36
(set-option :rlimit 16000)
(assert (not pt0_6@246@01))
(check-sat)
; unknown
(pop) ; 36
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1613 | !(pt0_6@246@01) | live]
; [else-branch: 1613 | pt0_6@246@01 | dead]
(set-option :rlimit 0)
(push) ; 36
; [then-branch: 1613 | !(pt0_6@246@01)]
; [then-branch: 1614 | pt1_6@247@01 | dead]
; [else-branch: 1614 | !(pt1_6@247@01) | live]
(push) ; 37
; [else-branch: 1614 | !(pt1_6@247@01)]
(pop) ; 37
; [eval] !pt1_6
(push) ; 37
(set-option :rlimit 16000)
(assert (not pt1_6@247@01))
(check-sat)
; unknown
(pop) ; 37
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1615 | !(pt1_6@247@01) | live]
; [else-branch: 1615 | pt1_6@247@01 | dead]
(set-option :rlimit 0)
(push) ; 37
; [then-branch: 1615 | !(pt1_6@247@01)]
; [then-branch: 1616 | False | dead]
; [else-branch: 1616 | True | live]
(push) ; 38
; [else-branch: 1616 | True]
(pop) ; 38
; [eval] !pt2_6
(push) ; 38
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 38
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1617 | True | live]
; [else-branch: 1617 | False | dead]
(set-option :rlimit 0)
(push) ; 38
; [then-branch: 1617 | True]
(push) ; 39
(set-option :rlimit 16000)
(assert (not (not pf0_6@248@01)))
(check-sat)
; unsat
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1618 | pf0_6@248@01 | dead]
; [else-branch: 1618 | !(pf0_6@248@01) | live]
(set-option :rlimit 0)
(push) ; 39
; [else-branch: 1618 | !(pf0_6@248@01)]
(assert (not pf0_6@248@01))
(pop) ; 39
; [eval] !pf0_6
(push) ; 39
(set-option :rlimit 16000)
(assert (not pf0_6@248@01))
(check-sat)
; unknown
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 39
(set-option :rlimit 16000)
(assert (not (not pf0_6@248@01)))
(check-sat)
; unsat
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1619 | !(pf0_6@248@01) | live]
; [else-branch: 1619 | pf0_6@248@01 | dead]
(set-option :rlimit 0)
(push) ; 39
; [then-branch: 1619 | !(pf0_6@248@01)]
(assert (not pf0_6@248@01))
(push) ; 40
(set-option :rlimit 16000)
(assert (not (not pf1_6@249@01)))
(check-sat)
; unsat
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1620 | pf1_6@249@01 | dead]
; [else-branch: 1620 | !(pf1_6@249@01) | live]
(set-option :rlimit 0)
(push) ; 40
; [else-branch: 1620 | !(pf1_6@249@01)]
(assert (not pf1_6@249@01))
(pop) ; 40
; [eval] !pf1_6
(push) ; 40
(set-option :rlimit 16000)
(assert (not pf1_6@249@01))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 40
(set-option :rlimit 16000)
(assert (not (not pf1_6@249@01)))
(check-sat)
; unsat
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1621 | !(pf1_6@249@01) | live]
; [else-branch: 1621 | pf1_6@249@01 | dead]
(set-option :rlimit 0)
(push) ; 40
; [then-branch: 1621 | !(pf1_6@249@01)]
(assert (not pf1_6@249@01))
; [then-branch: 1622 | False | dead]
; [else-branch: 1622 | True | live]
(push) ; 41
; [else-branch: 1622 | True]
(pop) ; 41
; [eval] !pf2_6
(push) ; 41
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1623 | True | live]
; [else-branch: 1623 | False | dead]
(set-option :rlimit 0)
(push) ; 41
; [then-branch: 1623 | True]
; [then-branch: 1624 | pf0_6@248@01 | dead]
; [else-branch: 1624 | !(pf0_6@248@01) | live]
(push) ; 42
; [else-branch: 1624 | !(pf0_6@248@01)]
(pop) ; 42
; [eval] !pf0_6
(push) ; 42
(set-option :rlimit 16000)
(assert (not pf0_6@248@01))
(check-sat)
; unknown
(pop) ; 42
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1625 | !(pf0_6@248@01) | live]
; [else-branch: 1625 | pf0_6@248@01 | dead]
(set-option :rlimit 0)
(push) ; 42
; [then-branch: 1625 | !(pf0_6@248@01)]
; [then-branch: 1626 | pf1_6@249@01 | dead]
; [else-branch: 1626 | !(pf1_6@249@01) | live]
(push) ; 43
; [else-branch: 1626 | !(pf1_6@249@01)]
(pop) ; 43
; [eval] !pf1_6
(push) ; 43
(set-option :rlimit 16000)
(assert (not pf1_6@249@01))
(check-sat)
; unknown
(pop) ; 43
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1627 | !(pf1_6@249@01) | live]
; [else-branch: 1627 | pf1_6@249@01 | dead]
(set-option :rlimit 0)
(push) ; 43
; [then-branch: 1627 | !(pf1_6@249@01)]
; [then-branch: 1628 | False | dead]
; [else-branch: 1628 | True | live]
(push) ; 44
; [else-branch: 1628 | True]
(pop) ; 44
; [eval] !pf2_6
(push) ; 44
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 44
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1629 | True | live]
; [else-branch: 1629 | False | dead]
(set-option :rlimit 0)
(push) ; 44
; [then-branch: 1629 | True]
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@240@01)))
(check-sat)
; unsat
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1630 | pf0_4@240@01 | dead]
; [else-branch: 1630 | !(pf0_4@240@01) | live]
(set-option :rlimit 0)
(push) ; 45
; [else-branch: 1630 | !(pf0_4@240@01)]
(assert (not pf0_4@240@01))
(pop) ; 45
; [eval] !pf0_4
(push) ; 45
(set-option :rlimit 16000)
(assert (not pf0_4@240@01))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@240@01)))
(check-sat)
; unsat
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1631 | !(pf0_4@240@01) | live]
; [else-branch: 1631 | pf0_4@240@01 | dead]
(set-option :rlimit 0)
(push) ; 45
; [then-branch: 1631 | !(pf0_4@240@01)]
(assert (not pf0_4@240@01))
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@241@01)))
(check-sat)
; unsat
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1632 | pf1_4@241@01 | dead]
; [else-branch: 1632 | !(pf1_4@241@01) | live]
(set-option :rlimit 0)
(push) ; 46
; [else-branch: 1632 | !(pf1_4@241@01)]
(assert (not pf1_4@241@01))
(pop) ; 46
; [eval] !pf1_4
(push) ; 46
(set-option :rlimit 16000)
(assert (not pf1_4@241@01))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@241@01)))
(check-sat)
; unsat
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1633 | !(pf1_4@241@01) | live]
; [else-branch: 1633 | pf1_4@241@01 | dead]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 1633 | !(pf1_4@241@01)]
(assert (not pf1_4@241@01))
; [then-branch: 1634 | False | dead]
; [else-branch: 1634 | True | live]
(push) ; 47
; [else-branch: 1634 | True]
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1635 | True | live]
; [else-branch: 1635 | False | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 1635 | True]
; [then-branch: 1636 | pf0_4@240@01 | dead]
; [else-branch: 1636 | !(pf0_4@240@01) | live]
(push) ; 48
; [else-branch: 1636 | !(pf0_4@240@01)]
(pop) ; 48
; [eval] !pf0_4
(push) ; 48
(set-option :rlimit 16000)
(assert (not pf0_4@240@01))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1637 | !(pf0_4@240@01) | live]
; [else-branch: 1637 | pf0_4@240@01 | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 1637 | !(pf0_4@240@01)]
; [then-branch: 1638 | pf1_4@241@01 | dead]
; [else-branch: 1638 | !(pf1_4@241@01) | live]
(push) ; 49
; [else-branch: 1638 | !(pf1_4@241@01)]
(pop) ; 49
; [eval] !pf1_4
(push) ; 49
(set-option :rlimit 16000)
(assert (not pf1_4@241@01))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1639 | !(pf1_4@241@01) | live]
; [else-branch: 1639 | pf1_4@241@01 | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 1639 | !(pf1_4@241@01)]
; [then-branch: 1640 | False | dead]
; [else-branch: 1640 | True | live]
(push) ; 50
; [else-branch: 1640 | True]
(pop) ; 50
; [eval] !pf2_4
(push) ; 50
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1641 | True | live]
; [else-branch: 1641 | False | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 1641 | True]
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@232@01)))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 51
(set-option :rlimit 16000)
(assert (not pf0_2@232@01))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1642 | pf0_2@232@01 | live]
; [else-branch: 1642 | !(pf0_2@232@01) | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 1642 | pf0_2@232@01]
(assert pf0_2@232@01)
; [exec]
; res := -1
; [eval] -1
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@233@01)))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1643 | pf1_2@233@01 | dead]
; [else-branch: 1643 | !(pf1_2@233@01) | live]
(set-option :rlimit 0)
(push) ; 52
; [else-branch: 1643 | !(pf1_2@233@01)]
(assert (not pf1_2@233@01))
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not pf1_2@233@01))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@233@01)))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1644 | !(pf1_2@233@01) | live]
; [else-branch: 1644 | pf1_2@233@01 | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 1644 | !(pf1_2@233@01)]
(assert (not pf1_2@233@01))
; [then-branch: 1645 | False | dead]
; [else-branch: 1645 | True | live]
(push) ; 53
; [else-branch: 1645 | True]
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1646 | True | live]
; [else-branch: 1646 | False | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 1646 | True]
(push) ; 54
(set-option :rlimit 16000)
(assert (not (not pf0_2@232@01)))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1647 | pf0_2@232@01 | live]
; [else-branch: 1647 | !(pf0_2@232@01) | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 1647 | pf0_2@232@01]
; [exec]
; returned := true
; [then-branch: 1648 | pf1_2@233@01 | dead]
; [else-branch: 1648 | !(pf1_2@233@01) | live]
(push) ; 55
; [else-branch: 1648 | !(pf1_2@233@01)]
(pop) ; 55
; [eval] !pf1_2
(push) ; 55
(set-option :rlimit 16000)
(assert (not pf1_2@233@01))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1649 | !(pf1_2@233@01) | live]
; [else-branch: 1649 | pf1_2@233@01 | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 1649 | !(pf1_2@233@01)]
; [then-branch: 1650 | False | dead]
; [else-branch: 1650 | True | live]
(push) ; 56
; [else-branch: 1650 | True]
(pop) ; 56
; [eval] !pf2_2
(push) ; 56
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1651 | True | live]
; [else-branch: 1651 | False | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 1651 | True]
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1652 | p0@12@01 | live]
; [else-branch: 1652 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1652 | p0@12@01]
(assert p0@12@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1653 | p1@13@01 | live]
; [else-branch: 1653 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1653 | p1@13@01]
(assert p1@13@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p1@13@01)
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1654 | p2@14@01 | live]
; [else-branch: 1654 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1654 | p2@14@01]
(assert p2@14@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p2@14@01)
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1655 | p0@12@01 | live]
; [else-branch: 1655 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1655 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1656 | False | live]
; [else-branch: 1656 | True | live]
(push) ; 60
; [then-branch: 1656 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1656 | True]
(push) ; 61
; [then-branch: 1657 | !(p0@12@01) | live]
; [else-branch: 1657 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1657 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1657 | p0@12@01]
(push) ; 63
; [then-branch: 1658 | !(p1@13@01) | live]
; [else-branch: 1658 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1658 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1658 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1659 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1659 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1659 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1660 | False | dead]
; [else-branch: 1660 | True | live]
(push) ; 62
; [else-branch: 1660 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
; [eval] p1 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1661 | p1@13@01 | live]
; [else-branch: 1661 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1661 | p1@13@01]
(assert p1@13@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1662 | False | live]
; [else-branch: 1662 | True | live]
(push) ; 60
; [then-branch: 1662 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1662 | True]
(push) ; 61
; [then-branch: 1663 | !(p0@12@01) | live]
; [else-branch: 1663 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1663 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1663 | p0@12@01]
(push) ; 63
; [then-branch: 1664 | !(p1@13@01) | live]
; [else-branch: 1664 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1664 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1664 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1665 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1665 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1665 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1666 | False | dead]
; [else-branch: 1666 | True | live]
(push) ; 62
; [else-branch: 1666 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p1@13@01
  (and
    p1@13@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p2@14@01)))
(assert p1@13@01)
; [eval] p2 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1667 | p2@14@01 | live]
; [else-branch: 1667 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1667 | p2@14@01]
(assert p2@14@01)
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1668 | False | live]
; [else-branch: 1668 | True | live]
(push) ; 60
; [then-branch: 1668 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1668 | True]
(push) ; 61
; [then-branch: 1669 | !(p0@12@01) | live]
; [else-branch: 1669 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1669 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1669 | p0@12@01]
(assert p0@12@01)
(push) ; 63
; [then-branch: 1670 | !(p1@13@01) | live]
; [else-branch: 1670 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1670 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1670 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1671 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1671 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1671 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1672 | False | dead]
; [else-branch: 1672 | True | live]
(push) ; 62
; [else-branch: 1672 | True]
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p2@14@01
  (and
    p2@14@01
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01)))
(assert p2@14@01)
(pop) ; 56
(pop) ; 55
(pop) ; 54
; [eval] !pf0_2
; [then-branch: 1673 | !(pf0_2@232@01) | dead]
; [else-branch: 1673 | pf0_2@232@01 | live]
(push) ; 54
; [else-branch: 1673 | pf0_2@232@01]
(pop) ; 54
(pop) ; 53
(pop) ; 52
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not pf0_2@232@01))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1674 | !(pf0_2@232@01) | dead]
; [else-branch: 1674 | pf0_2@232@01 | live]
(set-option :rlimit 0)
(push) ; 51
; [else-branch: 1674 | pf0_2@232@01]
(assert pf0_2@232@01)
(pop) ; 51
(pop) ; 50
(pop) ; 49
(pop) ; 48
(pop) ; 47
(pop) ; 46
(pop) ; 45
(pop) ; 44
(pop) ; 43
(pop) ; 42
(pop) ; 41
(pop) ; 40
(pop) ; 39
(pop) ; 38
(pop) ; 37
(pop) ; 36
(pop) ; 35
(pop) ; 34
(pop) ; 33
(pop) ; 32
(pop) ; 31
(pop) ; 30
(pop) ; 29
(pop) ; 28
(pop) ; 27
(pop) ; 26
(pop) ; 25
(pop) ; 24
(pop) ; 23
(pop) ; 22
(pop) ; 21
(pop) ; 20
(pop) ; 19
; [eval] !pt1_1
; [then-branch: 1675 | !(pt1_1@207@01) | dead]
; [else-branch: 1675 | pt1_1@207@01 | live]
(push) ; 19
; [else-branch: 1675 | pt1_1@207@01]
(pop) ; 19
(pop) ; 18
(pop) ; 17
(pop) ; 16
(push) ; 16
; [else-branch: 1554 | !(pt1_1@207@01)]
(assert (not pt1_1@207@01))
(pop) ; 16
; [eval] !pt1_1
(push) ; 16
(set-option :rlimit 16000)
(assert (not pt1_1@207@01))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 16
(set-option :rlimit 16000)
(assert (not (not pt1_1@207@01)))
(check-sat)
; unknown
(pop) ; 16
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1676 | !(pt1_1@207@01) | live]
; [else-branch: 1676 | pt1_1@207@01 | live]
(set-option :rlimit 0)
(push) ; 16
; [then-branch: 1676 | !(pt1_1@207@01)]
(assert (not pt1_1@207@01))
; [then-branch: 1677 | False | dead]
; [else-branch: 1677 | True | live]
(push) ; 17
; [else-branch: 1677 | True]
(pop) ; 17
; [eval] !pt2_1
(push) ; 17
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 17
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1678 | True | live]
; [else-branch: 1678 | False | dead]
(set-option :rlimit 0)
(push) ; 17
; [then-branch: 1678 | True]
; [then-branch: 1679 | pt0_1@206@01 | dead]
; [else-branch: 1679 | !(pt0_1@206@01) | live]
(push) ; 18
; [else-branch: 1679 | !(pt0_1@206@01)]
(pop) ; 18
; [eval] !pt0_1
(push) ; 18
(set-option :rlimit 16000)
(assert (not pt0_1@206@01))
(check-sat)
; unknown
(pop) ; 18
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1680 | !(pt0_1@206@01) | live]
; [else-branch: 1680 | pt0_1@206@01 | dead]
(set-option :rlimit 0)
(push) ; 18
; [then-branch: 1680 | !(pt0_1@206@01)]
; [then-branch: 1681 | pt1_1@207@01 | dead]
; [else-branch: 1681 | !(pt1_1@207@01) | live]
(push) ; 19
; [else-branch: 1681 | !(pt1_1@207@01)]
(pop) ; 19
; [eval] !pt1_1
(push) ; 19
(set-option :rlimit 16000)
(assert (not pt1_1@207@01))
(check-sat)
; unknown
(pop) ; 19
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1682 | !(pt1_1@207@01) | live]
; [else-branch: 1682 | pt1_1@207@01 | dead]
(set-option :rlimit 0)
(push) ; 19
; [then-branch: 1682 | !(pt1_1@207@01)]
; [then-branch: 1683 | False | dead]
; [else-branch: 1683 | True | live]
(push) ; 20
; [else-branch: 1683 | True]
(pop) ; 20
; [eval] !pt2_1
(push) ; 20
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 20
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1684 | True | live]
; [else-branch: 1684 | False | dead]
(set-option :rlimit 0)
(push) ; 20
; [then-branch: 1684 | True]
; [exec]
; pt0_2 := pf0_1 && getCardSet(o1) == getCardSet(o2)
; [eval] pf0_1 && getCardSet(o1) == getCardSet(o2)
(push) ; 21
; [then-branch: 1685 | !(pf0_1@208@01) | live]
; [else-branch: 1685 | pf0_1@208@01 | live]
(push) ; 22
; [then-branch: 1685 | !(pf0_1@208@01)]
(assert (not pf0_1@208@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1685 | pf0_1@208@01]
(assert pf0_1@208@01)
; [eval] getCardSet(o1) == getCardSet(o2)
; [eval] getCardSet(o1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1@15@01))
; [eval] getCardSet(o2)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_1@208@01
  (and
    pf0_1@208@01
    (getCardSet%precondition $Snap.unit o1@15@01)
    (getCardSet%precondition $Snap.unit o2@18@01))))
(assert (or pf0_1@208@01 (not pf0_1@208@01)))
(declare-const pt0_2@250@01 Bool)
(assert (=
  pt0_2@250@01
  (and
    pf0_1@208@01
    (= (getCardSet $Snap.unit o1@15@01) (getCardSet $Snap.unit o2@18@01)))))
; [exec]
; pt1_2 := pf1_1 && getCardSet(o1_0) == getCardSet(o2_0)
; [eval] pf1_1 && getCardSet(o1_0) == getCardSet(o2_0)
(push) ; 21
; [then-branch: 1686 | !(pf1_1@209@01) | live]
; [else-branch: 1686 | pf1_1@209@01 | live]
(push) ; 22
; [then-branch: 1686 | !(pf1_1@209@01)]
(assert (not pf1_1@209@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1686 | pf1_1@209@01]
(assert pf1_1@209@01)
; [eval] getCardSet(o1_0) == getCardSet(o2_0)
; [eval] getCardSet(o1_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
; [eval] getCardSet(o2_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_1@209@01
  (and
    pf1_1@209@01
    (getCardSet%precondition $Snap.unit o1_0@16@01)
    (getCardSet%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_1@209@01 (not pf1_1@209@01)))
(declare-const pt1_2@251@01 Bool)
(assert (=
  pt1_2@251@01
  (and
    pf1_1@209@01
    (= (getCardSet $Snap.unit o1_0@16@01) (getCardSet $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_2 := pf2_1 && getCardSet(o1_1) == getCardSet(o2_1)
; [eval] pf2_1 && getCardSet(o1_1) == getCardSet(o2_1)
; [exec]
; pf0_2 := pf0_1 && !(getCardSet(o1) == getCardSet(o2))
; [eval] pf0_1 && !(getCardSet(o1) == getCardSet(o2))
(push) ; 21
; [then-branch: 1687 | !(pf0_1@208@01) | live]
; [else-branch: 1687 | pf0_1@208@01 | live]
(push) ; 22
; [then-branch: 1687 | !(pf0_1@208@01)]
(assert (not pf0_1@208@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1687 | pf0_1@208@01]
(assert pf0_1@208@01)
; [eval] !(getCardSet(o1) == getCardSet(o2))
; [eval] getCardSet(o1) == getCardSet(o2)
; [eval] getCardSet(o1)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1@15@01))
; [eval] getCardSet(o2)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf0_2@252@01 Bool)
(assert (=
  pf0_2@252@01
  (and
    pf0_1@208@01
    (not (= (getCardSet $Snap.unit o1@15@01) (getCardSet $Snap.unit o2@18@01))))))
; [exec]
; pf1_2 := pf1_1 && !(getCardSet(o1_0) == getCardSet(o2_0))
; [eval] pf1_1 && !(getCardSet(o1_0) == getCardSet(o2_0))
(push) ; 21
; [then-branch: 1688 | !(pf1_1@209@01) | live]
; [else-branch: 1688 | pf1_1@209@01 | live]
(push) ; 22
; [then-branch: 1688 | !(pf1_1@209@01)]
(assert (not pf1_1@209@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1688 | pf1_1@209@01]
(assert pf1_1@209@01)
; [eval] !(getCardSet(o1_0) == getCardSet(o2_0))
; [eval] getCardSet(o1_0) == getCardSet(o2_0)
; [eval] getCardSet(o1_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o1_0@16@01))
; [eval] getCardSet(o2_0)
(push) ; 23
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardSet%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf1_2@253@01 Bool)
(assert (=
  pf1_2@253@01
  (and
    pf1_1@209@01
    (not
      (= (getCardSet $Snap.unit o1_0@16@01) (getCardSet $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_2 := pf2_1 && !(getCardSet(o1_1) == getCardSet(o2_1))
; [eval] pf2_1 && !(getCardSet(o1_1) == getCardSet(o2_1))
; [exec]
; pt0_3 := pt0_2 && getCardRarity(o1) < getCardRarity(o2)
; [eval] pt0_2 && getCardRarity(o1) < getCardRarity(o2)
(push) ; 21
; [then-branch: 1689 | !(pt0_2@250@01) | live]
; [else-branch: 1689 | pt0_2@250@01 | live]
(push) ; 22
; [then-branch: 1689 | !(pt0_2@250@01)]
(assert (not pt0_2@250@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1689 | pt0_2@250@01]
(assert pt0_2@250@01)
; [eval] getCardRarity(o1) < getCardRarity(o2)
; [eval] getCardRarity(o1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
; [eval] getCardRarity(o2)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pt0_2@250@01
  (and
    pt0_2@250@01
    (getCardRarity%precondition $Snap.unit o1@15@01)
    (getCardRarity%precondition $Snap.unit o2@18@01))))
(assert (or pt0_2@250@01 (not pt0_2@250@01)))
(declare-const pt0_3@254@01 Bool)
(assert (=
  pt0_3@254@01
  (and
    pt0_2@250@01
    (< (getCardRarity $Snap.unit o1@15@01) (getCardRarity $Snap.unit o2@18@01)))))
; [exec]
; pt1_3 := pt1_2 && getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] pt1_2 && getCardRarity(o1_0) < getCardRarity(o2_0)
(push) ; 21
; [then-branch: 1690 | !(pt1_2@251@01) | live]
; [else-branch: 1690 | pt1_2@251@01 | live]
(push) ; 22
; [then-branch: 1690 | !(pt1_2@251@01)]
(assert (not pt1_2@251@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1690 | pt1_2@251@01]
(assert pt1_2@251@01)
; [eval] getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] getCardRarity(o1_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
; [eval] getCardRarity(o2_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(assert (=>
  pt1_2@251@01
  (and
    pt1_2@251@01
    (getCardRarity%precondition $Snap.unit o1_0@16@01)
    (getCardRarity%precondition $Snap.unit o2_0@19@01))))
(assert (or pt1_2@251@01 (not pt1_2@251@01)))
(declare-const pt1_3@255@01 Bool)
(assert (=
  pt1_3@255@01
  (and
    pt1_2@251@01
    (<
      (getCardRarity $Snap.unit o1_0@16@01)
      (getCardRarity $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_3 := pt2_2 && getCardRarity(o1_1) < getCardRarity(o2_1)
; [eval] pt2_2 && getCardRarity(o1_1) < getCardRarity(o2_1)
; [exec]
; pf0_3 := pt0_2 && !(getCardRarity(o1) < getCardRarity(o2))
; [eval] pt0_2 && !(getCardRarity(o1) < getCardRarity(o2))
(push) ; 21
; [then-branch: 1691 | !(pt0_2@250@01) | live]
; [else-branch: 1691 | pt0_2@250@01 | live]
(push) ; 22
; [then-branch: 1691 | !(pt0_2@250@01)]
(assert (not pt0_2@250@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1691 | pt0_2@250@01]
(assert pt0_2@250@01)
; [eval] !(getCardRarity(o1) < getCardRarity(o2))
; [eval] getCardRarity(o1) < getCardRarity(o2)
; [eval] getCardRarity(o1)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1@15@01))
; [eval] getCardRarity(o2)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2@18@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf0_3@256@01 Bool)
(assert (=
  pf0_3@256@01
  (and
    pt0_2@250@01
    (not
      (< (getCardRarity $Snap.unit o1@15@01) (getCardRarity $Snap.unit o2@18@01))))))
; [exec]
; pf1_3 := pt1_2 && !(getCardRarity(o1_0) < getCardRarity(o2_0))
; [eval] pt1_2 && !(getCardRarity(o1_0) < getCardRarity(o2_0))
(push) ; 21
; [then-branch: 1692 | !(pt1_2@251@01) | live]
; [else-branch: 1692 | pt1_2@251@01 | live]
(push) ; 22
; [then-branch: 1692 | !(pt1_2@251@01)]
(assert (not pt1_2@251@01))
(pop) ; 22
(push) ; 22
; [else-branch: 1692 | pt1_2@251@01]
(assert pt1_2@251@01)
; [eval] !(getCardRarity(o1_0) < getCardRarity(o2_0))
; [eval] getCardRarity(o1_0) < getCardRarity(o2_0)
; [eval] getCardRarity(o1_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o1_0@16@01))
; [eval] getCardRarity(o2_0)
(push) ; 23
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 23
; Joined path conditions
(assert (getCardRarity%precondition $Snap.unit o2_0@19@01))
(pop) ; 22
(pop) ; 21
; Joined path conditions
; Joined path conditions
(declare-const pf1_3@257@01 Bool)
(assert (=
  pf1_3@257@01
  (and
    pt1_2@251@01
    (not
      (<
        (getCardRarity $Snap.unit o1_0@16@01)
        (getCardRarity $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_3 := pt2_2 && !(getCardRarity(o1_1) < getCardRarity(o2_1))
; [eval] pt2_2 && !(getCardRarity(o1_1) < getCardRarity(o2_1))
(push) ; 21
(set-option :rlimit 16000)
(assert (not (not pt0_3@254@01)))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 21
(set-option :rlimit 16000)
(assert (not pt0_3@254@01))
(check-sat)
; unknown
(pop) ; 21
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1693 | pt0_3@254@01 | live]
; [else-branch: 1693 | !(pt0_3@254@01) | live]
(set-option :rlimit 0)
(push) ; 21
; [then-branch: 1693 | pt0_3@254@01]
(assert pt0_3@254@01)
; [exec]
; res := 1
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not pt1_3@255@01)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1694 | pt1_3@255@01 | dead]
; [else-branch: 1694 | !(pt1_3@255@01) | live]
(set-option :rlimit 0)
(push) ; 22
; [else-branch: 1694 | !(pt1_3@255@01)]
(assert (not pt1_3@255@01))
(pop) ; 22
; [eval] !pt1_3
(push) ; 22
(set-option :rlimit 16000)
(assert (not pt1_3@255@01))
(check-sat)
; unknown
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 22
(set-option :rlimit 16000)
(assert (not (not pt1_3@255@01)))
(check-sat)
; unsat
(pop) ; 22
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1695 | !(pt1_3@255@01) | live]
; [else-branch: 1695 | pt1_3@255@01 | dead]
(set-option :rlimit 0)
(push) ; 22
; [then-branch: 1695 | !(pt1_3@255@01)]
(assert (not pt1_3@255@01))
; [then-branch: 1696 | False | dead]
; [else-branch: 1696 | True | live]
(push) ; 23
; [else-branch: 1696 | True]
(pop) ; 23
; [eval] !pt2_3
(push) ; 23
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 23
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1697 | True | live]
; [else-branch: 1697 | False | dead]
(set-option :rlimit 0)
(push) ; 23
; [then-branch: 1697 | True]
(push) ; 24
(set-option :rlimit 16000)
(assert (not (not pt0_3@254@01)))
(check-sat)
; unknown
(pop) ; 24
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1698 | pt0_3@254@01 | live]
; [else-branch: 1698 | !(pt0_3@254@01) | dead]
(set-option :rlimit 0)
(push) ; 24
; [then-branch: 1698 | pt0_3@254@01]
; [exec]
; returned := true
; [then-branch: 1699 | pt1_3@255@01 | dead]
; [else-branch: 1699 | !(pt1_3@255@01) | live]
(push) ; 25
; [else-branch: 1699 | !(pt1_3@255@01)]
(pop) ; 25
; [eval] !pt1_3
(push) ; 25
(set-option :rlimit 16000)
(assert (not pt1_3@255@01))
(check-sat)
; unknown
(pop) ; 25
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1700 | !(pt1_3@255@01) | live]
; [else-branch: 1700 | pt1_3@255@01 | dead]
(set-option :rlimit 0)
(push) ; 25
; [then-branch: 1700 | !(pt1_3@255@01)]
; [then-branch: 1701 | False | dead]
; [else-branch: 1701 | True | live]
(push) ; 26
; [else-branch: 1701 | True]
(pop) ; 26
; [eval] !pt2_3
(push) ; 26
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 26
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1702 | True | live]
; [else-branch: 1702 | False | dead]
(set-option :rlimit 0)
(push) ; 26
; [then-branch: 1702 | True]
; [exec]
; pt0_4 := pf0_3 && getCardId(o1) == getCardId(o2)
; [eval] pf0_3 && getCardId(o1) == getCardId(o2)
(push) ; 27
; [then-branch: 1703 | !(pf0_3@256@01) | live]
; [else-branch: 1703 | pf0_3@256@01 | live]
(push) ; 28
; [then-branch: 1703 | !(pf0_3@256@01)]
(assert (not pf0_3@256@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1703 | pf0_3@256@01]
(assert pf0_3@256@01)
; [eval] getCardId(o1) == getCardId(o2)
; [eval] getCardId(o1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1@15@01))
; [eval] getCardId(o2)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_3@256@01
  (and
    pf0_3@256@01
    (getCardId%precondition $Snap.unit o1@15@01)
    (getCardId%precondition $Snap.unit o2@18@01))))
(assert (or pf0_3@256@01 (not pf0_3@256@01)))
(declare-const pt0_4@258@01 Bool)
(assert (=
  pt0_4@258@01
  (and
    pf0_3@256@01
    (= (getCardId $Snap.unit o1@15@01) (getCardId $Snap.unit o2@18@01)))))
; [exec]
; pt1_4 := pf1_3 && getCardId(o1_0) == getCardId(o2_0)
; [eval] pf1_3 && getCardId(o1_0) == getCardId(o2_0)
(push) ; 27
; [then-branch: 1704 | !(pf1_3@257@01) | live]
; [else-branch: 1704 | pf1_3@257@01 | live]
(push) ; 28
; [then-branch: 1704 | !(pf1_3@257@01)]
(assert (not pf1_3@257@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1704 | pf1_3@257@01]
(assert pf1_3@257@01)
; [eval] getCardId(o1_0) == getCardId(o2_0)
; [eval] getCardId(o1_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
; [eval] getCardId(o2_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_3@257@01
  (and
    pf1_3@257@01
    (getCardId%precondition $Snap.unit o1_0@16@01)
    (getCardId%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_3@257@01 (not pf1_3@257@01)))
(declare-const pt1_4@259@01 Bool)
(assert (=
  pt1_4@259@01
  (and
    pf1_3@257@01
    (= (getCardId $Snap.unit o1_0@16@01) (getCardId $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_4 := pf2_3 && getCardId(o1_1) == getCardId(o2_1)
; [eval] pf2_3 && getCardId(o1_1) == getCardId(o2_1)
; [exec]
; pf0_4 := pf0_3 && !(getCardId(o1) == getCardId(o2))
; [eval] pf0_3 && !(getCardId(o1) == getCardId(o2))
(push) ; 27
; [then-branch: 1705 | !(pf0_3@256@01) | live]
; [else-branch: 1705 | pf0_3@256@01 | live]
(push) ; 28
; [then-branch: 1705 | !(pf0_3@256@01)]
(assert (not pf0_3@256@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1705 | pf0_3@256@01]
(assert pf0_3@256@01)
; [eval] !(getCardId(o1) == getCardId(o2))
; [eval] getCardId(o1) == getCardId(o2)
; [eval] getCardId(o1)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1@15@01))
; [eval] getCardId(o2)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf0_4@260@01 Bool)
(assert (=
  pf0_4@260@01
  (and
    pf0_3@256@01
    (not (= (getCardId $Snap.unit o1@15@01) (getCardId $Snap.unit o2@18@01))))))
; [exec]
; pf1_4 := pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
; [eval] pf1_3 && !(getCardId(o1_0) == getCardId(o2_0))
(push) ; 27
; [then-branch: 1706 | !(pf1_3@257@01) | live]
; [else-branch: 1706 | pf1_3@257@01 | live]
(push) ; 28
; [then-branch: 1706 | !(pf1_3@257@01)]
(assert (not pf1_3@257@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1706 | pf1_3@257@01]
(assert pf1_3@257@01)
; [eval] !(getCardId(o1_0) == getCardId(o2_0))
; [eval] getCardId(o1_0) == getCardId(o2_0)
; [eval] getCardId(o1_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o1_0@16@01))
; [eval] getCardId(o2_0)
(push) ; 29
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (getCardId%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf1_4@261@01 Bool)
(assert (=
  pf1_4@261@01
  (and
    pf1_3@257@01
    (not (= (getCardId $Snap.unit o1_0@16@01) (getCardId $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_4 := pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
; [eval] pf2_3 && !(getCardId(o1_1) == getCardId(o2_1))
; [exec]
; pt0_5 := pt0_4 && cardType(o1) > cardType(o2)
; [eval] pt0_4 && cardType(o1) > cardType(o2)
(push) ; 27
; [then-branch: 1707 | !(pt0_4@258@01) | live]
; [else-branch: 1707 | pt0_4@258@01 | live]
(push) ; 28
; [then-branch: 1707 | !(pt0_4@258@01)]
(assert (not pt0_4@258@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1707 | pt0_4@258@01]
(assert pt0_4@258@01)
; [eval] cardType(o1) > cardType(o2)
; [eval] cardType(o1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt0_4@258@01
  (and
    pt0_4@258@01
    (cardType%precondition $Snap.unit o1@15@01)
    (cardType%precondition $Snap.unit o2@18@01))))
(assert (or pt0_4@258@01 (not pt0_4@258@01)))
(declare-const pt0_5@262@01 Bool)
(assert (=
  pt0_5@262@01
  (and
    pt0_4@258@01
    (> (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01)))))
; [exec]
; pt1_5 := pt1_4 && cardType(o1_0) > cardType(o2_0)
; [eval] pt1_4 && cardType(o1_0) > cardType(o2_0)
(push) ; 27
; [then-branch: 1708 | !(pt1_4@259@01) | live]
; [else-branch: 1708 | pt1_4@259@01 | live]
(push) ; 28
; [then-branch: 1708 | !(pt1_4@259@01)]
(assert (not pt1_4@259@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1708 | pt1_4@259@01]
(assert pt1_4@259@01)
; [eval] cardType(o1_0) > cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(assert (=>
  pt1_4@259@01
  (and
    pt1_4@259@01
    (cardType%precondition $Snap.unit o1_0@16@01)
    (cardType%precondition $Snap.unit o2_0@19@01))))
(assert (or pt1_4@259@01 (not pt1_4@259@01)))
(declare-const pt1_5@263@01 Bool)
(assert (=
  pt1_5@263@01
  (and
    pt1_4@259@01
    (> (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_5 := pt2_4 && cardType(o1_1) > cardType(o2_1)
; [eval] pt2_4 && cardType(o1_1) > cardType(o2_1)
; [exec]
; pf0_5 := pt0_4 && !(cardType(o1) > cardType(o2))
; [eval] pt0_4 && !(cardType(o1) > cardType(o2))
(push) ; 27
; [then-branch: 1709 | !(pt0_4@258@01) | live]
; [else-branch: 1709 | pt0_4@258@01 | live]
(push) ; 28
; [then-branch: 1709 | !(pt0_4@258@01)]
(assert (not pt0_4@258@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1709 | pt0_4@258@01]
(assert pt0_4@258@01)
; [eval] !(cardType(o1) > cardType(o2))
; [eval] cardType(o1) > cardType(o2)
; [eval] cardType(o1)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf0_5@264@01 Bool)
(assert (=
  pf0_5@264@01
  (and
    pt0_4@258@01
    (not (> (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01))))))
; [exec]
; pf1_5 := pt1_4 && !(cardType(o1_0) > cardType(o2_0))
; [eval] pt1_4 && !(cardType(o1_0) > cardType(o2_0))
(push) ; 27
; [then-branch: 1710 | !(pt1_4@259@01) | live]
; [else-branch: 1710 | pt1_4@259@01 | live]
(push) ; 28
; [then-branch: 1710 | !(pt1_4@259@01)]
(assert (not pt1_4@259@01))
(pop) ; 28
(push) ; 28
; [else-branch: 1710 | pt1_4@259@01]
(assert pt1_4@259@01)
; [eval] !(cardType(o1_0) > cardType(o2_0))
; [eval] cardType(o1_0) > cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 29
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 29
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 28
(pop) ; 27
; Joined path conditions
; Joined path conditions
(declare-const pf1_5@265@01 Bool)
(assert (=
  pf1_5@265@01
  (and
    pt1_4@259@01
    (not (> (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_5 := pt2_4 && !(cardType(o1_1) > cardType(o2_1))
; [eval] pt2_4 && !(cardType(o1_1) > cardType(o2_1))
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not pt0_5@262@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1711 | pt0_5@262@01 | dead]
; [else-branch: 1711 | !(pt0_5@262@01) | live]
(set-option :rlimit 0)
(push) ; 27
; [else-branch: 1711 | !(pt0_5@262@01)]
(assert (not pt0_5@262@01))
(pop) ; 27
; [eval] !pt0_5
(push) ; 27
(set-option :rlimit 16000)
(assert (not pt0_5@262@01))
(check-sat)
; unknown
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 27
(set-option :rlimit 16000)
(assert (not (not pt0_5@262@01)))
(check-sat)
; unsat
(pop) ; 27
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1712 | !(pt0_5@262@01) | live]
; [else-branch: 1712 | pt0_5@262@01 | dead]
(set-option :rlimit 0)
(push) ; 27
; [then-branch: 1712 | !(pt0_5@262@01)]
(assert (not pt0_5@262@01))
(push) ; 28
(set-option :rlimit 16000)
(assert (not (not pt1_5@263@01)))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 28
(set-option :rlimit 16000)
(assert (not pt1_5@263@01))
(check-sat)
; unknown
(pop) ; 28
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1713 | pt1_5@263@01 | live]
; [else-branch: 1713 | !(pt1_5@263@01) | live]
(set-option :rlimit 0)
(push) ; 28
; [then-branch: 1713 | pt1_5@263@01]
(assert pt1_5@263@01)
; [exec]
; res_0 := 1
; [then-branch: 1714 | False | dead]
; [else-branch: 1714 | True | live]
(push) ; 29
; [else-branch: 1714 | True]
(pop) ; 29
; [eval] !pt2_5
(push) ; 29
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 29
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1715 | True | live]
; [else-branch: 1715 | False | dead]
(set-option :rlimit 0)
(push) ; 29
; [then-branch: 1715 | True]
; [then-branch: 1716 | pt0_5@262@01 | dead]
; [else-branch: 1716 | !(pt0_5@262@01) | live]
(push) ; 30
; [else-branch: 1716 | !(pt0_5@262@01)]
(pop) ; 30
; [eval] !pt0_5
(push) ; 30
(set-option :rlimit 16000)
(assert (not pt0_5@262@01))
(check-sat)
; unknown
(pop) ; 30
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1717 | !(pt0_5@262@01) | live]
; [else-branch: 1717 | pt0_5@262@01 | dead]
(set-option :rlimit 0)
(push) ; 30
; [then-branch: 1717 | !(pt0_5@262@01)]
(push) ; 31
(set-option :rlimit 16000)
(assert (not (not pt1_5@263@01)))
(check-sat)
; unknown
(pop) ; 31
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1718 | pt1_5@263@01 | live]
; [else-branch: 1718 | !(pt1_5@263@01) | dead]
(set-option :rlimit 0)
(push) ; 31
; [then-branch: 1718 | pt1_5@263@01]
; [exec]
; returned_0 := true
; [then-branch: 1719 | False | dead]
; [else-branch: 1719 | True | live]
(push) ; 32
; [else-branch: 1719 | True]
(pop) ; 32
; [eval] !pt2_5
(push) ; 32
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 32
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1720 | True | live]
; [else-branch: 1720 | False | dead]
(set-option :rlimit 0)
(push) ; 32
; [then-branch: 1720 | True]
; [exec]
; pt0_6 := pf0_5 && cardType(o1) == cardType(o2)
; [eval] pf0_5 && cardType(o1) == cardType(o2)
(push) ; 33
; [then-branch: 1721 | !(pf0_5@264@01) | live]
; [else-branch: 1721 | pf0_5@264@01 | live]
(push) ; 34
; [then-branch: 1721 | !(pf0_5@264@01)]
(assert (not pf0_5@264@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1721 | pf0_5@264@01]
(assert pf0_5@264@01)
; [eval] cardType(o1) == cardType(o2)
; [eval] cardType(o1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf0_5@264@01
  (and
    pf0_5@264@01
    (cardType%precondition $Snap.unit o1@15@01)
    (cardType%precondition $Snap.unit o2@18@01))))
(assert (or pf0_5@264@01 (not pf0_5@264@01)))
(declare-const pt0_6@266@01 Bool)
(assert (=
  pt0_6@266@01
  (and
    pf0_5@264@01
    (= (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01)))))
; [exec]
; pt1_6 := pf1_5 && cardType(o1_0) == cardType(o2_0)
; [eval] pf1_5 && cardType(o1_0) == cardType(o2_0)
(push) ; 33
; [then-branch: 1722 | !(pf1_5@265@01) | live]
; [else-branch: 1722 | pf1_5@265@01 | live]
(push) ; 34
; [then-branch: 1722 | !(pf1_5@265@01)]
(assert (not pf1_5@265@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1722 | pf1_5@265@01]
(assert pf1_5@265@01)
; [eval] cardType(o1_0) == cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(assert (=>
  pf1_5@265@01
  (and
    pf1_5@265@01
    (cardType%precondition $Snap.unit o1_0@16@01)
    (cardType%precondition $Snap.unit o2_0@19@01))))
(assert (or pf1_5@265@01 (not pf1_5@265@01)))
(declare-const pt1_6@267@01 Bool)
(assert (=
  pt1_6@267@01
  (and
    pf1_5@265@01
    (= (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01)))))
; [exec]
; pt2_6 := pf2_5 && cardType(o1_1) == cardType(o2_1)
; [eval] pf2_5 && cardType(o1_1) == cardType(o2_1)
; [exec]
; pf0_6 := pf0_5 && !(cardType(o1) == cardType(o2))
; [eval] pf0_5 && !(cardType(o1) == cardType(o2))
(push) ; 33
; [then-branch: 1723 | !(pf0_5@264@01) | live]
; [else-branch: 1723 | pf0_5@264@01 | live]
(push) ; 34
; [then-branch: 1723 | !(pf0_5@264@01)]
(assert (not pf0_5@264@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1723 | pf0_5@264@01]
(assert pf0_5@264@01)
; [eval] !(cardType(o1) == cardType(o2))
; [eval] cardType(o1) == cardType(o2)
; [eval] cardType(o1)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1@15@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1@15@01))
; [eval] cardType(o2)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2@18@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf0_6@268@01 Bool)
(assert (=
  pf0_6@268@01
  (and
    pf0_5@264@01
    (not (= (cardType $Snap.unit o1@15@01) (cardType $Snap.unit o2@18@01))))))
; [exec]
; pf1_6 := pf1_5 && !(cardType(o1_0) == cardType(o2_0))
; [eval] pf1_5 && !(cardType(o1_0) == cardType(o2_0))
(push) ; 33
; [then-branch: 1724 | !(pf1_5@265@01) | live]
; [else-branch: 1724 | pf1_5@265@01 | live]
(push) ; 34
; [then-branch: 1724 | !(pf1_5@265@01)]
(assert (not pf1_5@265@01))
(pop) ; 34
(push) ; 34
; [else-branch: 1724 | pf1_5@265@01]
(assert pf1_5@265@01)
; [eval] !(cardType(o1_0) == cardType(o2_0))
; [eval] cardType(o1_0) == cardType(o2_0)
; [eval] cardType(o1_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o1_0@16@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o1_0@16@01))
; [eval] cardType(o2_0)
(push) ; 35
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 35
; Joined path conditions
(assert (cardType%precondition $Snap.unit o2_0@19@01))
(pop) ; 34
(pop) ; 33
; Joined path conditions
; Joined path conditions
(declare-const pf1_6@269@01 Bool)
(assert (=
  pf1_6@269@01
  (and
    pf1_5@265@01
    (not (= (cardType $Snap.unit o1_0@16@01) (cardType $Snap.unit o2_0@19@01))))))
; [exec]
; pf2_6 := pf2_5 && !(cardType(o1_1) == cardType(o2_1))
; [eval] pf2_5 && !(cardType(o1_1) == cardType(o2_1))
(push) ; 33
(set-option :rlimit 16000)
(assert (not (not pt0_6@266@01)))
(check-sat)
; unsat
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1725 | pt0_6@266@01 | dead]
; [else-branch: 1725 | !(pt0_6@266@01) | live]
(set-option :rlimit 0)
(push) ; 33
; [else-branch: 1725 | !(pt0_6@266@01)]
(assert (not pt0_6@266@01))
(pop) ; 33
; [eval] !pt0_6
(push) ; 33
(set-option :rlimit 16000)
(assert (not pt0_6@266@01))
(check-sat)
; unknown
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 33
(set-option :rlimit 16000)
(assert (not (not pt0_6@266@01)))
(check-sat)
; unsat
(pop) ; 33
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1726 | !(pt0_6@266@01) | live]
; [else-branch: 1726 | pt0_6@266@01 | dead]
(set-option :rlimit 0)
(push) ; 33
; [then-branch: 1726 | !(pt0_6@266@01)]
(assert (not pt0_6@266@01))
(push) ; 34
(set-option :rlimit 16000)
(assert (not (not pt1_6@267@01)))
(check-sat)
; unsat
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1727 | pt1_6@267@01 | dead]
; [else-branch: 1727 | !(pt1_6@267@01) | live]
(set-option :rlimit 0)
(push) ; 34
; [else-branch: 1727 | !(pt1_6@267@01)]
(assert (not pt1_6@267@01))
(pop) ; 34
; [eval] !pt1_6
(push) ; 34
(set-option :rlimit 16000)
(assert (not pt1_6@267@01))
(check-sat)
; unknown
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 34
(set-option :rlimit 16000)
(assert (not (not pt1_6@267@01)))
(check-sat)
; unsat
(pop) ; 34
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1728 | !(pt1_6@267@01) | live]
; [else-branch: 1728 | pt1_6@267@01 | dead]
(set-option :rlimit 0)
(push) ; 34
; [then-branch: 1728 | !(pt1_6@267@01)]
(assert (not pt1_6@267@01))
; [then-branch: 1729 | False | dead]
; [else-branch: 1729 | True | live]
(push) ; 35
; [else-branch: 1729 | True]
(pop) ; 35
; [eval] !pt2_6
(push) ; 35
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 35
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1730 | True | live]
; [else-branch: 1730 | False | dead]
(set-option :rlimit 0)
(push) ; 35
; [then-branch: 1730 | True]
; [then-branch: 1731 | pt0_6@266@01 | dead]
; [else-branch: 1731 | !(pt0_6@266@01) | live]
(push) ; 36
; [else-branch: 1731 | !(pt0_6@266@01)]
(pop) ; 36
; [eval] !pt0_6
(push) ; 36
(set-option :rlimit 16000)
(assert (not pt0_6@266@01))
(check-sat)
; unknown
(pop) ; 36
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1732 | !(pt0_6@266@01) | live]
; [else-branch: 1732 | pt0_6@266@01 | dead]
(set-option :rlimit 0)
(push) ; 36
; [then-branch: 1732 | !(pt0_6@266@01)]
; [then-branch: 1733 | pt1_6@267@01 | dead]
; [else-branch: 1733 | !(pt1_6@267@01) | live]
(push) ; 37
; [else-branch: 1733 | !(pt1_6@267@01)]
(pop) ; 37
; [eval] !pt1_6
(push) ; 37
(set-option :rlimit 16000)
(assert (not pt1_6@267@01))
(check-sat)
; unknown
(pop) ; 37
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1734 | !(pt1_6@267@01) | live]
; [else-branch: 1734 | pt1_6@267@01 | dead]
(set-option :rlimit 0)
(push) ; 37
; [then-branch: 1734 | !(pt1_6@267@01)]
; [then-branch: 1735 | False | dead]
; [else-branch: 1735 | True | live]
(push) ; 38
; [else-branch: 1735 | True]
(pop) ; 38
; [eval] !pt2_6
(push) ; 38
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 38
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1736 | True | live]
; [else-branch: 1736 | False | dead]
(set-option :rlimit 0)
(push) ; 38
; [then-branch: 1736 | True]
(push) ; 39
(set-option :rlimit 16000)
(assert (not (not pf0_6@268@01)))
(check-sat)
; unsat
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1737 | pf0_6@268@01 | dead]
; [else-branch: 1737 | !(pf0_6@268@01) | live]
(set-option :rlimit 0)
(push) ; 39
; [else-branch: 1737 | !(pf0_6@268@01)]
(assert (not pf0_6@268@01))
(pop) ; 39
; [eval] !pf0_6
(push) ; 39
(set-option :rlimit 16000)
(assert (not pf0_6@268@01))
(check-sat)
; unknown
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 39
(set-option :rlimit 16000)
(assert (not (not pf0_6@268@01)))
(check-sat)
; unsat
(pop) ; 39
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1738 | !(pf0_6@268@01) | live]
; [else-branch: 1738 | pf0_6@268@01 | dead]
(set-option :rlimit 0)
(push) ; 39
; [then-branch: 1738 | !(pf0_6@268@01)]
(assert (not pf0_6@268@01))
(push) ; 40
(set-option :rlimit 16000)
(assert (not (not pf1_6@269@01)))
(check-sat)
; unsat
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1739 | pf1_6@269@01 | dead]
; [else-branch: 1739 | !(pf1_6@269@01) | live]
(set-option :rlimit 0)
(push) ; 40
; [else-branch: 1739 | !(pf1_6@269@01)]
(assert (not pf1_6@269@01))
(pop) ; 40
; [eval] !pf1_6
(push) ; 40
(set-option :rlimit 16000)
(assert (not pf1_6@269@01))
(check-sat)
; unknown
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 40
(set-option :rlimit 16000)
(assert (not (not pf1_6@269@01)))
(check-sat)
; unsat
(pop) ; 40
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1740 | !(pf1_6@269@01) | live]
; [else-branch: 1740 | pf1_6@269@01 | dead]
(set-option :rlimit 0)
(push) ; 40
; [then-branch: 1740 | !(pf1_6@269@01)]
(assert (not pf1_6@269@01))
; [then-branch: 1741 | False | dead]
; [else-branch: 1741 | True | live]
(push) ; 41
; [else-branch: 1741 | True]
(pop) ; 41
; [eval] !pf2_6
(push) ; 41
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 41
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1742 | True | live]
; [else-branch: 1742 | False | dead]
(set-option :rlimit 0)
(push) ; 41
; [then-branch: 1742 | True]
; [then-branch: 1743 | pf0_6@268@01 | dead]
; [else-branch: 1743 | !(pf0_6@268@01) | live]
(push) ; 42
; [else-branch: 1743 | !(pf0_6@268@01)]
(pop) ; 42
; [eval] !pf0_6
(push) ; 42
(set-option :rlimit 16000)
(assert (not pf0_6@268@01))
(check-sat)
; unknown
(pop) ; 42
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1744 | !(pf0_6@268@01) | live]
; [else-branch: 1744 | pf0_6@268@01 | dead]
(set-option :rlimit 0)
(push) ; 42
; [then-branch: 1744 | !(pf0_6@268@01)]
; [then-branch: 1745 | pf1_6@269@01 | dead]
; [else-branch: 1745 | !(pf1_6@269@01) | live]
(push) ; 43
; [else-branch: 1745 | !(pf1_6@269@01)]
(pop) ; 43
; [eval] !pf1_6
(push) ; 43
(set-option :rlimit 16000)
(assert (not pf1_6@269@01))
(check-sat)
; unknown
(pop) ; 43
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1746 | !(pf1_6@269@01) | live]
; [else-branch: 1746 | pf1_6@269@01 | dead]
(set-option :rlimit 0)
(push) ; 43
; [then-branch: 1746 | !(pf1_6@269@01)]
; [then-branch: 1747 | False | dead]
; [else-branch: 1747 | True | live]
(push) ; 44
; [else-branch: 1747 | True]
(pop) ; 44
; [eval] !pf2_6
(push) ; 44
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 44
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1748 | True | live]
; [else-branch: 1748 | False | dead]
(set-option :rlimit 0)
(push) ; 44
; [then-branch: 1748 | True]
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@260@01)))
(check-sat)
; unsat
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1749 | pf0_4@260@01 | dead]
; [else-branch: 1749 | !(pf0_4@260@01) | live]
(set-option :rlimit 0)
(push) ; 45
; [else-branch: 1749 | !(pf0_4@260@01)]
(assert (not pf0_4@260@01))
(pop) ; 45
; [eval] !pf0_4
(push) ; 45
(set-option :rlimit 16000)
(assert (not pf0_4@260@01))
(check-sat)
; unknown
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 45
(set-option :rlimit 16000)
(assert (not (not pf0_4@260@01)))
(check-sat)
; unsat
(pop) ; 45
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1750 | !(pf0_4@260@01) | live]
; [else-branch: 1750 | pf0_4@260@01 | dead]
(set-option :rlimit 0)
(push) ; 45
; [then-branch: 1750 | !(pf0_4@260@01)]
(assert (not pf0_4@260@01))
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@261@01)))
(check-sat)
; unsat
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1751 | pf1_4@261@01 | dead]
; [else-branch: 1751 | !(pf1_4@261@01) | live]
(set-option :rlimit 0)
(push) ; 46
; [else-branch: 1751 | !(pf1_4@261@01)]
(assert (not pf1_4@261@01))
(pop) ; 46
; [eval] !pf1_4
(push) ; 46
(set-option :rlimit 16000)
(assert (not pf1_4@261@01))
(check-sat)
; unknown
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 46
(set-option :rlimit 16000)
(assert (not (not pf1_4@261@01)))
(check-sat)
; unsat
(pop) ; 46
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1752 | !(pf1_4@261@01) | live]
; [else-branch: 1752 | pf1_4@261@01 | dead]
(set-option :rlimit 0)
(push) ; 46
; [then-branch: 1752 | !(pf1_4@261@01)]
(assert (not pf1_4@261@01))
; [then-branch: 1753 | False | dead]
; [else-branch: 1753 | True | live]
(push) ; 47
; [else-branch: 1753 | True]
(pop) ; 47
; [eval] !pf2_4
(push) ; 47
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 47
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1754 | True | live]
; [else-branch: 1754 | False | dead]
(set-option :rlimit 0)
(push) ; 47
; [then-branch: 1754 | True]
; [then-branch: 1755 | pf0_4@260@01 | dead]
; [else-branch: 1755 | !(pf0_4@260@01) | live]
(push) ; 48
; [else-branch: 1755 | !(pf0_4@260@01)]
(pop) ; 48
; [eval] !pf0_4
(push) ; 48
(set-option :rlimit 16000)
(assert (not pf0_4@260@01))
(check-sat)
; unknown
(pop) ; 48
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1756 | !(pf0_4@260@01) | live]
; [else-branch: 1756 | pf0_4@260@01 | dead]
(set-option :rlimit 0)
(push) ; 48
; [then-branch: 1756 | !(pf0_4@260@01)]
; [then-branch: 1757 | pf1_4@261@01 | dead]
; [else-branch: 1757 | !(pf1_4@261@01) | live]
(push) ; 49
; [else-branch: 1757 | !(pf1_4@261@01)]
(pop) ; 49
; [eval] !pf1_4
(push) ; 49
(set-option :rlimit 16000)
(assert (not pf1_4@261@01))
(check-sat)
; unknown
(pop) ; 49
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1758 | !(pf1_4@261@01) | live]
; [else-branch: 1758 | pf1_4@261@01 | dead]
(set-option :rlimit 0)
(push) ; 49
; [then-branch: 1758 | !(pf1_4@261@01)]
; [then-branch: 1759 | False | dead]
; [else-branch: 1759 | True | live]
(push) ; 50
; [else-branch: 1759 | True]
(pop) ; 50
; [eval] !pf2_4
(push) ; 50
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 50
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1760 | True | live]
; [else-branch: 1760 | False | dead]
(set-option :rlimit 0)
(push) ; 50
; [then-branch: 1760 | True]
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@252@01)))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1761 | pf0_2@252@01 | dead]
; [else-branch: 1761 | !(pf0_2@252@01) | live]
(set-option :rlimit 0)
(push) ; 51
; [else-branch: 1761 | !(pf0_2@252@01)]
(assert (not pf0_2@252@01))
(pop) ; 51
; [eval] !pf0_2
(push) ; 51
(set-option :rlimit 16000)
(assert (not pf0_2@252@01))
(check-sat)
; unknown
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 51
(set-option :rlimit 16000)
(assert (not (not pf0_2@252@01)))
(check-sat)
; unsat
(pop) ; 51
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1762 | !(pf0_2@252@01) | live]
; [else-branch: 1762 | pf0_2@252@01 | dead]
(set-option :rlimit 0)
(push) ; 51
; [then-branch: 1762 | !(pf0_2@252@01)]
(assert (not pf0_2@252@01))
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@253@01)))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1763 | pf1_2@253@01 | dead]
; [else-branch: 1763 | !(pf1_2@253@01) | live]
(set-option :rlimit 0)
(push) ; 52
; [else-branch: 1763 | !(pf1_2@253@01)]
(assert (not pf1_2@253@01))
(pop) ; 52
; [eval] !pf1_2
(push) ; 52
(set-option :rlimit 16000)
(assert (not pf1_2@253@01))
(check-sat)
; unknown
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 52
(set-option :rlimit 16000)
(assert (not (not pf1_2@253@01)))
(check-sat)
; unsat
(pop) ; 52
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1764 | !(pf1_2@253@01) | live]
; [else-branch: 1764 | pf1_2@253@01 | dead]
(set-option :rlimit 0)
(push) ; 52
; [then-branch: 1764 | !(pf1_2@253@01)]
(assert (not pf1_2@253@01))
; [then-branch: 1765 | False | dead]
; [else-branch: 1765 | True | live]
(push) ; 53
; [else-branch: 1765 | True]
(pop) ; 53
; [eval] !pf2_2
(push) ; 53
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 53
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1766 | True | live]
; [else-branch: 1766 | False | dead]
(set-option :rlimit 0)
(push) ; 53
; [then-branch: 1766 | True]
; [then-branch: 1767 | pf0_2@252@01 | dead]
; [else-branch: 1767 | !(pf0_2@252@01) | live]
(push) ; 54
; [else-branch: 1767 | !(pf0_2@252@01)]
(pop) ; 54
; [eval] !pf0_2
(push) ; 54
(set-option :rlimit 16000)
(assert (not pf0_2@252@01))
(check-sat)
; unknown
(pop) ; 54
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1768 | !(pf0_2@252@01) | live]
; [else-branch: 1768 | pf0_2@252@01 | dead]
(set-option :rlimit 0)
(push) ; 54
; [then-branch: 1768 | !(pf0_2@252@01)]
; [then-branch: 1769 | pf1_2@253@01 | dead]
; [else-branch: 1769 | !(pf1_2@253@01) | live]
(push) ; 55
; [else-branch: 1769 | !(pf1_2@253@01)]
(pop) ; 55
; [eval] !pf1_2
(push) ; 55
(set-option :rlimit 16000)
(assert (not pf1_2@253@01))
(check-sat)
; unknown
(pop) ; 55
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1770 | !(pf1_2@253@01) | live]
; [else-branch: 1770 | pf1_2@253@01 | dead]
(set-option :rlimit 0)
(push) ; 55
; [then-branch: 1770 | !(pf1_2@253@01)]
; [then-branch: 1771 | False | dead]
; [else-branch: 1771 | True | live]
(push) ; 56
; [else-branch: 1771 | True]
(pop) ; 56
; [eval] !pf2_2
(push) ; 56
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 56
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1772 | True | live]
; [else-branch: 1772 | False | dead]
(set-option :rlimit 0)
(push) ; 56
; [then-branch: 1772 | True]
; [exec]
; assert (p0 ==> returned) && ((p1 ==> returned_0) && (p2 ==> returned_1))
; [eval] p0 ==> returned
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p0@12@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1773 | p0@12@01 | live]
; [else-branch: 1773 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1773 | p0@12@01]
(assert p0@12@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
; [eval] p1 ==> returned_0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p1@13@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p1@13@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1774 | p1@13@01 | live]
; [else-branch: 1774 | !(p1@13@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1774 | p1@13@01]
(assert p1@13@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p1@13@01)
; [eval] p2 ==> returned_1
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p2@14@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 58
(set-option :rlimit 16000)
(assert (not p2@14@01))
(check-sat)
; unsat
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1775 | p2@14@01 | live]
; [else-branch: 1775 | !(p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1775 | p2@14@01]
(assert p2@14@01)
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p2@14@01)
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1776 | p0@12@01 | live]
; [else-branch: 1776 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1776 | p0@12@01]
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(push) ; 59
; [then-branch: 1777 | False | live]
; [else-branch: 1777 | True | live]
(push) ; 60
; [then-branch: 1777 | False]
(assert false)
(pop) ; 60
(push) ; 60
; [else-branch: 1777 | True]
(push) ; 61
; [then-branch: 1778 | !(p0@12@01) | live]
; [else-branch: 1778 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1778 | !(p0@12@01)]
(assert (not p0@12@01))
(pop) ; 62
(push) ; 62
; [else-branch: 1778 | p0@12@01]
(push) ; 63
; [then-branch: 1779 | !(p1@13@01) | live]
; [else-branch: 1779 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1779 | !(p1@13@01)]
(assert (not p1@13@01))
(pop) ; 64
(push) ; 64
; [else-branch: 1779 | p1@13@01]
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1780 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1780 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1780 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(push) ; 61
; [then-branch: 1781 | False | live]
; [else-branch: 1781 | True | live]
(push) ; 62
; [then-branch: 1781 | False]
(assert false)
(pop) ; 62
(push) ; 62
; [else-branch: 1781 | True]
; [eval] res_0 > 0
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(push) ; 61
(push) ; 62
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 62
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1782 | True | live]
; [else-branch: 1782 | False | dead]
(set-option :rlimit 0)
(push) ; 62
; [then-branch: 1782 | True]
; [eval] res_1 > 0
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert (=>
  p0@12@01
  (and
    (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01))
    p0@12@01
    p1@13@01
    p2@14@01)))
(assert p0@12@01)
(push) ; 57
(assert (not (=> (and p0@12@01 (and p0@12@01 (and p1@13@01 p2@14@01))) false)))
(check-sat)
; unknown
(pop) ; 57
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(set-option :rlimit 0)
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1783 | p0@12@01 | live]
; [else-branch: 1783 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1783 | p0@12@01]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(set-option :rlimit 0)
(push) ; 59
; [then-branch: 1784 | False | live]
; [else-branch: 1784 | True | live]
(push) ; 60
; [then-branch: 1784 | False]
(assert false)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unsat
(pop) ; 60
(set-option :rlimit 0)
(push) ; 60
; [else-branch: 1784 | True]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 61
; [then-branch: 1785 | !(p0@12@01) | live]
; [else-branch: 1785 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1785 | !(p0@12@01)]
(assert (not p0@12@01))
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unsat
(pop) ; 62
(set-option :rlimit 0)
(push) ; 62
; [else-branch: 1785 | p0@12@01]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 63
; [then-branch: 1786 | !(p1@13@01) | live]
; [else-branch: 1786 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1786 | !(p1@13@01)]
(assert (not p1@13@01))
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unsat
(pop) ; 64
(set-option :rlimit 0)
(push) ; 64
; [else-branch: 1786 | p1@13@01]
(assert p1@13@01)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(set-option :rlimit 0)
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1787 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1787 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1787 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(set-option :rlimit 0)
(push) ; 61
; [then-branch: 1788 | False | live]
; [else-branch: 1788 | True | live]
(push) ; 62
; [then-branch: 1788 | False]
(assert false)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unsat
(pop) ; 62
(set-option :rlimit 0)
(push) ; 62
; [else-branch: 1788 | True]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] res_0 > 0
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(set-option :rlimit 0)
(push) ; 61
(push) ; 62
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 62
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1789 | True | live]
; [else-branch: 1789 | False | dead]
(set-option :rlimit 0)
(push) ; 62
; [then-branch: 1789 | True]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] res_1 > 0
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
(set-option :rlimit 0)
(push) ; 57
(assert (not (=> (and p0@12@01 (and p0@12@01 (and p1@13@01 p2@14@01))) false)))
(check-sat)
; unknown
(pop) ; 57
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(set-option :rlimit 0)
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1790 | p0@12@01 | live]
; [else-branch: 1790 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1790 | p0@12@01]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(set-option :rlimit 0)
(push) ; 59
; [then-branch: 1791 | False | live]
; [else-branch: 1791 | True | live]
(push) ; 60
; [then-branch: 1791 | False]
(assert false)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unsat
(pop) ; 60
(set-option :rlimit 0)
(push) ; 60
; [else-branch: 1791 | True]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 61
; [then-branch: 1792 | !(p0@12@01) | live]
; [else-branch: 1792 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1792 | !(p0@12@01)]
(assert (not p0@12@01))
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unsat
(pop) ; 62
(set-option :rlimit 0)
(push) ; 62
; [else-branch: 1792 | p0@12@01]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 63
; [then-branch: 1793 | !(p1@13@01) | live]
; [else-branch: 1793 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1793 | !(p1@13@01)]
(assert (not p1@13@01))
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unsat
(pop) ; 64
(set-option :rlimit 0)
(push) ; 64
; [else-branch: 1793 | p1@13@01]
(assert p1@13@01)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(set-option :rlimit 0)
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1794 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1794 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1794 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(set-option :rlimit 0)
(push) ; 61
; [then-branch: 1795 | False | live]
; [else-branch: 1795 | True | live]
(push) ; 62
; [then-branch: 1795 | False]
(assert false)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unsat
(pop) ; 62
(set-option :rlimit 0)
(push) ; 62
; [else-branch: 1795 | True]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] res_0 > 0
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(set-option :rlimit 0)
(push) ; 61
(push) ; 62
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 62
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1796 | True | live]
; [else-branch: 1796 | False | dead]
(set-option :rlimit 0)
(push) ; 62
; [then-branch: 1796 | True]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] res_1 > 0
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
(set-option :rlimit 0)
(push) ; 57
(assert (not (=> (and p0@12@01 (and p0@12@01 (and p1@13@01 p2@14@01))) false)))
(check-sat)
; unknown
(pop) ; 57
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] p0 ==> true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
(set-option :rlimit 0)
(push) ; 57
(push) ; 58
(set-option :rlimit 16000)
(assert (not (not p0@12@01)))
(check-sat)
; unknown
(pop) ; 58
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1797 | p0@12@01 | live]
; [else-branch: 1797 | !(p0@12@01) | dead]
(set-option :rlimit 0)
(push) ; 58
; [then-branch: 1797 | p0@12@01]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] true && (p0 && (p1 && p2)) ==> res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] true && (p0 && (p1 && p2))
(set-option :rlimit 0)
(push) ; 59
; [then-branch: 1798 | False | live]
; [else-branch: 1798 | True | live]
(push) ; 60
; [then-branch: 1798 | False]
(assert false)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unsat
(pop) ; 60
(set-option :rlimit 0)
(push) ; 60
; [else-branch: 1798 | True]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 61
; [then-branch: 1799 | !(p0@12@01) | live]
; [else-branch: 1799 | p0@12@01 | live]
(push) ; 62
; [then-branch: 1799 | !(p0@12@01)]
(assert (not p0@12@01))
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unsat
(pop) ; 62
(set-option :rlimit 0)
(push) ; 62
; [else-branch: 1799 | p0@12@01]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 63
; [then-branch: 1800 | !(p1@13@01) | live]
; [else-branch: 1800 | p1@13@01 | live]
(push) ; 64
; [then-branch: 1800 | !(p1@13@01)]
(assert (not p1@13@01))
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unsat
(pop) ; 64
(set-option :rlimit 0)
(push) ; 64
; [else-branch: 1800 | p1@13@01]
(assert p1@13@01)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
(pop) ; 64
(pop) ; 63
; Joined path conditions
; Joined path conditions
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
; Joined path conditions
(set-option :rlimit 0)
(push) ; 59
(push) ; 60
(set-option :rlimit 16000)
(assert (not (not (and p0@12@01 (and p1@13@01 p2@14@01)))))
(check-sat)
; unknown
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 60
(set-option :rlimit 16000)
(assert (not (and p0@12@01 (and p1@13@01 p2@14@01))))
(check-sat)
; unsat
(pop) ; 60
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1801 | p0@12@01 && p1@13@01 && p2@14@01 | live]
; [else-branch: 1801 | !(p0@12@01 && p1@13@01 && p2@14@01) | dead]
(set-option :rlimit 0)
(push) ; 60
; [then-branch: 1801 | p0@12@01 && p1@13@01 && p2@14@01]
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] res > 0 && res_0 > 0 ==> res_1 > 0
; [eval] res > 0 && res_0 > 0
; [eval] res > 0
(set-option :rlimit 0)
(push) ; 61
; [then-branch: 1802 | False | live]
; [else-branch: 1802 | True | live]
(push) ; 62
; [then-branch: 1802 | False]
(assert false)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unsat
(pop) ; 62
(set-option :rlimit 0)
(push) ; 62
; [else-branch: 1802 | True]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] res_0 > 0
(pop) ; 62
(pop) ; 61
; Joined path conditions
; Joined path conditions
(set-option :rlimit 0)
(push) ; 61
(push) ; 62
(set-option :rlimit 16000)
(assert (not false))
(check-sat)
; unknown
(pop) ; 62
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1803 | True | live]
; [else-branch: 1803 | False | dead]
(set-option :rlimit 0)
(push) ; 62
; [then-branch: 1803 | True]
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] res_1 > 0
(pop) ; 62
(pop) ; 61
; Joined path conditions
(pop) ; 60
(pop) ; 59
; Joined path conditions
(assert (=> (and p0@12@01 (and p1@13@01 p2@14@01)) (and p0@12@01 p1@13@01 p2@14@01)))
(assert (and p0@12@01 (and p1@13@01 p2@14@01)))
(pop) ; 58
(pop) ; 57
; Joined path conditions
(assert p0@12@01)
(set-option :rlimit 0)
(push) ; 57
(assert (not (=> (and p0@12@01 (and p0@12@01 (and p1@13@01 p2@14@01))) false)))
(check-sat)
; unknown
(pop) ; 57
; 0.00s
; (get-info :all-statistics)
(pop) ; 56
(pop) ; 55
(pop) ; 54
(pop) ; 53
(pop) ; 52
(pop) ; 51
(pop) ; 50
(pop) ; 49
(pop) ; 48
(pop) ; 47
(pop) ; 46
(pop) ; 45
(pop) ; 44
(pop) ; 43
(pop) ; 42
(pop) ; 41
(pop) ; 40
(pop) ; 39
(pop) ; 38
(pop) ; 37
(pop) ; 36
(pop) ; 35
(pop) ; 34
(pop) ; 33
(pop) ; 32
(pop) ; 31
(pop) ; 30
(pop) ; 29
(pop) ; 28
(pop) ; 27
(pop) ; 26
(pop) ; 25
(pop) ; 24
(pop) ; 23
(pop) ; 22
(pop) ; 21
(pop) ; 20
(pop) ; 19
(pop) ; 18
(pop) ; 17
(pop) ; 16
(pop) ; 15
(pop) ; 14
(pop) ; 13
(pop) ; 12
(pop) ; 11
(pop) ; 10
(pop) ; 9
(pop) ; 8
(pop) ; 7
(pop) ; 6
(pop) ; 5
(pop) ; 4
(pop) ; 3
(pop) ; 2
(pop) ; 1
