(get-info :version)
; (:version "4.8.7")
; Started: 2025-12-05 12:34:39
; Silicon.version: 1.1-SNAPSHOT (95328487@(detached))
; Input file: ./functions/number_theory.vpr
; Verifier id: 00
; ------------------------------------------------------------
; Begin preamble
; ////////// Static preamble
; 
; ; /z3config.smt2
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :smt.qi.max_multi_patterns 1000)
; 
; ; /preamble.smt2
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(define-fun $Perm.min ((p1 $Perm) (p2 $Perm)) Real
    (ite (<= p1 p2) p1 p2))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
; ////////// Sorts
; ////////// Sort wrappers
; Declaring additional sort wrappers
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
; ////////// Symbols
; Declaring symbols related to program functions (from program analysis)
(declare-fun divisible_ ($Snap Int Int) Bool)
(declare-fun divisible%limited ($Snap Int Int) Bool)
(declare-fun divisible%stateless (Int Int) Bool)
(declare-fun divisible%precondition ($Snap Int Int) Bool)
(declare-fun digit_sum ($Snap Int) Int)
(declare-fun digit_sum%limited ($Snap Int) Int)
(declare-fun digit_sum%stateless (Int) Bool)
(declare-fun digit_sum%precondition ($Snap Int) Bool)
(declare-fun sum_divisors_upto ($Snap Int Int) Int)
(declare-fun sum_divisors_upto%limited ($Snap Int Int) Int)
(declare-fun sum_divisors_upto%stateless (Int Int) Bool)
(declare-fun sum_divisors_upto%precondition ($Snap Int Int) Bool)
(declare-fun is_palindrome_helper ($Snap Int Int Int) Bool)
(declare-fun is_palindrome_helper%limited ($Snap Int Int Int) Bool)
(declare-fun is_palindrome_helper%stateless (Int Int Int) Bool)
(declare-fun is_palindrome_helper%precondition ($Snap Int Int Int) Bool)
(declare-fun gcd ($Snap Int Int) Int)
(declare-fun gcd%limited ($Snap Int Int) Int)
(declare-fun gcd%stateless (Int Int) Bool)
(declare-fun gcd%precondition ($Snap Int Int) Bool)
(declare-fun has_divisor_between ($Snap Int Int Int) Bool)
(declare-fun has_divisor_between%limited ($Snap Int Int Int) Bool)
(declare-fun has_divisor_between%stateless (Int Int Int) Bool)
(declare-fun has_divisor_between%precondition ($Snap Int Int Int) Bool)
(declare-fun triangular ($Snap Int) Int)
(declare-fun triangular%limited ($Snap Int) Int)
(declare-fun triangular%stateless (Int) Bool)
(declare-fun triangular%precondition ($Snap Int) Bool)
(declare-fun is_triangular ($Snap Int Int) Bool)
(declare-fun is_triangular%limited ($Snap Int Int) Bool)
(declare-fun is_triangular%stateless (Int Int) Bool)
(declare-fun is_triangular%precondition ($Snap Int Int) Bool)
(declare-fun digital_root ($Snap Int Int) Int)
(declare-fun digital_root%limited ($Snap Int Int) Int)
(declare-fun digital_root%stateless (Int Int) Bool)
(declare-fun digital_root%precondition ($Snap Int Int) Bool)
(declare-fun is_perfect ($Snap Int) Bool)
(declare-fun is_perfect%limited ($Snap Int) Bool)
(declare-fun is_perfect%stateless (Int) Bool)
(declare-fun is_perfect%precondition ($Snap Int) Bool)
(declare-fun is_palindrome ($Snap Int) Bool)
(declare-fun is_palindrome%limited ($Snap Int) Bool)
(declare-fun is_palindrome%stateless (Int) Bool)
(declare-fun is_palindrome%precondition ($Snap Int) Bool)
(declare-fun count_divisors_upto ($Snap Int Int) Int)
(declare-fun count_divisors_upto%limited ($Snap Int Int) Int)
(declare-fun count_divisors_upto%stateless (Int Int) Bool)
(declare-fun count_divisors_upto%precondition ($Snap Int Int) Bool)
(declare-fun sum_of_squares ($Snap Int) Int)
(declare-fun sum_of_squares%limited ($Snap Int) Int)
(declare-fun sum_of_squares%stateless (Int) Bool)
(declare-fun sum_of_squares%precondition ($Snap Int) Bool)
(declare-fun gcd_extended_steps ($Snap Int Int Int) Int)
(declare-fun gcd_extended_steps%limited ($Snap Int Int Int) Int)
(declare-fun gcd_extended_steps%stateless (Int Int Int) Bool)
(declare-fun gcd_extended_steps%precondition ($Snap Int Int Int) Bool)
(declare-fun is_perfect_square ($Snap Int Int) Bool)
(declare-fun is_perfect_square%limited ($Snap Int Int) Bool)
(declare-fun is_perfect_square%stateless (Int Int) Bool)
(declare-fun is_perfect_square%precondition ($Snap Int Int) Bool)
(declare-fun lcm ($Snap Int Int) Int)
(declare-fun lcm%limited ($Snap Int Int) Int)
(declare-fun lcm%stateless (Int Int) Bool)
(declare-fun lcm%precondition ($Snap Int Int) Bool)
(declare-fun is_prime ($Snap Int) Bool)
(declare-fun is_prime%limited ($Snap Int) Bool)
(declare-fun is_prime%stateless (Int) Bool)
(declare-fun is_prime%precondition ($Snap Int) Bool)
(declare-fun collatz_length ($Snap Int Int) Int)
(declare-fun collatz_length%limited ($Snap Int Int) Int)
(declare-fun collatz_length%stateless (Int Int) Bool)
(declare-fun collatz_length%precondition ($Snap Int Int) Bool)
(declare-fun power_mod_helper ($Snap Int Int Int) Int)
(declare-fun power_mod_helper%limited ($Snap Int Int Int) Int)
(declare-fun power_mod_helper%stateless (Int Int Int) Bool)
(declare-fun power_mod_helper%precondition ($Snap Int Int Int) Bool)
(declare-fun catalan ($Snap Int) Int)
(declare-fun catalan%limited ($Snap Int) Int)
(declare-fun catalan%stateless (Int) Bool)
(declare-fun catalan%precondition ($Snap Int) Bool)
(declare-fun catalan_sum_helper ($Snap Int Int) Int)
(declare-fun catalan_sum_helper%limited ($Snap Int Int) Int)
(declare-fun catalan_sum_helper%stateless (Int Int) Bool)
(declare-fun catalan_sum_helper%precondition ($Snap Int Int) Bool)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
; Declaring predicate trigger functions
; ////////// Uniqueness assumptions from domains
; ////////// Axioms
; End preamble
; ------------------------------------------------------------
; State saturation: after preamble
(set-option :rlimit 160000)
(check-sat)
; unknown
; ---------- FUNCTION divisible----------
(declare-fun n@0@00 () Int)
(declare-fun d@1@00 () Int)
(declare-fun result@2@00 () Bool)
; ----- Well-definedness of specifications -----
(set-option :rlimit 0)
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] d > 0
(assert (> d@1@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@0@00 Int) (d@1@00 Int)) (!
  (= (divisible%limited s@$ n@0@00 d@1@00) (divisible_ s@$ n@0@00 d@1@00))
  :pattern ((divisible_ s@$ n@0@00 d@1@00))
  :qid |quant-u-0|)))
(assert (forall ((s@$ $Snap) (n@0@00 Int) (d@1@00 Int)) (!
  (divisible%stateless n@0@00 d@1@00)
  :pattern ((divisible%limited s@$ n@0@00 d@1@00))
  :qid |quant-u-1|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (> d@1@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] n % d == 0
; [eval] n % d
(set-option :rlimit 0)
(push) ; 2
(assert (not (not (= d@1@00 0))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (= result@2@00 (= (mod n@0@00 d@1@00) 0)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@0@00 Int) (d@1@00 Int)) (!
  (=>
    (divisible%precondition s@$ n@0@00 d@1@00)
    (= (divisible_ s@$ n@0@00 d@1@00) (= (mod n@0@00 d@1@00) 0)))
  :pattern ((divisible_ s@$ n@0@00 d@1@00))
  :qid |quant-u-42|)))
(assert (forall ((s@$ $Snap) (n@0@00 Int) (d@1@00 Int)) (!
  true
  :pattern ((divisible_ s@$ n@0@00 d@1@00))
  :qid |quant-u-43|)))
; ---------- FUNCTION digit_sum----------
(declare-fun n@3@00 () Int)
(declare-fun result@4@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] n >= 0
(assert (>= n@3@00 0))
(declare-const $t@60@00 $Snap)
(assert (= $t@60@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@4@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@3@00 Int)) (!
  (= (digit_sum%limited s@$ n@3@00) (digit_sum s@$ n@3@00))
  :pattern ((digit_sum s@$ n@3@00))
  :qid |quant-u-2|)))
(assert (forall ((s@$ $Snap) (n@3@00 Int)) (!
  (digit_sum%stateless n@3@00)
  :pattern ((digit_sum%limited s@$ n@3@00))
  :qid |quant-u-3|)))
(assert (forall ((s@$ $Snap) (n@3@00 Int)) (!
  (let ((result@4@00 (digit_sum%limited s@$ n@3@00))) (=>
    (digit_sum%precondition s@$ n@3@00)
    (>= result@4@00 0)))
  :pattern ((digit_sum%limited s@$ n@3@00))
  :qid |quant-u-44|)))
(assert (forall ((s@$ $Snap) (n@3@00 Int)) (!
  (let ((result@4@00 (digit_sum%limited s@$ n@3@00))) true)
  :pattern ((digit_sum%limited s@$ n@3@00))
  :qid |quant-u-45|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (>= n@3@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (n < 10 ? n : n % 10 + digit_sum(n \ 10))
; [eval] n < 10
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (< n@3@00 10))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (< n@3@00 10)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 0 | n@3@00 < 10 | live]
; [else-branch: 0 | !(n@3@00 < 10) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 0 | n@3@00 < 10]
(assert (< n@3@00 10))
(pop) ; 3
(push) ; 3
; [else-branch: 0 | !(n@3@00 < 10)]
(assert (not (< n@3@00 10)))
; [eval] n % 10 + digit_sum(n \ 10)
; [eval] n % 10
; [eval] digit_sum(n \ 10)
; [eval] n \ 10
(push) ; 4
; [eval] n >= 0
(push) ; 5
(assert (not (>= (div n@3@00 10) 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (>= (div n@3@00 10) 0))
(assert (digit_sum%precondition $Snap.unit (div n@3@00 10)))
(pop) ; 4
; Joined path conditions
(assert (and (>= (div n@3@00 10) 0) (digit_sum%precondition $Snap.unit (div n@3@00 10))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (< n@3@00 10))
  (and
    (not (< n@3@00 10))
    (>= (div n@3@00 10) 0)
    (digit_sum%precondition $Snap.unit (div n@3@00 10)))))
(assert (or (not (< n@3@00 10)) (< n@3@00 10)))
(assert (=
  result@4@00
  (ite
    (< n@3@00 10)
    n@3@00
    (+ (mod n@3@00 10) (digit_sum $Snap.unit (div n@3@00 10))))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@4@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@4@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@3@00 Int)) (!
  (=>
    (digit_sum%precondition s@$ n@3@00)
    (=
      (digit_sum s@$ n@3@00)
      (ite
        (< n@3@00 10)
        n@3@00
        (+ (mod n@3@00 10) (digit_sum%limited $Snap.unit (div n@3@00 10))))))
  :pattern ((digit_sum s@$ n@3@00))
  :qid |quant-u-46|)))
(assert (forall ((s@$ $Snap) (n@3@00 Int)) (!
  (=>
    (digit_sum%precondition s@$ n@3@00)
    (ite (< n@3@00 10) true (digit_sum%precondition $Snap.unit (div n@3@00 10))))
  :pattern ((digit_sum s@$ n@3@00))
  :qid |quant-u-47|)))
; ---------- FUNCTION sum_divisors_upto----------
(declare-fun n@5@00 () Int)
(declare-fun limit@6@00 () Int)
(declare-fun result@7@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] n > 0
(assert (> n@5@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
; [eval] limit > 0
(assert (> limit@6@00 0))
(declare-const $t@61@00 $Snap)
(assert (= $t@61@00 ($Snap.combine ($Snap.first $t@61@00) ($Snap.second $t@61@00))))
(assert (= ($Snap.first $t@61@00) $Snap.unit))
; [eval] result >= 0
(assert (>= result@7@00 0))
(assert (= ($Snap.second $t@61@00) $Snap.unit))
; [eval] limit == 1 ==> result == (divisible(n, 1) ? 1 : 0)
; [eval] limit == 1
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= limit@6@00 1))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= limit@6@00 1)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1 | limit@6@00 == 1 | live]
; [else-branch: 1 | limit@6@00 != 1 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 1 | limit@6@00 == 1]
(assert (= limit@6@00 1))
; [eval] result == (divisible(n, 1) ? 1 : 0)
; [eval] (divisible(n, 1) ? 1 : 0)
; [eval] divisible(n, 1)
(push) ; 4
; [eval] d > 0
(assert (divisible%precondition $Snap.unit n@5@00 1))
(pop) ; 4
; Joined path conditions
(assert (divisible%precondition $Snap.unit n@5@00 1))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (divisible_ $Snap.unit n@5@00 1))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (divisible_ $Snap.unit n@5@00 1)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 2 | divisible(_, n@5@00, 1) | live]
; [else-branch: 2 | !(divisible(_, n@5@00, 1)) | dead]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 2 | divisible(_, n@5@00, 1)]
(assert (divisible_ $Snap.unit n@5@00 1))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (divisible_ $Snap.unit n@5@00 1))
(pop) ; 3
(push) ; 3
; [else-branch: 1 | limit@6@00 != 1]
(assert (not (= limit@6@00 1)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
(assert (=>
  (= limit@6@00 1)
  (and
    (= limit@6@00 1)
    (divisible%precondition $Snap.unit n@5@00 1)
    (divisible_ $Snap.unit n@5@00 1))))
; Joined path conditions
(assert (or (not (= limit@6@00 1)) (= limit@6@00 1)))
(assert (=> (= limit@6@00 1) (= result@7@00 1)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@5@00 Int) (limit@6@00 Int)) (!
  (=
    (sum_divisors_upto%limited s@$ n@5@00 limit@6@00)
    (sum_divisors_upto s@$ n@5@00 limit@6@00))
  :pattern ((sum_divisors_upto s@$ n@5@00 limit@6@00))
  :qid |quant-u-4|)))
(assert (forall ((s@$ $Snap) (n@5@00 Int) (limit@6@00 Int)) (!
  (sum_divisors_upto%stateless n@5@00 limit@6@00)
  :pattern ((sum_divisors_upto%limited s@$ n@5@00 limit@6@00))
  :qid |quant-u-5|)))
(assert (forall ((s@$ $Snap) (n@5@00 Int) (limit@6@00 Int)) (!
  (let ((result@7@00 (sum_divisors_upto%limited s@$ n@5@00 limit@6@00))) (=>
    (sum_divisors_upto%precondition s@$ n@5@00 limit@6@00)
    (and
      (>= result@7@00 0)
      (=>
        (= limit@6@00 1)
        (= result@7@00 (ite (divisible_ $Snap.unit n@5@00 1) 1 0))))))
  :pattern ((sum_divisors_upto%limited s@$ n@5@00 limit@6@00))
  :qid |quant-u-48|)))
(assert (forall ((s@$ $Snap) (n@5@00 Int) (limit@6@00 Int)) (!
  (let ((result@7@00 (sum_divisors_upto%limited s@$ n@5@00 limit@6@00))) true)
  :pattern ((sum_divisors_upto%limited s@$ n@5@00 limit@6@00))
  :qid |quant-u-49|)))
(assert (forall ((s@$ $Snap) (n@5@00 Int) (limit@6@00 Int)) (!
  (let ((result@7@00 (sum_divisors_upto%limited s@$ n@5@00 limit@6@00))) (=>
    (and (sum_divisors_upto%precondition s@$ n@5@00 limit@6@00) (= limit@6@00 1))
    (divisible%precondition $Snap.unit n@5@00 1)))
  :pattern ((sum_divisors_upto%limited s@$ n@5@00 limit@6@00))
  :qid |quant-u-50|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (> n@5@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
(assert (> limit@6@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (limit == 1 ? 1 : (divisible(n, limit) ? limit + sum_divisors_upto(n, limit - 1) : sum_divisors_upto(n, limit - 1)))
; [eval] limit == 1
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= limit@6@00 1))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= limit@6@00 1)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 3 | limit@6@00 == 1 | live]
; [else-branch: 3 | limit@6@00 != 1 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 3 | limit@6@00 == 1]
(assert (= limit@6@00 1))
(pop) ; 3
(push) ; 3
; [else-branch: 3 | limit@6@00 != 1]
(assert (not (= limit@6@00 1)))
; [eval] (divisible(n, limit) ? limit + sum_divisors_upto(n, limit - 1) : sum_divisors_upto(n, limit - 1))
; [eval] divisible(n, limit)
(push) ; 4
; [eval] d > 0
(assert (divisible%precondition $Snap.unit n@5@00 limit@6@00))
(pop) ; 4
; Joined path conditions
(assert (divisible%precondition $Snap.unit n@5@00 limit@6@00))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (divisible_ $Snap.unit n@5@00 limit@6@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (divisible_ $Snap.unit n@5@00 limit@6@00)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 4 | divisible(_, n@5@00, limit@6@00) | live]
; [else-branch: 4 | !(divisible(_, n@5@00, limit@6@00)) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 4 | divisible(_, n@5@00, limit@6@00)]
(assert (divisible_ $Snap.unit n@5@00 limit@6@00))
; [eval] limit + sum_divisors_upto(n, limit - 1)
; [eval] sum_divisors_upto(n, limit - 1)
; [eval] limit - 1
(push) ; 6
; [eval] n > 0
; [eval] limit > 0
(push) ; 7
(assert (not (> (- limit@6@00 1) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (> (- limit@6@00 1) 0))
(assert (sum_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@5@00 (-
  limit@6@00
  1)))
(pop) ; 6
; Joined path conditions
(assert (and
  (> (- limit@6@00 1) 0)
  (sum_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@5@00 (-
    limit@6@00
    1))))
(pop) ; 5
(push) ; 5
; [else-branch: 4 | !(divisible(_, n@5@00, limit@6@00))]
(assert (not (divisible_ $Snap.unit n@5@00 limit@6@00)))
; [eval] sum_divisors_upto(n, limit - 1)
; [eval] limit - 1
(push) ; 6
; [eval] n > 0
; [eval] limit > 0
(push) ; 7
(assert (not (> (- limit@6@00 1) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (> (- limit@6@00 1) 0))
(assert (sum_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@5@00 (-
  limit@6@00
  1)))
(pop) ; 6
; Joined path conditions
(assert (and
  (> (- limit@6@00 1) 0)
  (sum_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@5@00 (-
    limit@6@00
    1))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=>
  (divisible_ $Snap.unit n@5@00 limit@6@00)
  (and
    (divisible_ $Snap.unit n@5@00 limit@6@00)
    (> (- limit@6@00 1) 0)
    (sum_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@5@00 (-
      limit@6@00
      1)))))
; Joined path conditions
(assert (=>
  (not (divisible_ $Snap.unit n@5@00 limit@6@00))
  (and
    (not (divisible_ $Snap.unit n@5@00 limit@6@00))
    (> (- limit@6@00 1) 0)
    (sum_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@5@00 (-
      limit@6@00
      1)))))
(assert (or
  (not (divisible_ $Snap.unit n@5@00 limit@6@00))
  (divisible_ $Snap.unit n@5@00 limit@6@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= limit@6@00 1))
  (and
    (not (= limit@6@00 1))
    (divisible%precondition $Snap.unit n@5@00 limit@6@00)
    (=>
      (divisible_ $Snap.unit n@5@00 limit@6@00)
      (and
        (divisible_ $Snap.unit n@5@00 limit@6@00)
        (> (- limit@6@00 1) 0)
        (sum_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@5@00 (-
          limit@6@00
          1))))
    (=>
      (not (divisible_ $Snap.unit n@5@00 limit@6@00))
      (and
        (not (divisible_ $Snap.unit n@5@00 limit@6@00))
        (> (- limit@6@00 1) 0)
        (sum_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@5@00 (-
          limit@6@00
          1))))
    (or
      (not (divisible_ $Snap.unit n@5@00 limit@6@00))
      (divisible_ $Snap.unit n@5@00 limit@6@00)))))
(assert (or (not (= limit@6@00 1)) (= limit@6@00 1)))
(assert (=
  result@7@00
  (ite
    (= limit@6@00 1)
    1
    (ite
      (divisible_ $Snap.unit n@5@00 limit@6@00)
      (+
        limit@6@00
        (sum_divisors_upto ($Snap.combine $Snap.unit $Snap.unit) n@5@00 (-
          limit@6@00
          1)))
      (sum_divisors_upto ($Snap.combine $Snap.unit $Snap.unit) n@5@00 (-
        limit@6@00
        1))))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@7@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@7@00 0))
; [eval] limit == 1 ==> result == (divisible(n, 1) ? 1 : 0)
; [eval] limit == 1
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= limit@6@00 1))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= limit@6@00 1)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 5 | limit@6@00 == 1 | live]
; [else-branch: 5 | limit@6@00 != 1 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 5 | limit@6@00 == 1]
(assert (= limit@6@00 1))
; [eval] result == (divisible(n, 1) ? 1 : 0)
; [eval] (divisible(n, 1) ? 1 : 0)
; [eval] divisible(n, 1)
(push) ; 4
; [eval] d > 0
(assert (divisible%precondition $Snap.unit n@5@00 1))
(pop) ; 4
; Joined path conditions
(assert (divisible%precondition $Snap.unit n@5@00 1))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (divisible_ $Snap.unit n@5@00 1))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (divisible_ $Snap.unit n@5@00 1)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 6 | divisible(_, n@5@00, 1) | live]
; [else-branch: 6 | !(divisible(_, n@5@00, 1)) | dead]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 6 | divisible(_, n@5@00, 1)]
(assert (divisible_ $Snap.unit n@5@00 1))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (divisible_ $Snap.unit n@5@00 1))
(pop) ; 3
(push) ; 3
; [else-branch: 5 | limit@6@00 != 1]
(assert (not (= limit@6@00 1)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
(assert (=>
  (= limit@6@00 1)
  (and
    (= limit@6@00 1)
    (divisible%precondition $Snap.unit n@5@00 1)
    (divisible_ $Snap.unit n@5@00 1))))
; Joined path conditions
(push) ; 2
(assert (not (=> (= limit@6@00 1) (= result@7@00 1))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=> (= limit@6@00 1) (= result@7@00 1)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@5@00 Int) (limit@6@00 Int)) (!
  (=>
    (sum_divisors_upto%precondition s@$ n@5@00 limit@6@00)
    (=
      (sum_divisors_upto s@$ n@5@00 limit@6@00)
      (ite
        (= limit@6@00 1)
        1
        (ite
          (divisible_ $Snap.unit n@5@00 limit@6@00)
          (+
            limit@6@00
            (sum_divisors_upto%limited ($Snap.combine $Snap.unit $Snap.unit) n@5@00 (-
              limit@6@00
              1)))
          (sum_divisors_upto%limited ($Snap.combine $Snap.unit $Snap.unit) n@5@00 (-
            limit@6@00
            1))))))
  :pattern ((sum_divisors_upto s@$ n@5@00 limit@6@00))
  :qid |quant-u-51|)))
(assert (forall ((s@$ $Snap) (n@5@00 Int) (limit@6@00 Int)) (!
  (=>
    (sum_divisors_upto%precondition s@$ n@5@00 limit@6@00)
    (ite
      (= limit@6@00 1)
      true
      (and
        (divisible%precondition $Snap.unit n@5@00 limit@6@00)
        (sum_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@5@00 (-
          limit@6@00
          1)))))
  :pattern ((sum_divisors_upto s@$ n@5@00 limit@6@00))
  :qid |quant-u-52|)))
; ---------- FUNCTION is_palindrome_helper----------
(declare-fun n@8@00 () Int)
(declare-fun reversed@9@00 () Int)
(declare-fun original@10@00 () Int)
(declare-fun result@11@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] n >= 0
(assert (>= n@8@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
; [eval] reversed >= 0
(assert (>= reversed@9@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@8@00 Int) (reversed@9@00 Int) (original@10@00 Int)) (!
  (=
    (is_palindrome_helper%limited s@$ n@8@00 reversed@9@00 original@10@00)
    (is_palindrome_helper s@$ n@8@00 reversed@9@00 original@10@00))
  :pattern ((is_palindrome_helper s@$ n@8@00 reversed@9@00 original@10@00))
  :qid |quant-u-6|)))
(assert (forall ((s@$ $Snap) (n@8@00 Int) (reversed@9@00 Int) (original@10@00 Int)) (!
  (is_palindrome_helper%stateless n@8@00 reversed@9@00 original@10@00)
  :pattern ((is_palindrome_helper%limited s@$ n@8@00 reversed@9@00 original@10@00))
  :qid |quant-u-7|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (>= n@8@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
(assert (>= reversed@9@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (n == 0 ? reversed == original : is_palindrome_helper(n \ 10, reversed * 10 + n % 10, original))
; [eval] n == 0
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= n@8@00 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= n@8@00 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 7 | n@8@00 == 0 | live]
; [else-branch: 7 | n@8@00 != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 7 | n@8@00 == 0]
(assert (= n@8@00 0))
; [eval] reversed == original
(pop) ; 3
(push) ; 3
; [else-branch: 7 | n@8@00 != 0]
(assert (not (= n@8@00 0)))
; [eval] is_palindrome_helper(n \ 10, reversed * 10 + n % 10, original)
; [eval] n \ 10
; [eval] reversed * 10 + n % 10
; [eval] reversed * 10
; [eval] n % 10
(push) ; 4
; [eval] n >= 0
(push) ; 5
(assert (not (>= (div n@8@00 10) 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (>= (div n@8@00 10) 0))
; [eval] reversed >= 0
(push) ; 5
(assert (not (>= (+ (* reversed@9@00 10) (mod n@8@00 10)) 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (>= (+ (* reversed@9@00 10) (mod n@8@00 10)) 0))
(assert (is_palindrome_helper%precondition ($Snap.combine $Snap.unit $Snap.unit) (div
  n@8@00
  10) (+ (* reversed@9@00 10) (mod n@8@00 10)) original@10@00))
(pop) ; 4
; Joined path conditions
(assert (and
  (>= (div n@8@00 10) 0)
  (>= (+ (* reversed@9@00 10) (mod n@8@00 10)) 0)
  (is_palindrome_helper%precondition ($Snap.combine $Snap.unit $Snap.unit) (div
    n@8@00
    10) (+ (* reversed@9@00 10) (mod n@8@00 10)) original@10@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= n@8@00 0))
  (and
    (not (= n@8@00 0))
    (>= (div n@8@00 10) 0)
    (>= (+ (* reversed@9@00 10) (mod n@8@00 10)) 0)
    (is_palindrome_helper%precondition ($Snap.combine $Snap.unit $Snap.unit) (div
      n@8@00
      10) (+ (* reversed@9@00 10) (mod n@8@00 10)) original@10@00))))
(assert (or (not (= n@8@00 0)) (= n@8@00 0)))
(assert (=
  result@11@00
  (ite
    (= n@8@00 0)
    (= reversed@9@00 original@10@00)
    (is_palindrome_helper ($Snap.combine $Snap.unit $Snap.unit) (div n@8@00 10) (+
      (* reversed@9@00 10)
      (mod n@8@00 10)) original@10@00))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@8@00 Int) (reversed@9@00 Int) (original@10@00 Int)) (!
  (=>
    (is_palindrome_helper%precondition s@$ n@8@00 reversed@9@00 original@10@00)
    (=
      (is_palindrome_helper s@$ n@8@00 reversed@9@00 original@10@00)
      (ite
        (= n@8@00 0)
        (= reversed@9@00 original@10@00)
        (is_palindrome_helper%limited ($Snap.combine $Snap.unit $Snap.unit) (div
          n@8@00
          10) (+ (* reversed@9@00 10) (mod n@8@00 10)) original@10@00))))
  :pattern ((is_palindrome_helper s@$ n@8@00 reversed@9@00 original@10@00))
  :qid |quant-u-53|)))
(assert (forall ((s@$ $Snap) (n@8@00 Int) (reversed@9@00 Int) (original@10@00 Int)) (!
  (=>
    (is_palindrome_helper%precondition s@$ n@8@00 reversed@9@00 original@10@00)
    (ite
      (= n@8@00 0)
      true
      (is_palindrome_helper%precondition ($Snap.combine $Snap.unit $Snap.unit) (div
        n@8@00
        10) (+ (* reversed@9@00 10) (mod n@8@00 10)) original@10@00)))
  :pattern ((is_palindrome_helper s@$ n@8@00 reversed@9@00 original@10@00))
  :qid |quant-u-54|)))
; ---------- FUNCTION gcd----------
(declare-fun a@12@00 () Int)
(declare-fun b@13@00 () Int)
(declare-fun result@14@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] a > 0
(assert (> a@12@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
; [eval] b > 0
(assert (> b@13@00 0))
(declare-const $t@62@00 $Snap)
(assert (= $t@62@00 ($Snap.combine ($Snap.first $t@62@00) ($Snap.second $t@62@00))))
(assert (= ($Snap.first $t@62@00) $Snap.unit))
; [eval] result > 0
(assert (> result@14@00 0))
(assert (=
  ($Snap.second $t@62@00)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@62@00))
    ($Snap.second ($Snap.second $t@62@00)))))
(assert (= ($Snap.first ($Snap.second $t@62@00)) $Snap.unit))
; [eval] result <= a
(assert (<= result@14@00 a@12@00))
(assert (= ($Snap.second ($Snap.second $t@62@00)) $Snap.unit))
; [eval] result <= b
(assert (<= result@14@00 b@13@00))
(pop) ; 1
(assert (forall ((s@$ $Snap) (a@12@00 Int) (b@13@00 Int)) (!
  (= (gcd%limited s@$ a@12@00 b@13@00) (gcd s@$ a@12@00 b@13@00))
  :pattern ((gcd s@$ a@12@00 b@13@00))
  :qid |quant-u-8|)))
(assert (forall ((s@$ $Snap) (a@12@00 Int) (b@13@00 Int)) (!
  (gcd%stateless a@12@00 b@13@00)
  :pattern ((gcd%limited s@$ a@12@00 b@13@00))
  :qid |quant-u-9|)))
(assert (forall ((s@$ $Snap) (a@12@00 Int) (b@13@00 Int)) (!
  (let ((result@14@00 (gcd%limited s@$ a@12@00 b@13@00))) (=>
    (gcd%precondition s@$ a@12@00 b@13@00)
    (and
      (> result@14@00 0)
      (and (<= result@14@00 a@12@00) (<= result@14@00 b@13@00)))))
  :pattern ((gcd%limited s@$ a@12@00 b@13@00))
  :qid |quant-u-55|)))
(assert (forall ((s@$ $Snap) (a@12@00 Int) (b@13@00 Int)) (!
  (let ((result@14@00 (gcd%limited s@$ a@12@00 b@13@00))) true)
  :pattern ((gcd%limited s@$ a@12@00 b@13@00))
  :qid |quant-u-56|)))
(assert (forall ((s@$ $Snap) (a@12@00 Int) (b@13@00 Int)) (!
  (let ((result@14@00 (gcd%limited s@$ a@12@00 b@13@00))) true)
  :pattern ((gcd%limited s@$ a@12@00 b@13@00))
  :qid |quant-u-57|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (> a@12@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
(assert (> b@13@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (b == 0 ? a : gcd(b, a % b))
; [eval] b == 0
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= b@13@00 0))))
(check-sat)
; unsat
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 8 | b@13@00 == 0 | dead]
; [else-branch: 8 | b@13@00 != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [else-branch: 8 | b@13@00 != 0]
(assert (not (= b@13@00 0)))
; [eval] gcd(b, a % b)
; [eval] a % b
(push) ; 4
; [eval] a > 0
; [eval] b > 0
(push) ; 5
(assert (not (> (mod a@12@00 b@13@00) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] b > 0
(set-option :rlimit 0)
(push) ; 5
(assert (not (> (mod a@12@00 b@13@00) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] b > 0
(set-option :rlimit 0)
(push) ; 5
(assert (not (> (mod a@12@00 b@13@00) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] b > 0
(set-option :rlimit 0)
(push) ; 5
(assert (not (> (mod a@12@00 b@13@00) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(pop) ; 4
(pop) ; 3
(pop) ; 2
(pop) ; 1
; ---------- FUNCTION has_divisor_between----------
(declare-fun n@15@00 () Int)
(declare-fun lower@16@00 () Int)
(declare-fun upper@17@00 () Int)
(declare-fun result@18@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] n > 0
(assert (> n@15@00 0))
(assert (=
  ($Snap.second s@$)
  ($Snap.combine
    ($Snap.first ($Snap.second s@$))
    ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.first ($Snap.second s@$)) $Snap.unit))
; [eval] lower > 0
(assert (> lower@16@00 0))
(assert (= ($Snap.second ($Snap.second s@$)) $Snap.unit))
; [eval] lower <= upper + 1
; [eval] upper + 1
(assert (<= lower@16@00 (+ upper@17@00 1)))
(declare-const $t@63@00 $Snap)
(assert (= $t@63@00 $Snap.unit))
; [eval] lower > upper ==> !result
; [eval] lower > upper
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (> lower@16@00 upper@17@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (> lower@16@00 upper@17@00)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 9 | lower@16@00 > upper@17@00 | live]
; [else-branch: 9 | !(lower@16@00 > upper@17@00) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 9 | lower@16@00 > upper@17@00]
(assert (> lower@16@00 upper@17@00))
; [eval] !result
(pop) ; 3
(push) ; 3
; [else-branch: 9 | !(lower@16@00 > upper@17@00)]
(assert (not (> lower@16@00 upper@17@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (> lower@16@00 upper@17@00)) (> lower@16@00 upper@17@00)))
(assert (=> (> lower@16@00 upper@17@00) (not result@18@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@15@00 Int) (lower@16@00 Int) (upper@17@00 Int)) (!
  (=
    (has_divisor_between%limited s@$ n@15@00 lower@16@00 upper@17@00)
    (has_divisor_between s@$ n@15@00 lower@16@00 upper@17@00))
  :pattern ((has_divisor_between s@$ n@15@00 lower@16@00 upper@17@00))
  :qid |quant-u-10|)))
(assert (forall ((s@$ $Snap) (n@15@00 Int) (lower@16@00 Int) (upper@17@00 Int)) (!
  (has_divisor_between%stateless n@15@00 lower@16@00 upper@17@00)
  :pattern ((has_divisor_between%limited s@$ n@15@00 lower@16@00 upper@17@00))
  :qid |quant-u-11|)))
(assert (forall ((s@$ $Snap) (n@15@00 Int) (lower@16@00 Int) (upper@17@00 Int)) (!
  (let ((result@18@00 (has_divisor_between%limited s@$ n@15@00 lower@16@00 upper@17@00))) (=>
    (and
      (has_divisor_between%precondition s@$ n@15@00 lower@16@00 upper@17@00)
      (> lower@16@00 upper@17@00))
    (not result@18@00)))
  :pattern ((has_divisor_between%limited s@$ n@15@00 lower@16@00 upper@17@00))
  :qid |quant-u-58|)))
(assert (forall ((s@$ $Snap) (n@15@00 Int) (lower@16@00 Int) (upper@17@00 Int)) (!
  (let ((result@18@00 (has_divisor_between%limited s@$ n@15@00 lower@16@00 upper@17@00))) true)
  :pattern ((has_divisor_between%limited s@$ n@15@00 lower@16@00 upper@17@00))
  :qid |quant-u-59|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (> n@15@00 0))
(assert (=
  ($Snap.second s@$)
  ($Snap.combine
    ($Snap.first ($Snap.second s@$))
    ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.first ($Snap.second s@$)) $Snap.unit))
(assert (> lower@16@00 0))
(assert (= ($Snap.second ($Snap.second s@$)) $Snap.unit))
(assert (<= lower@16@00 (+ upper@17@00 1)))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (lower > upper ? false : divisible(n, lower) || has_divisor_between(n, lower + 1, upper))
; [eval] lower > upper
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (> lower@16@00 upper@17@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (> lower@16@00 upper@17@00)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 10 | lower@16@00 > upper@17@00 | live]
; [else-branch: 10 | !(lower@16@00 > upper@17@00) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 10 | lower@16@00 > upper@17@00]
(assert (> lower@16@00 upper@17@00))
(pop) ; 3
(push) ; 3
; [else-branch: 10 | !(lower@16@00 > upper@17@00)]
(assert (not (> lower@16@00 upper@17@00)))
; [eval] divisible(n, lower) || has_divisor_between(n, lower + 1, upper)
; [eval] divisible(n, lower)
(push) ; 4
; [eval] d > 0
(assert (divisible%precondition $Snap.unit n@15@00 lower@16@00))
(pop) ; 4
; Joined path conditions
(assert (divisible%precondition $Snap.unit n@15@00 lower@16@00))
(push) ; 4
; [then-branch: 11 | divisible(_, n@15@00, lower@16@00) | live]
; [else-branch: 11 | !(divisible(_, n@15@00, lower@16@00)) | live]
(push) ; 5
; [then-branch: 11 | divisible(_, n@15@00, lower@16@00)]
(assert (divisible_ $Snap.unit n@15@00 lower@16@00))
(pop) ; 5
(push) ; 5
; [else-branch: 11 | !(divisible(_, n@15@00, lower@16@00))]
(assert (not (divisible_ $Snap.unit n@15@00 lower@16@00)))
; [eval] has_divisor_between(n, lower + 1, upper)
; [eval] lower + 1
(push) ; 6
; [eval] n > 0
; [eval] lower > 0
(push) ; 7
(assert (not (> (+ lower@16@00 1) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (> (+ lower@16@00 1) 0))
; [eval] lower <= upper + 1
; [eval] upper + 1
(push) ; 7
(assert (not (<= (+ lower@16@00 1) (+ upper@17@00 1))))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (<= (+ lower@16@00 1) (+ upper@17@00 1)))
(assert (has_divisor_between%precondition ($Snap.combine
  $Snap.unit
  ($Snap.combine $Snap.unit $Snap.unit)) n@15@00 (+ lower@16@00 1) upper@17@00))
(pop) ; 6
; Joined path conditions
(assert (and
  (> (+ lower@16@00 1) 0)
  (<= (+ lower@16@00 1) (+ upper@17@00 1))
  (has_divisor_between%precondition ($Snap.combine
    $Snap.unit
    ($Snap.combine $Snap.unit $Snap.unit)) n@15@00 (+ lower@16@00 1) upper@17@00)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (divisible_ $Snap.unit n@15@00 lower@16@00))
  (and
    (not (divisible_ $Snap.unit n@15@00 lower@16@00))
    (> (+ lower@16@00 1) 0)
    (<= (+ lower@16@00 1) (+ upper@17@00 1))
    (has_divisor_between%precondition ($Snap.combine
      $Snap.unit
      ($Snap.combine $Snap.unit $Snap.unit)) n@15@00 (+ lower@16@00 1) upper@17@00))))
(assert (or
  (not (divisible_ $Snap.unit n@15@00 lower@16@00))
  (divisible_ $Snap.unit n@15@00 lower@16@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (> lower@16@00 upper@17@00))
  (and
    (not (> lower@16@00 upper@17@00))
    (divisible%precondition $Snap.unit n@15@00 lower@16@00)
    (=>
      (not (divisible_ $Snap.unit n@15@00 lower@16@00))
      (and
        (not (divisible_ $Snap.unit n@15@00 lower@16@00))
        (> (+ lower@16@00 1) 0)
        (<= (+ lower@16@00 1) (+ upper@17@00 1))
        (has_divisor_between%precondition ($Snap.combine
          $Snap.unit
          ($Snap.combine $Snap.unit $Snap.unit)) n@15@00 (+ lower@16@00 1) upper@17@00)))
    (or
      (not (divisible_ $Snap.unit n@15@00 lower@16@00))
      (divisible_ $Snap.unit n@15@00 lower@16@00)))))
(assert (or (not (> lower@16@00 upper@17@00)) (> lower@16@00 upper@17@00)))
(assert (=
  result@18@00
  (ite
    (> lower@16@00 upper@17@00)
    false
    (or
      (divisible_ $Snap.unit n@15@00 lower@16@00)
      (has_divisor_between ($Snap.combine
        $Snap.unit
        ($Snap.combine $Snap.unit $Snap.unit)) n@15@00 (+ lower@16@00 1) upper@17@00)))))
; [eval] lower > upper ==> !result
; [eval] lower > upper
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (> lower@16@00 upper@17@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (> lower@16@00 upper@17@00)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 12 | lower@16@00 > upper@17@00 | live]
; [else-branch: 12 | !(lower@16@00 > upper@17@00) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 12 | lower@16@00 > upper@17@00]
(assert (> lower@16@00 upper@17@00))
; [eval] !result
(pop) ; 3
(push) ; 3
; [else-branch: 12 | !(lower@16@00 > upper@17@00)]
(assert (not (> lower@16@00 upper@17@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(push) ; 2
(assert (not (=> (> lower@16@00 upper@17@00) (not result@18@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=> (> lower@16@00 upper@17@00) (not result@18@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@15@00 Int) (lower@16@00 Int) (upper@17@00 Int)) (!
  (=>
    (has_divisor_between%precondition s@$ n@15@00 lower@16@00 upper@17@00)
    (=
      (has_divisor_between s@$ n@15@00 lower@16@00 upper@17@00)
      (ite
        (> lower@16@00 upper@17@00)
        false
        (or
          (divisible_ $Snap.unit n@15@00 lower@16@00)
          (has_divisor_between%limited ($Snap.combine
            $Snap.unit
            ($Snap.combine $Snap.unit $Snap.unit)) n@15@00 (+ lower@16@00 1) upper@17@00)))))
  :pattern ((has_divisor_between s@$ n@15@00 lower@16@00 upper@17@00))
  :qid |quant-u-60|)))
(assert (forall ((s@$ $Snap) (n@15@00 Int) (lower@16@00 Int) (upper@17@00 Int)) (!
  (=>
    (has_divisor_between%precondition s@$ n@15@00 lower@16@00 upper@17@00)
    (ite
      (> lower@16@00 upper@17@00)
      true
      (and
        (divisible%precondition $Snap.unit n@15@00 lower@16@00)
        (=>
          (not (divisible_ $Snap.unit n@15@00 lower@16@00))
          (has_divisor_between%precondition ($Snap.combine
            $Snap.unit
            ($Snap.combine $Snap.unit $Snap.unit)) n@15@00 (+ lower@16@00 1) upper@17@00)))))
  :pattern ((has_divisor_between s@$ n@15@00 lower@16@00 upper@17@00))
  :qid |quant-u-61|)))
; ---------- FUNCTION triangular----------
(declare-fun n@19@00 () Int)
(declare-fun result@20@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] n >= 0
(assert (>= n@19@00 0))
(declare-const $t@64@00 $Snap)
(assert (= $t@64@00 ($Snap.combine ($Snap.first $t@64@00) ($Snap.second $t@64@00))))
(assert (= ($Snap.first $t@64@00) $Snap.unit))
; [eval] result >= 0
(assert (>= result@20@00 0))
(assert (= ($Snap.second $t@64@00) $Snap.unit))
; [eval] result == n * (n + 1) \ 2
; [eval] n * (n + 1) \ 2
; [eval] n * (n + 1)
; [eval] n + 1
(assert (= result@20@00 (div (* n@19@00 (+ n@19@00 1)) 2)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@19@00 Int)) (!
  (= (triangular%limited s@$ n@19@00) (triangular s@$ n@19@00))
  :pattern ((triangular s@$ n@19@00))
  :qid |quant-u-12|)))
(assert (forall ((s@$ $Snap) (n@19@00 Int)) (!
  (triangular%stateless n@19@00)
  :pattern ((triangular%limited s@$ n@19@00))
  :qid |quant-u-13|)))
(assert (forall ((s@$ $Snap) (n@19@00 Int)) (!
  (let ((result@20@00 (triangular%limited s@$ n@19@00))) (=>
    (triangular%precondition s@$ n@19@00)
    (and (>= result@20@00 0) (= result@20@00 (div (* n@19@00 (+ n@19@00 1)) 2)))))
  :pattern ((triangular%limited s@$ n@19@00))
  :qid |quant-u-62|)))
(assert (forall ((s@$ $Snap) (n@19@00 Int)) (!
  (let ((result@20@00 (triangular%limited s@$ n@19@00))) true)
  :pattern ((triangular%limited s@$ n@19@00))
  :qid |quant-u-63|)))
(assert (forall ((s@$ $Snap) (n@19@00 Int)) (!
  (let ((result@20@00 (triangular%limited s@$ n@19@00))) true)
  :pattern ((triangular%limited s@$ n@19@00))
  :qid |quant-u-64|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (>= n@19@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (n == 0 ? 0 : n + triangular(n - 1))
; [eval] n == 0
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= n@19@00 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= n@19@00 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 13 | n@19@00 == 0 | live]
; [else-branch: 13 | n@19@00 != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 13 | n@19@00 == 0]
(assert (= n@19@00 0))
(pop) ; 3
(push) ; 3
; [else-branch: 13 | n@19@00 != 0]
(assert (not (= n@19@00 0)))
; [eval] n + triangular(n - 1)
; [eval] triangular(n - 1)
; [eval] n - 1
(push) ; 4
; [eval] n >= 0
(push) ; 5
(assert (not (>= (- n@19@00 1) 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (>= (- n@19@00 1) 0))
(assert (triangular%precondition $Snap.unit (- n@19@00 1)))
(pop) ; 4
; Joined path conditions
(assert (and (>= (- n@19@00 1) 0) (triangular%precondition $Snap.unit (- n@19@00 1))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= n@19@00 0))
  (and
    (not (= n@19@00 0))
    (>= (- n@19@00 1) 0)
    (triangular%precondition $Snap.unit (- n@19@00 1)))))
(assert (or (not (= n@19@00 0)) (= n@19@00 0)))
(assert (=
  result@20@00
  (ite (= n@19@00 0) 0 (+ n@19@00 (triangular $Snap.unit (- n@19@00 1))))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@20@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@20@00 0))
; [eval] result == n * (n + 1) \ 2
; [eval] n * (n + 1) \ 2
; [eval] n * (n + 1)
; [eval] n + 1
(push) ; 2
(assert (not (= result@20@00 (div (* n@19@00 (+ n@19@00 1)) 2))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (= result@20@00 (div (* n@19@00 (+ n@19@00 1)) 2)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@19@00 Int)) (!
  (=>
    (triangular%precondition s@$ n@19@00)
    (=
      (triangular s@$ n@19@00)
      (ite
        (= n@19@00 0)
        0
        (+ n@19@00 (triangular%limited $Snap.unit (- n@19@00 1))))))
  :pattern ((triangular s@$ n@19@00))
  :qid |quant-u-65|)))
(assert (forall ((s@$ $Snap) (n@19@00 Int)) (!
  (=>
    (triangular%precondition s@$ n@19@00)
    (ite (= n@19@00 0) true (triangular%precondition $Snap.unit (- n@19@00 1))))
  :pattern ((triangular s@$ n@19@00))
  :qid |quant-u-66|)))
; ---------- FUNCTION is_triangular----------
(declare-fun n@21@00 () Int)
(declare-fun k@22@00 () Int)
(declare-fun result@23@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] n >= 0
(assert (>= n@21@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
; [eval] k >= 0
(assert (>= k@22@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@21@00 Int) (k@22@00 Int)) (!
  (=
    (is_triangular%limited s@$ n@21@00 k@22@00)
    (is_triangular s@$ n@21@00 k@22@00))
  :pattern ((is_triangular s@$ n@21@00 k@22@00))
  :qid |quant-u-14|)))
(assert (forall ((s@$ $Snap) (n@21@00 Int) (k@22@00 Int)) (!
  (is_triangular%stateless n@21@00 k@22@00)
  :pattern ((is_triangular%limited s@$ n@21@00 k@22@00))
  :qid |quant-u-15|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (>= n@21@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
(assert (>= k@22@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (k * (k + 1) \ 2 == n ? true : (k * (k + 1) \ 2 > n ? false : is_triangular(n, k + 1)))
; [eval] k * (k + 1) \ 2 == n
; [eval] k * (k + 1) \ 2
; [eval] k * (k + 1)
; [eval] k + 1
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 14 | k@22@00 * k@22@00 + 1 / 2 == n@21@00 | live]
; [else-branch: 14 | k@22@00 * k@22@00 + 1 / 2 != n@21@00 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 14 | k@22@00 * k@22@00 + 1 / 2 == n@21@00]
(assert (= (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00))
(pop) ; 3
(push) ; 3
; [else-branch: 14 | k@22@00 * k@22@00 + 1 / 2 != n@21@00]
(assert (not (= (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00)))
; [eval] (k * (k + 1) \ 2 > n ? false : is_triangular(n, k + 1))
; [eval] k * (k + 1) \ 2 > n
; [eval] k * (k + 1) \ 2
; [eval] k * (k + 1)
; [eval] k + 1
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (> (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (> (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 15 | k@22@00 * k@22@00 + 1 / 2 > n@21@00 | live]
; [else-branch: 15 | !(k@22@00 * k@22@00 + 1 / 2 > n@21@00) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 15 | k@22@00 * k@22@00 + 1 / 2 > n@21@00]
(assert (> (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00))
(pop) ; 5
(push) ; 5
; [else-branch: 15 | !(k@22@00 * k@22@00 + 1 / 2 > n@21@00)]
(assert (not (> (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00)))
; [eval] is_triangular(n, k + 1)
; [eval] k + 1
(push) ; 6
; [eval] n >= 0
; [eval] k >= 0
(push) ; 7
(assert (not (>= (+ k@22@00 1) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (>= (+ k@22@00 1) 0))
(assert (is_triangular%precondition ($Snap.combine $Snap.unit $Snap.unit) n@21@00 (+
  k@22@00
  1)))
(pop) ; 6
; Joined path conditions
(assert (and
  (>= (+ k@22@00 1) 0)
  (is_triangular%precondition ($Snap.combine $Snap.unit $Snap.unit) n@21@00 (+
    k@22@00
    1))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (> (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00))
  (and
    (not (> (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00))
    (>= (+ k@22@00 1) 0)
    (is_triangular%precondition ($Snap.combine $Snap.unit $Snap.unit) n@21@00 (+
      k@22@00
      1)))))
(assert (or
  (not (> (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00))
  (> (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00))
  (and
    (not (= (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00))
    (=>
      (not (> (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00))
      (and
        (not (> (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00))
        (>= (+ k@22@00 1) 0)
        (is_triangular%precondition ($Snap.combine $Snap.unit $Snap.unit) n@21@00 (+
          k@22@00
          1))))
    (or
      (not (> (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00))
      (> (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00)))))
(assert (or
  (not (= (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00))
  (= (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00)))
(assert (=
  result@23@00
  (ite
    (= (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00)
    true
    (ite
      (> (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00)
      false
      (is_triangular ($Snap.combine $Snap.unit $Snap.unit) n@21@00 (+ k@22@00 1))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@21@00 Int) (k@22@00 Int)) (!
  (=>
    (is_triangular%precondition s@$ n@21@00 k@22@00)
    (=
      (is_triangular s@$ n@21@00 k@22@00)
      (ite
        (= (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00)
        true
        (ite
          (> (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00)
          false
          (is_triangular%limited ($Snap.combine $Snap.unit $Snap.unit) n@21@00 (+
            k@22@00
            1))))))
  :pattern ((is_triangular s@$ n@21@00 k@22@00))
  :qid |quant-u-67|)))
(assert (forall ((s@$ $Snap) (n@21@00 Int) (k@22@00 Int)) (!
  (=>
    (is_triangular%precondition s@$ n@21@00 k@22@00)
    (ite
      (= (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00)
      true
      (ite
        (> (div (* k@22@00 (+ k@22@00 1)) 2) n@21@00)
        true
        (is_triangular%precondition ($Snap.combine $Snap.unit $Snap.unit) n@21@00 (+
          k@22@00
          1)))))
  :pattern ((is_triangular s@$ n@21@00 k@22@00))
  :qid |quant-u-68|)))
; ---------- FUNCTION digital_root----------
(declare-fun n@24@00 () Int)
(declare-fun depth@25@00 () Int)
(declare-fun result@26@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] n >= 0
(assert (>= n@24@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
; [eval] depth >= 0
(assert (>= depth@25@00 0))
(declare-const $t@65@00 $Snap)
(assert (= $t@65@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@26@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@24@00 Int) (depth@25@00 Int)) (!
  (=
    (digital_root%limited s@$ n@24@00 depth@25@00)
    (digital_root s@$ n@24@00 depth@25@00))
  :pattern ((digital_root s@$ n@24@00 depth@25@00))
  :qid |quant-u-16|)))
(assert (forall ((s@$ $Snap) (n@24@00 Int) (depth@25@00 Int)) (!
  (digital_root%stateless n@24@00 depth@25@00)
  :pattern ((digital_root%limited s@$ n@24@00 depth@25@00))
  :qid |quant-u-17|)))
(assert (forall ((s@$ $Snap) (n@24@00 Int) (depth@25@00 Int)) (!
  (let ((result@26@00 (digital_root%limited s@$ n@24@00 depth@25@00))) (=>
    (digital_root%precondition s@$ n@24@00 depth@25@00)
    (>= result@26@00 0)))
  :pattern ((digital_root%limited s@$ n@24@00 depth@25@00))
  :qid |quant-u-69|)))
(assert (forall ((s@$ $Snap) (n@24@00 Int) (depth@25@00 Int)) (!
  (let ((result@26@00 (digital_root%limited s@$ n@24@00 depth@25@00))) true)
  :pattern ((digital_root%limited s@$ n@24@00 depth@25@00))
  :qid |quant-u-70|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (>= n@24@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
(assert (>= depth@25@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (depth == 0 ? n : (n < 10 ? n : digital_root(digit_sum(n), depth - 1)))
; [eval] depth == 0
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= depth@25@00 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= depth@25@00 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 16 | depth@25@00 == 0 | live]
; [else-branch: 16 | depth@25@00 != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 16 | depth@25@00 == 0]
(assert (= depth@25@00 0))
(pop) ; 3
(push) ; 3
; [else-branch: 16 | depth@25@00 != 0]
(assert (not (= depth@25@00 0)))
; [eval] (n < 10 ? n : digital_root(digit_sum(n), depth - 1))
; [eval] n < 10
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (< n@24@00 10))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (< n@24@00 10)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 17 | n@24@00 < 10 | live]
; [else-branch: 17 | !(n@24@00 < 10) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 17 | n@24@00 < 10]
(assert (< n@24@00 10))
(pop) ; 5
(push) ; 5
; [else-branch: 17 | !(n@24@00 < 10)]
(assert (not (< n@24@00 10)))
; [eval] digital_root(digit_sum(n), depth - 1)
; [eval] digit_sum(n)
(push) ; 6
; [eval] n >= 0
(assert (digit_sum%precondition $Snap.unit n@24@00))
(pop) ; 6
; Joined path conditions
(assert (digit_sum%precondition $Snap.unit n@24@00))
; [eval] depth - 1
(push) ; 6
; [eval] n >= 0
(push) ; 7
(assert (not (>= (digit_sum $Snap.unit n@24@00) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (>= (digit_sum $Snap.unit n@24@00) 0))
; [eval] depth >= 0
(push) ; 7
(assert (not (>= (- depth@25@00 1) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (>= (- depth@25@00 1) 0))
(assert (digital_root%precondition ($Snap.combine $Snap.unit $Snap.unit) (digit_sum $Snap.unit n@24@00) (-
  depth@25@00
  1)))
(pop) ; 6
; Joined path conditions
(assert (and
  (>= (digit_sum $Snap.unit n@24@00) 0)
  (>= (- depth@25@00 1) 0)
  (digital_root%precondition ($Snap.combine $Snap.unit $Snap.unit) (digit_sum $Snap.unit n@24@00) (-
    depth@25@00
    1))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (< n@24@00 10))
  (and
    (not (< n@24@00 10))
    (digit_sum%precondition $Snap.unit n@24@00)
    (>= (digit_sum $Snap.unit n@24@00) 0)
    (>= (- depth@25@00 1) 0)
    (digital_root%precondition ($Snap.combine $Snap.unit $Snap.unit) (digit_sum $Snap.unit n@24@00) (-
      depth@25@00
      1)))))
(assert (or (not (< n@24@00 10)) (< n@24@00 10)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= depth@25@00 0))
  (and
    (not (= depth@25@00 0))
    (=>
      (not (< n@24@00 10))
      (and
        (not (< n@24@00 10))
        (digit_sum%precondition $Snap.unit n@24@00)
        (>= (digit_sum $Snap.unit n@24@00) 0)
        (>= (- depth@25@00 1) 0)
        (digital_root%precondition ($Snap.combine $Snap.unit $Snap.unit) (digit_sum $Snap.unit n@24@00) (-
          depth@25@00
          1))))
    (or (not (< n@24@00 10)) (< n@24@00 10)))))
(assert (or (not (= depth@25@00 0)) (= depth@25@00 0)))
(assert (=
  result@26@00
  (ite
    (= depth@25@00 0)
    n@24@00
    (ite
      (< n@24@00 10)
      n@24@00
      (digital_root ($Snap.combine $Snap.unit $Snap.unit) (digit_sum $Snap.unit n@24@00) (-
        depth@25@00
        1))))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@26@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@26@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@24@00 Int) (depth@25@00 Int)) (!
  (=>
    (digital_root%precondition s@$ n@24@00 depth@25@00)
    (=
      (digital_root s@$ n@24@00 depth@25@00)
      (ite
        (= depth@25@00 0)
        n@24@00
        (ite
          (< n@24@00 10)
          n@24@00
          (digital_root%limited ($Snap.combine $Snap.unit $Snap.unit) (digit_sum $Snap.unit n@24@00) (-
            depth@25@00
            1))))))
  :pattern ((digital_root s@$ n@24@00 depth@25@00))
  :qid |quant-u-71|)))
(assert (forall ((s@$ $Snap) (n@24@00 Int) (depth@25@00 Int)) (!
  (=>
    (digital_root%precondition s@$ n@24@00 depth@25@00)
    (ite
      (= depth@25@00 0)
      true
      (ite
        (< n@24@00 10)
        true
        (and
          (digit_sum%precondition $Snap.unit n@24@00)
          (digital_root%precondition ($Snap.combine $Snap.unit $Snap.unit) (digit_sum $Snap.unit n@24@00) (-
            depth@25@00
            1))))))
  :pattern ((digital_root s@$ n@24@00 depth@25@00))
  :qid |quant-u-72|)))
; ---------- FUNCTION is_perfect----------
(declare-fun n@27@00 () Int)
(declare-fun result@28@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] n > 1
(assert (> n@27@00 1))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@27@00 Int)) (!
  (= (is_perfect%limited s@$ n@27@00) (is_perfect s@$ n@27@00))
  :pattern ((is_perfect s@$ n@27@00))
  :qid |quant-u-18|)))
(assert (forall ((s@$ $Snap) (n@27@00 Int)) (!
  (is_perfect%stateless n@27@00)
  :pattern ((is_perfect%limited s@$ n@27@00))
  :qid |quant-u-19|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (> n@27@00 1))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] sum_divisors_upto(n, n - 1) == n
; [eval] sum_divisors_upto(n, n - 1)
; [eval] n - 1
(set-option :rlimit 0)
(push) ; 2
; [eval] n > 0
(push) ; 3
(assert (not (> n@27@00 0)))
(check-sat)
; unsat
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(assert (> n@27@00 0))
; [eval] limit > 0
(push) ; 3
(assert (not (> (- n@27@00 1) 0)))
(check-sat)
; unsat
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(assert (> (- n@27@00 1) 0))
(assert (sum_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@27@00 (-
  n@27@00
  1)))
(pop) ; 2
; Joined path conditions
(assert (and
  (> n@27@00 0)
  (> (- n@27@00 1) 0)
  (sum_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@27@00 (-
    n@27@00
    1))))
(assert (=
  result@28@00
  (=
    (sum_divisors_upto ($Snap.combine $Snap.unit $Snap.unit) n@27@00 (-
      n@27@00
      1))
    n@27@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@27@00 Int)) (!
  (=>
    (is_perfect%precondition s@$ n@27@00)
    (=
      (is_perfect s@$ n@27@00)
      (=
        (sum_divisors_upto ($Snap.combine $Snap.unit $Snap.unit) n@27@00 (-
          n@27@00
          1))
        n@27@00)))
  :pattern ((is_perfect s@$ n@27@00))
  :qid |quant-u-73|)))
(assert (forall ((s@$ $Snap) (n@27@00 Int)) (!
  (=>
    (is_perfect%precondition s@$ n@27@00)
    (sum_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@27@00 (-
      n@27@00
      1)))
  :pattern ((is_perfect s@$ n@27@00))
  :qid |quant-u-74|)))
; ---------- FUNCTION is_palindrome----------
(declare-fun n@29@00 () Int)
(declare-fun result@30@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] n >= 0
(assert (>= n@29@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@29@00 Int)) (!
  (= (is_palindrome%limited s@$ n@29@00) (is_palindrome s@$ n@29@00))
  :pattern ((is_palindrome s@$ n@29@00))
  :qid |quant-u-20|)))
(assert (forall ((s@$ $Snap) (n@29@00 Int)) (!
  (is_palindrome%stateless n@29@00)
  :pattern ((is_palindrome%limited s@$ n@29@00))
  :qid |quant-u-21|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (>= n@29@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] is_palindrome_helper(n, 0, n)
(set-option :rlimit 0)
(push) ; 2
; [eval] n >= 0
; [eval] reversed >= 0
(assert (is_palindrome_helper%precondition ($Snap.combine $Snap.unit $Snap.unit) n@29@00 0 n@29@00))
(pop) ; 2
; Joined path conditions
(assert (is_palindrome_helper%precondition ($Snap.combine $Snap.unit $Snap.unit) n@29@00 0 n@29@00))
(assert (=
  result@30@00
  (is_palindrome_helper ($Snap.combine $Snap.unit $Snap.unit) n@29@00 0 n@29@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@29@00 Int)) (!
  (=>
    (is_palindrome%precondition s@$ n@29@00)
    (=
      (is_palindrome s@$ n@29@00)
      (is_palindrome_helper ($Snap.combine $Snap.unit $Snap.unit) n@29@00 0 n@29@00)))
  :pattern ((is_palindrome s@$ n@29@00))
  :qid |quant-u-75|)))
(assert (forall ((s@$ $Snap) (n@29@00 Int)) (!
  (=>
    (is_palindrome%precondition s@$ n@29@00)
    (is_palindrome_helper%precondition ($Snap.combine $Snap.unit $Snap.unit) n@29@00 0 n@29@00))
  :pattern ((is_palindrome s@$ n@29@00))
  :qid |quant-u-76|)))
; ---------- FUNCTION count_divisors_upto----------
(declare-fun n@31@00 () Int)
(declare-fun limit@32@00 () Int)
(declare-fun result@33@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] n > 0
(assert (> n@31@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
; [eval] limit > 0
(assert (> limit@32@00 0))
(declare-const $t@66@00 $Snap)
(assert (= $t@66@00 ($Snap.combine ($Snap.first $t@66@00) ($Snap.second $t@66@00))))
(assert (= ($Snap.first $t@66@00) $Snap.unit))
; [eval] result >= 0
(assert (>= result@33@00 0))
(assert (= ($Snap.second $t@66@00) $Snap.unit))
; [eval] result >= 1
(assert (>= result@33@00 1))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@31@00 Int) (limit@32@00 Int)) (!
  (=
    (count_divisors_upto%limited s@$ n@31@00 limit@32@00)
    (count_divisors_upto s@$ n@31@00 limit@32@00))
  :pattern ((count_divisors_upto s@$ n@31@00 limit@32@00))
  :qid |quant-u-22|)))
(assert (forall ((s@$ $Snap) (n@31@00 Int) (limit@32@00 Int)) (!
  (count_divisors_upto%stateless n@31@00 limit@32@00)
  :pattern ((count_divisors_upto%limited s@$ n@31@00 limit@32@00))
  :qid |quant-u-23|)))
(assert (forall ((s@$ $Snap) (n@31@00 Int) (limit@32@00 Int)) (!
  (let ((result@33@00 (count_divisors_upto%limited s@$ n@31@00 limit@32@00))) (=>
    (count_divisors_upto%precondition s@$ n@31@00 limit@32@00)
    (and (>= result@33@00 0) (>= result@33@00 1))))
  :pattern ((count_divisors_upto%limited s@$ n@31@00 limit@32@00))
  :qid |quant-u-77|)))
(assert (forall ((s@$ $Snap) (n@31@00 Int) (limit@32@00 Int)) (!
  (let ((result@33@00 (count_divisors_upto%limited s@$ n@31@00 limit@32@00))) true)
  :pattern ((count_divisors_upto%limited s@$ n@31@00 limit@32@00))
  :qid |quant-u-78|)))
(assert (forall ((s@$ $Snap) (n@31@00 Int) (limit@32@00 Int)) (!
  (let ((result@33@00 (count_divisors_upto%limited s@$ n@31@00 limit@32@00))) true)
  :pattern ((count_divisors_upto%limited s@$ n@31@00 limit@32@00))
  :qid |quant-u-79|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (> n@31@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
(assert (> limit@32@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (limit == 1 ? 1 : (divisible(n, limit) ? 1 + count_divisors_upto(n, limit - 1) : count_divisors_upto(n, limit - 1)))
; [eval] limit == 1
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= limit@32@00 1))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= limit@32@00 1)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 18 | limit@32@00 == 1 | live]
; [else-branch: 18 | limit@32@00 != 1 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 18 | limit@32@00 == 1]
(assert (= limit@32@00 1))
(pop) ; 3
(push) ; 3
; [else-branch: 18 | limit@32@00 != 1]
(assert (not (= limit@32@00 1)))
; [eval] (divisible(n, limit) ? 1 + count_divisors_upto(n, limit - 1) : count_divisors_upto(n, limit - 1))
; [eval] divisible(n, limit)
(push) ; 4
; [eval] d > 0
(assert (divisible%precondition $Snap.unit n@31@00 limit@32@00))
(pop) ; 4
; Joined path conditions
(assert (divisible%precondition $Snap.unit n@31@00 limit@32@00))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (divisible_ $Snap.unit n@31@00 limit@32@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (divisible_ $Snap.unit n@31@00 limit@32@00)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 19 | divisible(_, n@31@00, limit@32@00) | live]
; [else-branch: 19 | !(divisible(_, n@31@00, limit@32@00)) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 19 | divisible(_, n@31@00, limit@32@00)]
(assert (divisible_ $Snap.unit n@31@00 limit@32@00))
; [eval] 1 + count_divisors_upto(n, limit - 1)
; [eval] count_divisors_upto(n, limit - 1)
; [eval] limit - 1
(push) ; 6
; [eval] n > 0
; [eval] limit > 0
(push) ; 7
(assert (not (> (- limit@32@00 1) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (> (- limit@32@00 1) 0))
(assert (count_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@31@00 (-
  limit@32@00
  1)))
(pop) ; 6
; Joined path conditions
(assert (and
  (> (- limit@32@00 1) 0)
  (count_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@31@00 (-
    limit@32@00
    1))))
(pop) ; 5
(push) ; 5
; [else-branch: 19 | !(divisible(_, n@31@00, limit@32@00))]
(assert (not (divisible_ $Snap.unit n@31@00 limit@32@00)))
; [eval] count_divisors_upto(n, limit - 1)
; [eval] limit - 1
(push) ; 6
; [eval] n > 0
; [eval] limit > 0
(push) ; 7
(assert (not (> (- limit@32@00 1) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (> (- limit@32@00 1) 0))
(assert (count_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@31@00 (-
  limit@32@00
  1)))
(pop) ; 6
; Joined path conditions
(assert (and
  (> (- limit@32@00 1) 0)
  (count_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@31@00 (-
    limit@32@00
    1))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=>
  (divisible_ $Snap.unit n@31@00 limit@32@00)
  (and
    (divisible_ $Snap.unit n@31@00 limit@32@00)
    (> (- limit@32@00 1) 0)
    (count_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@31@00 (-
      limit@32@00
      1)))))
; Joined path conditions
(assert (=>
  (not (divisible_ $Snap.unit n@31@00 limit@32@00))
  (and
    (not (divisible_ $Snap.unit n@31@00 limit@32@00))
    (> (- limit@32@00 1) 0)
    (count_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@31@00 (-
      limit@32@00
      1)))))
(assert (or
  (not (divisible_ $Snap.unit n@31@00 limit@32@00))
  (divisible_ $Snap.unit n@31@00 limit@32@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= limit@32@00 1))
  (and
    (not (= limit@32@00 1))
    (divisible%precondition $Snap.unit n@31@00 limit@32@00)
    (=>
      (divisible_ $Snap.unit n@31@00 limit@32@00)
      (and
        (divisible_ $Snap.unit n@31@00 limit@32@00)
        (> (- limit@32@00 1) 0)
        (count_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@31@00 (-
          limit@32@00
          1))))
    (=>
      (not (divisible_ $Snap.unit n@31@00 limit@32@00))
      (and
        (not (divisible_ $Snap.unit n@31@00 limit@32@00))
        (> (- limit@32@00 1) 0)
        (count_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@31@00 (-
          limit@32@00
          1))))
    (or
      (not (divisible_ $Snap.unit n@31@00 limit@32@00))
      (divisible_ $Snap.unit n@31@00 limit@32@00)))))
(assert (or (not (= limit@32@00 1)) (= limit@32@00 1)))
(assert (=
  result@33@00
  (ite
    (= limit@32@00 1)
    1
    (ite
      (divisible_ $Snap.unit n@31@00 limit@32@00)
      (+
        1
        (count_divisors_upto ($Snap.combine $Snap.unit $Snap.unit) n@31@00 (-
          limit@32@00
          1)))
      (count_divisors_upto ($Snap.combine $Snap.unit $Snap.unit) n@31@00 (-
        limit@32@00
        1))))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@33@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@33@00 0))
; [eval] result >= 1
(push) ; 2
(assert (not (>= result@33@00 1)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@33@00 1))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@31@00 Int) (limit@32@00 Int)) (!
  (=>
    (count_divisors_upto%precondition s@$ n@31@00 limit@32@00)
    (=
      (count_divisors_upto s@$ n@31@00 limit@32@00)
      (ite
        (= limit@32@00 1)
        1
        (ite
          (divisible_ $Snap.unit n@31@00 limit@32@00)
          (+
            1
            (count_divisors_upto%limited ($Snap.combine $Snap.unit $Snap.unit) n@31@00 (-
              limit@32@00
              1)))
          (count_divisors_upto%limited ($Snap.combine $Snap.unit $Snap.unit) n@31@00 (-
            limit@32@00
            1))))))
  :pattern ((count_divisors_upto s@$ n@31@00 limit@32@00))
  :qid |quant-u-80|)))
(assert (forall ((s@$ $Snap) (n@31@00 Int) (limit@32@00 Int)) (!
  (=>
    (count_divisors_upto%precondition s@$ n@31@00 limit@32@00)
    (ite
      (= limit@32@00 1)
      true
      (and
        (divisible%precondition $Snap.unit n@31@00 limit@32@00)
        (count_divisors_upto%precondition ($Snap.combine $Snap.unit $Snap.unit) n@31@00 (-
          limit@32@00
          1)))))
  :pattern ((count_divisors_upto s@$ n@31@00 limit@32@00))
  :qid |quant-u-81|)))
; ---------- FUNCTION sum_of_squares----------
(declare-fun n@34@00 () Int)
(declare-fun result@35@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] n >= 0
(assert (>= n@34@00 0))
(declare-const $t@67@00 $Snap)
(assert (= $t@67@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@35@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@34@00 Int)) (!
  (= (sum_of_squares%limited s@$ n@34@00) (sum_of_squares s@$ n@34@00))
  :pattern ((sum_of_squares s@$ n@34@00))
  :qid |quant-u-24|)))
(assert (forall ((s@$ $Snap) (n@34@00 Int)) (!
  (sum_of_squares%stateless n@34@00)
  :pattern ((sum_of_squares%limited s@$ n@34@00))
  :qid |quant-u-25|)))
(assert (forall ((s@$ $Snap) (n@34@00 Int)) (!
  (let ((result@35@00 (sum_of_squares%limited s@$ n@34@00))) (=>
    (sum_of_squares%precondition s@$ n@34@00)
    (>= result@35@00 0)))
  :pattern ((sum_of_squares%limited s@$ n@34@00))
  :qid |quant-u-82|)))
(assert (forall ((s@$ $Snap) (n@34@00 Int)) (!
  (let ((result@35@00 (sum_of_squares%limited s@$ n@34@00))) true)
  :pattern ((sum_of_squares%limited s@$ n@34@00))
  :qid |quant-u-83|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (>= n@34@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (n == 0 ? 0 : n * n + sum_of_squares(n - 1))
; [eval] n == 0
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= n@34@00 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= n@34@00 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 20 | n@34@00 == 0 | live]
; [else-branch: 20 | n@34@00 != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 20 | n@34@00 == 0]
(assert (= n@34@00 0))
(pop) ; 3
(push) ; 3
; [else-branch: 20 | n@34@00 != 0]
(assert (not (= n@34@00 0)))
; [eval] n * n + sum_of_squares(n - 1)
; [eval] n * n
; [eval] sum_of_squares(n - 1)
; [eval] n - 1
(push) ; 4
; [eval] n >= 0
(push) ; 5
(assert (not (>= (- n@34@00 1) 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (>= (- n@34@00 1) 0))
(assert (sum_of_squares%precondition $Snap.unit (- n@34@00 1)))
(pop) ; 4
; Joined path conditions
(assert (and (>= (- n@34@00 1) 0) (sum_of_squares%precondition $Snap.unit (- n@34@00 1))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= n@34@00 0))
  (and
    (not (= n@34@00 0))
    (>= (- n@34@00 1) 0)
    (sum_of_squares%precondition $Snap.unit (- n@34@00 1)))))
(assert (or (not (= n@34@00 0)) (= n@34@00 0)))
(assert (=
  result@35@00
  (ite
    (= n@34@00 0)
    0
    (+ (* n@34@00 n@34@00) (sum_of_squares $Snap.unit (- n@34@00 1))))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@35@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@35@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@34@00 Int)) (!
  (=>
    (sum_of_squares%precondition s@$ n@34@00)
    (=
      (sum_of_squares s@$ n@34@00)
      (ite
        (= n@34@00 0)
        0
        (+ (* n@34@00 n@34@00) (sum_of_squares%limited $Snap.unit (- n@34@00 1))))))
  :pattern ((sum_of_squares s@$ n@34@00))
  :qid |quant-u-84|)))
(assert (forall ((s@$ $Snap) (n@34@00 Int)) (!
  (=>
    (sum_of_squares%precondition s@$ n@34@00)
    (ite
      (= n@34@00 0)
      true
      (sum_of_squares%precondition $Snap.unit (- n@34@00 1))))
  :pattern ((sum_of_squares s@$ n@34@00))
  :qid |quant-u-85|)))
; ---------- FUNCTION gcd_extended_steps----------
(declare-fun a@36@00 () Int)
(declare-fun b@37@00 () Int)
(declare-fun steps@38@00 () Int)
(declare-fun result@39@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] a >= 0
(assert (>= a@36@00 0))
(assert (=
  ($Snap.second s@$)
  ($Snap.combine
    ($Snap.first ($Snap.second s@$))
    ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.first ($Snap.second s@$)) $Snap.unit))
; [eval] b >= 0
(assert (>= b@37@00 0))
(assert (= ($Snap.second ($Snap.second s@$)) $Snap.unit))
; [eval] steps >= 0
(assert (>= steps@38@00 0))
(declare-const $t@68@00 $Snap)
(assert (= $t@68@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@39@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (a@36@00 Int) (b@37@00 Int) (steps@38@00 Int)) (!
  (=
    (gcd_extended_steps%limited s@$ a@36@00 b@37@00 steps@38@00)
    (gcd_extended_steps s@$ a@36@00 b@37@00 steps@38@00))
  :pattern ((gcd_extended_steps s@$ a@36@00 b@37@00 steps@38@00))
  :qid |quant-u-26|)))
(assert (forall ((s@$ $Snap) (a@36@00 Int) (b@37@00 Int) (steps@38@00 Int)) (!
  (gcd_extended_steps%stateless a@36@00 b@37@00 steps@38@00)
  :pattern ((gcd_extended_steps%limited s@$ a@36@00 b@37@00 steps@38@00))
  :qid |quant-u-27|)))
(assert (forall ((s@$ $Snap) (a@36@00 Int) (b@37@00 Int) (steps@38@00 Int)) (!
  (let ((result@39@00 (gcd_extended_steps%limited s@$ a@36@00 b@37@00 steps@38@00))) (=>
    (gcd_extended_steps%precondition s@$ a@36@00 b@37@00 steps@38@00)
    (>= result@39@00 0)))
  :pattern ((gcd_extended_steps%limited s@$ a@36@00 b@37@00 steps@38@00))
  :qid |quant-u-86|)))
(assert (forall ((s@$ $Snap) (a@36@00 Int) (b@37@00 Int) (steps@38@00 Int)) (!
  (let ((result@39@00 (gcd_extended_steps%limited s@$ a@36@00 b@37@00 steps@38@00))) true)
  :pattern ((gcd_extended_steps%limited s@$ a@36@00 b@37@00 steps@38@00))
  :qid |quant-u-87|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (>= a@36@00 0))
(assert (=
  ($Snap.second s@$)
  ($Snap.combine
    ($Snap.first ($Snap.second s@$))
    ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.first ($Snap.second s@$)) $Snap.unit))
(assert (>= b@37@00 0))
(assert (= ($Snap.second ($Snap.second s@$)) $Snap.unit))
(assert (>= steps@38@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (steps == 0 || b == 0 ? a : gcd_extended_steps(b, a % b, steps - 1))
; [eval] steps == 0 || b == 0
; [eval] steps == 0
(set-option :rlimit 0)
(push) ; 2
; [then-branch: 21 | steps@38@00 == 0 | live]
; [else-branch: 21 | steps@38@00 != 0 | live]
(push) ; 3
; [then-branch: 21 | steps@38@00 == 0]
(assert (= steps@38@00 0))
(pop) ; 3
(push) ; 3
; [else-branch: 21 | steps@38@00 != 0]
(assert (not (= steps@38@00 0)))
; [eval] b == 0
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= steps@38@00 0)) (= steps@38@00 0)))
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (or (= steps@38@00 0) (= b@37@00 0)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (or (= steps@38@00 0) (= b@37@00 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 22 | steps@38@00 == 0 || b@37@00 == 0 | live]
; [else-branch: 22 | !(steps@38@00 == 0 || b@37@00 == 0) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 22 | steps@38@00 == 0 || b@37@00 == 0]
(assert (or (= steps@38@00 0) (= b@37@00 0)))
(pop) ; 3
(push) ; 3
; [else-branch: 22 | !(steps@38@00 == 0 || b@37@00 == 0)]
(assert (not (or (= steps@38@00 0) (= b@37@00 0))))
; [eval] gcd_extended_steps(b, a % b, steps - 1)
; [eval] a % b
(push) ; 4
(assert (not (not (= b@37@00 0))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [eval] steps - 1
(push) ; 4
; [eval] a >= 0
; [eval] b >= 0
(push) ; 5
(assert (not (>= (mod a@36@00 b@37@00) 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (>= (mod a@36@00 b@37@00) 0))
; [eval] steps >= 0
(push) ; 5
(assert (not (>= (- steps@38@00 1) 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (>= (- steps@38@00 1) 0))
(assert (gcd_extended_steps%precondition ($Snap.combine
  $Snap.unit
  ($Snap.combine $Snap.unit $Snap.unit)) b@37@00 (mod a@36@00 b@37@00) (-
  steps@38@00
  1)))
(pop) ; 4
; Joined path conditions
(assert (and
  (>= (mod a@36@00 b@37@00) 0)
  (>= (- steps@38@00 1) 0)
  (gcd_extended_steps%precondition ($Snap.combine
    $Snap.unit
    ($Snap.combine $Snap.unit $Snap.unit)) b@37@00 (mod a@36@00 b@37@00) (-
    steps@38@00
    1))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (or (= steps@38@00 0) (= b@37@00 0)))
  (and
    (not (or (= steps@38@00 0) (= b@37@00 0)))
    (>= (mod a@36@00 b@37@00) 0)
    (>= (- steps@38@00 1) 0)
    (gcd_extended_steps%precondition ($Snap.combine
      $Snap.unit
      ($Snap.combine $Snap.unit $Snap.unit)) b@37@00 (mod a@36@00 b@37@00) (-
      steps@38@00
      1)))))
(assert (or
  (not (or (= steps@38@00 0) (= b@37@00 0)))
  (or (= steps@38@00 0) (= b@37@00 0))))
(assert (=
  result@39@00
  (ite
    (or (= steps@38@00 0) (= b@37@00 0))
    a@36@00
    (gcd_extended_steps ($Snap.combine
      $Snap.unit
      ($Snap.combine $Snap.unit $Snap.unit)) b@37@00 (mod a@36@00 b@37@00) (-
      steps@38@00
      1)))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@39@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@39@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (a@36@00 Int) (b@37@00 Int) (steps@38@00 Int)) (!
  (=>
    (gcd_extended_steps%precondition s@$ a@36@00 b@37@00 steps@38@00)
    (=
      (gcd_extended_steps s@$ a@36@00 b@37@00 steps@38@00)
      (ite
        (or (= steps@38@00 0) (= b@37@00 0))
        a@36@00
        (gcd_extended_steps%limited ($Snap.combine
          $Snap.unit
          ($Snap.combine $Snap.unit $Snap.unit)) b@37@00 (mod a@36@00 b@37@00) (-
          steps@38@00
          1)))))
  :pattern ((gcd_extended_steps s@$ a@36@00 b@37@00 steps@38@00))
  :qid |quant-u-88|)))
(assert (forall ((s@$ $Snap) (a@36@00 Int) (b@37@00 Int) (steps@38@00 Int)) (!
  (=>
    (gcd_extended_steps%precondition s@$ a@36@00 b@37@00 steps@38@00)
    (ite
      (or (= steps@38@00 0) (= b@37@00 0))
      true
      (gcd_extended_steps%precondition ($Snap.combine
        $Snap.unit
        ($Snap.combine $Snap.unit $Snap.unit)) b@37@00 (mod a@36@00 b@37@00) (-
        steps@38@00
        1))))
  :pattern ((gcd_extended_steps s@$ a@36@00 b@37@00 steps@38@00))
  :qid |quant-u-89|)))
; ---------- FUNCTION is_perfect_square----------
(declare-fun n@40@00 () Int)
(declare-fun k@41@00 () Int)
(declare-fun result@42@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] n >= 0
(assert (>= n@40@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
; [eval] k >= 0
(assert (>= k@41@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@40@00 Int) (k@41@00 Int)) (!
  (=
    (is_perfect_square%limited s@$ n@40@00 k@41@00)
    (is_perfect_square s@$ n@40@00 k@41@00))
  :pattern ((is_perfect_square s@$ n@40@00 k@41@00))
  :qid |quant-u-28|)))
(assert (forall ((s@$ $Snap) (n@40@00 Int) (k@41@00 Int)) (!
  (is_perfect_square%stateless n@40@00 k@41@00)
  :pattern ((is_perfect_square%limited s@$ n@40@00 k@41@00))
  :qid |quant-u-29|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (>= n@40@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
(assert (>= k@41@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (k * k == n ? true : (k * k > n ? false : is_perfect_square(n, k + 1)))
; [eval] k * k == n
; [eval] k * k
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (* k@41@00 k@41@00) n@40@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (* k@41@00 k@41@00) n@40@00)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 23 | k@41@00 * k@41@00 == n@40@00 | live]
; [else-branch: 23 | k@41@00 * k@41@00 != n@40@00 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 23 | k@41@00 * k@41@00 == n@40@00]
(assert (= (* k@41@00 k@41@00) n@40@00))
(pop) ; 3
(push) ; 3
; [else-branch: 23 | k@41@00 * k@41@00 != n@40@00]
(assert (not (= (* k@41@00 k@41@00) n@40@00)))
; [eval] (k * k > n ? false : is_perfect_square(n, k + 1))
; [eval] k * k > n
; [eval] k * k
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (> (* k@41@00 k@41@00) n@40@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (> (* k@41@00 k@41@00) n@40@00)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 24 | k@41@00 * k@41@00 > n@40@00 | live]
; [else-branch: 24 | !(k@41@00 * k@41@00 > n@40@00) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 24 | k@41@00 * k@41@00 > n@40@00]
(assert (> (* k@41@00 k@41@00) n@40@00))
(pop) ; 5
(push) ; 5
; [else-branch: 24 | !(k@41@00 * k@41@00 > n@40@00)]
(assert (not (> (* k@41@00 k@41@00) n@40@00)))
; [eval] is_perfect_square(n, k + 1)
; [eval] k + 1
(push) ; 6
; [eval] n >= 0
; [eval] k >= 0
(push) ; 7
(assert (not (>= (+ k@41@00 1) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (>= (+ k@41@00 1) 0))
(assert (is_perfect_square%precondition ($Snap.combine $Snap.unit $Snap.unit) n@40@00 (+
  k@41@00
  1)))
(pop) ; 6
; Joined path conditions
(assert (and
  (>= (+ k@41@00 1) 0)
  (is_perfect_square%precondition ($Snap.combine $Snap.unit $Snap.unit) n@40@00 (+
    k@41@00
    1))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (> (* k@41@00 k@41@00) n@40@00))
  (and
    (not (> (* k@41@00 k@41@00) n@40@00))
    (>= (+ k@41@00 1) 0)
    (is_perfect_square%precondition ($Snap.combine $Snap.unit $Snap.unit) n@40@00 (+
      k@41@00
      1)))))
(assert (or (not (> (* k@41@00 k@41@00) n@40@00)) (> (* k@41@00 k@41@00) n@40@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (* k@41@00 k@41@00) n@40@00))
  (and
    (not (= (* k@41@00 k@41@00) n@40@00))
    (=>
      (not (> (* k@41@00 k@41@00) n@40@00))
      (and
        (not (> (* k@41@00 k@41@00) n@40@00))
        (>= (+ k@41@00 1) 0)
        (is_perfect_square%precondition ($Snap.combine $Snap.unit $Snap.unit) n@40@00 (+
          k@41@00
          1))))
    (or (not (> (* k@41@00 k@41@00) n@40@00)) (> (* k@41@00 k@41@00) n@40@00)))))
(assert (or (not (= (* k@41@00 k@41@00) n@40@00)) (= (* k@41@00 k@41@00) n@40@00)))
(assert (=
  result@42@00
  (ite
    (= (* k@41@00 k@41@00) n@40@00)
    true
    (ite
      (> (* k@41@00 k@41@00) n@40@00)
      false
      (is_perfect_square ($Snap.combine $Snap.unit $Snap.unit) n@40@00 (+
        k@41@00
        1))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@40@00 Int) (k@41@00 Int)) (!
  (=>
    (is_perfect_square%precondition s@$ n@40@00 k@41@00)
    (=
      (is_perfect_square s@$ n@40@00 k@41@00)
      (ite
        (= (* k@41@00 k@41@00) n@40@00)
        true
        (ite
          (> (* k@41@00 k@41@00) n@40@00)
          false
          (is_perfect_square%limited ($Snap.combine $Snap.unit $Snap.unit) n@40@00 (+
            k@41@00
            1))))))
  :pattern ((is_perfect_square s@$ n@40@00 k@41@00))
  :qid |quant-u-90|)))
(assert (forall ((s@$ $Snap) (n@40@00 Int) (k@41@00 Int)) (!
  (=>
    (is_perfect_square%precondition s@$ n@40@00 k@41@00)
    (ite
      (= (* k@41@00 k@41@00) n@40@00)
      true
      (ite
        (> (* k@41@00 k@41@00) n@40@00)
        true
        (is_perfect_square%precondition ($Snap.combine $Snap.unit $Snap.unit) n@40@00 (+
          k@41@00
          1)))))
  :pattern ((is_perfect_square s@$ n@40@00 k@41@00))
  :qid |quant-u-91|)))
; ---------- FUNCTION lcm----------
(declare-fun a@43@00 () Int)
(declare-fun b@44@00 () Int)
(declare-fun result@45@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] a > 0
(assert (> a@43@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
; [eval] b > 0
(assert (> b@44@00 0))
(declare-const $t@69@00 $Snap)
(assert (= $t@69@00 ($Snap.combine ($Snap.first $t@69@00) ($Snap.second $t@69@00))))
(assert (= ($Snap.first $t@69@00) $Snap.unit))
; [eval] result >= a
(assert (>= result@45@00 a@43@00))
(assert (=
  ($Snap.second $t@69@00)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@69@00))
    ($Snap.second ($Snap.second $t@69@00)))))
(assert (= ($Snap.first ($Snap.second $t@69@00)) $Snap.unit))
; [eval] result >= b
(assert (>= result@45@00 b@44@00))
(assert (= ($Snap.second ($Snap.second $t@69@00)) $Snap.unit))
; [eval] result > 0
(assert (> result@45@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (a@43@00 Int) (b@44@00 Int)) (!
  (= (lcm%limited s@$ a@43@00 b@44@00) (lcm s@$ a@43@00 b@44@00))
  :pattern ((lcm s@$ a@43@00 b@44@00))
  :qid |quant-u-30|)))
(assert (forall ((s@$ $Snap) (a@43@00 Int) (b@44@00 Int)) (!
  (lcm%stateless a@43@00 b@44@00)
  :pattern ((lcm%limited s@$ a@43@00 b@44@00))
  :qid |quant-u-31|)))
(assert (forall ((s@$ $Snap) (a@43@00 Int) (b@44@00 Int)) (!
  (let ((result@45@00 (lcm%limited s@$ a@43@00 b@44@00))) (=>
    (lcm%precondition s@$ a@43@00 b@44@00)
    (and
      (and (>= result@45@00 a@43@00) (>= result@45@00 b@44@00))
      (> result@45@00 0))))
  :pattern ((lcm%limited s@$ a@43@00 b@44@00))
  :qid |quant-u-92|)))
(assert (forall ((s@$ $Snap) (a@43@00 Int) (b@44@00 Int)) (!
  (let ((result@45@00 (lcm%limited s@$ a@43@00 b@44@00))) true)
  :pattern ((lcm%limited s@$ a@43@00 b@44@00))
  :qid |quant-u-93|)))
(assert (forall ((s@$ $Snap) (a@43@00 Int) (b@44@00 Int)) (!
  (let ((result@45@00 (lcm%limited s@$ a@43@00 b@44@00))) true)
  :pattern ((lcm%limited s@$ a@43@00 b@44@00))
  :qid |quant-u-94|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (> a@43@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
(assert (> b@44@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] a * b \ gcd(a, b)
; [eval] a * b
; [eval] gcd(a, b)
(set-option :rlimit 0)
(push) ; 2
; [eval] a > 0
; [eval] b > 0
(assert (gcd%precondition ($Snap.combine $Snap.unit $Snap.unit) a@43@00 b@44@00))
(pop) ; 2
; Joined path conditions
(assert (gcd%precondition ($Snap.combine $Snap.unit $Snap.unit) a@43@00 b@44@00))
(push) ; 2
(assert (not (not (= (gcd ($Snap.combine $Snap.unit $Snap.unit) a@43@00 b@44@00) 0))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=
  result@45@00
  (div
    (* a@43@00 b@44@00)
    (gcd ($Snap.combine $Snap.unit $Snap.unit) a@43@00 b@44@00))))
; [eval] result >= a
(push) ; 2
(assert (not (>= result@45@00 a@43@00)))
(check-sat)
