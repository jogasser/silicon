(get-info :version)
; (:version "4.8.7")
; Started: 2025-12-05 12:41:36
; Silicon.version: 1.1-SNAPSHOT (95328487@(detached))
; Input file: ./functions/sequence_operations.vpr
; Verifier id: 00
; ------------------------------------------------------------
; Begin preamble
; ////////// Static preamble
; 
; ; /z3config.smt2
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :smt.qi.max_multi_patterns 1000)
; 
; ; /preamble.smt2
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(define-fun $Perm.min ((p1 $Perm) (p2 $Perm)) Real
    (ite (<= p1 p2) p1 p2))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
; ////////// Sorts
(declare-sort Seq<Seq<Int>> 0)
(declare-sort Seq<Int> 0)
(declare-sort Set<Int> 0)
; ////////// Sort wrappers
; Declaring additional sort wrappers
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.Seq<Seq<Int>>To$Snap (Seq<Seq<Int>>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<Seq<Int>> ($Snap) Seq<Seq<Int>>)
(assert (forall ((x Seq<Seq<Int>>)) (!
    (= x ($SortWrappers.$SnapToSeq<Seq<Int>>($SortWrappers.Seq<Seq<Int>>To$Snap x)))
    :pattern (($SortWrappers.Seq<Seq<Int>>To$Snap x))
    :qid |$Snap.$SnapToSeq<Seq<Int>>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<Seq<Int>>To$Snap($SortWrappers.$SnapToSeq<Seq<Int>> x)))
    :pattern (($SortWrappers.$SnapToSeq<Seq<Int>> x))
    :qid |$Snap.Seq<Seq<Int>>To$SnapToSeq<Seq<Int>>|
    )))
(declare-fun $SortWrappers.Seq<Int>To$Snap (Seq<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<Int> ($Snap) Seq<Int>)
(assert (forall ((x Seq<Int>)) (!
    (= x ($SortWrappers.$SnapToSeq<Int>($SortWrappers.Seq<Int>To$Snap x)))
    :pattern (($SortWrappers.Seq<Int>To$Snap x))
    :qid |$Snap.$SnapToSeq<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<Int>To$Snap($SortWrappers.$SnapToSeq<Int> x)))
    :pattern (($SortWrappers.$SnapToSeq<Int> x))
    :qid |$Snap.Seq<Int>To$SnapToSeq<Int>|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.Set<Int>To$Snap (Set<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<Int> ($Snap) Set<Int>)
(assert (forall ((x Set<Int>)) (!
    (= x ($SortWrappers.$SnapToSet<Int>($SortWrappers.Set<Int>To$Snap x)))
    :pattern (($SortWrappers.Set<Int>To$Snap x))
    :qid |$Snap.$SnapToSet<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<Int>To$Snap($SortWrappers.$SnapToSet<Int> x)))
    :pattern (($SortWrappers.$SnapToSet<Int> x))
    :qid |$Snap.Set<Int>To$SnapToSet<Int>|
    )))
; ////////// Symbols
(declare-fun Set_card (Set<Int>) Int)
(declare-const Set_empty Set<Int>)
(declare-fun Set_in (Int Set<Int>) Bool)
(declare-fun Set_singleton (Int) Set<Int>)
(declare-fun Set_unionone (Set<Int> Int) Set<Int>)
(declare-fun Set_union (Set<Int> Set<Int>) Set<Int>)
(declare-fun Set_intersection (Set<Int> Set<Int>) Set<Int>)
(declare-fun Set_difference (Set<Int> Set<Int>) Set<Int>)
(declare-fun Set_subset (Set<Int> Set<Int>) Bool)
(declare-fun Set_equal (Set<Int> Set<Int>) Bool)
(declare-fun Set_skolem_diff (Set<Int> Set<Int>) Int)
(declare-fun Seq_length (Seq<Seq<Int>>) Int)
(declare-const Seq_empty Seq<Seq<Int>>)
(declare-fun Seq_singleton (Seq<Int>) Seq<Seq<Int>>)
(declare-fun Seq_append (Seq<Seq<Int>> Seq<Seq<Int>>) Seq<Seq<Int>>)
(declare-fun Seq_index (Seq<Seq<Int>> Int) Seq<Int>)
(declare-fun Seq_add (Int Int) Int)
(declare-fun Seq_sub (Int Int) Int)
(declare-fun Seq_update (Seq<Seq<Int>> Int Seq<Int>) Seq<Seq<Int>>)
(declare-fun Seq_take (Seq<Seq<Int>> Int) Seq<Seq<Int>>)
(declare-fun Seq_drop (Seq<Seq<Int>> Int) Seq<Seq<Int>>)
(declare-fun Seq_contains (Seq<Seq<Int>> Seq<Int>) Bool)
(declare-fun Seq_contains_trigger (Seq<Seq<Int>> Seq<Int>) Bool)
(declare-fun Seq_skolem (Seq<Seq<Int>> Seq<Int>) Int)
(declare-fun Seq_equal (Seq<Seq<Int>> Seq<Seq<Int>>) Bool)
(declare-fun Seq_skolem_diff (Seq<Seq<Int>> Seq<Seq<Int>>) Int)
(declare-fun Seq_length (Seq<Int>) Int)
(declare-const Seq_empty Seq<Int>)
(declare-fun Seq_singleton (Int) Seq<Int>)
(declare-fun Seq_append (Seq<Int> Seq<Int>) Seq<Int>)
(declare-fun Seq_index (Seq<Int> Int) Int)
(declare-fun Seq_update (Seq<Int> Int Int) Seq<Int>)
(declare-fun Seq_take (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_drop (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_contains (Seq<Int> Int) Bool)
(declare-fun Seq_contains_trigger (Seq<Int> Int) Bool)
(declare-fun Seq_skolem (Seq<Int> Int) Int)
(declare-fun Seq_equal (Seq<Int> Seq<Int>) Bool)
(declare-fun Seq_skolem_diff (Seq<Int> Seq<Int>) Int)
(declare-fun Seq_range (Int Int) Seq<Int>)
; Declaring symbols related to program functions (from program analysis)
(declare-fun min_int ($Snap Int Int) Int)
(declare-fun min_int%limited ($Snap Int Int) Int)
(declare-fun min_int%stateless (Int Int) Bool)
(declare-fun min_int%precondition ($Snap Int Int) Bool)
(declare-fun max_int ($Snap Int Int) Int)
(declare-fun max_int%limited ($Snap Int Int) Int)
(declare-fun max_int%stateless (Int Int) Bool)
(declare-fun max_int%precondition ($Snap Int Int) Bool)
(declare-fun min_of_three ($Snap Int Int Int) Int)
(declare-fun min_of_three%limited ($Snap Int Int Int) Int)
(declare-fun min_of_three%stateless (Int Int Int) Bool)
(declare-fun min_of_three%precondition ($Snap Int Int Int) Bool)
(declare-fun adjacent_products_sum ($Snap Seq<Int>) Int)
(declare-fun adjacent_products_sum%limited ($Snap Seq<Int>) Int)
(declare-fun adjacent_products_sum%stateless (Seq<Int>) Bool)
(declare-fun adjacent_products_sum%precondition ($Snap Seq<Int>) Bool)
(declare-fun split_at_first ($Snap Seq<Int> Int Int) Seq<Int>)
(declare-fun split_at_first%limited ($Snap Seq<Int> Int Int) Seq<Int>)
(declare-fun split_at_first%stateless (Seq<Int> Int Int) Bool)
(declare-fun split_at_first%precondition ($Snap Seq<Int> Int Int) Bool)
(declare-fun max_subarray_sum ($Snap Seq<Int> Int Int Int) Int)
(declare-fun max_subarray_sum%limited ($Snap Seq<Int> Int Int Int) Int)
(declare-fun max_subarray_sum%stateless (Seq<Int> Int Int Int) Bool)
(declare-fun max_subarray_sum%precondition ($Snap Seq<Int> Int Int Int) Bool)
(declare-fun is_decreasing ($Snap Seq<Int>) Bool)
(declare-fun is_decreasing%limited ($Snap Seq<Int>) Bool)
(declare-fun is_decreasing%stateless (Seq<Int>) Bool)
(declare-fun is_decreasing%precondition ($Snap Seq<Int>) Bool)
(declare-fun lcp_length ($Snap Seq<Int> Seq<Int> Int) Int)
(declare-fun lcp_length%limited ($Snap Seq<Int> Seq<Int> Int) Int)
(declare-fun lcp_length%stateless (Seq<Int> Seq<Int> Int) Bool)
(declare-fun lcp_length%precondition ($Snap Seq<Int> Seq<Int> Int) Bool)
(declare-fun interleave ($Snap Seq<Int> Seq<Int>) Seq<Int>)
(declare-fun interleave%limited ($Snap Seq<Int> Seq<Int>) Seq<Int>)
(declare-fun interleave%stateless (Seq<Int> Seq<Int>) Bool)
(declare-fun interleave%precondition ($Snap Seq<Int> Seq<Int>) Bool)
(declare-fun is_palindrome ($Snap Seq<Int>) Bool)
(declare-fun is_palindrome%limited ($Snap Seq<Int>) Bool)
(declare-fun is_palindrome%stateless (Seq<Int>) Bool)
(declare-fun is_palindrome%precondition ($Snap Seq<Int>) Bool)
(declare-fun count_palindromes ($Snap Seq<Int> Int Int) Int)
(declare-fun count_palindromes%limited ($Snap Seq<Int> Int Int) Int)
(declare-fun count_palindromes%stateless (Seq<Int> Int Int) Bool)
(declare-fun count_palindromes%precondition ($Snap Seq<Int> Int Int) Bool)
(declare-fun alternating_sum ($Snap Seq<Int> Int) Int)
(declare-fun alternating_sum%limited ($Snap Seq<Int> Int) Int)
(declare-fun alternating_sum%stateless (Seq<Int> Int) Bool)
(declare-fun alternating_sum%precondition ($Snap Seq<Int> Int) Bool)
(declare-fun run_length_count ($Snap Seq<Int> Int Int Int) Int)
(declare-fun run_length_count%limited ($Snap Seq<Int> Int Int Int) Int)
(declare-fun run_length_count%stateless (Seq<Int> Int Int Int) Bool)
(declare-fun run_length_count%precondition ($Snap Seq<Int> Int Int Int) Bool)
(declare-fun flatten_sequences ($Snap Seq<Seq<Int>> Int) Seq<Int>)
(declare-fun flatten_sequences%limited ($Snap Seq<Seq<Int>> Int) Seq<Int>)
(declare-fun flatten_sequences%stateless (Seq<Seq<Int>> Int) Bool)
(declare-fun flatten_sequences%precondition ($Snap Seq<Seq<Int>> Int) Bool)
(declare-fun lcs_length ($Snap Seq<Int> Seq<Int>) Int)
(declare-fun lcs_length%limited ($Snap Seq<Int> Seq<Int>) Int)
(declare-fun lcs_length%stateless (Seq<Int> Seq<Int>) Bool)
(declare-fun lcs_length%precondition ($Snap Seq<Int> Seq<Int>) Bool)
(declare-fun count_inversions ($Snap Seq<Int> Int Int) Int)
(declare-fun count_inversions%limited ($Snap Seq<Int> Int Int) Int)
(declare-fun count_inversions%stateless (Seq<Int> Int Int) Bool)
(declare-fun count_inversions%precondition ($Snap Seq<Int> Int Int) Bool)
(declare-fun rotate_left_ ($Snap Seq<Int> Int) Seq<Int>)
(declare-fun rotate_left%limited ($Snap Seq<Int> Int) Seq<Int>)
(declare-fun rotate_left%stateless (Seq<Int> Int) Bool)
(declare-fun rotate_left%precondition ($Snap Seq<Int> Int) Bool)
(declare-fun has_duplicates ($Snap Seq<Int> Set<Int>) Bool)
(declare-fun has_duplicates%limited ($Snap Seq<Int> Set<Int>) Bool)
(declare-fun has_duplicates%stateless (Seq<Int> Set<Int>) Bool)
(declare-fun has_duplicates%precondition ($Snap Seq<Int> Set<Int>) Bool)
(declare-fun edit_distance ($Snap Seq<Int> Seq<Int>) Int)
(declare-fun edit_distance%limited ($Snap Seq<Int> Seq<Int>) Int)
(declare-fun edit_distance%stateless (Seq<Int> Seq<Int>) Bool)
(declare-fun edit_distance%precondition ($Snap Seq<Int> Seq<Int>) Bool)
(declare-fun remove_duplicates ($Snap Seq<Int> Set<Int>) Seq<Int>)
(declare-fun remove_duplicates%limited ($Snap Seq<Int> Set<Int>) Seq<Int>)
(declare-fun remove_duplicates%stateless (Seq<Int> Set<Int>) Bool)
(declare-fun remove_duplicates%precondition ($Snap Seq<Int> Set<Int>) Bool)
(declare-fun is_increasing ($Snap Seq<Int>) Bool)
(declare-fun is_increasing%limited ($Snap Seq<Int>) Bool)
(declare-fun is_increasing%stateless (Seq<Int>) Bool)
(declare-fun is_increasing%precondition ($Snap Seq<Int>) Bool)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
; Declaring predicate trigger functions
; ////////// Uniqueness assumptions from domains
; ////////// Axioms
(assert (forall ((s Seq<Seq<Int>>)) (!
  (<= 0 (Seq_length s))
  :pattern ((Seq_length s))
  :qid |$Seq[Seq[Int]]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty  Seq<Seq<Int>>)) 0))
(assert (forall ((s Seq<Seq<Int>>)) (!
  (=> (= (Seq_length s) 0) (= s (as Seq_empty  Seq<Seq<Int>>)))
  :pattern ((Seq_length s))
  :qid |$Seq[Seq[Int]]_prog.Seq_length_zero|)))
(assert (forall ((e Seq<Int>)) (!
  (= (Seq_length (Seq_singleton e)) 1)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Seq[Int]]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<Seq<Int>>) (s1 Seq<Seq<Int>>)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Seq<Int>>)))
      (not (= s1 (as Seq_empty  Seq<Seq<Int>>))))
    (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1))))
  :pattern ((Seq_length (Seq_append s0 s1)))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<Seq<Int>>) (s1 Seq<Seq<Int>>)) (!
  (and
    (=> (= s0 (as Seq_empty  Seq<Seq<Int>>)) (= (Seq_append s0 s1) s1))
    (=> (= s1 (as Seq_empty  Seq<Seq<Int>>)) (= (Seq_append s0 s1) s0)))
  :pattern ((Seq_append s0 s1))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_empty|)))
(assert (forall ((e Seq<Int>)) (!
  (= (Seq_index (Seq_singleton e) 0) e)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Seq[Int]]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_add i j) (+ i j))
  :pattern ((Seq_add i j))
  :qid |$Seq[Seq[Int]]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_sub i j) (- i j))
  :pattern ((Seq_sub i j))
  :qid |$Seq[Seq[Int]]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<Seq<Int>>) (s1 Seq<Seq<Int>>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Seq<Int>>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Seq<Int>>)))
        (and (<= 0 n) (< n (Seq_length s0)))))
    (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n)))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :pattern ((Seq_index s0 n) (Seq_append s0 s1))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<Seq<Int>>) (s1 Seq<Seq<Int>>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Seq<Int>>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Seq<Int>>)))
        (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1))))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n)
      (=
        (Seq_index (Seq_append s0 s1) n)
        (Seq_index s1 (Seq_sub n (Seq_length s0))))))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<Seq<Int>>) (s1 Seq<Seq<Int>>) (m Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Seq<Int>>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Seq<Int>>)))
        (and (<= 0 m) (< m (Seq_length s1)))))
    (and
      (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m)
      (=
        (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0)))
        (Seq_index s1 m))))
  :pattern ((Seq_index s1 m) (Seq_append s0 s1))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<Seq<Int>>) (i Int) (v Seq<Int>)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (Seq_length (Seq_update s i v)) (Seq_length s)))
  :pattern ((Seq_length (Seq_update s i v)))
  :pattern ((Seq_length s) (Seq_update s i v))
  :qid |$Seq[Seq[Int]]_prog.Seq_update_length|)))
(assert (forall ((s Seq<Seq<Int>>) (i Int) (v Seq<Int>) (n Int)) (!
  (=>
    (and (<= 0 n) (< n (Seq_length s)))
    (and
      (=> (= i n) (= (Seq_index (Seq_update s i v) n) v))
      (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n)))))
  :pattern ((Seq_index (Seq_update s i v) n))
  :pattern ((Seq_index s n) (Seq_update s i v))
  :qid |$Seq[Seq[Int]]_prog.Seq_update_index|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s)))))
    (=> (< n 0) (= (Seq_length (Seq_take s n)) 0)))
  :pattern ((Seq_length (Seq_take s n)))
  :pattern ((Seq_take s n) (Seq_length s))
  :qid |$Seq[Seq[Int]]_prog.Seq_take_length|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int) (j Int)) (!
  (=>
    (and (<= 0 j) (and (< j n) (< j (Seq_length s))))
    (= (Seq_index (Seq_take s n) j) (Seq_index s j)))
  :pattern ((Seq_index (Seq_take s n) j))
  :pattern ((Seq_index s j) (Seq_take s n))
  :qid |$Seq[Seq[Int]]_prog.Seq_take_index|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=>
          (<= n (Seq_length s))
          (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n)))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0))))
    (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s))))
  :pattern ((Seq_length (Seq_drop s n)))
  :pattern ((Seq_length s) (Seq_drop s n))
  :qid |$Seq[Seq[Int]]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int) (j Int)) (!
  (=>
    (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n))))
    (and
      (= (Seq_sub (Seq_add j n) n) j)
      (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n)))))
  :pattern ((Seq_index (Seq_drop s n) j))
  :qid |$Seq[Seq[Int]]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int) (i Int)) (!
  (=>
    (and (< 0 n) (and (<= n i) (< i (Seq_length s))))
    (and
      (= (Seq_add (Seq_sub i n) n) i)
      (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i))))
  :pattern ((Seq_drop s n) (Seq_index s i))
  :qid |$Seq[Seq[Int]]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<Seq<Int>>) (t Seq<Seq<Int>>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_take (Seq_append s t) n) (Seq_take s n)))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<Seq<Int>>) (t Seq<Seq<Int>>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (=
        (Seq_take (Seq_append s t) n)
        (Seq_append s (Seq_take t (Seq_sub n (Seq_length s)))))))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<Seq<Int>>) (t Seq<Seq<Int>>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t)))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<Seq<Int>>) (t Seq<Seq<Int>>) (n Int)) (!
  (=>
    (and (> n 0) (> n (Seq_length s)))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s))))))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int)) (!
  (=> (<= n 0) (= (Seq_take s n) (as Seq_empty  Seq<Seq<Int>>)))
  :pattern ((Seq_take s n))
  :qid |$Seq[Seq[Int]]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int)) (!
  (=> (<= n 0) (= (Seq_drop s n) s))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Seq[Int]]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_take s n) s))
  :pattern ((Seq_take s n))
  :qid |$Seq[Seq[Int]]_prog.Seq_take_all|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty  Seq<Seq<Int>>)))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Seq[Int]]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<Seq<Int>>) (x Seq<Int>)) (!
  (=>
    (Seq_contains s x)
    (and
      (<= 0 (Seq_skolem s x))
      (and
        (< (Seq_skolem s x) (Seq_length s))
        (= (Seq_index s (Seq_skolem s x)) x))))
  :pattern ((Seq_contains s x))
  :qid |$Seq[Seq[Int]]_prog.Seq_contains1|)))
(assert (forall ((s Seq<Seq<Int>>) (x Seq<Int>) (i Int)) (!
  (=>
    (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x)))
    (Seq_contains s x))
  :pattern ((Seq_contains s x) (Seq_index s i))
  :qid |$Seq[Seq[Int]]_prog.Seq_contains2|)))
(assert (forall ((s Seq<Seq<Int>>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (Seq_contains_trigger s (Seq_index s i)))
  :pattern ((Seq_index s i))
  :qid |$Seq[Seq[Int]]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<Seq<Int>>) (s1 Seq<Seq<Int>>)) (!
  (or
    (and (= s0 s1) (Seq_equal s0 s1))
    (or
      (and
        (not (= s0 s1))
        (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1)))))
      (and
        (not (= s0 s1))
        (and
          (not (Seq_equal s0 s1))
          (and
            (= (Seq_length s0) (Seq_length s1))
            (and
              (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0))
              (and
                (<= 0 (Seq_skolem_diff s0 s1))
                (and
                  (< (Seq_skolem_diff s0 s1) (Seq_length s0))
                  (not
                    (=
                      (Seq_index s0 (Seq_skolem_diff s0 s1))
                      (Seq_index s1 (Seq_skolem_diff s0 s1))))))))))))
  :pattern ((Seq_equal s0 s1))
  :qid |$Seq[Seq[Int]]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<Seq<Int>>) (b Seq<Seq<Int>>)) (!
  (=> (Seq_equal a b) (= a b))
  :pattern ((Seq_equal a b))
  :qid |$Seq[Seq[Int]]_prog.Seq_equal_ext|)))
(assert (forall ((x Seq<Int>) (y Seq<Int>)) (!
  (= (Seq_contains (Seq_singleton x) y) (= x y))
  :pattern ((Seq_contains (Seq_singleton x) y))
  :qid |$Seq[Seq[Int]]_prog.Seq_singleton_contains|)))
(assert (forall ((s Seq<Int>)) (!
  (<= 0 (Seq_length s))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty  Seq<Int>)) 0))
(assert (forall ((s Seq<Int>)) (!
  (=> (= (Seq_length s) 0) (= s (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_zero|)))
(assert (forall ((e Int)) (!
  (= (Seq_length (Seq_singleton e)) 1)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (not (= s1 (as Seq_empty  Seq<Int>))))
    (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1))))
  :pattern ((Seq_length (Seq_append s0 s1)))
  :qid |$Seq[Int]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (and
    (=> (= s0 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s1))
    (=> (= s1 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s0)))
  :pattern ((Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_empty|)))
(assert (forall ((e Int)) (!
  (= (Seq_index (Seq_singleton e) 0) e)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_add i j) (+ i j))
  :pattern ((Seq_add i j))
  :qid |$Seq[Int]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_sub i j) (- i j))
  :pattern ((Seq_sub i j))
  :qid |$Seq[Int]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= 0 n) (< n (Seq_length s0)))))
    (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n)))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :pattern ((Seq_index s0 n) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1))))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n)
      (=
        (Seq_index (Seq_append s0 s1) n)
        (Seq_index s1 (Seq_sub n (Seq_length s0))))))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :qid |$Seq[Int]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (m Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= 0 m) (< m (Seq_length s1)))))
    (and
      (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m)
      (=
        (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0)))
        (Seq_index s1 m))))
  :pattern ((Seq_index s1 m) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (Seq_length (Seq_update s i v)) (Seq_length s)))
  :pattern ((Seq_length (Seq_update s i v)))
  :pattern ((Seq_length s) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_length|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int) (n Int)) (!
  (=>
    (and (<= 0 n) (< n (Seq_length s)))
    (and
      (=> (= i n) (= (Seq_index (Seq_update s i v) n) v))
      (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n)))))
  :pattern ((Seq_index (Seq_update s i v) n))
  :pattern ((Seq_index s n) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s)))))
    (=> (< n 0) (= (Seq_length (Seq_take s n)) 0)))
  :pattern ((Seq_length (Seq_take s n)))
  :pattern ((Seq_take s n) (Seq_length s))
  :qid |$Seq[Int]_prog.Seq_take_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (<= 0 j) (and (< j n) (< j (Seq_length s))))
    (= (Seq_index (Seq_take s n) j) (Seq_index s j)))
  :pattern ((Seq_index (Seq_take s n) j))
  :pattern ((Seq_index s j) (Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=>
          (<= n (Seq_length s))
          (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n)))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0))))
    (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s))))
  :pattern ((Seq_length (Seq_drop s n)))
  :pattern ((Seq_length s) (Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n))))
    (and
      (= (Seq_sub (Seq_add j n) n) j)
      (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n)))))
  :pattern ((Seq_index (Seq_drop s n) j))
  :qid |$Seq[Int]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<Int>) (n Int) (i Int)) (!
  (=>
    (and (< 0 n) (and (<= n i) (< i (Seq_length s))))
    (and
      (= (Seq_add (Seq_sub i n) n) i)
      (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i))))
  :pattern ((Seq_drop s n) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_take (Seq_append s t) n) (Seq_take s n)))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (=
        (Seq_take (Seq_append s t) n)
        (Seq_append s (Seq_take t (Seq_sub n (Seq_length s)))))))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t)))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (> n (Seq_length s)))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s))))))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_take s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_drop s n) s))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_take s n) s))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_all|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<Int>) (x Int)) (!
  (=>
    (Seq_contains s x)
    (and
      (<= 0 (Seq_skolem s x))
      (and
        (< (Seq_skolem s x) (Seq_length s))
        (= (Seq_index s (Seq_skolem s x)) x))))
  :pattern ((Seq_contains s x))
  :qid |$Seq[Int]_prog.Seq_contains1|)))
(assert (forall ((s Seq<Int>) (x Int) (i Int)) (!
  (=>
    (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x)))
    (Seq_contains s x))
  :pattern ((Seq_contains s x) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains2|)))
(assert (forall ((s Seq<Int>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (Seq_contains_trigger s (Seq_index s i)))
  :pattern ((Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (or
    (and (= s0 s1) (Seq_equal s0 s1))
    (or
      (and
        (not (= s0 s1))
        (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1)))))
      (and
        (not (= s0 s1))
        (and
          (not (Seq_equal s0 s1))
          (and
            (= (Seq_length s0) (Seq_length s1))
            (and
              (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0))
              (and
                (<= 0 (Seq_skolem_diff s0 s1))
                (and
                  (< (Seq_skolem_diff s0 s1) (Seq_length s0))
                  (not
                    (=
                      (Seq_index s0 (Seq_skolem_diff s0 s1))
                      (Seq_index s1 (Seq_skolem_diff s0 s1))))))))))))
  :pattern ((Seq_equal s0 s1))
  :qid |$Seq[Int]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<Int>) (b Seq<Int>)) (!
  (=> (Seq_equal a b) (= a b))
  :pattern ((Seq_equal a b))
  :qid |$Seq[Int]_prog.Seq_equal_ext|)))
(assert (forall ((x Int) (y Int)) (!
  (= (Seq_contains (Seq_singleton x) y) (= x y))
  :pattern ((Seq_contains (Seq_singleton x) y))
  :qid |$Seq[Int]_prog.Seq_singleton_contains|)))
(assert (forall ((min_ Int) (max Int)) (!
  (and
    (=> (< min_ max) (= (Seq_length (Seq_range min_ max)) (- max min_)))
    (=> (<= max min_) (= (Seq_length (Seq_range min_ max)) 0)))
  :pattern ((Seq_length (Seq_range min_ max)))
  :qid |$Seq[Int]_prog.Seq_range_length|)))
(assert (forall ((min_ Int) (max Int) (j Int)) (!
  (=>
    (and (<= 0 j) (< j (- max min_)))
    (= (Seq_index (Seq_range min_ max) j) (+ min_ j)))
  :pattern ((Seq_index (Seq_range min_ max) j))
  :qid |$Seq[Int]_prog.Seq_range_index|)))
(assert (forall ((min_ Int) (max Int) (v Int)) (!
  (= (Seq_contains (Seq_range min_ max) v) (and (<= min_ v) (< v max)))
  :pattern ((Seq_contains (Seq_range min_ max) v))
  :qid |$Seq[Int]_prog.Seq_range_contains|)))
(assert (forall ((s Set<Int>)) (!
  (<= 0 (Set_card s))
  :pattern ((Set_card s))
  :qid |$Set[Int]_prog.Set_card_nonneg|)))
(assert (forall ((o Int)) (!
  (not (Set_in o (as Set_empty  Set<Int>)))
  :pattern ((Set_in o (as Set_empty  Set<Int>)))
  :qid |$Set[Int]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<Int>)) (!
  (and
    (=> (= (Set_card s) 0) (= s (as Set_empty  Set<Int>)))
    (=> (not (= (Set_card s) 0)) (exists ((x Int))  (Set_in x s))))
  :pattern ((Set_card s))
  :qid |$Set[Int]_prog.Set_card_zero|)))
(assert (forall ((r Int)) (!
  (Set_in r (Set_singleton r))
  :pattern ((Set_singleton r))
  :qid |$Set[Int]_prog.Set_singleton_contains1|)))
(assert (forall ((r Int) (o Int)) (!
  (= (Set_in o (Set_singleton r)) (= r o))
  :pattern ((Set_in o (Set_singleton r)))
  :qid |$Set[Int]_prog.Set_singleton_contains2|)))
(assert (forall ((r Int)) (!
  (= (Set_card (Set_singleton r)) 1)
  :pattern ((Set_card (Set_singleton r)))
  :qid |$Set[Int]_prog.Set_singleton_card|)))
(assert (forall ((a Set<Int>) (x Int) (o Int)) (!
  (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a)))
  :pattern ((Set_in o (Set_unionone a x)))
  :qid |$Set[Int]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<Int>) (x Int)) (!
  (Set_in x (Set_unionone a x))
  :pattern ((Set_unionone a x))
  :qid |$Set[Int]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<Int>) (x Int) (y Int)) (!
  (=> (Set_in y a) (Set_in y (Set_unionone a x)))
  :pattern ((Set_unionone a x) (Set_in y a))
  :qid |$Set[Int]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<Int>) (x Int)) (!
  (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[Int]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<Int>) (x Int)) (!
  (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[Int]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (o Int)) (!
  (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_union a b)))
  :qid |$Set[Int]_prog.Set_union_contains1|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (y Int)) (!
  (=> (Set_in y a) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y a))
  :qid |$Set[Int]_prog.Set_union_contains2|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (y Int)) (!
  (=> (Set_in y b) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y b))
  :qid |$Set[Int]_prog.Set_union_contains3|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (o Int)) (!
  (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_intersection a b)))
  :pattern ((Set_intersection a b) (Set_in o a))
  :pattern ((Set_intersection a b) (Set_in o b))
  :qid |$Set[Int]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (= (Set_union (Set_union a b) b) (Set_union a b))
  :pattern ((Set_union (Set_union a b) b))
  :qid |$Set[Int]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (= (Set_union a (Set_union a b)) (Set_union a b))
  :pattern ((Set_union a (Set_union a b)))
  :qid |$Set[Int]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b))
  :pattern ((Set_intersection (Set_intersection a b) b))
  :qid |$Set[Int]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b))
  :pattern ((Set_intersection a (Set_intersection a b)))
  :qid |$Set[Int]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (=
    (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b)))
    (+ (Set_card a) (Set_card b)))
  :pattern ((Set_card (Set_union a b)))
  :pattern ((Set_card (Set_intersection a b)))
  :qid |$Set[Int]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (o Int)) (!
  (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b))))
  :pattern ((Set_in o (Set_difference a b)))
  :pattern ((Set_difference a b) (Set_in o a))
  :qid |$Set[Int]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (y Int)) (!
  (=> (Set_in y b) (not (Set_in y (Set_difference a b))))
  :pattern ((Set_difference a b) (Set_in y b))
  :qid |$Set[Int]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (and
    (=
      (+
        (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a)))
        (Set_card (Set_intersection a b)))
      (Set_card (Set_union a b)))
    (=
      (Set_card (Set_difference a b))
      (- (Set_card a) (Set_card (Set_intersection a b)))))
  :pattern ((Set_card (Set_difference a b)))
  :qid |$Set[Int]_prog.Set_diff_card|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (=
    (Set_subset a b)
    (forall ((o Int)) (!
      (=> (Set_in o a) (Set_in o b))
      :pattern ((Set_in o a))
      :pattern ((Set_in o b))
      )))
  :pattern ((Set_subset a b))
  :qid |$Set[Int]_prog.Set_subset_def|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (or
    (and (Set_equal a b) (= a b))
    (and
      (not (Set_equal a b))
      (and
        (not (= a b))
        (and
          (= (Set_skolem_diff a b) (Set_skolem_diff b a))
          (not
            (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b)))))))
  :pattern ((Set_equal a b))
  :qid |$Set[Int]_prog.Set_equal_def|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (=> (Set_equal a b) (= a b))
  :pattern ((Set_equal a b))
  :qid |$Set[Int]_prog.Set_equal_ext|)))
; End preamble
; ------------------------------------------------------------
; State saturation: after preamble
(set-option :rlimit 160000)
(check-sat)
; unknown
; ---------- FUNCTION min_int----------
(declare-fun a@0@00 () Int)
(declare-fun b@1@00 () Int)
(declare-fun result@2@00 () Int)
; ----- Well-definedness of specifications -----
(set-option :rlimit 0)
(push) ; 1
(declare-const $t@68@00 $Snap)
(assert (= $t@68@00 ($Snap.combine ($Snap.first $t@68@00) ($Snap.second $t@68@00))))
(assert (= ($Snap.first $t@68@00) $Snap.unit))
; [eval] result <= a
(assert (<= result@2@00 a@0@00))
(assert (=
  ($Snap.second $t@68@00)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@68@00))
    ($Snap.second ($Snap.second $t@68@00)))))
(assert (= ($Snap.first ($Snap.second $t@68@00)) $Snap.unit))
; [eval] result <= b
(assert (<= result@2@00 b@1@00))
(assert (= ($Snap.second ($Snap.second $t@68@00)) $Snap.unit))
; [eval] result == a || result == b
; [eval] result == a
(push) ; 2
; [then-branch: 0 | result@2@00 == a@0@00 | live]
; [else-branch: 0 | result@2@00 != a@0@00 | live]
(push) ; 3
; [then-branch: 0 | result@2@00 == a@0@00]
(assert (= result@2@00 a@0@00))
(pop) ; 3
(push) ; 3
; [else-branch: 0 | result@2@00 != a@0@00]
(assert (not (= result@2@00 a@0@00)))
; [eval] result == b
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= result@2@00 a@0@00)) (= result@2@00 a@0@00)))
(assert (or (= result@2@00 a@0@00) (= result@2@00 b@1@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (= (min_int%limited s@$ a@0@00 b@1@00) (min_int s@$ a@0@00 b@1@00))
  :pattern ((min_int s@$ a@0@00 b@1@00))
  :qid |quant-u-0|)))
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (min_int%stateless a@0@00 b@1@00)
  :pattern ((min_int%limited s@$ a@0@00 b@1@00))
  :qid |quant-u-1|)))
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (let ((result@2@00 (min_int%limited s@$ a@0@00 b@1@00))) (=>
    (min_int%precondition s@$ a@0@00 b@1@00)
    (and
      (and (<= result@2@00 a@0@00) (<= result@2@00 b@1@00))
      (or (= result@2@00 a@0@00) (= result@2@00 b@1@00)))))
  :pattern ((min_int%limited s@$ a@0@00 b@1@00))
  :qid |quant-u-42|)))
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (let ((result@2@00 (min_int%limited s@$ a@0@00 b@1@00))) true)
  :pattern ((min_int%limited s@$ a@0@00 b@1@00))
  :qid |quant-u-43|)))
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (let ((result@2@00 (min_int%limited s@$ a@0@00 b@1@00))) true)
  :pattern ((min_int%limited s@$ a@0@00 b@1@00))
  :qid |quant-u-44|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (a < b ? a : b)
; [eval] a < b
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (< a@0@00 b@1@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (< a@0@00 b@1@00)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1 | a@0@00 < b@1@00 | live]
; [else-branch: 1 | !(a@0@00 < b@1@00) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 1 | a@0@00 < b@1@00]
(assert (< a@0@00 b@1@00))
(pop) ; 3
(push) ; 3
; [else-branch: 1 | !(a@0@00 < b@1@00)]
(assert (not (< a@0@00 b@1@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (< a@0@00 b@1@00)) (< a@0@00 b@1@00)))
(assert (= result@2@00 (ite (< a@0@00 b@1@00) a@0@00 b@1@00)))
; [eval] result <= a
(push) ; 2
(assert (not (<= result@2@00 a@0@00)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (<= result@2@00 a@0@00))
; [eval] result <= b
(push) ; 2
(assert (not (<= result@2@00 b@1@00)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (<= result@2@00 b@1@00))
; [eval] result == a || result == b
; [eval] result == a
(push) ; 2
; [then-branch: 2 | result@2@00 == a@0@00 | live]
; [else-branch: 2 | result@2@00 != a@0@00 | live]
(push) ; 3
; [then-branch: 2 | result@2@00 == a@0@00]
(assert (= result@2@00 a@0@00))
(pop) ; 3
(push) ; 3
; [else-branch: 2 | result@2@00 != a@0@00]
(assert (not (= result@2@00 a@0@00)))
; [eval] result == b
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= result@2@00 a@0@00)) (= result@2@00 a@0@00)))
(push) ; 2
(assert (not (or (= result@2@00 a@0@00) (= result@2@00 b@1@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (or (= result@2@00 a@0@00) (= result@2@00 b@1@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (=>
    (min_int%precondition s@$ a@0@00 b@1@00)
    (= (min_int s@$ a@0@00 b@1@00) (ite (< a@0@00 b@1@00) a@0@00 b@1@00)))
  :pattern ((min_int s@$ a@0@00 b@1@00))
  :qid |quant-u-45|)))
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  true
  :pattern ((min_int s@$ a@0@00 b@1@00))
  :qid |quant-u-46|)))
; ---------- FUNCTION max_int----------
(declare-fun a@3@00 () Int)
(declare-fun b@4@00 () Int)
(declare-fun result@5@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@69@00 $Snap)
(assert (= $t@69@00 ($Snap.combine ($Snap.first $t@69@00) ($Snap.second $t@69@00))))
(assert (= ($Snap.first $t@69@00) $Snap.unit))
; [eval] result >= a
(assert (>= result@5@00 a@3@00))
(assert (=
  ($Snap.second $t@69@00)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@69@00))
    ($Snap.second ($Snap.second $t@69@00)))))
(assert (= ($Snap.first ($Snap.second $t@69@00)) $Snap.unit))
; [eval] result >= b
(assert (>= result@5@00 b@4@00))
(assert (= ($Snap.second ($Snap.second $t@69@00)) $Snap.unit))
; [eval] result == a || result == b
; [eval] result == a
(push) ; 2
; [then-branch: 3 | result@5@00 == a@3@00 | live]
; [else-branch: 3 | result@5@00 != a@3@00 | live]
(push) ; 3
; [then-branch: 3 | result@5@00 == a@3@00]
(assert (= result@5@00 a@3@00))
(pop) ; 3
(push) ; 3
; [else-branch: 3 | result@5@00 != a@3@00]
(assert (not (= result@5@00 a@3@00)))
; [eval] result == b
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= result@5@00 a@3@00)) (= result@5@00 a@3@00)))
(assert (or (= result@5@00 a@3@00) (= result@5@00 b@4@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (a@3@00 Int) (b@4@00 Int)) (!
  (= (max_int%limited s@$ a@3@00 b@4@00) (max_int s@$ a@3@00 b@4@00))
  :pattern ((max_int s@$ a@3@00 b@4@00))
  :qid |quant-u-2|)))
(assert (forall ((s@$ $Snap) (a@3@00 Int) (b@4@00 Int)) (!
  (max_int%stateless a@3@00 b@4@00)
  :pattern ((max_int%limited s@$ a@3@00 b@4@00))
  :qid |quant-u-3|)))
(assert (forall ((s@$ $Snap) (a@3@00 Int) (b@4@00 Int)) (!
  (let ((result@5@00 (max_int%limited s@$ a@3@00 b@4@00))) (=>
    (max_int%precondition s@$ a@3@00 b@4@00)
    (and
      (and (>= result@5@00 a@3@00) (>= result@5@00 b@4@00))
      (or (= result@5@00 a@3@00) (= result@5@00 b@4@00)))))
  :pattern ((max_int%limited s@$ a@3@00 b@4@00))
  :qid |quant-u-47|)))
(assert (forall ((s@$ $Snap) (a@3@00 Int) (b@4@00 Int)) (!
  (let ((result@5@00 (max_int%limited s@$ a@3@00 b@4@00))) true)
  :pattern ((max_int%limited s@$ a@3@00 b@4@00))
  :qid |quant-u-48|)))
(assert (forall ((s@$ $Snap) (a@3@00 Int) (b@4@00 Int)) (!
  (let ((result@5@00 (max_int%limited s@$ a@3@00 b@4@00))) true)
  :pattern ((max_int%limited s@$ a@3@00 b@4@00))
  :qid |quant-u-49|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (a > b ? a : b)
; [eval] a > b
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (> a@3@00 b@4@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (> a@3@00 b@4@00)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 4 | a@3@00 > b@4@00 | live]
; [else-branch: 4 | !(a@3@00 > b@4@00) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 4 | a@3@00 > b@4@00]
(assert (> a@3@00 b@4@00))
(pop) ; 3
(push) ; 3
; [else-branch: 4 | !(a@3@00 > b@4@00)]
(assert (not (> a@3@00 b@4@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (> a@3@00 b@4@00)) (> a@3@00 b@4@00)))
(assert (= result@5@00 (ite (> a@3@00 b@4@00) a@3@00 b@4@00)))
; [eval] result >= a
(push) ; 2
(assert (not (>= result@5@00 a@3@00)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@5@00 a@3@00))
; [eval] result >= b
(push) ; 2
(assert (not (>= result@5@00 b@4@00)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@5@00 b@4@00))
; [eval] result == a || result == b
; [eval] result == a
(push) ; 2
; [then-branch: 5 | result@5@00 == a@3@00 | live]
; [else-branch: 5 | result@5@00 != a@3@00 | live]
(push) ; 3
; [then-branch: 5 | result@5@00 == a@3@00]
(assert (= result@5@00 a@3@00))
(pop) ; 3
(push) ; 3
; [else-branch: 5 | result@5@00 != a@3@00]
(assert (not (= result@5@00 a@3@00)))
; [eval] result == b
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= result@5@00 a@3@00)) (= result@5@00 a@3@00)))
(push) ; 2
(assert (not (or (= result@5@00 a@3@00) (= result@5@00 b@4@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (or (= result@5@00 a@3@00) (= result@5@00 b@4@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (a@3@00 Int) (b@4@00 Int)) (!
  (=>
    (max_int%precondition s@$ a@3@00 b@4@00)
    (= (max_int s@$ a@3@00 b@4@00) (ite (> a@3@00 b@4@00) a@3@00 b@4@00)))
  :pattern ((max_int s@$ a@3@00 b@4@00))
  :qid |quant-u-50|)))
(assert (forall ((s@$ $Snap) (a@3@00 Int) (b@4@00 Int)) (!
  true
  :pattern ((max_int s@$ a@3@00 b@4@00))
  :qid |quant-u-51|)))
; ---------- FUNCTION min_of_three----------
(declare-fun a@6@00 () Int)
(declare-fun b@7@00 () Int)
(declare-fun c@8@00 () Int)
(declare-fun result@9@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@70@00 $Snap)
(assert (= $t@70@00 ($Snap.combine ($Snap.first $t@70@00) ($Snap.second $t@70@00))))
(assert (= ($Snap.first $t@70@00) $Snap.unit))
; [eval] result <= a
(assert (<= result@9@00 a@6@00))
(assert (=
  ($Snap.second $t@70@00)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@70@00))
    ($Snap.second ($Snap.second $t@70@00)))))
(assert (= ($Snap.first ($Snap.second $t@70@00)) $Snap.unit))
; [eval] result <= b
(assert (<= result@9@00 b@7@00))
(assert (= ($Snap.second ($Snap.second $t@70@00)) $Snap.unit))
; [eval] result <= c
(assert (<= result@9@00 c@8@00))
(pop) ; 1
(assert (forall ((s@$ $Snap) (a@6@00 Int) (b@7@00 Int) (c@8@00 Int)) (!
  (=
    (min_of_three%limited s@$ a@6@00 b@7@00 c@8@00)
    (min_of_three s@$ a@6@00 b@7@00 c@8@00))
  :pattern ((min_of_three s@$ a@6@00 b@7@00 c@8@00))
  :qid |quant-u-4|)))
(assert (forall ((s@$ $Snap) (a@6@00 Int) (b@7@00 Int) (c@8@00 Int)) (!
  (min_of_three%stateless a@6@00 b@7@00 c@8@00)
  :pattern ((min_of_three%limited s@$ a@6@00 b@7@00 c@8@00))
  :qid |quant-u-5|)))
(assert (forall ((s@$ $Snap) (a@6@00 Int) (b@7@00 Int) (c@8@00 Int)) (!
  (let ((result@9@00 (min_of_three%limited s@$ a@6@00 b@7@00 c@8@00))) (=>
    (min_of_three%precondition s@$ a@6@00 b@7@00 c@8@00)
    (and
      (<= result@9@00 a@6@00)
      (and (<= result@9@00 b@7@00) (<= result@9@00 c@8@00)))))
  :pattern ((min_of_three%limited s@$ a@6@00 b@7@00 c@8@00))
  :qid |quant-u-52|)))
(assert (forall ((s@$ $Snap) (a@6@00 Int) (b@7@00 Int) (c@8@00 Int)) (!
  (let ((result@9@00 (min_of_three%limited s@$ a@6@00 b@7@00 c@8@00))) true)
  :pattern ((min_of_three%limited s@$ a@6@00 b@7@00 c@8@00))
  :qid |quant-u-53|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] min_int(min_int(a, b), c)
; [eval] min_int(a, b)
(set-option :rlimit 0)
(push) ; 2
(assert (min_int%precondition $Snap.unit a@6@00 b@7@00))
(pop) ; 2
; Joined path conditions
(assert (min_int%precondition $Snap.unit a@6@00 b@7@00))
(push) ; 2
(assert (min_int%precondition $Snap.unit (min_int $Snap.unit a@6@00 b@7@00) c@8@00))
(pop) ; 2
; Joined path conditions
(assert (min_int%precondition $Snap.unit (min_int $Snap.unit a@6@00 b@7@00) c@8@00))
(assert (= result@9@00 (min_int $Snap.unit (min_int $Snap.unit a@6@00 b@7@00) c@8@00)))
; [eval] result <= a
(push) ; 2
(assert (not (<= result@9@00 a@6@00)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (<= result@9@00 a@6@00))
; [eval] result <= b
(push) ; 2
(assert (not (<= result@9@00 b@7@00)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (<= result@9@00 b@7@00))
; [eval] result <= c
(push) ; 2
(assert (not (<= result@9@00 c@8@00)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (<= result@9@00 c@8@00))
(pop) ; 1
(assert (forall ((s@$ $Snap) (a@6@00 Int) (b@7@00 Int) (c@8@00 Int)) (!
  (=>
    (min_of_three%precondition s@$ a@6@00 b@7@00 c@8@00)
    (=
      (min_of_three s@$ a@6@00 b@7@00 c@8@00)
      (min_int $Snap.unit (min_int $Snap.unit a@6@00 b@7@00) c@8@00)))
  :pattern ((min_of_three s@$ a@6@00 b@7@00 c@8@00))
  :qid |quant-u-54|)))
(assert (forall ((s@$ $Snap) (a@6@00 Int) (b@7@00 Int) (c@8@00 Int)) (!
  (=>
    (min_of_three%precondition s@$ a@6@00 b@7@00 c@8@00)
    (and
      (min_int%precondition $Snap.unit a@6@00 b@7@00)
      (min_int%precondition $Snap.unit (min_int $Snap.unit a@6@00 b@7@00) c@8@00)))
  :pattern ((min_of_three s@$ a@6@00 b@7@00 c@8@00))
  :qid |quant-u-55|)))
; ---------- FUNCTION adjacent_products_sum----------
(declare-fun s@10@00 () Seq<Int>)
(declare-fun result@11@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@71@00 $Snap)
(assert (= $t@71@00 $Snap.unit))
; [eval] |s| <= 1 ==> result == 0
; [eval] |s| <= 1
; [eval] |s|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (<= (Seq_length s@10@00) 1))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (<= (Seq_length s@10@00) 1)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 6 | |s@10@00| <= 1 | live]
; [else-branch: 6 | !(|s@10@00| <= 1) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 6 | |s@10@00| <= 1]
(assert (<= (Seq_length s@10@00) 1))
; [eval] result == 0
(pop) ; 3
(push) ; 3
; [else-branch: 6 | !(|s@10@00| <= 1)]
(assert (not (<= (Seq_length s@10@00) 1)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (<= (Seq_length s@10@00) 1)) (<= (Seq_length s@10@00) 1)))
(assert (=> (<= (Seq_length s@10@00) 1) (= result@11@00 0)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@10@00 Seq<Int>)) (!
  (=
    (adjacent_products_sum%limited s@$ s@10@00)
    (adjacent_products_sum s@$ s@10@00))
  :pattern ((adjacent_products_sum s@$ s@10@00))
  :qid |quant-u-6|)))
(assert (forall ((s@$ $Snap) (s@10@00 Seq<Int>)) (!
  (adjacent_products_sum%stateless s@10@00)
  :pattern ((adjacent_products_sum%limited s@$ s@10@00))
  :qid |quant-u-7|)))
(assert (forall ((s@$ $Snap) (s@10@00 Seq<Int>)) (!
  (let ((result@11@00 (adjacent_products_sum%limited s@$ s@10@00))) (=>
    (and
      (adjacent_products_sum%precondition s@$ s@10@00)
      (<= (Seq_length s@10@00) 1))
    (= result@11@00 0)))
  :pattern ((adjacent_products_sum%limited s@$ s@10@00))
  :qid |quant-u-56|)))
(assert (forall ((s@$ $Snap) (s@10@00 Seq<Int>)) (!
  (let ((result@11@00 (adjacent_products_sum%limited s@$ s@10@00))) true)
  :pattern ((adjacent_products_sum%limited s@$ s@10@00))
  :qid |quant-u-57|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|s| <= 1 ? 0 : s[0] * s[1] + adjacent_products_sum(s[1..]))
; [eval] |s| <= 1
; [eval] |s|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (<= (Seq_length s@10@00) 1))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (<= (Seq_length s@10@00) 1)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 7 | |s@10@00| <= 1 | live]
; [else-branch: 7 | !(|s@10@00| <= 1) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 7 | |s@10@00| <= 1]
(assert (<= (Seq_length s@10@00) 1))
(pop) ; 3
(push) ; 3
; [else-branch: 7 | !(|s@10@00| <= 1)]
(assert (not (<= (Seq_length s@10@00) 1)))
; [eval] s[0] * s[1] + adjacent_products_sum(s[1..])
; [eval] s[0] * s[1]
; [eval] s[0]
(push) ; 4
(assert (not (< 0 (Seq_length s@10@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [eval] s[1]
(push) ; 4
(assert (not (< 1 (Seq_length s@10@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [eval] adjacent_products_sum(s[1..])
; [eval] s[1..]
(push) ; 4
(assert (adjacent_products_sum%precondition $Snap.unit (Seq_drop s@10@00 1)))
(pop) ; 4
; Joined path conditions
(assert (adjacent_products_sum%precondition $Snap.unit (Seq_drop s@10@00 1)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (<= (Seq_length s@10@00) 1))
  (and
    (not (<= (Seq_length s@10@00) 1))
    (adjacent_products_sum%precondition $Snap.unit (Seq_drop s@10@00 1)))))
(assert (or (not (<= (Seq_length s@10@00) 1)) (<= (Seq_length s@10@00) 1)))
(assert (=
  result@11@00
  (ite
    (<= (Seq_length s@10@00) 1)
    0
    (+
      (* (Seq_index s@10@00 0) (Seq_index s@10@00 1))
      (adjacent_products_sum $Snap.unit (Seq_drop s@10@00 1))))))
; [eval] |s| <= 1 ==> result == 0
; [eval] |s| <= 1
; [eval] |s|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (<= (Seq_length s@10@00) 1))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (<= (Seq_length s@10@00) 1)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 8 | |s@10@00| <= 1 | live]
; [else-branch: 8 | !(|s@10@00| <= 1) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 8 | |s@10@00| <= 1]
(assert (<= (Seq_length s@10@00) 1))
; [eval] result == 0
(pop) ; 3
(push) ; 3
; [else-branch: 8 | !(|s@10@00| <= 1)]
(assert (not (<= (Seq_length s@10@00) 1)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(push) ; 2
(assert (not (=> (<= (Seq_length s@10@00) 1) (= result@11@00 0))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=> (<= (Seq_length s@10@00) 1) (= result@11@00 0)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@10@00 Seq<Int>)) (!
  (=>
    (adjacent_products_sum%precondition s@$ s@10@00)
    (=
      (adjacent_products_sum s@$ s@10@00)
      (ite
        (<= (Seq_length s@10@00) 1)
        0
        (+
          (* (Seq_index s@10@00 0) (Seq_index s@10@00 1))
          (adjacent_products_sum%limited $Snap.unit (Seq_drop s@10@00 1))))))
  :pattern ((adjacent_products_sum s@$ s@10@00))
  :qid |quant-u-58|)))
(assert (forall ((s@$ $Snap) (s@10@00 Seq<Int>)) (!
  (=>
    (adjacent_products_sum%precondition s@$ s@10@00)
    (ite
      (<= (Seq_length s@10@00) 1)
      true
      (adjacent_products_sum%precondition $Snap.unit (Seq_drop s@10@00 1))))
  :pattern ((adjacent_products_sum s@$ s@10@00))
  :qid |quant-u-59|)))
; ---------- FUNCTION split_at_first----------
(declare-fun s@12@00 () Seq<Int>)
(declare-fun x@13@00 () Int)
(declare-fun idx@14@00 () Int)
(declare-fun result@15@00 () Seq<Int>)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] idx >= 0
(assert (>= idx@14@00 0))
(declare-const $t@72@00 $Snap)
(assert (= $t@72@00 $Snap.unit))
; [eval] idx >= |s| ==> result == s
; [eval] idx >= |s|
; [eval] |s|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= idx@14@00 (Seq_length s@12@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= idx@14@00 (Seq_length s@12@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 9 | idx@14@00 >= |s@12@00| | live]
; [else-branch: 9 | !(idx@14@00 >= |s@12@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 9 | idx@14@00 >= |s@12@00|]
(assert (>= idx@14@00 (Seq_length s@12@00)))
; [eval] result == s
(pop) ; 3
(push) ; 3
; [else-branch: 9 | !(idx@14@00 >= |s@12@00|)]
(assert (not (>= idx@14@00 (Seq_length s@12@00))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or
  (not (>= idx@14@00 (Seq_length s@12@00)))
  (>= idx@14@00 (Seq_length s@12@00))))
(assert (=> (>= idx@14@00 (Seq_length s@12@00)) (Seq_equal result@15@00 s@12@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@12@00 Seq<Int>) (x@13@00 Int) (idx@14@00 Int)) (!
  (=
    (split_at_first%limited s@$ s@12@00 x@13@00 idx@14@00)
    (split_at_first s@$ s@12@00 x@13@00 idx@14@00))
  :pattern ((split_at_first s@$ s@12@00 x@13@00 idx@14@00))
  :qid |quant-u-8|)))
(assert (forall ((s@$ $Snap) (s@12@00 Seq<Int>) (x@13@00 Int) (idx@14@00 Int)) (!
  (split_at_first%stateless s@12@00 x@13@00 idx@14@00)
  :pattern ((split_at_first%limited s@$ s@12@00 x@13@00 idx@14@00))
  :qid |quant-u-9|)))
(assert (forall ((s@$ $Snap) (s@12@00 Seq<Int>) (x@13@00 Int) (idx@14@00 Int)) (!
  (let ((result@15@00 (split_at_first%limited s@$ s@12@00 x@13@00 idx@14@00))) (=>
    (and
      (split_at_first%precondition s@$ s@12@00 x@13@00 idx@14@00)
      (>= idx@14@00 (Seq_length s@12@00)))
    (Seq_equal result@15@00 s@12@00)))
  :pattern ((split_at_first%limited s@$ s@12@00 x@13@00 idx@14@00))
  :qid |quant-u-60|)))
(assert (forall ((s@$ $Snap) (s@12@00 Seq<Int>) (x@13@00 Int) (idx@14@00 Int)) (!
  (let ((result@15@00 (split_at_first%limited s@$ s@12@00 x@13@00 idx@14@00))) true)
  :pattern ((split_at_first%limited s@$ s@12@00 x@13@00 idx@14@00))
  :qid |quant-u-61|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (>= idx@14@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (idx >= |s| ? s : (s[idx] == x ? s[..idx] : split_at_first(s, x, idx + 1)))
; [eval] idx >= |s|
; [eval] |s|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= idx@14@00 (Seq_length s@12@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= idx@14@00 (Seq_length s@12@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 10 | idx@14@00 >= |s@12@00| | live]
; [else-branch: 10 | !(idx@14@00 >= |s@12@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 10 | idx@14@00 >= |s@12@00|]
(assert (>= idx@14@00 (Seq_length s@12@00)))
(pop) ; 3
(push) ; 3
; [else-branch: 10 | !(idx@14@00 >= |s@12@00|)]
(assert (not (>= idx@14@00 (Seq_length s@12@00))))
; [eval] (s[idx] == x ? s[..idx] : split_at_first(s, x, idx + 1))
; [eval] s[idx] == x
; [eval] s[idx]
(push) ; 4
(assert (not (< idx@14@00 (Seq_length s@12@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (= (Seq_index s@12@00 idx@14@00) x@13@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= (Seq_index s@12@00 idx@14@00) x@13@00)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 11 | s@12@00[idx@14@00] == x@13@00 | live]
; [else-branch: 11 | s@12@00[idx@14@00] != x@13@00 | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 11 | s@12@00[idx@14@00] == x@13@00]
(assert (= (Seq_index s@12@00 idx@14@00) x@13@00))
; [eval] s[..idx]
(pop) ; 5
(push) ; 5
; [else-branch: 11 | s@12@00[idx@14@00] != x@13@00]
(assert (not (= (Seq_index s@12@00 idx@14@00) x@13@00)))
; [eval] split_at_first(s, x, idx + 1)
; [eval] idx + 1
(push) ; 6
; [eval] idx >= 0
(push) ; 7
(assert (not (>= (+ idx@14@00 1) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (>= (+ idx@14@00 1) 0))
(assert (split_at_first%precondition $Snap.unit s@12@00 x@13@00 (+ idx@14@00 1)))
(pop) ; 6
; Joined path conditions
(assert (and
  (>= (+ idx@14@00 1) 0)
  (split_at_first%precondition $Snap.unit s@12@00 x@13@00 (+ idx@14@00 1))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Seq_index s@12@00 idx@14@00) x@13@00))
  (and
    (not (= (Seq_index s@12@00 idx@14@00) x@13@00))
    (>= (+ idx@14@00 1) 0)
    (split_at_first%precondition $Snap.unit s@12@00 x@13@00 (+ idx@14@00 1)))))
(assert (or
  (not (= (Seq_index s@12@00 idx@14@00) x@13@00))
  (= (Seq_index s@12@00 idx@14@00) x@13@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (>= idx@14@00 (Seq_length s@12@00)))
  (and
    (not (>= idx@14@00 (Seq_length s@12@00)))
    (=>
      (not (= (Seq_index s@12@00 idx@14@00) x@13@00))
      (and
        (not (= (Seq_index s@12@00 idx@14@00) x@13@00))
        (>= (+ idx@14@00 1) 0)
        (split_at_first%precondition $Snap.unit s@12@00 x@13@00 (+ idx@14@00 1))))
    (or
      (not (= (Seq_index s@12@00 idx@14@00) x@13@00))
      (= (Seq_index s@12@00 idx@14@00) x@13@00)))))
(assert (or
  (not (>= idx@14@00 (Seq_length s@12@00)))
  (>= idx@14@00 (Seq_length s@12@00))))
(assert (=
  result@15@00
  (ite
    (>= idx@14@00 (Seq_length s@12@00))
    s@12@00
    (ite
      (= (Seq_index s@12@00 idx@14@00) x@13@00)
      (Seq_take s@12@00 idx@14@00)
      (split_at_first $Snap.unit s@12@00 x@13@00 (+ idx@14@00 1))))))
; [eval] idx >= |s| ==> result == s
; [eval] idx >= |s|
; [eval] |s|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= idx@14@00 (Seq_length s@12@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= idx@14@00 (Seq_length s@12@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 12 | idx@14@00 >= |s@12@00| | live]
; [else-branch: 12 | !(idx@14@00 >= |s@12@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 12 | idx@14@00 >= |s@12@00|]
(assert (>= idx@14@00 (Seq_length s@12@00)))
; [eval] result == s
(pop) ; 3
(push) ; 3
; [else-branch: 12 | !(idx@14@00 >= |s@12@00|)]
(assert (not (>= idx@14@00 (Seq_length s@12@00))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(push) ; 2
(assert (not (=> (>= idx@14@00 (Seq_length s@12@00)) (Seq_equal result@15@00 s@12@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=> (>= idx@14@00 (Seq_length s@12@00)) (Seq_equal result@15@00 s@12@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@12@00 Seq<Int>) (x@13@00 Int) (idx@14@00 Int)) (!
  (=>
    (split_at_first%precondition s@$ s@12@00 x@13@00 idx@14@00)
    (=
      (split_at_first s@$ s@12@00 x@13@00 idx@14@00)
      (ite
        (>= idx@14@00 (Seq_length s@12@00))
        s@12@00
        (ite
          (= (Seq_index s@12@00 idx@14@00) x@13@00)
          (Seq_take s@12@00 idx@14@00)
          (split_at_first%limited $Snap.unit s@12@00 x@13@00 (+ idx@14@00 1))))))
  :pattern ((split_at_first s@$ s@12@00 x@13@00 idx@14@00))
  :qid |quant-u-62|)))
(assert (forall ((s@$ $Snap) (s@12@00 Seq<Int>) (x@13@00 Int) (idx@14@00 Int)) (!
  (=>
    (split_at_first%precondition s@$ s@12@00 x@13@00 idx@14@00)
    (ite
      (>= idx@14@00 (Seq_length s@12@00))
      true
      (ite
        (= (Seq_index s@12@00 idx@14@00) x@13@00)
        true
        (split_at_first%precondition $Snap.unit s@12@00 x@13@00 (+ idx@14@00 1)))))
  :pattern ((split_at_first s@$ s@12@00 x@13@00 idx@14@00))
  :qid |quant-u-63|)))
; ---------- FUNCTION max_subarray_sum----------
(declare-fun s@16@00 () Seq<Int>)
(declare-fun idx@17@00 () Int)
(declare-fun current_sum@18@00 () Int)
(declare-fun max_sum@19@00 () Int)
(declare-fun result@20@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] idx >= 0
(assert (>= idx@17@00 0))
(declare-const $t@73@00 $Snap)
(assert (= $t@73@00 $Snap.unit))
; [eval] idx >= |s| ==> result == max_sum
; [eval] idx >= |s|
; [eval] |s|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= idx@17@00 (Seq_length s@16@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= idx@17@00 (Seq_length s@16@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 13 | idx@17@00 >= |s@16@00| | live]
; [else-branch: 13 | !(idx@17@00 >= |s@16@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 13 | idx@17@00 >= |s@16@00|]
(assert (>= idx@17@00 (Seq_length s@16@00)))
; [eval] result == max_sum
(pop) ; 3
(push) ; 3
; [else-branch: 13 | !(idx@17@00 >= |s@16@00|)]
(assert (not (>= idx@17@00 (Seq_length s@16@00))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or
  (not (>= idx@17@00 (Seq_length s@16@00)))
  (>= idx@17@00 (Seq_length s@16@00))))
(assert (=> (>= idx@17@00 (Seq_length s@16@00)) (= result@20@00 max_sum@19@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@16@00 Seq<Int>) (idx@17@00 Int) (current_sum@18@00 Int) (max_sum@19@00 Int)) (!
  (=
    (max_subarray_sum%limited s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00)
    (max_subarray_sum s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))
  :pattern ((max_subarray_sum s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))
  :qid |quant-u-10|)))
(assert (forall ((s@$ $Snap) (s@16@00 Seq<Int>) (idx@17@00 Int) (current_sum@18@00 Int) (max_sum@19@00 Int)) (!
  (max_subarray_sum%stateless s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00)
  :pattern ((max_subarray_sum%limited s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))
  :qid |quant-u-11|)))
(assert (forall ((s@$ $Snap) (s@16@00 Seq<Int>) (idx@17@00 Int) (current_sum@18@00 Int) (max_sum@19@00 Int)) (!
  (let ((result@20@00 (max_subarray_sum%limited s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))) (=>
    (and
      (max_subarray_sum%precondition s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00)
      (>= idx@17@00 (Seq_length s@16@00)))
    (= result@20@00 max_sum@19@00)))
  :pattern ((max_subarray_sum%limited s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))
  :qid |quant-u-64|)))
(assert (forall ((s@$ $Snap) (s@16@00 Seq<Int>) (idx@17@00 Int) (current_sum@18@00 Int) (max_sum@19@00 Int)) (!
  (let ((result@20@00 (max_subarray_sum%limited s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))) true)
  :pattern ((max_subarray_sum%limited s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))
  :qid |quant-u-65|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (>= idx@17@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (idx >= |s| ? max_sum : (let new_current == (max_int(s[idx], current_sum + s[idx])) in (let new_max == (max_int(max_sum, new_current)) in max_subarray_sum(s, idx + 1, new_current, new_max))))
; [eval] idx >= |s|
; [eval] |s|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= idx@17@00 (Seq_length s@16@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= idx@17@00 (Seq_length s@16@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 14 | idx@17@00 >= |s@16@00| | live]
; [else-branch: 14 | !(idx@17@00 >= |s@16@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 14 | idx@17@00 >= |s@16@00|]
(assert (>= idx@17@00 (Seq_length s@16@00)))
(pop) ; 3
(push) ; 3
; [else-branch: 14 | !(idx@17@00 >= |s@16@00|)]
(assert (not (>= idx@17@00 (Seq_length s@16@00))))
; [eval] (let new_current == (max_int(s[idx], current_sum + s[idx])) in (let new_max == (max_int(max_sum, new_current)) in max_subarray_sum(s, idx + 1, new_current, new_max)))
; [eval] max_int(s[idx], current_sum + s[idx])
; [eval] s[idx]
(push) ; 4
(assert (not (< idx@17@00 (Seq_length s@16@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [eval] current_sum + s[idx]
; [eval] s[idx]
(push) ; 4
(assert (not (< idx@17@00 (Seq_length s@16@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(push) ; 4
(assert (max_int%precondition $Snap.unit (Seq_index s@16@00 idx@17@00) (+
  current_sum@18@00
  (Seq_index s@16@00 idx@17@00))))
(pop) ; 4
; Joined path conditions
(assert (max_int%precondition $Snap.unit (Seq_index s@16@00 idx@17@00) (+
  current_sum@18@00
  (Seq_index s@16@00 idx@17@00))))
(declare-fun letvar@74@00 ($Snap Seq<Int> Int Int Int) Int)
(assert (=
  (letvar@74@00 s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00)
  (max_int $Snap.unit (Seq_index s@16@00 idx@17@00) (+
    current_sum@18@00
    (Seq_index s@16@00 idx@17@00)))))
; [eval] (let new_max == (max_int(max_sum, new_current)) in max_subarray_sum(s, idx + 1, new_current, new_max))
; [eval] max_int(max_sum, new_current)
(push) ; 4
(assert (max_int%precondition $Snap.unit max_sum@19@00 (max_int $Snap.unit (Seq_index
  s@16@00
  idx@17@00) (+ current_sum@18@00 (Seq_index s@16@00 idx@17@00)))))
(pop) ; 4
; Joined path conditions
(assert (max_int%precondition $Snap.unit max_sum@19@00 (max_int $Snap.unit (Seq_index
  s@16@00
  idx@17@00) (+ current_sum@18@00 (Seq_index s@16@00 idx@17@00)))))
(declare-fun letvar@75@00 ($Snap Seq<Int> Int Int Int) Int)
(assert (=
  (letvar@75@00 s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00)
  (max_int $Snap.unit max_sum@19@00 (max_int $Snap.unit (Seq_index
    s@16@00
    idx@17@00) (+ current_sum@18@00 (Seq_index s@16@00 idx@17@00))))))
; [eval] max_subarray_sum(s, idx + 1, new_current, new_max)
; [eval] idx + 1
(push) ; 4
; [eval] idx >= 0
(push) ; 5
(assert (not (>= (+ idx@17@00 1) 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (>= (+ idx@17@00 1) 0))
(assert (max_subarray_sum%precondition $Snap.unit s@16@00 (+ idx@17@00 1) (max_int $Snap.unit (Seq_index
  s@16@00
  idx@17@00) (+ current_sum@18@00 (Seq_index s@16@00 idx@17@00))) (max_int $Snap.unit max_sum@19@00 (max_int $Snap.unit (Seq_index
  s@16@00
  idx@17@00) (+ current_sum@18@00 (Seq_index s@16@00 idx@17@00))))))
(pop) ; 4
; Joined path conditions
(assert (and
  (>= (+ idx@17@00 1) 0)
  (max_subarray_sum%precondition $Snap.unit s@16@00 (+ idx@17@00 1) (max_int $Snap.unit (Seq_index
    s@16@00
    idx@17@00) (+ current_sum@18@00 (Seq_index s@16@00 idx@17@00))) (max_int $Snap.unit max_sum@19@00 (max_int $Snap.unit (Seq_index
    s@16@00
    idx@17@00) (+ current_sum@18@00 (Seq_index s@16@00 idx@17@00)))))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (>= idx@17@00 (Seq_length s@16@00)))
  (and
    (not (>= idx@17@00 (Seq_length s@16@00)))
    (max_int%precondition $Snap.unit (Seq_index s@16@00 idx@17@00) (+
      current_sum@18@00
      (Seq_index s@16@00 idx@17@00)))
    (=
      (letvar@74@00 s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00)
      (max_int $Snap.unit (Seq_index s@16@00 idx@17@00) (+
        current_sum@18@00
        (Seq_index s@16@00 idx@17@00))))
    (max_int%precondition $Snap.unit max_sum@19@00 (max_int $Snap.unit (Seq_index
      s@16@00
      idx@17@00) (+ current_sum@18@00 (Seq_index s@16@00 idx@17@00))))
    (=
      (letvar@75@00 s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00)
      (max_int $Snap.unit max_sum@19@00 (max_int $Snap.unit (Seq_index
        s@16@00
        idx@17@00) (+ current_sum@18@00 (Seq_index s@16@00 idx@17@00)))))
    (>= (+ idx@17@00 1) 0)
    (max_subarray_sum%precondition $Snap.unit s@16@00 (+ idx@17@00 1) (max_int $Snap.unit (Seq_index
      s@16@00
      idx@17@00) (+ current_sum@18@00 (Seq_index s@16@00 idx@17@00))) (max_int $Snap.unit max_sum@19@00 (max_int $Snap.unit (Seq_index
      s@16@00
      idx@17@00) (+ current_sum@18@00 (Seq_index s@16@00 idx@17@00))))))))
(assert (or
  (not (>= idx@17@00 (Seq_length s@16@00)))
  (>= idx@17@00 (Seq_length s@16@00))))
(assert (=
  result@20@00
  (ite
    (>= idx@17@00 (Seq_length s@16@00))
    max_sum@19@00
    (max_subarray_sum $Snap.unit s@16@00 (+ idx@17@00 1) (max_int $Snap.unit (Seq_index
      s@16@00
      idx@17@00) (+ current_sum@18@00 (Seq_index s@16@00 idx@17@00))) (max_int $Snap.unit max_sum@19@00 (max_int $Snap.unit (Seq_index
      s@16@00
      idx@17@00) (+ current_sum@18@00 (Seq_index s@16@00 idx@17@00))))))))
; [eval] idx >= |s| ==> result == max_sum
; [eval] idx >= |s|
; [eval] |s|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= idx@17@00 (Seq_length s@16@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= idx@17@00 (Seq_length s@16@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 15 | idx@17@00 >= |s@16@00| | live]
; [else-branch: 15 | !(idx@17@00 >= |s@16@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 15 | idx@17@00 >= |s@16@00|]
(assert (>= idx@17@00 (Seq_length s@16@00)))
; [eval] result == max_sum
(pop) ; 3
(push) ; 3
; [else-branch: 15 | !(idx@17@00 >= |s@16@00|)]
(assert (not (>= idx@17@00 (Seq_length s@16@00))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(push) ; 2
(assert (not (=> (>= idx@17@00 (Seq_length s@16@00)) (= result@20@00 max_sum@19@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=> (>= idx@17@00 (Seq_length s@16@00)) (= result@20@00 max_sum@19@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@16@00 Seq<Int>) (idx@17@00 Int) (current_sum@18@00 Int) (max_sum@19@00 Int)) (!
  (=>
    (max_subarray_sum%precondition s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00)
    (=
      (max_subarray_sum s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00)
      (ite
        (>= idx@17@00 (Seq_length s@16@00))
        max_sum@19@00
        (let ((new_current (max_int $Snap.unit (Seq_index s@16@00 idx@17@00) (+
          current_sum@18@00
          (Seq_index s@16@00 idx@17@00))))) (let ((new_max (max_int $Snap.unit max_sum@19@00 new_current))) (max_subarray_sum%limited $Snap.unit s@16@00 (+
          idx@17@00
          1) new_current new_max))))))
  :pattern ((max_subarray_sum s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))
  :qid |quant-u-66|)))
(assert (forall ((s@$ $Snap) (s@16@00 Seq<Int>) (idx@17@00 Int) (current_sum@18@00 Int) (max_sum@19@00 Int)) (!
  (=>
    (max_subarray_sum%precondition s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00)
    (ite
      (>= idx@17@00 (Seq_length s@16@00))
      true
      (and
        (max_int%precondition $Snap.unit (Seq_index s@16@00 idx@17@00) (+
          current_sum@18@00
          (Seq_index s@16@00 idx@17@00)))
        (let ((new_current (max_int $Snap.unit (Seq_index s@16@00 idx@17@00) (+
          current_sum@18@00
          (Seq_index s@16@00 idx@17@00))))) (and
          (max_int%precondition $Snap.unit max_sum@19@00 new_current)
          (let ((new_max (max_int $Snap.unit max_sum@19@00 new_current))) (max_subarray_sum%precondition $Snap.unit s@16@00 (+
            idx@17@00
            1) new_current new_max)))))))
  :pattern ((max_subarray_sum s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))
  :qid |quant-u-67|)))
; ---------- FUNCTION is_decreasing----------
(declare-fun s@21@00 () Seq<Int>)
(declare-fun result@22@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@21@00 Seq<Int>)) (!
  (= (is_decreasing%limited s@$ s@21@00) (is_decreasing s@$ s@21@00))
  :pattern ((is_decreasing s@$ s@21@00))
  :qid |quant-u-12|)))
(assert (forall ((s@$ $Snap) (s@21@00 Seq<Int>)) (!
  (is_decreasing%stateless s@21@00)
  :pattern ((is_decreasing%limited s@$ s@21@00))
  :qid |quant-u-13|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|s| <= 1 ? true : s[0] >= s[1] && is_decreasing(s[1..]))
; [eval] |s| <= 1
; [eval] |s|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (<= (Seq_length s@21@00) 1))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (<= (Seq_length s@21@00) 1)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 16 | |s@21@00| <= 1 | live]
; [else-branch: 16 | !(|s@21@00| <= 1) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 16 | |s@21@00| <= 1]
(assert (<= (Seq_length s@21@00) 1))
(pop) ; 3
(push) ; 3
; [else-branch: 16 | !(|s@21@00| <= 1)]
(assert (not (<= (Seq_length s@21@00) 1)))
; [eval] s[0] >= s[1] && is_decreasing(s[1..])
; [eval] s[0] >= s[1]
; [eval] s[0]
(push) ; 4
(assert (not (< 0 (Seq_length s@21@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [eval] s[1]
(push) ; 4
(assert (not (< 1 (Seq_length s@21@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(push) ; 4
; [then-branch: 17 | !(s@21@00[0] >= s@21@00[1]) | live]
; [else-branch: 17 | s@21@00[0] >= s@21@00[1] | live]
(push) ; 5
; [then-branch: 17 | !(s@21@00[0] >= s@21@00[1])]
(assert (not (>= (Seq_index s@21@00 0) (Seq_index s@21@00 1))))
(pop) ; 5
(push) ; 5
; [else-branch: 17 | s@21@00[0] >= s@21@00[1]]
(assert (>= (Seq_index s@21@00 0) (Seq_index s@21@00 1)))
; [eval] is_decreasing(s[1..])
; [eval] s[1..]
(push) ; 6
(assert (is_decreasing%precondition $Snap.unit (Seq_drop s@21@00 1)))
(pop) ; 6
; Joined path conditions
(assert (is_decreasing%precondition $Snap.unit (Seq_drop s@21@00 1)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (>= (Seq_index s@21@00 0) (Seq_index s@21@00 1))
  (and
    (>= (Seq_index s@21@00 0) (Seq_index s@21@00 1))
    (is_decreasing%precondition $Snap.unit (Seq_drop s@21@00 1)))))
(assert (or
  (>= (Seq_index s@21@00 0) (Seq_index s@21@00 1))
  (not (>= (Seq_index s@21@00 0) (Seq_index s@21@00 1)))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (<= (Seq_length s@21@00) 1))
  (and
    (not (<= (Seq_length s@21@00) 1))
    (=>
      (>= (Seq_index s@21@00 0) (Seq_index s@21@00 1))
      (and
        (>= (Seq_index s@21@00 0) (Seq_index s@21@00 1))
        (is_decreasing%precondition $Snap.unit (Seq_drop s@21@00 1))))
    (or
      (>= (Seq_index s@21@00 0) (Seq_index s@21@00 1))
      (not (>= (Seq_index s@21@00 0) (Seq_index s@21@00 1)))))))
(assert (or (not (<= (Seq_length s@21@00) 1)) (<= (Seq_length s@21@00) 1)))
(assert (=
  result@22@00
  (ite
    (<= (Seq_length s@21@00) 1)
    true
    (and
      (>= (Seq_index s@21@00 0) (Seq_index s@21@00 1))
      (is_decreasing $Snap.unit (Seq_drop s@21@00 1))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@21@00 Seq<Int>)) (!
  (=>
    (is_decreasing%precondition s@$ s@21@00)
    (=
      (is_decreasing s@$ s@21@00)
      (ite
        (<= (Seq_length s@21@00) 1)
        true
        (and
          (>= (Seq_index s@21@00 0) (Seq_index s@21@00 1))
          (is_decreasing%limited $Snap.unit (Seq_drop s@21@00 1))))))
  :pattern ((is_decreasing s@$ s@21@00))
  :qid |quant-u-68|)))
(assert (forall ((s@$ $Snap) (s@21@00 Seq<Int>)) (!
  (=>
    (is_decreasing%precondition s@$ s@21@00)
    (ite
      (<= (Seq_length s@21@00) 1)
      true
      (=>
        (>= (Seq_index s@21@00 0) (Seq_index s@21@00 1))
        (is_decreasing%precondition $Snap.unit (Seq_drop s@21@00 1)))))
  :pattern ((is_decreasing s@$ s@21@00))
  :qid |quant-u-69|)))
; ---------- FUNCTION lcp_length----------
(declare-fun s1@23@00 () Seq<Int>)
(declare-fun s2@24@00 () Seq<Int>)
(declare-fun idx@25@00 () Int)
(declare-fun result@26@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] idx >= 0
(assert (>= idx@25@00 0))
(declare-const $t@76@00 $Snap)
(assert (= $t@76@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@26@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s1@23@00 Seq<Int>) (s2@24@00 Seq<Int>) (idx@25@00 Int)) (!
  (=
    (lcp_length%limited s@$ s1@23@00 s2@24@00 idx@25@00)
    (lcp_length s@$ s1@23@00 s2@24@00 idx@25@00))
  :pattern ((lcp_length s@$ s1@23@00 s2@24@00 idx@25@00))
  :qid |quant-u-14|)))
(assert (forall ((s@$ $Snap) (s1@23@00 Seq<Int>) (s2@24@00 Seq<Int>) (idx@25@00 Int)) (!
  (lcp_length%stateless s1@23@00 s2@24@00 idx@25@00)
  :pattern ((lcp_length%limited s@$ s1@23@00 s2@24@00 idx@25@00))
  :qid |quant-u-15|)))
(assert (forall ((s@$ $Snap) (s1@23@00 Seq<Int>) (s2@24@00 Seq<Int>) (idx@25@00 Int)) (!
  (let ((result@26@00 (lcp_length%limited s@$ s1@23@00 s2@24@00 idx@25@00))) (=>
    (lcp_length%precondition s@$ s1@23@00 s2@24@00 idx@25@00)
    (>= result@26@00 0)))
  :pattern ((lcp_length%limited s@$ s1@23@00 s2@24@00 idx@25@00))
  :qid |quant-u-70|)))
(assert (forall ((s@$ $Snap) (s1@23@00 Seq<Int>) (s2@24@00 Seq<Int>) (idx@25@00 Int)) (!
  (let ((result@26@00 (lcp_length%limited s@$ s1@23@00 s2@24@00 idx@25@00))) true)
  :pattern ((lcp_length%limited s@$ s1@23@00 s2@24@00 idx@25@00))
  :qid |quant-u-71|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (>= idx@25@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (idx >= |s1| || idx >= |s2| ? idx : (s1[idx] != s2[idx] ? idx : lcp_length(s1, s2, idx + 1)))
; [eval] idx >= |s1| || idx >= |s2|
; [eval] idx >= |s1|
; [eval] |s1|
(set-option :rlimit 0)
(push) ; 2
; [then-branch: 18 | idx@25@00 >= |s1@23@00| | live]
; [else-branch: 18 | !(idx@25@00 >= |s1@23@00|) | live]
(push) ; 3
; [then-branch: 18 | idx@25@00 >= |s1@23@00|]
(assert (>= idx@25@00 (Seq_length s1@23@00)))
(pop) ; 3
(push) ; 3
; [else-branch: 18 | !(idx@25@00 >= |s1@23@00|)]
(assert (not (>= idx@25@00 (Seq_length s1@23@00))))
; [eval] idx >= |s2|
; [eval] |s2|
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or
  (not (>= idx@25@00 (Seq_length s1@23@00)))
  (>= idx@25@00 (Seq_length s1@23@00))))
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not
  (or (>= idx@25@00 (Seq_length s1@23@00)) (>= idx@25@00 (Seq_length s2@24@00))))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (or (>= idx@25@00 (Seq_length s1@23@00)) (>= idx@25@00 (Seq_length s2@24@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 19 | idx@25@00 >= |s1@23@00| || idx@25@00 >= |s2@24@00| | live]
; [else-branch: 19 | !(idx@25@00 >= |s1@23@00| || idx@25@00 >= |s2@24@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 19 | idx@25@00 >= |s1@23@00| || idx@25@00 >= |s2@24@00|]
(assert (or (>= idx@25@00 (Seq_length s1@23@00)) (>= idx@25@00 (Seq_length s2@24@00))))
(pop) ; 3
(push) ; 3
; [else-branch: 19 | !(idx@25@00 >= |s1@23@00| || idx@25@00 >= |s2@24@00|)]
(assert (not
  (or (>= idx@25@00 (Seq_length s1@23@00)) (>= idx@25@00 (Seq_length s2@24@00)))))
; [eval] (s1[idx] != s2[idx] ? idx : lcp_length(s1, s2, idx + 1))
; [eval] s1[idx] != s2[idx]
; [eval] s1[idx]
(push) ; 4
(assert (not (< idx@25@00 (Seq_length s1@23@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [eval] s2[idx]
(push) ; 4
(assert (not (< idx@25@00 (Seq_length s2@24@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= (Seq_index s1@23@00 idx@25@00) (Seq_index s2@24@00 idx@25@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (= (Seq_index s1@23@00 idx@25@00) (Seq_index s2@24@00 idx@25@00)))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 20 | s1@23@00[idx@25@00] != s2@24@00[idx@25@00] | live]
; [else-branch: 20 | s1@23@00[idx@25@00] == s2@24@00[idx@25@00] | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 20 | s1@23@00[idx@25@00] != s2@24@00[idx@25@00]]
(assert (not (= (Seq_index s1@23@00 idx@25@00) (Seq_index s2@24@00 idx@25@00))))
(pop) ; 5
(push) ; 5
; [else-branch: 20 | s1@23@00[idx@25@00] == s2@24@00[idx@25@00]]
(assert (= (Seq_index s1@23@00 idx@25@00) (Seq_index s2@24@00 idx@25@00)))
; [eval] lcp_length(s1, s2, idx + 1)
; [eval] idx + 1
(push) ; 6
; [eval] idx >= 0
(push) ; 7
(assert (not (>= (+ idx@25@00 1) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (>= (+ idx@25@00 1) 0))
(assert (lcp_length%precondition $Snap.unit s1@23@00 s2@24@00 (+ idx@25@00 1)))
(pop) ; 6
; Joined path conditions
(assert (and
  (>= (+ idx@25@00 1) 0)
  (lcp_length%precondition $Snap.unit s1@23@00 s2@24@00 (+ idx@25@00 1))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (= (Seq_index s1@23@00 idx@25@00) (Seq_index s2@24@00 idx@25@00))
  (and
    (= (Seq_index s1@23@00 idx@25@00) (Seq_index s2@24@00 idx@25@00))
    (>= (+ idx@25@00 1) 0)
    (lcp_length%precondition $Snap.unit s1@23@00 s2@24@00 (+ idx@25@00 1)))))
(assert (or
  (= (Seq_index s1@23@00 idx@25@00) (Seq_index s2@24@00 idx@25@00))
  (not (= (Seq_index s1@23@00 idx@25@00) (Seq_index s2@24@00 idx@25@00)))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not
    (or
      (>= idx@25@00 (Seq_length s1@23@00))
      (>= idx@25@00 (Seq_length s2@24@00))))
  (and
    (not
      (or
        (>= idx@25@00 (Seq_length s1@23@00))
        (>= idx@25@00 (Seq_length s2@24@00))))
    (=>
      (= (Seq_index s1@23@00 idx@25@00) (Seq_index s2@24@00 idx@25@00))
      (and
        (= (Seq_index s1@23@00 idx@25@00) (Seq_index s2@24@00 idx@25@00))
        (>= (+ idx@25@00 1) 0)
        (lcp_length%precondition $Snap.unit s1@23@00 s2@24@00 (+ idx@25@00 1))))
    (or
      (= (Seq_index s1@23@00 idx@25@00) (Seq_index s2@24@00 idx@25@00))
      (not (= (Seq_index s1@23@00 idx@25@00) (Seq_index s2@24@00 idx@25@00)))))))
(assert (or
  (not
    (or
      (>= idx@25@00 (Seq_length s1@23@00))
      (>= idx@25@00 (Seq_length s2@24@00))))
  (or (>= idx@25@00 (Seq_length s1@23@00)) (>= idx@25@00 (Seq_length s2@24@00)))))
(assert (=
  result@26@00
  (ite
    (or
      (>= idx@25@00 (Seq_length s1@23@00))
      (>= idx@25@00 (Seq_length s2@24@00)))
    idx@25@00
    (ite
      (not (= (Seq_index s1@23@00 idx@25@00) (Seq_index s2@24@00 idx@25@00)))
      idx@25@00
      (lcp_length $Snap.unit s1@23@00 s2@24@00 (+ idx@25@00 1))))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@26@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@26@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s1@23@00 Seq<Int>) (s2@24@00 Seq<Int>) (idx@25@00 Int)) (!
  (=>
    (lcp_length%precondition s@$ s1@23@00 s2@24@00 idx@25@00)
    (=
      (lcp_length s@$ s1@23@00 s2@24@00 idx@25@00)
      (ite
        (or
          (>= idx@25@00 (Seq_length s1@23@00))
          (>= idx@25@00 (Seq_length s2@24@00)))
        idx@25@00
        (ite
          (not (= (Seq_index s1@23@00 idx@25@00) (Seq_index s2@24@00 idx@25@00)))
          idx@25@00
          (lcp_length%limited $Snap.unit s1@23@00 s2@24@00 (+ idx@25@00 1))))))
  :pattern ((lcp_length s@$ s1@23@00 s2@24@00 idx@25@00))
  :qid |quant-u-72|)))
(assert (forall ((s@$ $Snap) (s1@23@00 Seq<Int>) (s2@24@00 Seq<Int>) (idx@25@00 Int)) (!
  (=>
    (lcp_length%precondition s@$ s1@23@00 s2@24@00 idx@25@00)
    (ite
      (or
        (>= idx@25@00 (Seq_length s1@23@00))
        (>= idx@25@00 (Seq_length s2@24@00)))
      true
      (ite
        (not (= (Seq_index s1@23@00 idx@25@00) (Seq_index s2@24@00 idx@25@00)))
        true
        (lcp_length%precondition $Snap.unit s1@23@00 s2@24@00 (+ idx@25@00 1)))))
  :pattern ((lcp_length s@$ s1@23@00 s2@24@00 idx@25@00))
  :qid |quant-u-73|)))
; ---------- FUNCTION interleave----------
(declare-fun s1@27@00 () Seq<Int>)
(declare-fun s2@28@00 () Seq<Int>)
(declare-fun result@29@00 () Seq<Int>)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@77@00 $Snap)
(assert (= $t@77@00 ($Snap.combine ($Snap.first $t@77@00) ($Snap.second $t@77@00))))
(assert (= ($Snap.first $t@77@00) $Snap.unit))
; [eval] |result| == |s1| + |s2|
; [eval] |result|
; [eval] |s1| + |s2|
; [eval] |s1|
; [eval] |s2|
(assert (= (Seq_length result@29@00) (+ (Seq_length s1@27@00) (Seq_length s2@28@00))))
(assert (=
  ($Snap.second $t@77@00)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@77@00))
    ($Snap.second ($Snap.second $t@77@00)))))
(assert (= ($Snap.first ($Snap.second $t@77@00)) $Snap.unit))
; [eval] |s1| == 0 ==> result == s2
; [eval] |s1| == 0
; [eval] |s1|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Seq_length s1@27@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Seq_length s1@27@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 21 | |s1@27@00| == 0 | live]
; [else-branch: 21 | |s1@27@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 21 | |s1@27@00| == 0]
(assert (= (Seq_length s1@27@00) 0))
; [eval] result == s2
(pop) ; 3
(push) ; 3
; [else-branch: 21 | |s1@27@00| != 0]
(assert (not (= (Seq_length s1@27@00) 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= (Seq_length s1@27@00) 0)) (= (Seq_length s1@27@00) 0)))
(assert (=> (= (Seq_length s1@27@00) 0) (Seq_equal result@29@00 s2@28@00)))
(assert (= ($Snap.second ($Snap.second $t@77@00)) $Snap.unit))
; [eval] |s2| == 0 ==> result == s1
; [eval] |s2| == 0
; [eval] |s2|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Seq_length s2@28@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Seq_length s2@28@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 22 | |s2@28@00| == 0 | live]
; [else-branch: 22 | |s2@28@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 22 | |s2@28@00| == 0]
(assert (= (Seq_length s2@28@00) 0))
; [eval] result == s1
(pop) ; 3
(push) ; 3
; [else-branch: 22 | |s2@28@00| != 0]
(assert (not (= (Seq_length s2@28@00) 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= (Seq_length s2@28@00) 0)) (= (Seq_length s2@28@00) 0)))
(assert (=> (= (Seq_length s2@28@00) 0) (Seq_equal result@29@00 s1@27@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s1@27@00 Seq<Int>) (s2@28@00 Seq<Int>)) (!
  (=
    (interleave%limited s@$ s1@27@00 s2@28@00)
    (interleave s@$ s1@27@00 s2@28@00))
  :pattern ((interleave s@$ s1@27@00 s2@28@00))
  :qid |quant-u-16|)))
(assert (forall ((s@$ $Snap) (s1@27@00 Seq<Int>) (s2@28@00 Seq<Int>)) (!
  (interleave%stateless s1@27@00 s2@28@00)
  :pattern ((interleave%limited s@$ s1@27@00 s2@28@00))
  :qid |quant-u-17|)))
(assert (forall ((s@$ $Snap) (s1@27@00 Seq<Int>) (s2@28@00 Seq<Int>)) (!
  (let ((result@29@00 (interleave%limited s@$ s1@27@00 s2@28@00))) (=>
    (interleave%precondition s@$ s1@27@00 s2@28@00)
    (and
      (=
        (Seq_length result@29@00)
        (+ (Seq_length s1@27@00) (Seq_length s2@28@00)))
      (=> (= (Seq_length s1@27@00) 0) (Seq_equal result@29@00 s2@28@00))
      (=> (= (Seq_length s2@28@00) 0) (Seq_equal result@29@00 s1@27@00)))))
  :pattern ((interleave%limited s@$ s1@27@00 s2@28@00))
  :qid |quant-u-74|)))
(assert (forall ((s@$ $Snap) (s1@27@00 Seq<Int>) (s2@28@00 Seq<Int>)) (!
  (let ((result@29@00 (interleave%limited s@$ s1@27@00 s2@28@00))) true)
  :pattern ((interleave%limited s@$ s1@27@00 s2@28@00))
  :qid |quant-u-75|)))
(assert (forall ((s@$ $Snap) (s1@27@00 Seq<Int>) (s2@28@00 Seq<Int>)) (!
  (let ((result@29@00 (interleave%limited s@$ s1@27@00 s2@28@00))) true)
  :pattern ((interleave%limited s@$ s1@27@00 s2@28@00))
  :qid |quant-u-76|)))
(assert (forall ((s@$ $Snap) (s1@27@00 Seq<Int>) (s2@28@00 Seq<Int>)) (!
  (let ((result@29@00 (interleave%limited s@$ s1@27@00 s2@28@00))) true)
  :pattern ((interleave%limited s@$ s1@27@00 s2@28@00))
  :qid |quant-u-77|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|s1| == 0 ? s2 : (|s2| == 0 ? s1 : Seq(s1[0]) ++ Seq(s2[0]) ++ interleave(s1[1..], s2[1..])))
; [eval] |s1| == 0
; [eval] |s1|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Seq_length s1@27@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Seq_length s1@27@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 23 | |s1@27@00| == 0 | live]
; [else-branch: 23 | |s1@27@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 23 | |s1@27@00| == 0]
(assert (= (Seq_length s1@27@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 23 | |s1@27@00| != 0]
(assert (not (= (Seq_length s1@27@00) 0)))
; [eval] (|s2| == 0 ? s1 : Seq(s1[0]) ++ Seq(s2[0]) ++ interleave(s1[1..], s2[1..]))
; [eval] |s2| == 0
; [eval] |s2|
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (= (Seq_length s2@28@00) 0))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= (Seq_length s2@28@00) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 24 | |s2@28@00| == 0 | live]
; [else-branch: 24 | |s2@28@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 24 | |s2@28@00| == 0]
(assert (= (Seq_length s2@28@00) 0))
(pop) ; 5
(push) ; 5
; [else-branch: 24 | |s2@28@00| != 0]
(assert (not (= (Seq_length s2@28@00) 0)))
; [eval] Seq(s1[0]) ++ Seq(s2[0]) ++ interleave(s1[1..], s2[1..])
; [eval] Seq(s1[0]) ++ Seq(s2[0])
; [eval] Seq(s1[0])
; [eval] s1[0]
(push) ; 6
(assert (not (< 0 (Seq_length s1@27@00))))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(assert (= (Seq_length (Seq_singleton (Seq_index s1@27@00 0))) 1))
; [eval] Seq(s2[0])
; [eval] s2[0]
(push) ; 6
(assert (not (< 0 (Seq_length s2@28@00))))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(assert (= (Seq_length (Seq_singleton (Seq_index s2@28@00 0))) 1))
; [eval] interleave(s1[1..], s2[1..])
; [eval] s1[1..]
; [eval] s2[1..]
(push) ; 6
(assert (interleave%precondition $Snap.unit (Seq_drop s1@27@00 1) (Seq_drop s2@28@00 1)))
(pop) ; 6
; Joined path conditions
(assert (interleave%precondition $Snap.unit (Seq_drop s1@27@00 1) (Seq_drop s2@28@00 1)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Seq_length s2@28@00) 0))
  (and
    (not (= (Seq_length s2@28@00) 0))
    (= (Seq_length (Seq_singleton (Seq_index s1@27@00 0))) 1)
    (= (Seq_length (Seq_singleton (Seq_index s2@28@00 0))) 1)
    (interleave%precondition $Snap.unit (Seq_drop s1@27@00 1) (Seq_drop
      s2@28@00
      1)))))
(assert (or (not (= (Seq_length s2@28@00) 0)) (= (Seq_length s2@28@00) 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Seq_length s1@27@00) 0))
  (and
    (not (= (Seq_length s1@27@00) 0))
    (=>
      (not (= (Seq_length s2@28@00) 0))
      (and
        (not (= (Seq_length s2@28@00) 0))
        (= (Seq_length (Seq_singleton (Seq_index s1@27@00 0))) 1)
        (= (Seq_length (Seq_singleton (Seq_index s2@28@00 0))) 1)
        (interleave%precondition $Snap.unit (Seq_drop s1@27@00 1) (Seq_drop
          s2@28@00
          1))))
    (or (not (= (Seq_length s2@28@00) 0)) (= (Seq_length s2@28@00) 0)))))
(assert (or (not (= (Seq_length s1@27@00) 0)) (= (Seq_length s1@27@00) 0)))
(assert (=
  result@29@00
  (ite
    (= (Seq_length s1@27@00) 0)
    s2@28@00
    (ite
      (= (Seq_length s2@28@00) 0)
      s1@27@00
      (Seq_append
        (Seq_append
          (Seq_singleton (Seq_index s1@27@00 0))
          (Seq_singleton (Seq_index s2@28@00 0)))
        (interleave $Snap.unit (Seq_drop s1@27@00 1) (Seq_drop s2@28@00 1)))))))
; [eval] |result| == |s1| + |s2|
; [eval] |result|
; [eval] |s1| + |s2|
; [eval] |s1|
; [eval] |s2|
(push) ; 2
(assert (not (= (Seq_length result@29@00) (+ (Seq_length s1@27@00) (Seq_length s2@28@00)))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (= (Seq_length result@29@00) (+ (Seq_length s1@27@00) (Seq_length s2@28@00))))
; [eval] |s1| == 0 ==> result == s2
; [eval] |s1| == 0
; [eval] |s1|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Seq_length s1@27@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Seq_length s1@27@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 25 | |s1@27@00| == 0 | live]
; [else-branch: 25 | |s1@27@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 25 | |s1@27@00| == 0]
(assert (= (Seq_length s1@27@00) 0))
; [eval] result == s2
(pop) ; 3
(push) ; 3
; [else-branch: 25 | |s1@27@00| != 0]
(assert (not (= (Seq_length s1@27@00) 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(push) ; 2
(assert (not (=> (= (Seq_length s1@27@00) 0) (Seq_equal result@29@00 s2@28@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=> (= (Seq_length s1@27@00) 0) (Seq_equal result@29@00 s2@28@00)))
; [eval] |s2| == 0 ==> result == s1
; [eval] |s2| == 0
; [eval] |s2|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Seq_length s2@28@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Seq_length s2@28@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 26 | |s2@28@00| == 0 | live]
; [else-branch: 26 | |s2@28@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 26 | |s2@28@00| == 0]
(assert (= (Seq_length s2@28@00) 0))
; [eval] result == s1
(pop) ; 3
(push) ; 3
; [else-branch: 26 | |s2@28@00| != 0]
(assert (not (= (Seq_length s2@28@00) 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= (Seq_length s2@28@00) 0)) (= (Seq_length s2@28@00) 0)))
(push) ; 2
(assert (not (=> (= (Seq_length s2@28@00) 0) (Seq_equal result@29@00 s1@27@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=> (= (Seq_length s2@28@00) 0) (Seq_equal result@29@00 s1@27@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s1@27@00 Seq<Int>) (s2@28@00 Seq<Int>)) (!
  (=>
    (interleave%precondition s@$ s1@27@00 s2@28@00)
    (=
      (interleave s@$ s1@27@00 s2@28@00)
      (ite
        (= (Seq_length s1@27@00) 0)
        s2@28@00
        (ite
          (= (Seq_length s2@28@00) 0)
          s1@27@00
          (Seq_append
            (Seq_append
              (Seq_singleton (Seq_index s1@27@00 0))
              (Seq_singleton (Seq_index s2@28@00 0)))
            (interleave%limited $Snap.unit (Seq_drop s1@27@00 1) (Seq_drop
              s2@28@00
              1)))))))
  :pattern ((interleave s@$ s1@27@00 s2@28@00))
  :qid |quant-u-78|)))
(assert (forall ((s@$ $Snap) (s1@27@00 Seq<Int>) (s2@28@00 Seq<Int>)) (!
  (=>
    (interleave%precondition s@$ s1@27@00 s2@28@00)
    (ite
      (= (Seq_length s1@27@00) 0)
      true
      (ite
        (= (Seq_length s2@28@00) 0)
        true
        (interleave%precondition $Snap.unit (Seq_drop s1@27@00 1) (Seq_drop
          s2@28@00
          1)))))
  :pattern ((interleave s@$ s1@27@00 s2@28@00))
  :qid |quant-u-79|)))
; ---------- FUNCTION is_palindrome----------
(declare-fun s@30@00 () Seq<Int>)
(declare-fun result@31@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@30@00 Seq<Int>)) (!
  (= (is_palindrome%limited s@$ s@30@00) (is_palindrome s@$ s@30@00))
  :pattern ((is_palindrome s@$ s@30@00))
  :qid |quant-u-18|)))
(assert (forall ((s@$ $Snap) (s@30@00 Seq<Int>)) (!
  (is_palindrome%stateless s@30@00)
  :pattern ((is_palindrome%limited s@$ s@30@00))
  :qid |quant-u-19|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|s| <= 1 ? true : s[0] == s[|s| - 1] && is_palindrome(s[1..|s| - 1]))
; [eval] |s| <= 1
; [eval] |s|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (<= (Seq_length s@30@00) 1))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (<= (Seq_length s@30@00) 1)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 27 | |s@30@00| <= 1 | live]
; [else-branch: 27 | !(|s@30@00| <= 1) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 27 | |s@30@00| <= 1]
(assert (<= (Seq_length s@30@00) 1))
(pop) ; 3
(push) ; 3
; [else-branch: 27 | !(|s@30@00| <= 1)]
(assert (not (<= (Seq_length s@30@00) 1)))
; [eval] s[0] == s[|s| - 1] && is_palindrome(s[1..|s| - 1])
; [eval] s[0] == s[|s| - 1]
; [eval] s[0]
(push) ; 4
(assert (not (< 0 (Seq_length s@30@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [eval] s[|s| - 1]
; [eval] |s| - 1
; [eval] |s|
(push) ; 4
(assert (not (>= (- (Seq_length s@30@00) 1) 0)))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(push) ; 4
(assert (not (< (- (Seq_length s@30@00) 1) (Seq_length s@30@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(push) ; 4
; [then-branch: 28 | s@30@00[0] != s@30@00[|s@30@00| - 1] | live]
; [else-branch: 28 | s@30@00[0] == s@30@00[|s@30@00| - 1] | live]
(push) ; 5
; [then-branch: 28 | s@30@00[0] != s@30@00[|s@30@00| - 1]]
(assert (not (= (Seq_index s@30@00 0) (Seq_index s@30@00 (- (Seq_length s@30@00) 1)))))
(pop) ; 5
(push) ; 5
; [else-branch: 28 | s@30@00[0] == s@30@00[|s@30@00| - 1]]
(assert (= (Seq_index s@30@00 0) (Seq_index s@30@00 (- (Seq_length s@30@00) 1))))
; [eval] is_palindrome(s[1..|s| - 1])
; [eval] s[1..|s| - 1]
; [eval] s[..|s| - 1]
; [eval] |s| - 1
; [eval] |s|
(push) ; 6
(assert (is_palindrome%precondition $Snap.unit (Seq_drop
  (Seq_take s@30@00 (- (Seq_length s@30@00) 1))
  1)))
(pop) ; 6
; Joined path conditions
(assert (is_palindrome%precondition $Snap.unit (Seq_drop
  (Seq_take s@30@00 (- (Seq_length s@30@00) 1))
  1)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (= (Seq_index s@30@00 0) (Seq_index s@30@00 (- (Seq_length s@30@00) 1)))
  (and
    (= (Seq_index s@30@00 0) (Seq_index s@30@00 (- (Seq_length s@30@00) 1)))
    (is_palindrome%precondition $Snap.unit (Seq_drop
      (Seq_take s@30@00 (- (Seq_length s@30@00) 1))
      1)))))
(assert (or
  (= (Seq_index s@30@00 0) (Seq_index s@30@00 (- (Seq_length s@30@00) 1)))
  (not (= (Seq_index s@30@00 0) (Seq_index s@30@00 (- (Seq_length s@30@00) 1))))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (<= (Seq_length s@30@00) 1))
  (and
    (not (<= (Seq_length s@30@00) 1))
    (=>
      (= (Seq_index s@30@00 0) (Seq_index s@30@00 (- (Seq_length s@30@00) 1)))
      (and
        (= (Seq_index s@30@00 0) (Seq_index s@30@00 (- (Seq_length s@30@00) 1)))
        (is_palindrome%precondition $Snap.unit (Seq_drop
          (Seq_take s@30@00 (- (Seq_length s@30@00) 1))
          1))))
    (or
      (= (Seq_index s@30@00 0) (Seq_index s@30@00 (- (Seq_length s@30@00) 1)))
      (not
        (= (Seq_index s@30@00 0) (Seq_index s@30@00 (- (Seq_length s@30@00) 1))))))))
(assert (or (not (<= (Seq_length s@30@00) 1)) (<= (Seq_length s@30@00) 1)))
(assert (=
  result@31@00
  (ite
    (<= (Seq_length s@30@00) 1)
    true
    (and
      (= (Seq_index s@30@00 0) (Seq_index s@30@00 (- (Seq_length s@30@00) 1)))
      (is_palindrome $Snap.unit (Seq_drop
        (Seq_take s@30@00 (- (Seq_length s@30@00) 1))
        1))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@30@00 Seq<Int>)) (!
  (=>
    (is_palindrome%precondition s@$ s@30@00)
    (=
      (is_palindrome s@$ s@30@00)
      (ite
        (<= (Seq_length s@30@00) 1)
        true
        (and
          (=
            (Seq_index s@30@00 0)
            (Seq_index s@30@00 (- (Seq_length s@30@00) 1)))
          (is_palindrome%limited $Snap.unit (Seq_drop
            (Seq_take s@30@00 (- (Seq_length s@30@00) 1))
            1))))))
  :pattern ((is_palindrome s@$ s@30@00))
  :qid |quant-u-80|)))
(assert (forall ((s@$ $Snap) (s@30@00 Seq<Int>)) (!
  (=>
    (is_palindrome%precondition s@$ s@30@00)
    (ite
      (<= (Seq_length s@30@00) 1)
      true
      (=>
        (= (Seq_index s@30@00 0) (Seq_index s@30@00 (- (Seq_length s@30@00) 1)))
        (is_palindrome%precondition $Snap.unit (Seq_drop
          (Seq_take s@30@00 (- (Seq_length s@30@00) 1))
          1)))))
  :pattern ((is_palindrome s@$ s@30@00))
  :qid |quant-u-81|)))
; ---------- FUNCTION count_palindromes----------
(declare-fun s@32@00 () Seq<Int>)
(declare-fun start@33@00 () Int)
(declare-fun end@34@00 () Int)
(declare-fun result@35@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] 0 <= start
(assert (<= 0 start@33@00))
(assert (=
  ($Snap.second s@$)
  ($Snap.combine
    ($Snap.first ($Snap.second s@$))
    ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.first ($Snap.second s@$)) $Snap.unit))
; [eval] start <= end
(assert (<= start@33@00 end@34@00))
(assert (= ($Snap.second ($Snap.second s@$)) $Snap.unit))
; [eval] end <= |s|
; [eval] |s|
(assert (<= end@34@00 (Seq_length s@32@00)))
(declare-const $t@78@00 $Snap)
(assert (= $t@78@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@35@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@32@00 Seq<Int>) (start@33@00 Int) (end@34@00 Int)) (!
  (=
    (count_palindromes%limited s@$ s@32@00 start@33@00 end@34@00)
    (count_palindromes s@$ s@32@00 start@33@00 end@34@00))
  :pattern ((count_palindromes s@$ s@32@00 start@33@00 end@34@00))
  :qid |quant-u-20|)))
(assert (forall ((s@$ $Snap) (s@32@00 Seq<Int>) (start@33@00 Int) (end@34@00 Int)) (!
  (count_palindromes%stateless s@32@00 start@33@00 end@34@00)
  :pattern ((count_palindromes%limited s@$ s@32@00 start@33@00 end@34@00))
  :qid |quant-u-21|)))
(assert (forall ((s@$ $Snap) (s@32@00 Seq<Int>) (start@33@00 Int) (end@34@00 Int)) (!
  (let ((result@35@00 (count_palindromes%limited s@$ s@32@00 start@33@00 end@34@00))) (=>
    (count_palindromes%precondition s@$ s@32@00 start@33@00 end@34@00)
    (>= result@35@00 0)))
  :pattern ((count_palindromes%limited s@$ s@32@00 start@33@00 end@34@00))
  :qid |quant-u-82|)))
(assert (forall ((s@$ $Snap) (s@32@00 Seq<Int>) (start@33@00 Int) (end@34@00 Int)) (!
  (let ((result@35@00 (count_palindromes%limited s@$ s@32@00 start@33@00 end@34@00))) true)
  :pattern ((count_palindromes%limited s@$ s@32@00 start@33@00 end@34@00))
  :qid |quant-u-83|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (<= 0 start@33@00))
(assert (=
  ($Snap.second s@$)
  ($Snap.combine
    ($Snap.first ($Snap.second s@$))
    ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.first ($Snap.second s@$)) $Snap.unit))
(assert (<= start@33@00 end@34@00))
(assert (= ($Snap.second ($Snap.second s@$)) $Snap.unit))
(assert (<= end@34@00 (Seq_length s@32@00)))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (start >= end ? 0 : (end - start == 1 ? 1 : (s[start] == s[end - 1] ? 1 + count_palindromes(s, start + 1, end - 1) + count_palindromes(s, start + 1, end) + count_palindromes(s, start, end - 1) : count_palindromes(s, start + 1, end) + count_palindromes(s, start, end - 1))))
; [eval] start >= end
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= start@33@00 end@34@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= start@33@00 end@34@00)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 29 | start@33@00 >= end@34@00 | live]
; [else-branch: 29 | !(start@33@00 >= end@34@00) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 29 | start@33@00 >= end@34@00]
(assert (>= start@33@00 end@34@00))
(pop) ; 3
(push) ; 3
; [else-branch: 29 | !(start@33@00 >= end@34@00)]
(assert (not (>= start@33@00 end@34@00)))
; [eval] (end - start == 1 ? 1 : (s[start] == s[end - 1] ? 1 + count_palindromes(s, start + 1, end - 1) + count_palindromes(s, start + 1, end) + count_palindromes(s, start, end - 1) : count_palindromes(s, start + 1, end) + count_palindromes(s, start, end - 1)))
; [eval] end - start == 1
; [eval] end - start
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (= (- end@34@00 start@33@00) 1))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= (- end@34@00 start@33@00) 1)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 30 | end@34@00 - start@33@00 == 1 | live]
; [else-branch: 30 | end@34@00 - start@33@00 != 1 | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 30 | end@34@00 - start@33@00 == 1]
(assert (= (- end@34@00 start@33@00) 1))
(pop) ; 5
(push) ; 5
; [else-branch: 30 | end@34@00 - start@33@00 != 1]
(assert (not (= (- end@34@00 start@33@00) 1)))
; [eval] (s[start] == s[end - 1] ? 1 + count_palindromes(s, start + 1, end - 1) + count_palindromes(s, start + 1, end) + count_palindromes(s, start, end - 1) : count_palindromes(s, start + 1, end) + count_palindromes(s, start, end - 1))
; [eval] s[start] == s[end - 1]
; [eval] s[start]
(push) ; 6
(assert (not (>= start@33@00 0)))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(push) ; 6
(assert (not (< start@33@00 (Seq_length s@32@00))))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [eval] s[end - 1]
; [eval] end - 1
(push) ; 6
(assert (not (>= (- end@34@00 1) 0)))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(push) ; 6
(assert (not (< (- end@34@00 1) (Seq_length s@32@00))))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(push) ; 6
(push) ; 7
(set-option :rlimit 16000)
(assert (not (not (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1))))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 16000)
(assert (not (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1)))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 31 | s@32@00[start@33@00] == s@32@00[end@34@00 - 1] | live]
; [else-branch: 31 | s@32@00[start@33@00] != s@32@00[end@34@00 - 1] | live]
(set-option :rlimit 0)
(push) ; 7
; [then-branch: 31 | s@32@00[start@33@00] == s@32@00[end@34@00 - 1]]
(assert (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1))))
; [eval] 1 + count_palindromes(s, start + 1, end - 1) + count_palindromes(s, start + 1, end) + count_palindromes(s, start, end - 1)
; [eval] 1 + count_palindromes(s, start + 1, end - 1) + count_palindromes(s, start + 1, end)
; [eval] 1 + count_palindromes(s, start + 1, end - 1)
; [eval] count_palindromes(s, start + 1, end - 1)
; [eval] start + 1
; [eval] end - 1
(push) ; 8
; [eval] 0 <= start
(push) ; 9
(assert (not (<= 0 (+ start@33@00 1))))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(assert (<= 0 (+ start@33@00 1)))
; [eval] start <= end
(push) ; 9
(assert (not (<= (+ start@33@00 1) (- end@34@00 1))))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(assert (<= (+ start@33@00 1) (- end@34@00 1)))
; [eval] end <= |s|
; [eval] |s|
(push) ; 9
(assert (not (<= (- end@34@00 1) (Seq_length s@32@00))))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(assert (<= (- end@34@00 1) (Seq_length s@32@00)))
(assert (count_palindromes%precondition ($Snap.combine
  $Snap.unit
  ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) (-
  end@34@00
  1)))
(pop) ; 8
; Joined path conditions
(assert (and
  (<= 0 (+ start@33@00 1))
  (<= (+ start@33@00 1) (- end@34@00 1))
  (<= (- end@34@00 1) (Seq_length s@32@00))
  (count_palindromes%precondition ($Snap.combine
    $Snap.unit
    ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) (-
    end@34@00
    1))))
; [eval] count_palindromes(s, start + 1, end)
; [eval] start + 1
(push) ; 8
; [eval] 0 <= start
; [eval] start <= end
(push) ; 9
(assert (not (<= (+ start@33@00 1) end@34@00)))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(assert (<= (+ start@33@00 1) end@34@00))
; [eval] end <= |s|
; [eval] |s|
(assert (count_palindromes%precondition ($Snap.combine
  $Snap.unit
  ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00))
(pop) ; 8
; Joined path conditions
(assert (and
  (<= (+ start@33@00 1) end@34@00)
  (count_palindromes%precondition ($Snap.combine
    $Snap.unit
    ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00)))
; [eval] count_palindromes(s, start, end - 1)
; [eval] end - 1
(push) ; 8
; [eval] 0 <= start
; [eval] start <= end
(push) ; 9
(assert (not (<= start@33@00 (- end@34@00 1))))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(assert (<= start@33@00 (- end@34@00 1)))
; [eval] end <= |s|
; [eval] |s|
(assert (count_palindromes%precondition ($Snap.combine
  $Snap.unit
  ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (- end@34@00 1)))
(pop) ; 8
; Joined path conditions
(assert (and
  (<= start@33@00 (- end@34@00 1))
  (count_palindromes%precondition ($Snap.combine
    $Snap.unit
    ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (- end@34@00 1))))
(pop) ; 7
(push) ; 7
; [else-branch: 31 | s@32@00[start@33@00] != s@32@00[end@34@00 - 1]]
(assert (not (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1)))))
; [eval] count_palindromes(s, start + 1, end) + count_palindromes(s, start, end - 1)
; [eval] count_palindromes(s, start + 1, end)
; [eval] start + 1
(push) ; 8
; [eval] 0 <= start
(push) ; 9
(assert (not (<= 0 (+ start@33@00 1))))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(assert (<= 0 (+ start@33@00 1)))
; [eval] start <= end
(push) ; 9
(assert (not (<= (+ start@33@00 1) end@34@00)))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(assert (<= (+ start@33@00 1) end@34@00))
; [eval] end <= |s|
; [eval] |s|
(assert (count_palindromes%precondition ($Snap.combine
  $Snap.unit
  ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00))
(pop) ; 8
; Joined path conditions
(assert (and
  (<= 0 (+ start@33@00 1))
  (<= (+ start@33@00 1) end@34@00)
  (count_palindromes%precondition ($Snap.combine
    $Snap.unit
    ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00)))
; [eval] count_palindromes(s, start, end - 1)
; [eval] end - 1
(push) ; 8
; [eval] 0 <= start
; [eval] start <= end
(push) ; 9
(assert (not (<= start@33@00 (- end@34@00 1))))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(assert (<= start@33@00 (- end@34@00 1)))
; [eval] end <= |s|
; [eval] |s|
(push) ; 9
(assert (not (<= (- end@34@00 1) (Seq_length s@32@00))))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(assert (<= (- end@34@00 1) (Seq_length s@32@00)))
(assert (count_palindromes%precondition ($Snap.combine
  $Snap.unit
  ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (- end@34@00 1)))
(pop) ; 8
; Joined path conditions
(assert (and
  (<= start@33@00 (- end@34@00 1))
  (<= (- end@34@00 1) (Seq_length s@32@00))
  (count_palindromes%precondition ($Snap.combine
    $Snap.unit
    ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (- end@34@00 1))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=>
  (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1)))
  (and
    (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1)))
    (<= 0 (+ start@33@00 1))
    (<= (+ start@33@00 1) (- end@34@00 1))
    (<= (- end@34@00 1) (Seq_length s@32@00))
    (count_palindromes%precondition ($Snap.combine
      $Snap.unit
      ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) (-
      end@34@00
      1))
    (<= (+ start@33@00 1) end@34@00)
    (count_palindromes%precondition ($Snap.combine
      $Snap.unit
      ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00)
    (<= start@33@00 (- end@34@00 1))
    (count_palindromes%precondition ($Snap.combine
      $Snap.unit
      ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (- end@34@00 1)))))
; Joined path conditions
(assert (=>
  (not (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1))))
  (and
    (not (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1))))
    (<= 0 (+ start@33@00 1))
    (<= (+ start@33@00 1) end@34@00)
    (count_palindromes%precondition ($Snap.combine
      $Snap.unit
      ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00)
    (<= start@33@00 (- end@34@00 1))
    (<= (- end@34@00 1) (Seq_length s@32@00))
    (count_palindromes%precondition ($Snap.combine
      $Snap.unit
      ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (- end@34@00 1)))))
(assert (or
  (not (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1))))
  (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1)))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (- end@34@00 start@33@00) 1))
  (and
    (not (= (- end@34@00 start@33@00) 1))
    (=>
      (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1)))
      (and
        (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1)))
        (<= 0 (+ start@33@00 1))
        (<= (+ start@33@00 1) (- end@34@00 1))
        (<= (- end@34@00 1) (Seq_length s@32@00))
        (count_palindromes%precondition ($Snap.combine
          $Snap.unit
          ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) (-
          end@34@00
          1))
        (<= (+ start@33@00 1) end@34@00)
        (count_palindromes%precondition ($Snap.combine
          $Snap.unit
          ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00)
        (<= start@33@00 (- end@34@00 1))
        (count_palindromes%precondition ($Snap.combine
          $Snap.unit
          ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (-
          end@34@00
          1))))
    (=>
      (not
        (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1))))
      (and
        (not
          (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1))))
        (<= 0 (+ start@33@00 1))
        (<= (+ start@33@00 1) end@34@00)
        (count_palindromes%precondition ($Snap.combine
          $Snap.unit
          ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00)
        (<= start@33@00 (- end@34@00 1))
        (<= (- end@34@00 1) (Seq_length s@32@00))
        (count_palindromes%precondition ($Snap.combine
          $Snap.unit
          ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (-
          end@34@00
          1))))
    (or
      (not
        (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1))))
      (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1)))))))
(assert (or (not (= (- end@34@00 start@33@00) 1)) (= (- end@34@00 start@33@00) 1)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (>= start@33@00 end@34@00))
  (and
    (not (>= start@33@00 end@34@00))
    (=>
      (not (= (- end@34@00 start@33@00) 1))
      (and
        (not (= (- end@34@00 start@33@00) 1))
        (=>
          (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1)))
          (and
            (=
              (Seq_index s@32@00 start@33@00)
              (Seq_index s@32@00 (- end@34@00 1)))
            (<= 0 (+ start@33@00 1))
            (<= (+ start@33@00 1) (- end@34@00 1))
            (<= (- end@34@00 1) (Seq_length s@32@00))
            (count_palindromes%precondition ($Snap.combine
              $Snap.unit
              ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) (-
              end@34@00
              1))
            (<= (+ start@33@00 1) end@34@00)
            (count_palindromes%precondition ($Snap.combine
              $Snap.unit
              ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00)
            (<= start@33@00 (- end@34@00 1))
            (count_palindromes%precondition ($Snap.combine
              $Snap.unit
              ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (-
              end@34@00
              1))))
        (=>
          (not
            (=
              (Seq_index s@32@00 start@33@00)
              (Seq_index s@32@00 (- end@34@00 1))))
          (and
            (not
              (=
                (Seq_index s@32@00 start@33@00)
                (Seq_index s@32@00 (- end@34@00 1))))
            (<= 0 (+ start@33@00 1))
            (<= (+ start@33@00 1) end@34@00)
            (count_palindromes%precondition ($Snap.combine
              $Snap.unit
              ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00)
            (<= start@33@00 (- end@34@00 1))
            (<= (- end@34@00 1) (Seq_length s@32@00))
            (count_palindromes%precondition ($Snap.combine
              $Snap.unit
              ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (-
              end@34@00
              1))))
        (or
          (not
            (=
              (Seq_index s@32@00 start@33@00)
              (Seq_index s@32@00 (- end@34@00 1))))
          (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1))))))
    (or (not (= (- end@34@00 start@33@00) 1)) (= (- end@34@00 start@33@00) 1)))))
(assert (or (not (>= start@33@00 end@34@00)) (>= start@33@00 end@34@00)))
(assert (=
  result@35@00
  (ite
    (>= start@33@00 end@34@00)
    0
    (ite
      (= (- end@34@00 start@33@00) 1)
      1
      (ite
        (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1)))
        (+
          (+
            (+
              1
              (count_palindromes ($Snap.combine
                $Snap.unit
                ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) (-
                end@34@00
                1)))
            (count_palindromes ($Snap.combine
              $Snap.unit
              ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00))
          (count_palindromes ($Snap.combine
            $Snap.unit
            ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (-
            end@34@00
            1)))
        (+
          (count_palindromes ($Snap.combine
            $Snap.unit
            ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00)
          (count_palindromes ($Snap.combine
            $Snap.unit
            ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (-
            end@34@00
            1))))))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@35@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@35@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@32@00 Seq<Int>) (start@33@00 Int) (end@34@00 Int)) (!
  (=>
    (count_palindromes%precondition s@$ s@32@00 start@33@00 end@34@00)
    (=
      (count_palindromes s@$ s@32@00 start@33@00 end@34@00)
      (ite
        (>= start@33@00 end@34@00)
        0
        (ite
          (= (- end@34@00 start@33@00) 1)
          1
          (ite
            (=
              (Seq_index s@32@00 start@33@00)
              (Seq_index s@32@00 (- end@34@00 1)))
            (+
              (+
                (+
                  1
                  (count_palindromes%limited ($Snap.combine
                    $Snap.unit
                    ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+
                    start@33@00
                    1) (- end@34@00 1)))
                (count_palindromes%limited ($Snap.combine
                  $Snap.unit
                  ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+
                  start@33@00
                  1) end@34@00))
              (count_palindromes%limited ($Snap.combine
                $Snap.unit
                ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (-
                end@34@00
                1)))
            (+
              (count_palindromes%limited ($Snap.combine
                $Snap.unit
                ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00)
              (count_palindromes%limited ($Snap.combine
                $Snap.unit
                ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (-
                end@34@00
                1))))))))
  :pattern ((count_palindromes s@$ s@32@00 start@33@00 end@34@00))
  :qid |quant-u-84|)))
(assert (forall ((s@$ $Snap) (s@32@00 Seq<Int>) (start@33@00 Int) (end@34@00 Int)) (!
  (=>
    (count_palindromes%precondition s@$ s@32@00 start@33@00 end@34@00)
    (ite
      (>= start@33@00 end@34@00)
      true
      (ite
        (= (- end@34@00 start@33@00) 1)
        true
        (ite
          (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1)))
          (and
            (and
              (count_palindromes%precondition ($Snap.combine
                $Snap.unit
                ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) (-
                end@34@00
                1))
              (count_palindromes%precondition ($Snap.combine
                $Snap.unit
                ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00))
            (count_palindromes%precondition ($Snap.combine
              $Snap.unit
              ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (-
              end@34@00
              1)))
          (and
            (count_palindromes%precondition ($Snap.combine
              $Snap.unit
              ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00)
            (count_palindromes%precondition ($Snap.combine
              $Snap.unit
              ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (-
              end@34@00
              1)))))))
  :pattern ((count_palindromes s@$ s@32@00 start@33@00 end@34@00))
  :qid |quant-u-85|)))
; ---------- FUNCTION alternating_sum----------
(declare-fun s@36@00 () Seq<Int>)
(declare-fun sign@37@00 () Int)
(declare-fun result@38@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@36@00 Seq<Int>) (sign@37@00 Int)) (!
  (=
    (alternating_sum%limited s@$ s@36@00 sign@37@00)
    (alternating_sum s@$ s@36@00 sign@37@00))
  :pattern ((alternating_sum s@$ s@36@00 sign@37@00))
  :qid |quant-u-22|)))
(assert (forall ((s@$ $Snap) (s@36@00 Seq<Int>) (sign@37@00 Int)) (!
  (alternating_sum%stateless s@36@00 sign@37@00)
  :pattern ((alternating_sum%limited s@$ s@36@00 sign@37@00))
  :qid |quant-u-23|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|s| == 0 ? 0 : sign * s[0] + alternating_sum(s[1..], -sign))
; [eval] |s| == 0
; [eval] |s|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Seq_length s@36@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Seq_length s@36@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 32 | |s@36@00| == 0 | live]
; [else-branch: 32 | |s@36@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 32 | |s@36@00| == 0]
(assert (= (Seq_length s@36@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 32 | |s@36@00| != 0]
(assert (not (= (Seq_length s@36@00) 0)))
; [eval] sign * s[0] + alternating_sum(s[1..], -sign)
; [eval] sign * s[0]
; [eval] s[0]
(push) ; 4
(assert (not (< 0 (Seq_length s@36@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [eval] alternating_sum(s[1..], -sign)
; [eval] s[1..]
; [eval] -sign
(push) ; 4
(assert (alternating_sum%precondition $Snap.unit (Seq_drop s@36@00 1) (- 0 sign@37@00)))
(pop) ; 4
; Joined path conditions
(assert (alternating_sum%precondition $Snap.unit (Seq_drop s@36@00 1) (- 0 sign@37@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Seq_length s@36@00) 0))
  (and
    (not (= (Seq_length s@36@00) 0))
    (alternating_sum%precondition $Snap.unit (Seq_drop s@36@00 1) (-
      0
      sign@37@00)))))
(assert (or (not (= (Seq_length s@36@00) 0)) (= (Seq_length s@36@00) 0)))
(assert (=
  result@38@00
  (ite
    (= (Seq_length s@36@00) 0)
    0
    (+
      (* sign@37@00 (Seq_index s@36@00 0))
      (alternating_sum $Snap.unit (Seq_drop s@36@00 1) (- 0 sign@37@00))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@36@00 Seq<Int>) (sign@37@00 Int)) (!
  (=>
    (alternating_sum%precondition s@$ s@36@00 sign@37@00)
    (=
      (alternating_sum s@$ s@36@00 sign@37@00)
      (ite
        (= (Seq_length s@36@00) 0)
        0
        (+
          (* sign@37@00 (Seq_index s@36@00 0))
          (alternating_sum%limited $Snap.unit (Seq_drop s@36@00 1) (-
            0
            sign@37@00))))))
  :pattern ((alternating_sum s@$ s@36@00 sign@37@00))
  :qid |quant-u-86|)))
(assert (forall ((s@$ $Snap) (s@36@00 Seq<Int>) (sign@37@00 Int)) (!
  (=>
    (alternating_sum%precondition s@$ s@36@00 sign@37@00)
    (ite
      (= (Seq_length s@36@00) 0)
      true
      (alternating_sum%precondition $Snap.unit (Seq_drop s@36@00 1) (-
        0
        sign@37@00))))
  :pattern ((alternating_sum s@$ s@36@00 sign@37@00))
  :qid |quant-u-87|)))
; ---------- FUNCTION run_length_count----------
(declare-fun s@39@00 () Seq<Int>)
(declare-fun idx@40@00 () Int)
(declare-fun current@41@00 () Int)
(declare-fun count@42@00 () Int)
(declare-fun result@43@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] idx >= 0
(assert (>= idx@40@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
; [eval] count >= 0
(assert (>= count@42@00 0))
(declare-const $t@79@00 $Snap)
(assert (= $t@79@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@43@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@39@00 Seq<Int>) (idx@40@00 Int) (current@41@00 Int) (count@42@00 Int)) (!
  (=
    (run_length_count%limited s@$ s@39@00 idx@40@00 current@41@00 count@42@00)
    (run_length_count s@$ s@39@00 idx@40@00 current@41@00 count@42@00))
  :pattern ((run_length_count s@$ s@39@00 idx@40@00 current@41@00 count@42@00))
  :qid |quant-u-24|)))
(assert (forall ((s@$ $Snap) (s@39@00 Seq<Int>) (idx@40@00 Int) (current@41@00 Int) (count@42@00 Int)) (!
  (run_length_count%stateless s@39@00 idx@40@00 current@41@00 count@42@00)
  :pattern ((run_length_count%limited s@$ s@39@00 idx@40@00 current@41@00 count@42@00))
  :qid |quant-u-25|)))
(assert (forall ((s@$ $Snap) (s@39@00 Seq<Int>) (idx@40@00 Int) (current@41@00 Int) (count@42@00 Int)) (!
  (let ((result@43@00 (run_length_count%limited s@$ s@39@00 idx@40@00 current@41@00 count@42@00))) (=>
    (run_length_count%precondition s@$ s@39@00 idx@40@00 current@41@00 count@42@00)
    (>= result@43@00 0)))
  :pattern ((run_length_count%limited s@$ s@39@00 idx@40@00 current@41@00 count@42@00))
  :qid |quant-u-88|)))
(assert (forall ((s@$ $Snap) (s@39@00 Seq<Int>) (idx@40@00 Int) (current@41@00 Int) (count@42@00 Int)) (!
  (let ((result@43@00 (run_length_count%limited s@$ s@39@00 idx@40@00 current@41@00 count@42@00))) true)
  :pattern ((run_length_count%limited s@$ s@39@00 idx@40@00 current@41@00 count@42@00))
  :qid |quant-u-89|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (>= idx@40@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
(assert (>= count@42@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (idx >= |s| ? (count > 0 ? 1 : 0) : (idx == 0 ? run_length_count(s, idx + 1, s[idx], 1) : (s[idx] == current ? run_length_count(s, idx + 1, current, count + 1) : 1 + run_length_count(s, idx + 1, s[idx], 1))))
; [eval] idx >= |s|
; [eval] |s|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= idx@40@00 (Seq_length s@39@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= idx@40@00 (Seq_length s@39@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 33 | idx@40@00 >= |s@39@00| | live]
; [else-branch: 33 | !(idx@40@00 >= |s@39@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 33 | idx@40@00 >= |s@39@00|]
(assert (>= idx@40@00 (Seq_length s@39@00)))
; [eval] (count > 0 ? 1 : 0)
; [eval] count > 0
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (> count@42@00 0))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (> count@42@00 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 34 | count@42@00 > 0 | live]
; [else-branch: 34 | !(count@42@00 > 0) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 34 | count@42@00 > 0]
(assert (> count@42@00 0))
(pop) ; 5
(push) ; 5
; [else-branch: 34 | !(count@42@00 > 0)]
(assert (not (> count@42@00 0)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or (not (> count@42@00 0)) (> count@42@00 0)))
(pop) ; 3
(push) ; 3
; [else-branch: 33 | !(idx@40@00 >= |s@39@00|)]
(assert (not (>= idx@40@00 (Seq_length s@39@00))))
; [eval] (idx == 0 ? run_length_count(s, idx + 1, s[idx], 1) : (s[idx] == current ? run_length_count(s, idx + 1, current, count + 1) : 1 + run_length_count(s, idx + 1, s[idx], 1)))
; [eval] idx == 0
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (= idx@40@00 0))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= idx@40@00 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 35 | idx@40@00 == 0 | live]
; [else-branch: 35 | idx@40@00 != 0 | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 35 | idx@40@00 == 0]
(assert (= idx@40@00 0))
; [eval] run_length_count(s, idx + 1, s[idx], 1)
; [eval] idx + 1
; [eval] s[idx]
(push) ; 6
(assert (not (< idx@40@00 (Seq_length s@39@00))))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(push) ; 6
; [eval] idx >= 0
(push) ; 7
(assert (not (>= (+ idx@40@00 1) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (>= (+ idx@40@00 1) 0))
; [eval] count >= 0
(assert (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
  idx@40@00
  1) (Seq_index s@39@00 idx@40@00) 1))
(pop) ; 6
; Joined path conditions
(assert (and
  (>= (+ idx@40@00 1) 0)
  (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
    idx@40@00
    1) (Seq_index s@39@00 idx@40@00) 1)))
(pop) ; 5
(push) ; 5
; [else-branch: 35 | idx@40@00 != 0]
(assert (not (= idx@40@00 0)))
; [eval] (s[idx] == current ? run_length_count(s, idx + 1, current, count + 1) : 1 + run_length_count(s, idx + 1, s[idx], 1))
; [eval] s[idx] == current
; [eval] s[idx]
(push) ; 6
(assert (not (< idx@40@00 (Seq_length s@39@00))))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(push) ; 6
(push) ; 7
(set-option :rlimit 16000)
(assert (not (not (= (Seq_index s@39@00 idx@40@00) current@41@00))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 16000)
(assert (not (= (Seq_index s@39@00 idx@40@00) current@41@00)))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 36 | s@39@00[idx@40@00] == current@41@00 | live]
; [else-branch: 36 | s@39@00[idx@40@00] != current@41@00 | live]
(set-option :rlimit 0)
(push) ; 7
; [then-branch: 36 | s@39@00[idx@40@00] == current@41@00]
(assert (= (Seq_index s@39@00 idx@40@00) current@41@00))
; [eval] run_length_count(s, idx + 1, current, count + 1)
; [eval] idx + 1
; [eval] count + 1
(push) ; 8
; [eval] idx >= 0
(push) ; 9
(assert (not (>= (+ idx@40@00 1) 0)))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(assert (>= (+ idx@40@00 1) 0))
; [eval] count >= 0
(push) ; 9
(assert (not (>= (+ count@42@00 1) 0)))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(assert (>= (+ count@42@00 1) 0))
(assert (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
  idx@40@00
  1) current@41@00 (+ count@42@00 1)))
(pop) ; 8
; Joined path conditions
(assert (and
  (>= (+ idx@40@00 1) 0)
  (>= (+ count@42@00 1) 0)
  (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
    idx@40@00
    1) current@41@00 (+ count@42@00 1))))
(pop) ; 7
(push) ; 7
; [else-branch: 36 | s@39@00[idx@40@00] != current@41@00]
(assert (not (= (Seq_index s@39@00 idx@40@00) current@41@00)))
; [eval] 1 + run_length_count(s, idx + 1, s[idx], 1)
; [eval] run_length_count(s, idx + 1, s[idx], 1)
; [eval] idx + 1
; [eval] s[idx]
(push) ; 8
(assert (not (< idx@40@00 (Seq_length s@39@00))))
(check-sat)
; unsat
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
(push) ; 8
; [eval] idx >= 0
(push) ; 9
(assert (not (>= (+ idx@40@00 1) 0)))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(assert (>= (+ idx@40@00 1) 0))
; [eval] count >= 0
(assert (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
  idx@40@00
  1) (Seq_index s@39@00 idx@40@00) 1))
(pop) ; 8
; Joined path conditions
(assert (and
  (>= (+ idx@40@00 1) 0)
  (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
    idx@40@00
    1) (Seq_index s@39@00 idx@40@00) 1)))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=>
  (= (Seq_index s@39@00 idx@40@00) current@41@00)
  (and
    (= (Seq_index s@39@00 idx@40@00) current@41@00)
    (>= (+ idx@40@00 1) 0)
    (>= (+ count@42@00 1) 0)
    (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
      idx@40@00
      1) current@41@00 (+ count@42@00 1)))))
; Joined path conditions
(assert (=>
  (not (= (Seq_index s@39@00 idx@40@00) current@41@00))
  (and
    (not (= (Seq_index s@39@00 idx@40@00) current@41@00))
    (>= (+ idx@40@00 1) 0)
    (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
      idx@40@00
      1) (Seq_index s@39@00 idx@40@00) 1))))
(assert (or
  (not (= (Seq_index s@39@00 idx@40@00) current@41@00))
  (= (Seq_index s@39@00 idx@40@00) current@41@00)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=>
  (= idx@40@00 0)
  (and
    (= idx@40@00 0)
    (>= (+ idx@40@00 1) 0)
    (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
      idx@40@00
      1) (Seq_index s@39@00 idx@40@00) 1))))
; Joined path conditions
(assert (=>
  (not (= idx@40@00 0))
  (and
    (not (= idx@40@00 0))
    (=>
      (= (Seq_index s@39@00 idx@40@00) current@41@00)
      (and
        (= (Seq_index s@39@00 idx@40@00) current@41@00)
        (>= (+ idx@40@00 1) 0)
        (>= (+ count@42@00 1) 0)
        (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
          idx@40@00
          1) current@41@00 (+ count@42@00 1))))
    (=>
      (not (= (Seq_index s@39@00 idx@40@00) current@41@00))
      (and
        (not (= (Seq_index s@39@00 idx@40@00) current@41@00))
        (>= (+ idx@40@00 1) 0)
        (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
          idx@40@00
          1) (Seq_index s@39@00 idx@40@00) 1)))
    (or
      (not (= (Seq_index s@39@00 idx@40@00) current@41@00))
      (= (Seq_index s@39@00 idx@40@00) current@41@00)))))
(assert (or (not (= idx@40@00 0)) (= idx@40@00 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
(assert (=>
  (>= idx@40@00 (Seq_length s@39@00))
  (and
    (>= idx@40@00 (Seq_length s@39@00))
    (or (not (> count@42@00 0)) (> count@42@00 0)))))
; Joined path conditions
(assert (=>
  (not (>= idx@40@00 (Seq_length s@39@00)))
  (and
    (not (>= idx@40@00 (Seq_length s@39@00)))
    (=>
      (= idx@40@00 0)
      (and
        (= idx@40@00 0)
        (>= (+ idx@40@00 1) 0)
        (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
          idx@40@00
          1) (Seq_index s@39@00 idx@40@00) 1)))
    (=>
      (not (= idx@40@00 0))
      (and
        (not (= idx@40@00 0))
        (=>
          (= (Seq_index s@39@00 idx@40@00) current@41@00)
          (and
            (= (Seq_index s@39@00 idx@40@00) current@41@00)
            (>= (+ idx@40@00 1) 0)
            (>= (+ count@42@00 1) 0)
            (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
              idx@40@00
              1) current@41@00 (+ count@42@00 1))))
        (=>
          (not (= (Seq_index s@39@00 idx@40@00) current@41@00))
          (and
            (not (= (Seq_index s@39@00 idx@40@00) current@41@00))
            (>= (+ idx@40@00 1) 0)
            (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
              idx@40@00
              1) (Seq_index s@39@00 idx@40@00) 1)))
        (or
          (not (= (Seq_index s@39@00 idx@40@00) current@41@00))
          (= (Seq_index s@39@00 idx@40@00) current@41@00))))
    (or (not (= idx@40@00 0)) (= idx@40@00 0)))))
(assert (or
  (not (>= idx@40@00 (Seq_length s@39@00)))
  (>= idx@40@00 (Seq_length s@39@00))))
(assert (=
  result@43@00
  (ite
    (>= idx@40@00 (Seq_length s@39@00))
    (ite (> count@42@00 0) 1 0)
    (ite
      (= idx@40@00 0)
      (run_length_count ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
        idx@40@00
        1) (Seq_index s@39@00 idx@40@00) 1)
      (ite
        (= (Seq_index s@39@00 idx@40@00) current@41@00)
        (run_length_count ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
          idx@40@00
          1) current@41@00 (+ count@42@00 1))
        (+
          1
          (run_length_count ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
            idx@40@00
            1) (Seq_index s@39@00 idx@40@00) 1)))))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@43@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@43@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@39@00 Seq<Int>) (idx@40@00 Int) (current@41@00 Int) (count@42@00 Int)) (!
  (=>
    (run_length_count%precondition s@$ s@39@00 idx@40@00 current@41@00 count@42@00)
    (=
      (run_length_count s@$ s@39@00 idx@40@00 current@41@00 count@42@00)
      (ite
        (>= idx@40@00 (Seq_length s@39@00))
        (ite (> count@42@00 0) 1 0)
        (ite
          (= idx@40@00 0)
          (run_length_count%limited ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
            idx@40@00
            1) (Seq_index s@39@00 idx@40@00) 1)
          (ite
            (= (Seq_index s@39@00 idx@40@00) current@41@00)
            (run_length_count%limited ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
              idx@40@00
              1) current@41@00 (+ count@42@00 1))
            (+
              1
              (run_length_count%limited ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
                idx@40@00
                1) (Seq_index s@39@00 idx@40@00) 1)))))))
  :pattern ((run_length_count s@$ s@39@00 idx@40@00 current@41@00 count@42@00))
  :qid |quant-u-90|)))
(assert (forall ((s@$ $Snap) (s@39@00 Seq<Int>) (idx@40@00 Int) (current@41@00 Int) (count@42@00 Int)) (!
  (=>
    (run_length_count%precondition s@$ s@39@00 idx@40@00 current@41@00 count@42@00)
    (ite
      (>= idx@40@00 (Seq_length s@39@00))
      true
      (ite
        (= idx@40@00 0)
        (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
          idx@40@00
          1) (Seq_index s@39@00 idx@40@00) 1)
        (ite
          (= (Seq_index s@39@00 idx@40@00) current@41@00)
          (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
            idx@40@00
            1) current@41@00 (+ count@42@00 1))
          (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
            idx@40@00
            1) (Seq_index s@39@00 idx@40@00) 1)))))
  :pattern ((run_length_count s@$ s@39@00 idx@40@00 current@41@00 count@42@00))
  :qid |quant-u-91|)))
; ---------- FUNCTION flatten_sequences----------
(declare-fun seqs@44@00 () Seq<Seq<Int>>)
(declare-fun idx@45@00 () Int)
(declare-fun result@46@00 () Seq<Int>)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] idx >= 0
(assert (>= idx@45@00 0))
(declare-const $t@80@00 $Snap)
(assert (= $t@80@00 $Snap.unit))
; [eval] idx >= |seqs| ==> result == Seq[Int]()
; [eval] idx >= |seqs|
; [eval] |seqs|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= idx@45@00 (Seq_length seqs@44@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= idx@45@00 (Seq_length seqs@44@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 37 | idx@45@00 >= |seqs@44@00| | live]
; [else-branch: 37 | !(idx@45@00 >= |seqs@44@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 37 | idx@45@00 >= |seqs@44@00|]
(assert (>= idx@45@00 (Seq_length seqs@44@00)))
; [eval] result == Seq[Int]()
; [eval] Seq[Int]()
(pop) ; 3
(push) ; 3
; [else-branch: 37 | !(idx@45@00 >= |seqs@44@00|)]
(assert (not (>= idx@45@00 (Seq_length seqs@44@00))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or
  (not (>= idx@45@00 (Seq_length seqs@44@00)))
  (>= idx@45@00 (Seq_length seqs@44@00))))
(assert (=>
  (>= idx@45@00 (Seq_length seqs@44@00))
  (Seq_equal result@46@00 (as Seq_empty  Seq<Int>))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (seqs@44@00 Seq<Seq<Int>>) (idx@45@00 Int)) (!
  (=
    (flatten_sequences%limited s@$ seqs@44@00 idx@45@00)
    (flatten_sequences s@$ seqs@44@00 idx@45@00))
  :pattern ((flatten_sequences s@$ seqs@44@00 idx@45@00))
  :qid |quant-u-26|)))
(assert (forall ((s@$ $Snap) (seqs@44@00 Seq<Seq<Int>>) (idx@45@00 Int)) (!
  (flatten_sequences%stateless seqs@44@00 idx@45@00)
  :pattern ((flatten_sequences%limited s@$ seqs@44@00 idx@45@00))
  :qid |quant-u-27|)))
(assert (forall ((s@$ $Snap) (seqs@44@00 Seq<Seq<Int>>) (idx@45@00 Int)) (!
  (let ((result@46@00 (flatten_sequences%limited s@$ seqs@44@00 idx@45@00))) (=>
    (and
      (flatten_sequences%precondition s@$ seqs@44@00 idx@45@00)
      (>= idx@45@00 (Seq_length seqs@44@00)))
    (Seq_equal result@46@00 (as Seq_empty  Seq<Int>))))
  :pattern ((flatten_sequences%limited s@$ seqs@44@00 idx@45@00))
  :qid |quant-u-92|)))
(assert (forall ((s@$ $Snap) (seqs@44@00 Seq<Seq<Int>>) (idx@45@00 Int)) (!
  (let ((result@46@00 (flatten_sequences%limited s@$ seqs@44@00 idx@45@00))) true)
  :pattern ((flatten_sequences%limited s@$ seqs@44@00 idx@45@00))
  :qid |quant-u-93|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (>= idx@45@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (idx >= |seqs| ? Seq[Int]() : seqs[idx] ++ flatten_sequences(seqs, idx + 1))
; [eval] idx >= |seqs|
; [eval] |seqs|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= idx@45@00 (Seq_length seqs@44@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= idx@45@00 (Seq_length seqs@44@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 38 | idx@45@00 >= |seqs@44@00| | live]
; [else-branch: 38 | !(idx@45@00 >= |seqs@44@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 38 | idx@45@00 >= |seqs@44@00|]
(assert (>= idx@45@00 (Seq_length seqs@44@00)))
; [eval] Seq[Int]()
(pop) ; 3
(push) ; 3
; [else-branch: 38 | !(idx@45@00 >= |seqs@44@00|)]
(assert (not (>= idx@45@00 (Seq_length seqs@44@00))))
; [eval] seqs[idx] ++ flatten_sequences(seqs, idx + 1)
; [eval] seqs[idx]
(push) ; 4
(assert (not (< idx@45@00 (Seq_length seqs@44@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [eval] flatten_sequences(seqs, idx + 1)
; [eval] idx + 1
(push) ; 4
; [eval] idx >= 0
(push) ; 5
(assert (not (>= (+ idx@45@00 1) 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (>= (+ idx@45@00 1) 0))
(assert (flatten_sequences%precondition $Snap.unit seqs@44@00 (+ idx@45@00 1)))
(pop) ; 4
; Joined path conditions
(assert (and
  (>= (+ idx@45@00 1) 0)
  (flatten_sequences%precondition $Snap.unit seqs@44@00 (+ idx@45@00 1))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (>= idx@45@00 (Seq_length seqs@44@00)))
  (and
    (not (>= idx@45@00 (Seq_length seqs@44@00)))
    (>= (+ idx@45@00 1) 0)
    (flatten_sequences%precondition $Snap.unit seqs@44@00 (+ idx@45@00 1)))))
(assert (or
  (not (>= idx@45@00 (Seq_length seqs@44@00)))
  (>= idx@45@00 (Seq_length seqs@44@00))))
(assert (=
  result@46@00
  (ite
    (>= idx@45@00 (Seq_length seqs@44@00))
    (as Seq_empty  Seq<Int>)
    (Seq_append
      (Seq_index seqs@44@00 idx@45@00)
      (flatten_sequences $Snap.unit seqs@44@00 (+ idx@45@00 1))))))
; [eval] idx >= |seqs| ==> result == Seq[Int]()
; [eval] idx >= |seqs|
; [eval] |seqs|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= idx@45@00 (Seq_length seqs@44@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= idx@45@00 (Seq_length seqs@44@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 39 | idx@45@00 >= |seqs@44@00| | live]
; [else-branch: 39 | !(idx@45@00 >= |seqs@44@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 39 | idx@45@00 >= |seqs@44@00|]
(assert (>= idx@45@00 (Seq_length seqs@44@00)))
; [eval] result == Seq[Int]()
; [eval] Seq[Int]()
(pop) ; 3
(push) ; 3
; [else-branch: 39 | !(idx@45@00 >= |seqs@44@00|)]
(assert (not (>= idx@45@00 (Seq_length seqs@44@00))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(push) ; 2
(assert (not (=>
  (>= idx@45@00 (Seq_length seqs@44@00))
  (Seq_equal result@46@00 (as Seq_empty  Seq<Int>)))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=>
  (>= idx@45@00 (Seq_length seqs@44@00))
  (Seq_equal result@46@00 (as Seq_empty  Seq<Int>))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (seqs@44@00 Seq<Seq<Int>>) (idx@45@00 Int)) (!
  (=>
    (flatten_sequences%precondition s@$ seqs@44@00 idx@45@00)
    (=
      (flatten_sequences s@$ seqs@44@00 idx@45@00)
      (ite
        (>= idx@45@00 (Seq_length seqs@44@00))
        (as Seq_empty  Seq<Int>)
        (Seq_append
          (Seq_index seqs@44@00 idx@45@00)
          (flatten_sequences%limited $Snap.unit seqs@44@00 (+ idx@45@00 1))))))
  :pattern ((flatten_sequences s@$ seqs@44@00 idx@45@00))
  :qid |quant-u-94|)))
(assert (forall ((s@$ $Snap) (seqs@44@00 Seq<Seq<Int>>) (idx@45@00 Int)) (!
  (=>
    (flatten_sequences%precondition s@$ seqs@44@00 idx@45@00)
    (ite
      (>= idx@45@00 (Seq_length seqs@44@00))
      true
      (flatten_sequences%precondition $Snap.unit seqs@44@00 (+ idx@45@00 1))))
  :pattern ((flatten_sequences s@$ seqs@44@00 idx@45@00))
  :qid |quant-u-95|)))
; ---------- FUNCTION lcs_length----------
(declare-fun s1@47@00 () Seq<Int>)
(declare-fun s2@48@00 () Seq<Int>)
(declare-fun result@49@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@81@00 $Snap)
(assert (= $t@81@00 ($Snap.combine ($Snap.first $t@81@00) ($Snap.second $t@81@00))))
(assert (= ($Snap.first $t@81@00) $Snap.unit))
; [eval] result >= 0
(assert (>= result@49@00 0))
(assert (=
  ($Snap.second $t@81@00)
  ($Snap.combine
    ($Snap.first ($Snap.second $t@81@00))
    ($Snap.second ($Snap.second $t@81@00)))))
(assert (= ($Snap.first ($Snap.second $t@81@00)) $Snap.unit))
; [eval] result <= |s1|
; [eval] |s1|
(assert (<= result@49@00 (Seq_length s1@47@00)))
(assert (= ($Snap.second ($Snap.second $t@81@00)) $Snap.unit))
; [eval] result <= |s2|
; [eval] |s2|
(assert (<= result@49@00 (Seq_length s2@48@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s1@47@00 Seq<Int>) (s2@48@00 Seq<Int>)) (!
  (=
    (lcs_length%limited s@$ s1@47@00 s2@48@00)
    (lcs_length s@$ s1@47@00 s2@48@00))
  :pattern ((lcs_length s@$ s1@47@00 s2@48@00))
  :qid |quant-u-28|)))
(assert (forall ((s@$ $Snap) (s1@47@00 Seq<Int>) (s2@48@00 Seq<Int>)) (!
  (lcs_length%stateless s1@47@00 s2@48@00)
  :pattern ((lcs_length%limited s@$ s1@47@00 s2@48@00))
  :qid |quant-u-29|)))
(assert (forall ((s@$ $Snap) (s1@47@00 Seq<Int>) (s2@48@00 Seq<Int>)) (!
  (let ((result@49@00 (lcs_length%limited s@$ s1@47@00 s2@48@00))) (=>
    (lcs_length%precondition s@$ s1@47@00 s2@48@00)
    (and
      (>= result@49@00 0)
      (and
        (<= result@49@00 (Seq_length s1@47@00))
        (<= result@49@00 (Seq_length s2@48@00))))))
  :pattern ((lcs_length%limited s@$ s1@47@00 s2@48@00))
  :qid |quant-u-96|)))
(assert (forall ((s@$ $Snap) (s1@47@00 Seq<Int>) (s2@48@00 Seq<Int>)) (!
  (let ((result@49@00 (lcs_length%limited s@$ s1@47@00 s2@48@00))) true)
  :pattern ((lcs_length%limited s@$ s1@47@00 s2@48@00))
  :qid |quant-u-97|)))
(assert (forall ((s@$ $Snap) (s1@47@00 Seq<Int>) (s2@48@00 Seq<Int>)) (!
  (let ((result@49@00 (lcs_length%limited s@$ s1@47@00 s2@48@00))) true)
  :pattern ((lcs_length%limited s@$ s1@47@00 s2@48@00))
  :qid |quant-u-98|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|s1| == 0 || |s2| == 0 ? 0 : (s1[0] == s2[0] ? 1 + lcs_length(s1[1..], s2[1..]) : max_int(lcs_length(s1[1..], s2), lcs_length(s1, s2[1..]))))
; [eval] |s1| == 0 || |s2| == 0
; [eval] |s1| == 0
; [eval] |s1|
(set-option :rlimit 0)
(push) ; 2
; [then-branch: 40 | |s1@47@00| == 0 | live]
; [else-branch: 40 | |s1@47@00| != 0 | live]
(push) ; 3
; [then-branch: 40 | |s1@47@00| == 0]
(assert (= (Seq_length s1@47@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 40 | |s1@47@00| != 0]
(assert (not (= (Seq_length s1@47@00) 0)))
; [eval] |s2| == 0
; [eval] |s2|
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= (Seq_length s1@47@00) 0)) (= (Seq_length s1@47@00) 0)))
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (or (= (Seq_length s1@47@00) 0) (= (Seq_length s2@48@00) 0)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (or (= (Seq_length s1@47@00) 0) (= (Seq_length s2@48@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 41 | |s1@47@00| == 0 || |s2@48@00| == 0 | live]
; [else-branch: 41 | !(|s1@47@00| == 0 || |s2@48@00| == 0) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 41 | |s1@47@00| == 0 || |s2@48@00| == 0]
(assert (or (= (Seq_length s1@47@00) 0) (= (Seq_length s2@48@00) 0)))
(pop) ; 3
(push) ; 3
; [else-branch: 41 | !(|s1@47@00| == 0 || |s2@48@00| == 0)]
(assert (not (or (= (Seq_length s1@47@00) 0) (= (Seq_length s2@48@00) 0))))
; [eval] (s1[0] == s2[0] ? 1 + lcs_length(s1[1..], s2[1..]) : max_int(lcs_length(s1[1..], s2), lcs_length(s1, s2[1..])))
; [eval] s1[0] == s2[0]
; [eval] s1[0]
(push) ; 4
(assert (not (< 0 (Seq_length s1@47@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [eval] s2[0]
(push) ; 4
(assert (not (< 0 (Seq_length s2@48@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0)))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 42 | s1@47@00[0] == s2@48@00[0] | live]
; [else-branch: 42 | s1@47@00[0] != s2@48@00[0] | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 42 | s1@47@00[0] == s2@48@00[0]]
(assert (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0)))
; [eval] 1 + lcs_length(s1[1..], s2[1..])
; [eval] lcs_length(s1[1..], s2[1..])
; [eval] s1[1..]
; [eval] s2[1..]
(push) ; 6
(assert (lcs_length%precondition $Snap.unit (Seq_drop s1@47@00 1) (Seq_drop s2@48@00 1)))
(pop) ; 6
; Joined path conditions
(assert (lcs_length%precondition $Snap.unit (Seq_drop s1@47@00 1) (Seq_drop s2@48@00 1)))
(pop) ; 5
(push) ; 5
; [else-branch: 42 | s1@47@00[0] != s2@48@00[0]]
(assert (not (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0))))
; [eval] max_int(lcs_length(s1[1..], s2), lcs_length(s1, s2[1..]))
; [eval] lcs_length(s1[1..], s2)
; [eval] s1[1..]
(push) ; 6
(assert (lcs_length%precondition $Snap.unit (Seq_drop s1@47@00 1) s2@48@00))
(pop) ; 6
; Joined path conditions
(assert (lcs_length%precondition $Snap.unit (Seq_drop s1@47@00 1) s2@48@00))
; [eval] lcs_length(s1, s2[1..])
; [eval] s2[1..]
(push) ; 6
(assert (lcs_length%precondition $Snap.unit s1@47@00 (Seq_drop s2@48@00 1)))
(pop) ; 6
; Joined path conditions
(assert (lcs_length%precondition $Snap.unit s1@47@00 (Seq_drop s2@48@00 1)))
(push) ; 6
(assert (max_int%precondition $Snap.unit (lcs_length $Snap.unit (Seq_drop s1@47@00 1) s2@48@00) (lcs_length $Snap.unit s1@47@00 (Seq_drop
  s2@48@00
  1))))
(pop) ; 6
; Joined path conditions
(assert (max_int%precondition $Snap.unit (lcs_length $Snap.unit (Seq_drop s1@47@00 1) s2@48@00) (lcs_length $Snap.unit s1@47@00 (Seq_drop
  s2@48@00
  1))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=>
  (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0))
  (and
    (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0))
    (lcs_length%precondition $Snap.unit (Seq_drop s1@47@00 1) (Seq_drop
      s2@48@00
      1)))))
; Joined path conditions
(assert (=>
  (not (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0)))
  (and
    (not (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0)))
    (lcs_length%precondition $Snap.unit (Seq_drop s1@47@00 1) s2@48@00)
    (lcs_length%precondition $Snap.unit s1@47@00 (Seq_drop s2@48@00 1))
    (max_int%precondition $Snap.unit (lcs_length $Snap.unit (Seq_drop s1@47@00 1) s2@48@00) (lcs_length $Snap.unit s1@47@00 (Seq_drop
      s2@48@00
      1))))))
(assert (or
  (not (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0)))
  (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (or (= (Seq_length s1@47@00) 0) (= (Seq_length s2@48@00) 0)))
  (and
    (not (or (= (Seq_length s1@47@00) 0) (= (Seq_length s2@48@00) 0)))
    (=>
      (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0))
      (and
        (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0))
        (lcs_length%precondition $Snap.unit (Seq_drop s1@47@00 1) (Seq_drop
          s2@48@00
          1))))
    (=>
      (not (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0)))
      (and
        (not (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0)))
        (lcs_length%precondition $Snap.unit (Seq_drop s1@47@00 1) s2@48@00)
        (lcs_length%precondition $Snap.unit s1@47@00 (Seq_drop s2@48@00 1))
        (max_int%precondition $Snap.unit (lcs_length $Snap.unit (Seq_drop
          s1@47@00
          1) s2@48@00) (lcs_length $Snap.unit s1@47@00 (Seq_drop s2@48@00 1)))))
    (or
      (not (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0)))
      (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0))))))
(assert (or
  (not (or (= (Seq_length s1@47@00) 0) (= (Seq_length s2@48@00) 0)))
  (or (= (Seq_length s1@47@00) 0) (= (Seq_length s2@48@00) 0))))
(assert (=
  result@49@00
  (ite
    (or (= (Seq_length s1@47@00) 0) (= (Seq_length s2@48@00) 0))
    0
    (ite
      (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0))
      (+ 1 (lcs_length $Snap.unit (Seq_drop s1@47@00 1) (Seq_drop s2@48@00 1)))
      (max_int $Snap.unit (lcs_length $Snap.unit (Seq_drop s1@47@00 1) s2@48@00) (lcs_length $Snap.unit s1@47@00 (Seq_drop
        s2@48@00
        1)))))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@49@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@49@00 0))
; [eval] result <= |s1|
; [eval] |s1|
(push) ; 2
(assert (not (<= result@49@00 (Seq_length s1@47@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (<= result@49@00 (Seq_length s1@47@00)))
; [eval] result <= |s2|
; [eval] |s2|
(push) ; 2
(assert (not (<= result@49@00 (Seq_length s2@48@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (<= result@49@00 (Seq_length s2@48@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s1@47@00 Seq<Int>) (s2@48@00 Seq<Int>)) (!
  (=>
    (lcs_length%precondition s@$ s1@47@00 s2@48@00)
    (=
      (lcs_length s@$ s1@47@00 s2@48@00)
      (ite
        (or (= (Seq_length s1@47@00) 0) (= (Seq_length s2@48@00) 0))
        0
        (ite
          (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0))
          (+
            1
            (lcs_length%limited $Snap.unit (Seq_drop s1@47@00 1) (Seq_drop
              s2@48@00
              1)))
          (max_int $Snap.unit (lcs_length%limited $Snap.unit (Seq_drop
            s1@47@00
            1) s2@48@00) (lcs_length%limited $Snap.unit s1@47@00 (Seq_drop
            s2@48@00
            1)))))))
  :pattern ((lcs_length s@$ s1@47@00 s2@48@00))
  :qid |quant-u-99|)))
(assert (forall ((s@$ $Snap) (s1@47@00 Seq<Int>) (s2@48@00 Seq<Int>)) (!
  (=>
    (lcs_length%precondition s@$ s1@47@00 s2@48@00)
    (ite
      (or (= (Seq_length s1@47@00) 0) (= (Seq_length s2@48@00) 0))
      true
      (ite
        (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0))
        (lcs_length%precondition $Snap.unit (Seq_drop s1@47@00 1) (Seq_drop
          s2@48@00
          1))
        (and
          (lcs_length%precondition $Snap.unit (Seq_drop s1@47@00 1) s2@48@00)
          (lcs_length%precondition $Snap.unit s1@47@00 (Seq_drop s2@48@00 1))
          (max_int%precondition $Snap.unit (lcs_length%limited $Snap.unit (Seq_drop
            s1@47@00
            1) s2@48@00) (lcs_length%limited $Snap.unit s1@47@00 (Seq_drop
            s2@48@00
            1)))))))
  :pattern ((lcs_length s@$ s1@47@00 s2@48@00))
  :qid |quant-u-100|)))
; ---------- FUNCTION count_inversions----------
(declare-fun s@50@00 () Seq<Int>)
(declare-fun i@51@00 () Int)
(declare-fun j@52@00 () Int)
(declare-fun result@53@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] 0 <= i
(assert (<= 0 i@51@00))
(assert (=
  ($Snap.second s@$)
  ($Snap.combine
    ($Snap.first ($Snap.second s@$))
    ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.first ($Snap.second s@$)) $Snap.unit))
; [eval] i <= |s|
; [eval] |s|
(assert (<= i@51@00 (Seq_length s@50@00)))
(assert (=
  ($Snap.second ($Snap.second s@$))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second s@$)))
    ($Snap.second ($Snap.second ($Snap.second s@$))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))
; [eval] 0 <= j
(assert (<= 0 j@52@00))
(assert (= ($Snap.second ($Snap.second ($Snap.second s@$))) $Snap.unit))
; [eval] j <= |s|
; [eval] |s|
(assert (<= j@52@00 (Seq_length s@50@00)))
(declare-const $t@82@00 $Snap)
(assert (= $t@82@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@53@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@50@00 Seq<Int>) (i@51@00 Int) (j@52@00 Int)) (!
  (=
    (count_inversions%limited s@$ s@50@00 i@51@00 j@52@00)
    (count_inversions s@$ s@50@00 i@51@00 j@52@00))
  :pattern ((count_inversions s@$ s@50@00 i@51@00 j@52@00))
  :qid |quant-u-30|)))
(assert (forall ((s@$ $Snap) (s@50@00 Seq<Int>) (i@51@00 Int) (j@52@00 Int)) (!
  (count_inversions%stateless s@50@00 i@51@00 j@52@00)
  :pattern ((count_inversions%limited s@$ s@50@00 i@51@00 j@52@00))
  :qid |quant-u-31|)))
(assert (forall ((s@$ $Snap) (s@50@00 Seq<Int>) (i@51@00 Int) (j@52@00 Int)) (!
  (let ((result@53@00 (count_inversions%limited s@$ s@50@00 i@51@00 j@52@00))) (=>
    (count_inversions%precondition s@$ s@50@00 i@51@00 j@52@00)
    (>= result@53@00 0)))
  :pattern ((count_inversions%limited s@$ s@50@00 i@51@00 j@52@00))
  :qid |quant-u-101|)))
(assert (forall ((s@$ $Snap) (s@50@00 Seq<Int>) (i@51@00 Int) (j@52@00 Int)) (!
  (let ((result@53@00 (count_inversions%limited s@$ s@50@00 i@51@00 j@52@00))) true)
  :pattern ((count_inversions%limited s@$ s@50@00 i@51@00 j@52@00))
  :qid |quant-u-102|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (<= 0 i@51@00))
(assert (=
  ($Snap.second s@$)
  ($Snap.combine
    ($Snap.first ($Snap.second s@$))
    ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.first ($Snap.second s@$)) $Snap.unit))
(assert (<= i@51@00 (Seq_length s@50@00)))
(assert (=
  ($Snap.second ($Snap.second s@$))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second s@$)))
    ($Snap.second ($Snap.second ($Snap.second s@$))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))
(assert (<= 0 j@52@00))
(assert (= ($Snap.second ($Snap.second ($Snap.second s@$))) $Snap.unit))
(assert (<= j@52@00 (Seq_length s@50@00)))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (i >= |s| ? 0 : (j >= |s| ? count_inversions(s, i + 1, i + 2) : (j <= i ? count_inversions(s, i, j + 1) : (s[i] > s[j] ? 1 : 0) + count_inversions(s, i, j + 1))))
; [eval] i >= |s|
; [eval] |s|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= i@51@00 (Seq_length s@50@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= i@51@00 (Seq_length s@50@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 43 | i@51@00 >= |s@50@00| | live]
; [else-branch: 43 | !(i@51@00 >= |s@50@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 43 | i@51@00 >= |s@50@00|]
(assert (>= i@51@00 (Seq_length s@50@00)))
(pop) ; 3
(push) ; 3
; [else-branch: 43 | !(i@51@00 >= |s@50@00|)]
(assert (not (>= i@51@00 (Seq_length s@50@00))))
; [eval] (j >= |s| ? count_inversions(s, i + 1, i + 2) : (j <= i ? count_inversions(s, i, j + 1) : (s[i] > s[j] ? 1 : 0) + count_inversions(s, i, j + 1)))
; [eval] j >= |s|
; [eval] |s|
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (>= j@52@00 (Seq_length s@50@00)))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (>= j@52@00 (Seq_length s@50@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 44 | j@52@00 >= |s@50@00| | live]
; [else-branch: 44 | !(j@52@00 >= |s@50@00|) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 44 | j@52@00 >= |s@50@00|]
(assert (>= j@52@00 (Seq_length s@50@00)))
; [eval] count_inversions(s, i + 1, i + 2)
; [eval] i + 1
; [eval] i + 2
(push) ; 6
; [eval] 0 <= i
(push) ; 7
(assert (not (<= 0 (+ i@51@00 1))))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (<= 0 (+ i@51@00 1)))
; [eval] i <= |s|
; [eval] |s|
(push) ; 7
(assert (not (<= (+ i@51@00 1) (Seq_length s@50@00))))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (<= (+ i@51@00 1) (Seq_length s@50@00)))
; [eval] 0 <= j
(push) ; 7
(assert (not (<= 0 (+ i@51@00 2))))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (<= 0 (+ i@51@00 2)))
; [eval] j <= |s|
; [eval] |s|
(push) ; 7
(assert (not (<= (+ i@51@00 2) (Seq_length s@50@00))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] j <= |s|
; [eval] |s|
(set-option :rlimit 0)
(push) ; 7
(assert (not (<= (+ i@51@00 2) (Seq_length s@50@00))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] j <= |s|
; [eval] |s|
(set-option :rlimit 0)
(push) ; 7
(assert (not (<= (+ i@51@00 2) (Seq_length s@50@00))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] j <= |s|
; [eval] |s|
(set-option :rlimit 0)
(push) ; 7
(assert (not (<= (+ i@51@00 2) (Seq_length s@50@00))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(pop) ; 6
(pop) ; 5
(pop) ; 4
(pop) ; 3
(pop) ; 2
(pop) ; 1
; ---------- FUNCTION rotate_left----------
(declare-fun s@54@00 () Seq<Int>)
(declare-fun n@55@00 () Int)
(declare-fun result@56@00 () Seq<Int>)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] n >= 0
(assert (>= n@55@00 0))
(declare-const $t@83@00 $Snap)
(assert (= $t@83@00 ($Snap.combine ($Snap.first $t@83@00) ($Snap.second $t@83@00))))
(assert (= ($Snap.first $t@83@00) $Snap.unit))
; [eval] |s| == 0 ==> result == s
; [eval] |s| == 0
; [eval] |s|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Seq_length s@54@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Seq_length s@54@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 45 | |s@54@00| == 0 | live]
; [else-branch: 45 | |s@54@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 45 | |s@54@00| == 0]
(assert (= (Seq_length s@54@00) 0))
; [eval] result == s
(pop) ; 3
(push) ; 3
; [else-branch: 45 | |s@54@00| != 0]
(assert (not (= (Seq_length s@54@00) 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= (Seq_length s@54@00) 0)) (= (Seq_length s@54@00) 0)))
(assert (=> (= (Seq_length s@54@00) 0) (Seq_equal result@56@00 s@54@00)))
(assert (= ($Snap.second $t@83@00) $Snap.unit))
; [eval] n == 0 ==> result == s
; [eval] n == 0
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= n@55@00 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= n@55@00 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 46 | n@55@00 == 0 | live]
; [else-branch: 46 | n@55@00 != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 46 | n@55@00 == 0]
(assert (= n@55@00 0))
; [eval] result == s
(pop) ; 3
(push) ; 3
; [else-branch: 46 | n@55@00 != 0]
(assert (not (= n@55@00 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= n@55@00 0)) (= n@55@00 0)))
(assert (=> (= n@55@00 0) (Seq_equal result@56@00 s@54@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@54@00 Seq<Int>) (n@55@00 Int)) (!
  (=
    (rotate_left%limited s@$ s@54@00 n@55@00)
    (rotate_left_ s@$ s@54@00 n@55@00))
  :pattern ((rotate_left_ s@$ s@54@00 n@55@00))
  :qid |quant-u-32|)))
(assert (forall ((s@$ $Snap) (s@54@00 Seq<Int>) (n@55@00 Int)) (!
  (rotate_left%stateless s@54@00 n@55@00)
  :pattern ((rotate_left%limited s@$ s@54@00 n@55@00))
  :qid |quant-u-33|)))
(assert (forall ((s@$ $Snap) (s@54@00 Seq<Int>) (n@55@00 Int)) (!
  (let ((result@56@00 (rotate_left%limited s@$ s@54@00 n@55@00))) (=>
    (rotate_left%precondition s@$ s@54@00 n@55@00)
    (and
      (=> (= (Seq_length s@54@00) 0) (Seq_equal result@56@00 s@54@00))
      (=> (= n@55@00 0) (Seq_equal result@56@00 s@54@00)))))
  :pattern ((rotate_left%limited s@$ s@54@00 n@55@00))
  :qid |quant-u-103|)))
(assert (forall ((s@$ $Snap) (s@54@00 Seq<Int>) (n@55@00 Int)) (!
  (let ((result@56@00 (rotate_left%limited s@$ s@54@00 n@55@00))) true)
  :pattern ((rotate_left%limited s@$ s@54@00 n@55@00))
  :qid |quant-u-104|)))
(assert (forall ((s@$ $Snap) (s@54@00 Seq<Int>) (n@55@00 Int)) (!
  (let ((result@56@00 (rotate_left%limited s@$ s@54@00 n@55@00))) true)
  :pattern ((rotate_left%limited s@$ s@54@00 n@55@00))
  :qid |quant-u-105|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (>= n@55@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|s| == 0 || n == 0 ? s : (n >= |s| ? rotate_left(s, n % |s|) : s[n..] ++ s[..n]))
; [eval] |s| == 0 || n == 0
; [eval] |s| == 0
; [eval] |s|
(set-option :rlimit 0)
(push) ; 2
; [then-branch: 47 | |s@54@00| == 0 | live]
; [else-branch: 47 | |s@54@00| != 0 | live]
(push) ; 3
; [then-branch: 47 | |s@54@00| == 0]
(assert (= (Seq_length s@54@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 47 | |s@54@00| != 0]
(assert (not (= (Seq_length s@54@00) 0)))
; [eval] n == 0
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= (Seq_length s@54@00) 0)) (= (Seq_length s@54@00) 0)))
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (or (= (Seq_length s@54@00) 0) (= n@55@00 0)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (or (= (Seq_length s@54@00) 0) (= n@55@00 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 48 | |s@54@00| == 0 || n@55@00 == 0 | live]
; [else-branch: 48 | !(|s@54@00| == 0 || n@55@00 == 0) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 48 | |s@54@00| == 0 || n@55@00 == 0]
(assert (or (= (Seq_length s@54@00) 0) (= n@55@00 0)))
(pop) ; 3
(push) ; 3
; [else-branch: 48 | !(|s@54@00| == 0 || n@55@00 == 0)]
(assert (not (or (= (Seq_length s@54@00) 0) (= n@55@00 0))))
; [eval] (n >= |s| ? rotate_left(s, n % |s|) : s[n..] ++ s[..n])
; [eval] n >= |s|
; [eval] |s|
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (>= n@55@00 (Seq_length s@54@00)))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (>= n@55@00 (Seq_length s@54@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 49 | n@55@00 >= |s@54@00| | live]
; [else-branch: 49 | !(n@55@00 >= |s@54@00|) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 49 | n@55@00 >= |s@54@00|]
(assert (>= n@55@00 (Seq_length s@54@00)))
; [eval] rotate_left(s, n % |s|)
; [eval] n % |s|
; [eval] |s|
(push) ; 6
(assert (not (not (= (Seq_length s@54@00) 0))))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(push) ; 6
; [eval] n >= 0
(push) ; 7
(assert (not (>= (mod n@55@00 (Seq_length s@54@00)) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (>= (mod n@55@00 (Seq_length s@54@00)) 0))
(assert (rotate_left%precondition $Snap.unit s@54@00 (mod n@55@00 (Seq_length s@54@00))))
(pop) ; 6
; Joined path conditions
(assert (and
  (>= (mod n@55@00 (Seq_length s@54@00)) 0)
  (rotate_left%precondition $Snap.unit s@54@00 (mod n@55@00 (Seq_length s@54@00)))))
(pop) ; 5
(push) ; 5
; [else-branch: 49 | !(n@55@00 >= |s@54@00|)]
(assert (not (>= n@55@00 (Seq_length s@54@00))))
; [eval] s[n..] ++ s[..n]
; [eval] s[n..]
; [eval] s[..n]
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=>
  (>= n@55@00 (Seq_length s@54@00))
  (and
    (>= n@55@00 (Seq_length s@54@00))
    (>= (mod n@55@00 (Seq_length s@54@00)) 0)
    (rotate_left%precondition $Snap.unit s@54@00 (mod
      n@55@00
      (Seq_length s@54@00))))))
; Joined path conditions
(assert (or (not (>= n@55@00 (Seq_length s@54@00))) (>= n@55@00 (Seq_length s@54@00))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (or (= (Seq_length s@54@00) 0) (= n@55@00 0)))
  (and
    (not (or (= (Seq_length s@54@00) 0) (= n@55@00 0)))
    (=>
      (>= n@55@00 (Seq_length s@54@00))
      (and
        (>= n@55@00 (Seq_length s@54@00))
        (>= (mod n@55@00 (Seq_length s@54@00)) 0)
        (rotate_left%precondition $Snap.unit s@54@00 (mod
          n@55@00
          (Seq_length s@54@00)))))
    (or
      (not (>= n@55@00 (Seq_length s@54@00)))
      (>= n@55@00 (Seq_length s@54@00))))))
(assert (or
  (not (or (= (Seq_length s@54@00) 0) (= n@55@00 0)))
  (or (= (Seq_length s@54@00) 0) (= n@55@00 0))))
(assert (=
  result@56@00
  (ite
    (or (= (Seq_length s@54@00) 0) (= n@55@00 0))
    s@54@00
    (ite
      (>= n@55@00 (Seq_length s@54@00))
      (rotate_left_ $Snap.unit s@54@00 (mod n@55@00 (Seq_length s@54@00)))
      (Seq_append (Seq_drop s@54@00 n@55@00) (Seq_take s@54@00 n@55@00))))))
; [eval] |s| == 0 ==> result == s
; [eval] |s| == 0
; [eval] |s|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Seq_length s@54@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Seq_length s@54@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 50 | |s@54@00| == 0 | live]
; [else-branch: 50 | |s@54@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 50 | |s@54@00| == 0]
(assert (= (Seq_length s@54@00) 0))
; [eval] result == s
(pop) ; 3
(push) ; 3
; [else-branch: 50 | |s@54@00| != 0]
(assert (not (= (Seq_length s@54@00) 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(push) ; 2
(assert (not (=> (= (Seq_length s@54@00) 0) (Seq_equal result@56@00 s@54@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=> (= (Seq_length s@54@00) 0) (Seq_equal result@56@00 s@54@00)))
; [eval] n == 0 ==> result == s
; [eval] n == 0
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= n@55@00 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= n@55@00 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 51 | n@55@00 == 0 | live]
; [else-branch: 51 | n@55@00 != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 51 | n@55@00 == 0]
(assert (= n@55@00 0))
; [eval] result == s
(pop) ; 3
(push) ; 3
; [else-branch: 51 | n@55@00 != 0]
(assert (not (= n@55@00 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= n@55@00 0)) (= n@55@00 0)))
(push) ; 2
(assert (not (=> (= n@55@00 0) (Seq_equal result@56@00 s@54@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=> (= n@55@00 0) (Seq_equal result@56@00 s@54@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@54@00 Seq<Int>) (n@55@00 Int)) (!
  (=>
    (rotate_left%precondition s@$ s@54@00 n@55@00)
    (=
      (rotate_left_ s@$ s@54@00 n@55@00)
      (ite
        (or (= (Seq_length s@54@00) 0) (= n@55@00 0))
        s@54@00
        (ite
          (>= n@55@00 (Seq_length s@54@00))
          (rotate_left%limited $Snap.unit s@54@00 (mod
            n@55@00
            (Seq_length s@54@00)))
          (Seq_append (Seq_drop s@54@00 n@55@00) (Seq_take s@54@00 n@55@00))))))
  :pattern ((rotate_left_ s@$ s@54@00 n@55@00))
  :qid |quant-u-106|)))
(assert (forall ((s@$ $Snap) (s@54@00 Seq<Int>) (n@55@00 Int)) (!
  (=>
    (rotate_left%precondition s@$ s@54@00 n@55@00)
    (ite
      (or (= (Seq_length s@54@00) 0) (= n@55@00 0))
      true
      (ite
        (>= n@55@00 (Seq_length s@54@00))
        (rotate_left%precondition $Snap.unit s@54@00 (mod
          n@55@00
          (Seq_length s@54@00)))
        true)))
  :pattern ((rotate_left_ s@$ s@54@00 n@55@00))
  :qid |quant-u-107|)))
; ---------- FUNCTION has_duplicates----------
(declare-fun s@57@00 () Seq<Int>)
(declare-fun checked@58@00 () Set<Int>)
(declare-fun result@59@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@57@00 Seq<Int>) (checked@58@00 Set<Int>)) (!
  (=
    (has_duplicates%limited s@$ s@57@00 checked@58@00)
    (has_duplicates s@$ s@57@00 checked@58@00))
  :pattern ((has_duplicates s@$ s@57@00 checked@58@00))
  :qid |quant-u-34|)))
(assert (forall ((s@$ $Snap) (s@57@00 Seq<Int>) (checked@58@00 Set<Int>)) (!
  (has_duplicates%stateless s@57@00 checked@58@00)
  :pattern ((has_duplicates%limited s@$ s@57@00 checked@58@00))
  :qid |quant-u-35|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|s| == 0 ? false : ((s[0] in checked) ? true : has_duplicates(s[1..], (checked union Set(s[0])))))
; [eval] |s| == 0
; [eval] |s|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Seq_length s@57@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Seq_length s@57@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 52 | |s@57@00| == 0 | live]
; [else-branch: 52 | |s@57@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 52 | |s@57@00| == 0]
(assert (= (Seq_length s@57@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 52 | |s@57@00| != 0]
(assert (not (= (Seq_length s@57@00) 0)))
; [eval] ((s[0] in checked) ? true : has_duplicates(s[1..], (checked union Set(s[0]))))
; [eval] (s[0] in checked)
; [eval] s[0]
(push) ; 4
(assert (not (< 0 (Seq_length s@57@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (Set_in (Seq_index s@57@00 0) checked@58@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (Set_in (Seq_index s@57@00 0) checked@58@00)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 53 | s@57@00[0] in checked@58@00 | live]
; [else-branch: 53 | !(s@57@00[0] in checked@58@00) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 53 | s@57@00[0] in checked@58@00]
(assert (Set_in (Seq_index s@57@00 0) checked@58@00))
(pop) ; 5
(push) ; 5
; [else-branch: 53 | !(s@57@00[0] in checked@58@00)]
(assert (not (Set_in (Seq_index s@57@00 0) checked@58@00)))
; [eval] has_duplicates(s[1..], (checked union Set(s[0])))
; [eval] s[1..]
; [eval] (checked union Set(s[0]))
; [eval] Set(s[0])
; [eval] s[0]
(push) ; 6
(assert (not (< 0 (Seq_length s@57@00))))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(push) ; 6
(assert (has_duplicates%precondition $Snap.unit (Seq_drop s@57@00 1) (Set_union checked@58@00 (Set_singleton (Seq_index
  s@57@00
  0)))))
(pop) ; 6
; Joined path conditions
(assert (has_duplicates%precondition $Snap.unit (Seq_drop s@57@00 1) (Set_union checked@58@00 (Set_singleton (Seq_index
  s@57@00
  0)))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (Set_in (Seq_index s@57@00 0) checked@58@00))
  (and
    (not (Set_in (Seq_index s@57@00 0) checked@58@00))
    (has_duplicates%precondition $Snap.unit (Seq_drop s@57@00 1) (Set_union checked@58@00 (Set_singleton (Seq_index
      s@57@00
      0)))))))
(assert (or
  (not (Set_in (Seq_index s@57@00 0) checked@58@00))
  (Set_in (Seq_index s@57@00 0) checked@58@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Seq_length s@57@00) 0))
  (and
    (not (= (Seq_length s@57@00) 0))
    (=>
      (not (Set_in (Seq_index s@57@00 0) checked@58@00))
      (and
        (not (Set_in (Seq_index s@57@00 0) checked@58@00))
        (has_duplicates%precondition $Snap.unit (Seq_drop s@57@00 1) (Set_union checked@58@00 (Set_singleton (Seq_index
          s@57@00
          0))))))
    (or
      (not (Set_in (Seq_index s@57@00 0) checked@58@00))
      (Set_in (Seq_index s@57@00 0) checked@58@00)))))
(assert (or (not (= (Seq_length s@57@00) 0)) (= (Seq_length s@57@00) 0)))
(assert (=
  result@59@00
  (ite
    (= (Seq_length s@57@00) 0)
    false
    (ite
      (Set_in (Seq_index s@57@00 0) checked@58@00)
      true
      (has_duplicates $Snap.unit (Seq_drop s@57@00 1) (Set_union checked@58@00 (Set_singleton (Seq_index
        s@57@00
        0))))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@57@00 Seq<Int>) (checked@58@00 Set<Int>)) (!
  (=>
    (has_duplicates%precondition s@$ s@57@00 checked@58@00)
    (=
      (has_duplicates s@$ s@57@00 checked@58@00)
      (ite
        (= (Seq_length s@57@00) 0)
        false
        (ite
          (Set_in (Seq_index s@57@00 0) checked@58@00)
          true
          (has_duplicates%limited $Snap.unit (Seq_drop s@57@00 1) (Set_union checked@58@00 (Set_singleton (Seq_index
            s@57@00
            0))))))))
  :pattern ((has_duplicates s@$ s@57@00 checked@58@00))
  :qid |quant-u-108|)))
(assert (forall ((s@$ $Snap) (s@57@00 Seq<Int>) (checked@58@00 Set<Int>)) (!
  (=>
    (has_duplicates%precondition s@$ s@57@00 checked@58@00)
    (ite
      (= (Seq_length s@57@00) 0)
      true
      (ite
        (Set_in (Seq_index s@57@00 0) checked@58@00)
        true
        (has_duplicates%precondition $Snap.unit (Seq_drop s@57@00 1) (Set_union checked@58@00 (Set_singleton (Seq_index
          s@57@00
          0)))))))
  :pattern ((has_duplicates s@$ s@57@00 checked@58@00))
  :qid |quant-u-109|)))
; ---------- FUNCTION edit_distance----------
(declare-fun s1@60@00 () Seq<Int>)
(declare-fun s2@61@00 () Seq<Int>)
(declare-fun result@62@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@84@00 $Snap)
(assert (= $t@84@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@62@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s1@60@00 Seq<Int>) (s2@61@00 Seq<Int>)) (!
  (=
    (edit_distance%limited s@$ s1@60@00 s2@61@00)
    (edit_distance s@$ s1@60@00 s2@61@00))
  :pattern ((edit_distance s@$ s1@60@00 s2@61@00))
  :qid |quant-u-36|)))
(assert (forall ((s@$ $Snap) (s1@60@00 Seq<Int>) (s2@61@00 Seq<Int>)) (!
  (edit_distance%stateless s1@60@00 s2@61@00)
  :pattern ((edit_distance%limited s@$ s1@60@00 s2@61@00))
  :qid |quant-u-37|)))
(assert (forall ((s@$ $Snap) (s1@60@00 Seq<Int>) (s2@61@00 Seq<Int>)) (!
  (let ((result@62@00 (edit_distance%limited s@$ s1@60@00 s2@61@00))) (=>
    (edit_distance%precondition s@$ s1@60@00 s2@61@00)
    (>= result@62@00 0)))
  :pattern ((edit_distance%limited s@$ s1@60@00 s2@61@00))
  :qid |quant-u-110|)))
(assert (forall ((s@$ $Snap) (s1@60@00 Seq<Int>) (s2@61@00 Seq<Int>)) (!
  (let ((result@62@00 (edit_distance%limited s@$ s1@60@00 s2@61@00))) true)
  :pattern ((edit_distance%limited s@$ s1@60@00 s2@61@00))
  :qid |quant-u-111|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|s1| == 0 ? |s2| : (|s2| == 0 ? |s1| : (s1[0] == s2[0] ? edit_distance(s1[1..], s2[1..]) : 1 + min_of_three(edit_distance(s1[1..], s2), edit_distance(s1, s2[1..]), edit_distance(s1[1..], s2[1..])))))
; [eval] |s1| == 0
; [eval] |s1|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Seq_length s1@60@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Seq_length s1@60@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 54 | |s1@60@00| == 0 | live]
; [else-branch: 54 | |s1@60@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 54 | |s1@60@00| == 0]
(assert (= (Seq_length s1@60@00) 0))
; [eval] |s2|
(pop) ; 3
(push) ; 3
; [else-branch: 54 | |s1@60@00| != 0]
(assert (not (= (Seq_length s1@60@00) 0)))
; [eval] (|s2| == 0 ? |s1| : (s1[0] == s2[0] ? edit_distance(s1[1..], s2[1..]) : 1 + min_of_three(edit_distance(s1[1..], s2), edit_distance(s1, s2[1..]), edit_distance(s1[1..], s2[1..]))))
; [eval] |s2| == 0
; [eval] |s2|
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (= (Seq_length s2@61@00) 0))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= (Seq_length s2@61@00) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 55 | |s2@61@00| == 0 | live]
; [else-branch: 55 | |s2@61@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 55 | |s2@61@00| == 0]
(assert (= (Seq_length s2@61@00) 0))
; [eval] |s1|
(pop) ; 5
(push) ; 5
; [else-branch: 55 | |s2@61@00| != 0]
(assert (not (= (Seq_length s2@61@00) 0)))
; [eval] (s1[0] == s2[0] ? edit_distance(s1[1..], s2[1..]) : 1 + min_of_three(edit_distance(s1[1..], s2), edit_distance(s1, s2[1..]), edit_distance(s1[1..], s2[1..])))
; [eval] s1[0] == s2[0]
; [eval] s1[0]
(push) ; 6
(assert (not (< 0 (Seq_length s1@60@00))))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [eval] s2[0]
(push) ; 6
(assert (not (< 0 (Seq_length s2@61@00))))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(push) ; 6
(push) ; 7
(set-option :rlimit 16000)
(assert (not (not (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0)))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 16000)
(assert (not (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 56 | s1@60@00[0] == s2@61@00[0] | live]
; [else-branch: 56 | s1@60@00[0] != s2@61@00[0] | live]
(set-option :rlimit 0)
(push) ; 7
; [then-branch: 56 | s1@60@00[0] == s2@61@00[0]]
(assert (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0)))
; [eval] edit_distance(s1[1..], s2[1..])
; [eval] s1[1..]
; [eval] s2[1..]
(push) ; 8
(assert (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
  s2@61@00
  1)))
(pop) ; 8
; Joined path conditions
(assert (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
  s2@61@00
  1)))
(pop) ; 7
(push) ; 7
; [else-branch: 56 | s1@60@00[0] != s2@61@00[0]]
(assert (not (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0))))
; [eval] 1 + min_of_three(edit_distance(s1[1..], s2), edit_distance(s1, s2[1..]), edit_distance(s1[1..], s2[1..]))
; [eval] min_of_three(edit_distance(s1[1..], s2), edit_distance(s1, s2[1..]), edit_distance(s1[1..], s2[1..]))
; [eval] edit_distance(s1[1..], s2)
; [eval] s1[1..]
(push) ; 8
(assert (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) s2@61@00))
(pop) ; 8
; Joined path conditions
(assert (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) s2@61@00))
; [eval] edit_distance(s1, s2[1..])
; [eval] s2[1..]
(push) ; 8
(assert (edit_distance%precondition $Snap.unit s1@60@00 (Seq_drop s2@61@00 1)))
(pop) ; 8
; Joined path conditions
(assert (edit_distance%precondition $Snap.unit s1@60@00 (Seq_drop s2@61@00 1)))
; [eval] edit_distance(s1[1..], s2[1..])
; [eval] s1[1..]
; [eval] s2[1..]
(push) ; 8
(assert (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
  s2@61@00
  1)))
(pop) ; 8
; Joined path conditions
(assert (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
  s2@61@00
  1)))
(push) ; 8
(assert (min_of_three%precondition $Snap.unit (edit_distance $Snap.unit (Seq_drop
  s1@60@00
  1) s2@61@00) (edit_distance $Snap.unit s1@60@00 (Seq_drop s2@61@00 1)) (edit_distance $Snap.unit (Seq_drop
  s1@60@00
  1) (Seq_drop s2@61@00 1))))
(pop) ; 8
; Joined path conditions
(assert (min_of_three%precondition $Snap.unit (edit_distance $Snap.unit (Seq_drop
  s1@60@00
  1) s2@61@00) (edit_distance $Snap.unit s1@60@00 (Seq_drop s2@61@00 1)) (edit_distance $Snap.unit (Seq_drop
  s1@60@00
  1) (Seq_drop s2@61@00 1))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=>
  (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0))
  (and
    (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0))
    (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
      s2@61@00
      1)))))
; Joined path conditions
(assert (=>
  (not (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0)))
  (and
    (not (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0)))
    (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) s2@61@00)
    (edit_distance%precondition $Snap.unit s1@60@00 (Seq_drop s2@61@00 1))
    (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
      s2@61@00
      1))
    (min_of_three%precondition $Snap.unit (edit_distance $Snap.unit (Seq_drop
      s1@60@00
      1) s2@61@00) (edit_distance $Snap.unit s1@60@00 (Seq_drop s2@61@00 1)) (edit_distance $Snap.unit (Seq_drop
      s1@60@00
      1) (Seq_drop s2@61@00 1))))))
(assert (or
  (not (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0)))
  (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Seq_length s2@61@00) 0))
  (and
    (not (= (Seq_length s2@61@00) 0))
    (=>
      (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0))
      (and
        (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0))
        (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
          s2@61@00
          1))))
    (=>
      (not (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0)))
      (and
        (not (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0)))
        (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) s2@61@00)
        (edit_distance%precondition $Snap.unit s1@60@00 (Seq_drop s2@61@00 1))
        (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
          s2@61@00
          1))
        (min_of_three%precondition $Snap.unit (edit_distance $Snap.unit (Seq_drop
          s1@60@00
          1) s2@61@00) (edit_distance $Snap.unit s1@60@00 (Seq_drop s2@61@00 1)) (edit_distance $Snap.unit (Seq_drop
          s1@60@00
          1) (Seq_drop s2@61@00 1)))))
    (or
      (not (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0)))
      (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0))))))
(assert (or (not (= (Seq_length s2@61@00) 0)) (= (Seq_length s2@61@00) 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Seq_length s1@60@00) 0))
  (and
    (not (= (Seq_length s1@60@00) 0))
    (=>
      (not (= (Seq_length s2@61@00) 0))
      (and
        (not (= (Seq_length s2@61@00) 0))
        (=>
          (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0))
          (and
            (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0))
            (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
              s2@61@00
              1))))
        (=>
          (not (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0)))
          (and
            (not (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0)))
            (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) s2@61@00)
            (edit_distance%precondition $Snap.unit s1@60@00 (Seq_drop s2@61@00 1))
            (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
              s2@61@00
              1))
            (min_of_three%precondition $Snap.unit (edit_distance $Snap.unit (Seq_drop
              s1@60@00
              1) s2@61@00) (edit_distance $Snap.unit s1@60@00 (Seq_drop
              s2@61@00
              1)) (edit_distance $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
              s2@61@00
              1)))))
        (or
          (not (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0)))
          (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0)))))
    (or (not (= (Seq_length s2@61@00) 0)) (= (Seq_length s2@61@00) 0)))))
(assert (or (not (= (Seq_length s1@60@00) 0)) (= (Seq_length s1@60@00) 0)))
(assert (=
  result@62@00
  (ite
    (= (Seq_length s1@60@00) 0)
    (Seq_length s2@61@00)
    (ite
      (= (Seq_length s2@61@00) 0)
      (Seq_length s1@60@00)
      (ite
        (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0))
        (edit_distance $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop s2@61@00 1))
        (+
          1
          (min_of_three $Snap.unit (edit_distance $Snap.unit (Seq_drop
            s1@60@00
            1) s2@61@00) (edit_distance $Snap.unit s1@60@00 (Seq_drop s2@61@00 1)) (edit_distance $Snap.unit (Seq_drop
            s1@60@00
            1) (Seq_drop s2@61@00 1)))))))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@62@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@62@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s1@60@00 Seq<Int>) (s2@61@00 Seq<Int>)) (!
  (=>
    (edit_distance%precondition s@$ s1@60@00 s2@61@00)
    (=
      (edit_distance s@$ s1@60@00 s2@61@00)
      (ite
        (= (Seq_length s1@60@00) 0)
        (Seq_length s2@61@00)
        (ite
          (= (Seq_length s2@61@00) 0)
          (Seq_length s1@60@00)
          (ite
            (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0))
            (edit_distance%limited $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
              s2@61@00
              1))
            (+
              1
              (min_of_three $Snap.unit (edit_distance%limited $Snap.unit (Seq_drop
                s1@60@00
                1) s2@61@00) (edit_distance%limited $Snap.unit s1@60@00 (Seq_drop
                s2@61@00
                1)) (edit_distance%limited $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
                s2@61@00
                1)))))))))
  :pattern ((edit_distance s@$ s1@60@00 s2@61@00))
  :qid |quant-u-112|)))
(assert (forall ((s@$ $Snap) (s1@60@00 Seq<Int>) (s2@61@00 Seq<Int>)) (!
  (=>
    (edit_distance%precondition s@$ s1@60@00 s2@61@00)
    (ite
      (= (Seq_length s1@60@00) 0)
      true
      (ite
        (= (Seq_length s2@61@00) 0)
        true
        (ite
          (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0))
          (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
            s2@61@00
            1))
          (and
            (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) s2@61@00)
            (edit_distance%precondition $Snap.unit s1@60@00 (Seq_drop s2@61@00 1))
            (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
              s2@61@00
              1))
            (min_of_three%precondition $Snap.unit (edit_distance%limited $Snap.unit (Seq_drop
              s1@60@00
              1) s2@61@00) (edit_distance%limited $Snap.unit s1@60@00 (Seq_drop
              s2@61@00
              1)) (edit_distance%limited $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
              s2@61@00
              1))))))))
  :pattern ((edit_distance s@$ s1@60@00 s2@61@00))
  :qid |quant-u-113|)))
; ---------- FUNCTION remove_duplicates----------
(declare-fun s@63@00 () Seq<Int>)
(declare-fun seen@64@00 () Set<Int>)
(declare-fun result@65@00 () Seq<Int>)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@85@00 $Snap)
(assert (= $t@85@00 $Snap.unit))
; [eval] |s| == 0 ==> result == s
; [eval] |s| == 0
; [eval] |s|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Seq_length s@63@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Seq_length s@63@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 57 | |s@63@00| == 0 | live]
; [else-branch: 57 | |s@63@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 57 | |s@63@00| == 0]
(assert (= (Seq_length s@63@00) 0))
; [eval] result == s
(pop) ; 3
(push) ; 3
; [else-branch: 57 | |s@63@00| != 0]
(assert (not (= (Seq_length s@63@00) 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= (Seq_length s@63@00) 0)) (= (Seq_length s@63@00) 0)))
(assert (=> (= (Seq_length s@63@00) 0) (Seq_equal result@65@00 s@63@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@63@00 Seq<Int>) (seen@64@00 Set<Int>)) (!
  (=
    (remove_duplicates%limited s@$ s@63@00 seen@64@00)
    (remove_duplicates s@$ s@63@00 seen@64@00))
  :pattern ((remove_duplicates s@$ s@63@00 seen@64@00))
  :qid |quant-u-38|)))
(assert (forall ((s@$ $Snap) (s@63@00 Seq<Int>) (seen@64@00 Set<Int>)) (!
  (remove_duplicates%stateless s@63@00 seen@64@00)
  :pattern ((remove_duplicates%limited s@$ s@63@00 seen@64@00))
  :qid |quant-u-39|)))
(assert (forall ((s@$ $Snap) (s@63@00 Seq<Int>) (seen@64@00 Set<Int>)) (!
  (let ((result@65@00 (remove_duplicates%limited s@$ s@63@00 seen@64@00))) (=>
    (and
      (remove_duplicates%precondition s@$ s@63@00 seen@64@00)
      (= (Seq_length s@63@00) 0))
    (Seq_equal result@65@00 s@63@00)))
  :pattern ((remove_duplicates%limited s@$ s@63@00 seen@64@00))
  :qid |quant-u-114|)))
(assert (forall ((s@$ $Snap) (s@63@00 Seq<Int>) (seen@64@00 Set<Int>)) (!
  (let ((result@65@00 (remove_duplicates%limited s@$ s@63@00 seen@64@00))) true)
  :pattern ((remove_duplicates%limited s@$ s@63@00 seen@64@00))
  :qid |quant-u-115|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|s| == 0 ? s : ((s[0] in seen) ? remove_duplicates(s[1..], seen) : Seq(s[0]) ++ remove_duplicates(s[1..], (seen union Set(s[0])))))
; [eval] |s| == 0
; [eval] |s|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Seq_length s@63@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Seq_length s@63@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 58 | |s@63@00| == 0 | live]
; [else-branch: 58 | |s@63@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 58 | |s@63@00| == 0]
(assert (= (Seq_length s@63@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 58 | |s@63@00| != 0]
(assert (not (= (Seq_length s@63@00) 0)))
; [eval] ((s[0] in seen) ? remove_duplicates(s[1..], seen) : Seq(s[0]) ++ remove_duplicates(s[1..], (seen union Set(s[0]))))
; [eval] (s[0] in seen)
; [eval] s[0]
(push) ; 4
(assert (not (< 0 (Seq_length s@63@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (Set_in (Seq_index s@63@00 0) seen@64@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (Set_in (Seq_index s@63@00 0) seen@64@00)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 59 | s@63@00[0] in seen@64@00 | live]
; [else-branch: 59 | !(s@63@00[0] in seen@64@00) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 59 | s@63@00[0] in seen@64@00]
(assert (Set_in (Seq_index s@63@00 0) seen@64@00))
; [eval] remove_duplicates(s[1..], seen)
; [eval] s[1..]
(push) ; 6
(assert (remove_duplicates%precondition $Snap.unit (Seq_drop s@63@00 1) seen@64@00))
(pop) ; 6
; Joined path conditions
(assert (remove_duplicates%precondition $Snap.unit (Seq_drop s@63@00 1) seen@64@00))
(pop) ; 5
(push) ; 5
; [else-branch: 59 | !(s@63@00[0] in seen@64@00)]
(assert (not (Set_in (Seq_index s@63@00 0) seen@64@00)))
; [eval] Seq(s[0]) ++ remove_duplicates(s[1..], (seen union Set(s[0])))
; [eval] Seq(s[0])
; [eval] s[0]
(push) ; 6
(assert (not (< 0 (Seq_length s@63@00))))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(assert (= (Seq_length (Seq_singleton (Seq_index s@63@00 0))) 1))
; [eval] remove_duplicates(s[1..], (seen union Set(s[0])))
; [eval] s[1..]
; [eval] (seen union Set(s[0]))
; [eval] Set(s[0])
; [eval] s[0]
(push) ; 6
(assert (not (< 0 (Seq_length s@63@00))))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(push) ; 6
(assert (remove_duplicates%precondition $Snap.unit (Seq_drop s@63@00 1) (Set_union seen@64@00 (Set_singleton (Seq_index
  s@63@00
  0)))))
(pop) ; 6
; Joined path conditions
(assert (remove_duplicates%precondition $Snap.unit (Seq_drop s@63@00 1) (Set_union seen@64@00 (Set_singleton (Seq_index
  s@63@00
  0)))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=>
  (Set_in (Seq_index s@63@00 0) seen@64@00)
  (and
    (Set_in (Seq_index s@63@00 0) seen@64@00)
    (remove_duplicates%precondition $Snap.unit (Seq_drop s@63@00 1) seen@64@00))))
; Joined path conditions
(assert (=>
  (not (Set_in (Seq_index s@63@00 0) seen@64@00))
  (and
    (not (Set_in (Seq_index s@63@00 0) seen@64@00))
    (= (Seq_length (Seq_singleton (Seq_index s@63@00 0))) 1)
    (remove_duplicates%precondition $Snap.unit (Seq_drop s@63@00 1) (Set_union seen@64@00 (Set_singleton (Seq_index
      s@63@00
      0)))))))
(assert (or
  (not (Set_in (Seq_index s@63@00 0) seen@64@00))
  (Set_in (Seq_index s@63@00 0) seen@64@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Seq_length s@63@00) 0))
  (and
    (not (= (Seq_length s@63@00) 0))
    (=>
      (Set_in (Seq_index s@63@00 0) seen@64@00)
      (and
        (Set_in (Seq_index s@63@00 0) seen@64@00)
        (remove_duplicates%precondition $Snap.unit (Seq_drop s@63@00 1) seen@64@00)))
    (=>
      (not (Set_in (Seq_index s@63@00 0) seen@64@00))
      (and
        (not (Set_in (Seq_index s@63@00 0) seen@64@00))
        (= (Seq_length (Seq_singleton (Seq_index s@63@00 0))) 1)
        (remove_duplicates%precondition $Snap.unit (Seq_drop s@63@00 1) (Set_union seen@64@00 (Set_singleton (Seq_index
          s@63@00
          0))))))
    (or
      (not (Set_in (Seq_index s@63@00 0) seen@64@00))
      (Set_in (Seq_index s@63@00 0) seen@64@00)))))
(assert (or (not (= (Seq_length s@63@00) 0)) (= (Seq_length s@63@00) 0)))
(assert (=
  result@65@00
  (ite
    (= (Seq_length s@63@00) 0)
    s@63@00
    (ite
      (Set_in (Seq_index s@63@00 0) seen@64@00)
      (remove_duplicates $Snap.unit (Seq_drop s@63@00 1) seen@64@00)
      (Seq_append
        (Seq_singleton (Seq_index s@63@00 0))
        (remove_duplicates $Snap.unit (Seq_drop s@63@00 1) (Set_union seen@64@00 (Set_singleton (Seq_index
          s@63@00
          0)))))))))
; [eval] |s| == 0 ==> result == s
; [eval] |s| == 0
; [eval] |s|
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Seq_length s@63@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Seq_length s@63@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 60 | |s@63@00| == 0 | live]
; [else-branch: 60 | |s@63@00| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 60 | |s@63@00| == 0]
(assert (= (Seq_length s@63@00) 0))
; [eval] result == s
(pop) ; 3
(push) ; 3
; [else-branch: 60 | |s@63@00| != 0]
(assert (not (= (Seq_length s@63@00) 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(push) ; 2
(assert (not (=> (= (Seq_length s@63@00) 0) (Seq_equal result@65@00 s@63@00))))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (=> (= (Seq_length s@63@00) 0) (Seq_equal result@65@00 s@63@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@63@00 Seq<Int>) (seen@64@00 Set<Int>)) (!
  (=>
    (remove_duplicates%precondition s@$ s@63@00 seen@64@00)
    (=
      (remove_duplicates s@$ s@63@00 seen@64@00)
      (ite
        (= (Seq_length s@63@00) 0)
        s@63@00
        (ite
          (Set_in (Seq_index s@63@00 0) seen@64@00)
          (remove_duplicates%limited $Snap.unit (Seq_drop s@63@00 1) seen@64@00)
          (Seq_append
            (Seq_singleton (Seq_index s@63@00 0))
            (remove_duplicates%limited $Snap.unit (Seq_drop s@63@00 1) (Set_union seen@64@00 (Set_singleton (Seq_index
              s@63@00
              0)))))))))
  :pattern ((remove_duplicates s@$ s@63@00 seen@64@00))
  :qid |quant-u-116|)))
(assert (forall ((s@$ $Snap) (s@63@00 Seq<Int>) (seen@64@00 Set<Int>)) (!
  (=>
    (remove_duplicates%precondition s@$ s@63@00 seen@64@00)
    (ite
      (= (Seq_length s@63@00) 0)
      true
      (ite
        (Set_in (Seq_index s@63@00 0) seen@64@00)
        (remove_duplicates%precondition $Snap.unit (Seq_drop s@63@00 1) seen@64@00)
        (remove_duplicates%precondition $Snap.unit (Seq_drop s@63@00 1) (Set_union seen@64@00 (Set_singleton (Seq_index
          s@63@00
          0)))))))
  :pattern ((remove_duplicates s@$ s@63@00 seen@64@00))
  :qid |quant-u-117|)))
; ---------- FUNCTION is_increasing----------
(declare-fun s@66@00 () Seq<Int>)
(declare-fun result@67@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@66@00 Seq<Int>)) (!
  (= (is_increasing%limited s@$ s@66@00) (is_increasing s@$ s@66@00))
  :pattern ((is_increasing s@$ s@66@00))
  :qid |quant-u-40|)))
(assert (forall ((s@$ $Snap) (s@66@00 Seq<Int>)) (!
  (is_increasing%stateless s@66@00)
  :pattern ((is_increasing%limited s@$ s@66@00))
  :qid |quant-u-41|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|s| <= 1 ? true : s[0] <= s[1] && is_increasing(s[1..]))
; [eval] |s| <= 1
; [eval] |s|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (<= (Seq_length s@66@00) 1))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (<= (Seq_length s@66@00) 1)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 61 | |s@66@00| <= 1 | live]
; [else-branch: 61 | !(|s@66@00| <= 1) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 61 | |s@66@00| <= 1]
(assert (<= (Seq_length s@66@00) 1))
(pop) ; 3
(push) ; 3
; [else-branch: 61 | !(|s@66@00| <= 1)]
(assert (not (<= (Seq_length s@66@00) 1)))
; [eval] s[0] <= s[1] && is_increasing(s[1..])
; [eval] s[0] <= s[1]
; [eval] s[0]
(push) ; 4
(assert (not (< 0 (Seq_length s@66@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [eval] s[1]
(push) ; 4
(assert (not (< 1 (Seq_length s@66@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(push) ; 4
; [then-branch: 62 | !(s@66@00[0] <= s@66@00[1]) | live]
; [else-branch: 62 | s@66@00[0] <= s@66@00[1] | live]
(push) ; 5
; [then-branch: 62 | !(s@66@00[0] <= s@66@00[1])]
(assert (not (<= (Seq_index s@66@00 0) (Seq_index s@66@00 1))))
(pop) ; 5
(push) ; 5
; [else-branch: 62 | s@66@00[0] <= s@66@00[1]]
(assert (<= (Seq_index s@66@00 0) (Seq_index s@66@00 1)))
; [eval] is_increasing(s[1..])
; [eval] s[1..]
(push) ; 6
(assert (is_increasing%precondition $Snap.unit (Seq_drop s@66@00 1)))
(pop) ; 6
; Joined path conditions
(assert (is_increasing%precondition $Snap.unit (Seq_drop s@66@00 1)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (<= (Seq_index s@66@00 0) (Seq_index s@66@00 1))
  (and
    (<= (Seq_index s@66@00 0) (Seq_index s@66@00 1))
    (is_increasing%precondition $Snap.unit (Seq_drop s@66@00 1)))))
(assert (or
  (<= (Seq_index s@66@00 0) (Seq_index s@66@00 1))
  (not (<= (Seq_index s@66@00 0) (Seq_index s@66@00 1)))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (<= (Seq_length s@66@00) 1))
  (and
    (not (<= (Seq_length s@66@00) 1))
    (=>
      (<= (Seq_index s@66@00 0) (Seq_index s@66@00 1))
      (and
        (<= (Seq_index s@66@00 0) (Seq_index s@66@00 1))
        (is_increasing%precondition $Snap.unit (Seq_drop s@66@00 1))))
    (or
      (<= (Seq_index s@66@00 0) (Seq_index s@66@00 1))
      (not (<= (Seq_index s@66@00 0) (Seq_index s@66@00 1)))))))
(assert (or (not (<= (Seq_length s@66@00) 1)) (<= (Seq_length s@66@00) 1)))
(assert (=
  result@67@00
  (ite
    (<= (Seq_length s@66@00) 1)
    true
    (and
      (<= (Seq_index s@66@00 0) (Seq_index s@66@00 1))
      (is_increasing $Snap.unit (Seq_drop s@66@00 1))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (s@66@00 Seq<Int>)) (!
  (=>
    (is_increasing%precondition s@$ s@66@00)
    (=
      (is_increasing s@$ s@66@00)
      (ite
        (<= (Seq_length s@66@00) 1)
        true
        (and
          (<= (Seq_index s@66@00 0) (Seq_index s@66@00 1))
          (is_increasing%limited $Snap.unit (Seq_drop s@66@00 1))))))
  :pattern ((is_increasing s@$ s@66@00))
  :qid |quant-u-118|)))
(assert (forall ((s@$ $Snap) (s@66@00 Seq<Int>)) (!
  (=>
    (is_increasing%precondition s@$ s@66@00)
    (ite
      (<= (Seq_length s@66@00) 1)
      true
      (=>
        (<= (Seq_index s@66@00 0) (Seq_index s@66@00 1))
        (is_increasing%precondition $Snap.unit (Seq_drop s@66@00 1)))))
  :pattern ((is_increasing s@$ s@66@00))
  :qid |quant-u-119|)))
