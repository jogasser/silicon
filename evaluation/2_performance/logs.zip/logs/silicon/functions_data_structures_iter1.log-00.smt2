(get-info :version)
; (:version "4.8.7")
; Started: 2025-12-05 12:19:16
; Silicon.version: 1.1-SNAPSHOT (95328487@(detached))
; Input file: ./functions/data_structures.vpr
; Verifier id: 00
; ------------------------------------------------------------
; Begin preamble
; ////////// Static preamble
; 
; ; /z3config.smt2
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :smt.qi.max_multi_patterns 1000)
; 
; ; /preamble.smt2
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(define-fun $Perm.min ((p1 $Perm) (p2 $Perm)) Real
    (ite (<= p1 p2) p1 p2))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
; ////////// Sorts
(declare-sort Seq<RoseTree> 0)
(declare-sort Seq<Trie> 0)
(declare-sort Seq<Int> 0)
(declare-sort RoseTree 0)
(declare-sort BST 0)
(declare-sort Trie 0)
(declare-sort Option<Int> 0)
(declare-sort ListZipper<Int> 0)
; ////////// Sort wrappers
; Declaring additional sort wrappers
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.Seq<RoseTree>To$Snap (Seq<RoseTree>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<RoseTree> ($Snap) Seq<RoseTree>)
(assert (forall ((x Seq<RoseTree>)) (!
    (= x ($SortWrappers.$SnapToSeq<RoseTree>($SortWrappers.Seq<RoseTree>To$Snap x)))
    :pattern (($SortWrappers.Seq<RoseTree>To$Snap x))
    :qid |$Snap.$SnapToSeq<RoseTree>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<RoseTree>To$Snap($SortWrappers.$SnapToSeq<RoseTree> x)))
    :pattern (($SortWrappers.$SnapToSeq<RoseTree> x))
    :qid |$Snap.Seq<RoseTree>To$SnapToSeq<RoseTree>|
    )))
(declare-fun $SortWrappers.Seq<Trie>To$Snap (Seq<Trie>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<Trie> ($Snap) Seq<Trie>)
(assert (forall ((x Seq<Trie>)) (!
    (= x ($SortWrappers.$SnapToSeq<Trie>($SortWrappers.Seq<Trie>To$Snap x)))
    :pattern (($SortWrappers.Seq<Trie>To$Snap x))
    :qid |$Snap.$SnapToSeq<Trie>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<Trie>To$Snap($SortWrappers.$SnapToSeq<Trie> x)))
    :pattern (($SortWrappers.$SnapToSeq<Trie> x))
    :qid |$Snap.Seq<Trie>To$SnapToSeq<Trie>|
    )))
(declare-fun $SortWrappers.Seq<Int>To$Snap (Seq<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<Int> ($Snap) Seq<Int>)
(assert (forall ((x Seq<Int>)) (!
    (= x ($SortWrappers.$SnapToSeq<Int>($SortWrappers.Seq<Int>To$Snap x)))
    :pattern (($SortWrappers.Seq<Int>To$Snap x))
    :qid |$Snap.$SnapToSeq<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<Int>To$Snap($SortWrappers.$SnapToSeq<Int> x)))
    :pattern (($SortWrappers.$SnapToSeq<Int> x))
    :qid |$Snap.Seq<Int>To$SnapToSeq<Int>|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.RoseTreeTo$Snap (RoseTree) $Snap)
(declare-fun $SortWrappers.$SnapToRoseTree ($Snap) RoseTree)
(assert (forall ((x RoseTree)) (!
    (= x ($SortWrappers.$SnapToRoseTree($SortWrappers.RoseTreeTo$Snap x)))
    :pattern (($SortWrappers.RoseTreeTo$Snap x))
    :qid |$Snap.$SnapToRoseTreeTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.RoseTreeTo$Snap($SortWrappers.$SnapToRoseTree x)))
    :pattern (($SortWrappers.$SnapToRoseTree x))
    :qid |$Snap.RoseTreeTo$SnapToRoseTree|
    )))
(declare-fun $SortWrappers.BSTTo$Snap (BST) $Snap)
(declare-fun $SortWrappers.$SnapToBST ($Snap) BST)
(assert (forall ((x BST)) (!
    (= x ($SortWrappers.$SnapToBST($SortWrappers.BSTTo$Snap x)))
    :pattern (($SortWrappers.BSTTo$Snap x))
    :qid |$Snap.$SnapToBSTTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BSTTo$Snap($SortWrappers.$SnapToBST x)))
    :pattern (($SortWrappers.$SnapToBST x))
    :qid |$Snap.BSTTo$SnapToBST|
    )))
(declare-fun $SortWrappers.TrieTo$Snap (Trie) $Snap)
(declare-fun $SortWrappers.$SnapToTrie ($Snap) Trie)
(assert (forall ((x Trie)) (!
    (= x ($SortWrappers.$SnapToTrie($SortWrappers.TrieTo$Snap x)))
    :pattern (($SortWrappers.TrieTo$Snap x))
    :qid |$Snap.$SnapToTrieTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.TrieTo$Snap($SortWrappers.$SnapToTrie x)))
    :pattern (($SortWrappers.$SnapToTrie x))
    :qid |$Snap.TrieTo$SnapToTrie|
    )))
(declare-fun $SortWrappers.Option<Int>To$Snap (Option<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToOption<Int> ($Snap) Option<Int>)
(assert (forall ((x Option<Int>)) (!
    (= x ($SortWrappers.$SnapToOption<Int>($SortWrappers.Option<Int>To$Snap x)))
    :pattern (($SortWrappers.Option<Int>To$Snap x))
    :qid |$Snap.$SnapToOption<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Option<Int>To$Snap($SortWrappers.$SnapToOption<Int> x)))
    :pattern (($SortWrappers.$SnapToOption<Int> x))
    :qid |$Snap.Option<Int>To$SnapToOption<Int>|
    )))
(declare-fun $SortWrappers.ListZipper<Int>To$Snap (ListZipper<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToListZipper<Int> ($Snap) ListZipper<Int>)
(assert (forall ((x ListZipper<Int>)) (!
    (= x ($SortWrappers.$SnapToListZipper<Int>($SortWrappers.ListZipper<Int>To$Snap x)))
    :pattern (($SortWrappers.ListZipper<Int>To$Snap x))
    :qid |$Snap.$SnapToListZipper<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.ListZipper<Int>To$Snap($SortWrappers.$SnapToListZipper<Int> x)))
    :pattern (($SortWrappers.$SnapToListZipper<Int> x))
    :qid |$Snap.ListZipper<Int>To$SnapToListZipper<Int>|
    )))
; ////////// Symbols
(declare-fun Seq_length (Seq<RoseTree>) Int)
(declare-const Seq_empty Seq<RoseTree>)
(declare-fun Seq_singleton (RoseTree) Seq<RoseTree>)
(declare-fun Seq_append (Seq<RoseTree> Seq<RoseTree>) Seq<RoseTree>)
(declare-fun Seq_index (Seq<RoseTree> Int) RoseTree)
(declare-fun Seq_add (Int Int) Int)
(declare-fun Seq_sub (Int Int) Int)
(declare-fun Seq_update (Seq<RoseTree> Int RoseTree) Seq<RoseTree>)
(declare-fun Seq_take (Seq<RoseTree> Int) Seq<RoseTree>)
(declare-fun Seq_drop (Seq<RoseTree> Int) Seq<RoseTree>)
(declare-fun Seq_contains (Seq<RoseTree> RoseTree) Bool)
(declare-fun Seq_contains_trigger (Seq<RoseTree> RoseTree) Bool)
(declare-fun Seq_skolem (Seq<RoseTree> RoseTree) Int)
(declare-fun Seq_equal (Seq<RoseTree> Seq<RoseTree>) Bool)
(declare-fun Seq_skolem_diff (Seq<RoseTree> Seq<RoseTree>) Int)
(declare-fun Seq_length (Seq<Trie>) Int)
(declare-const Seq_empty Seq<Trie>)
(declare-fun Seq_singleton (Trie) Seq<Trie>)
(declare-fun Seq_append (Seq<Trie> Seq<Trie>) Seq<Trie>)
(declare-fun Seq_index (Seq<Trie> Int) Trie)
(declare-fun Seq_update (Seq<Trie> Int Trie) Seq<Trie>)
(declare-fun Seq_take (Seq<Trie> Int) Seq<Trie>)
(declare-fun Seq_drop (Seq<Trie> Int) Seq<Trie>)
(declare-fun Seq_contains (Seq<Trie> Trie) Bool)
(declare-fun Seq_contains_trigger (Seq<Trie> Trie) Bool)
(declare-fun Seq_skolem (Seq<Trie> Trie) Int)
(declare-fun Seq_equal (Seq<Trie> Seq<Trie>) Bool)
(declare-fun Seq_skolem_diff (Seq<Trie> Seq<Trie>) Int)
(declare-fun Seq_length (Seq<Int>) Int)
(declare-const Seq_empty Seq<Int>)
(declare-fun Seq_singleton (Int) Seq<Int>)
(declare-fun Seq_append (Seq<Int> Seq<Int>) Seq<Int>)
(declare-fun Seq_index (Seq<Int> Int) Int)
(declare-fun Seq_update (Seq<Int> Int Int) Seq<Int>)
(declare-fun Seq_take (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_drop (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_contains (Seq<Int> Int) Bool)
(declare-fun Seq_contains_trigger (Seq<Int> Int) Bool)
(declare-fun Seq_skolem (Seq<Int> Int) Int)
(declare-fun Seq_equal (Seq<Int> Seq<Int>) Bool)
(declare-fun Seq_skolem_diff (Seq<Int> Seq<Int>) Int)
(declare-fun Seq_range (Int Int) Seq<Int>)
(declare-fun Zipper<ListZipper<Int>> (Seq<Int> Option<Int> Seq<Int>) ListZipper<Int>)
(declare-fun get_ListZipper_before<Seq<Int>> (ListZipper<Int>) Seq<Int>)
(declare-fun get_ListZipper_focus<Option<Int>> (ListZipper<Int>) Option<Int>)
(declare-fun get_ListZipper_after<Seq<Int>> (ListZipper<Int>) Seq<Int>)
(declare-fun ListZipper_tag<Int> (ListZipper<Int>) Int)
(declare-const Empty<RoseTree> RoseTree)
(declare-fun RoseNode<RoseTree> (Int Seq<RoseTree>) RoseTree)
(declare-fun get_RoseTree_value<Int> (RoseTree) Int)
(declare-fun get_RoseTree_children<Seq<RoseTree>> (RoseTree) Seq<RoseTree>)
(declare-fun RoseTree_tag<Int> (RoseTree) Int)
(declare-const BSTLeaf<BST> BST)
(declare-fun BSTNode<BST> (BST Int BST) BST)
(declare-fun get_BST_left<BST> (BST) BST)
(declare-fun get_BST_value<Int> (BST) Int)
(declare-fun get_BST_right<BST> (BST) BST)
(declare-fun BST_tag<Int> (BST) Int)
(declare-const None<Option<Int>> Option<Int>)
(declare-fun Some<Option<Int>> (Int) Option<Int>)
(declare-fun get_Option_value<Int> (Option<Int>) Int)
(declare-fun Option_tag<Int> (Option<Int>) Int)
(declare-const EmptyTrie<Trie> Trie)
(declare-fun TrieNode<Trie> (Bool Seq<Trie>) Trie)
(declare-fun get_Trie_isEnd<Bool> (Trie) Bool)
(declare-fun get_Trie_children<Seq<Trie>> (Trie) Seq<Trie>)
(declare-fun Trie_tag<Int> (Trie) Int)
; Declaring symbols related to program functions (from program analysis)
(declare-fun find_root ($Snap Seq<Int> Int Int) Int)
(declare-fun find_root%limited ($Snap Seq<Int> Int Int) Int)
(declare-fun find_root%stateless (Seq<Int> Int Int) Bool)
(declare-fun find_root%precondition ($Snap Seq<Int> Int Int) Bool)
(declare-fun trie_is_empty ($Snap Trie) Bool)
(declare-fun trie_is_empty%limited ($Snap Trie) Bool)
(declare-fun trie_is_empty%stateless (Trie) Bool)
(declare-fun trie_is_empty%precondition ($Snap Trie) Bool)
(declare-fun bst_max ($Snap BST) Option<Int>)
(declare-fun bst_max%limited ($Snap BST) Option<Int>)
(declare-fun bst_max%stateless (BST) Bool)
(declare-fun bst_max%precondition ($Snap BST) Bool)
(declare-fun zipper_backward ($Snap ListZipper<Int>) ListZipper<Int>)
(declare-fun zipper_backward%limited ($Snap ListZipper<Int>) ListZipper<Int>)
(declare-fun zipper_backward%stateless (ListZipper<Int>) Bool)
(declare-fun zipper_backward%precondition ($Snap ListZipper<Int>) Bool)
(declare-fun rose_size ($Snap RoseTree) Int)
(declare-fun rose_size%limited ($Snap RoseTree) Int)
(declare-fun rose_size%stateless (RoseTree) Bool)
(declare-fun rose_size%precondition ($Snap RoseTree) Bool)
(declare-fun rose_children_size ($Snap Seq<RoseTree> Int) Int)
(declare-fun rose_children_size%limited ($Snap Seq<RoseTree> Int) Int)
(declare-fun rose_children_size%stateless (Seq<RoseTree> Int) Bool)
(declare-fun rose_children_size%precondition ($Snap Seq<RoseTree> Int) Bool)
(declare-fun trie_count_words ($Snap Trie) Int)
(declare-fun trie_count_words%limited ($Snap Trie) Int)
(declare-fun trie_count_words%stateless (Trie) Bool)
(declare-fun trie_count_words%precondition ($Snap Trie) Bool)
(declare-fun trie_count_children_words ($Snap Seq<Trie> Int) Int)
(declare-fun trie_count_children_words%limited ($Snap Seq<Trie> Int) Int)
(declare-fun trie_count_children_words%stateless (Seq<Trie> Int) Bool)
(declare-fun trie_count_children_words%precondition ($Snap Seq<Trie> Int) Bool)
(declare-fun bst_insert ($Snap BST Int) BST)
(declare-fun bst_insert%limited ($Snap BST Int) BST)
(declare-fun bst_insert%stateless (BST Int) Bool)
(declare-fun bst_insert%precondition ($Snap BST Int) Bool)
(declare-fun is_valid_bst ($Snap BST Int Int) Bool)
(declare-fun is_valid_bst%limited ($Snap BST Int Int) Bool)
(declare-fun is_valid_bst%stateless (BST Int Int) Bool)
(declare-fun is_valid_bst%precondition ($Snap BST Int Int) Bool)
(declare-fun bst_search ($Snap BST Int) Bool)
(declare-fun bst_search%limited ($Snap BST Int) Bool)
(declare-fun bst_search%stateless (BST Int) Bool)
(declare-fun bst_search%precondition ($Snap BST Int) Bool)
(declare-fun bst_min ($Snap BST) Option<Int>)
(declare-fun bst_min%limited ($Snap BST) Option<Int>)
(declare-fun bst_min%stateless (BST) Bool)
(declare-fun bst_min%precondition ($Snap BST) Bool)
(declare-fun is_same_set ($Snap Seq<Int> Int Int Int) Bool)
(declare-fun is_same_set%limited ($Snap Seq<Int> Int Int Int) Bool)
(declare-fun is_same_set%stateless (Seq<Int> Int Int Int) Bool)
(declare-fun is_same_set%precondition ($Snap Seq<Int> Int Int Int) Bool)
(declare-fun is_max_heap ($Snap Seq<Int> Int) Bool)
(declare-fun is_max_heap%limited ($Snap Seq<Int> Int) Bool)
(declare-fun is_max_heap%stateless (Seq<Int> Int) Bool)
(declare-fun is_max_heap%precondition ($Snap Seq<Int> Int) Bool)
(declare-fun skip_list_level ($Snap Int Int) Int)
(declare-fun skip_list_level%limited ($Snap Int Int) Int)
(declare-fun skip_list_level%stateless (Int Int) Bool)
(declare-fun skip_list_level%precondition ($Snap Int Int) Bool)
(declare-fun is_min_heap ($Snap Seq<Int> Int) Bool)
(declare-fun is_min_heap%limited ($Snap Seq<Int> Int) Bool)
(declare-fun is_min_heap%stateless (Seq<Int> Int) Bool)
(declare-fun is_min_heap%precondition ($Snap Seq<Int> Int) Bool)
(declare-fun zipper_forward ($Snap ListZipper<Int>) ListZipper<Int>)
(declare-fun zipper_forward%limited ($Snap ListZipper<Int>) ListZipper<Int>)
(declare-fun zipper_forward%stateless (ListZipper<Int>) Bool)
(declare-fun zipper_forward%precondition ($Snap ListZipper<Int>) Bool)
(declare-fun rose_height ($Snap RoseTree) Int)
(declare-fun rose_height%limited ($Snap RoseTree) Int)
(declare-fun rose_height%stateless (RoseTree) Bool)
(declare-fun rose_height%precondition ($Snap RoseTree) Bool)
(declare-fun rose_children_max_height ($Snap Seq<RoseTree> Int Int) Int)
(declare-fun rose_children_max_height%limited ($Snap Seq<RoseTree> Int Int) Int)
(declare-fun rose_children_max_height%stateless (Seq<RoseTree> Int Int) Bool)
(declare-fun rose_children_max_height%precondition ($Snap Seq<RoseTree> Int Int) Bool)
(declare-fun segment_tree_query ($Snap Seq<Int> Int Int Int Int Int) Int)
(declare-fun segment_tree_query%limited ($Snap Seq<Int> Int Int Int Int Int) Int)
(declare-fun segment_tree_query%stateless (Seq<Int> Int Int Int Int Int) Bool)
(declare-fun segment_tree_query%precondition ($Snap Seq<Int> Int Int Int Int Int) Bool)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
; Declaring predicate trigger functions
; ////////// Uniqueness assumptions from domains
; ////////// Axioms
(assert (forall ((s Seq<RoseTree>)) (!
  (<= 0 (Seq_length s))
  :pattern ((Seq_length s))
  :qid |$Seq[RoseTree]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty  Seq<RoseTree>)) 0))
(assert (forall ((s Seq<RoseTree>)) (!
  (=> (= (Seq_length s) 0) (= s (as Seq_empty  Seq<RoseTree>)))
  :pattern ((Seq_length s))
  :qid |$Seq[RoseTree]_prog.Seq_length_zero|)))
(assert (forall ((e RoseTree)) (!
  (= (Seq_length (Seq_singleton e)) 1)
  :pattern ((Seq_singleton e))
  :qid |$Seq[RoseTree]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<RoseTree>) (s1 Seq<RoseTree>)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<RoseTree>)))
      (not (= s1 (as Seq_empty  Seq<RoseTree>))))
    (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1))))
  :pattern ((Seq_length (Seq_append s0 s1)))
  :qid |$Seq[RoseTree]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<RoseTree>) (s1 Seq<RoseTree>)) (!
  (and
    (=> (= s0 (as Seq_empty  Seq<RoseTree>)) (= (Seq_append s0 s1) s1))
    (=> (= s1 (as Seq_empty  Seq<RoseTree>)) (= (Seq_append s0 s1) s0)))
  :pattern ((Seq_append s0 s1))
  :qid |$Seq[RoseTree]_prog.Seq_append_empty|)))
(assert (forall ((e RoseTree)) (!
  (= (Seq_index (Seq_singleton e) 0) e)
  :pattern ((Seq_singleton e))
  :qid |$Seq[RoseTree]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_add i j) (+ i j))
  :pattern ((Seq_add i j))
  :qid |$Seq[RoseTree]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_sub i j) (- i j))
  :pattern ((Seq_sub i j))
  :qid |$Seq[RoseTree]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<RoseTree>) (s1 Seq<RoseTree>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<RoseTree>)))
      (and
        (not (= s1 (as Seq_empty  Seq<RoseTree>)))
        (and (<= 0 n) (< n (Seq_length s0)))))
    (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n)))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :pattern ((Seq_index s0 n) (Seq_append s0 s1))
  :qid |$Seq[RoseTree]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<RoseTree>) (s1 Seq<RoseTree>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<RoseTree>)))
      (and
        (not (= s1 (as Seq_empty  Seq<RoseTree>)))
        (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1))))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n)
      (=
        (Seq_index (Seq_append s0 s1) n)
        (Seq_index s1 (Seq_sub n (Seq_length s0))))))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :qid |$Seq[RoseTree]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<RoseTree>) (s1 Seq<RoseTree>) (m Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<RoseTree>)))
      (and
        (not (= s1 (as Seq_empty  Seq<RoseTree>)))
        (and (<= 0 m) (< m (Seq_length s1)))))
    (and
      (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m)
      (=
        (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0)))
        (Seq_index s1 m))))
  :pattern ((Seq_index s1 m) (Seq_append s0 s1))
  :qid |$Seq[RoseTree]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<RoseTree>) (i Int) (v RoseTree)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (Seq_length (Seq_update s i v)) (Seq_length s)))
  :pattern ((Seq_length (Seq_update s i v)))
  :pattern ((Seq_length s) (Seq_update s i v))
  :qid |$Seq[RoseTree]_prog.Seq_update_length|)))
(assert (forall ((s Seq<RoseTree>) (i Int) (v RoseTree) (n Int)) (!
  (=>
    (and (<= 0 n) (< n (Seq_length s)))
    (and
      (=> (= i n) (= (Seq_index (Seq_update s i v) n) v))
      (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n)))))
  :pattern ((Seq_index (Seq_update s i v) n))
  :pattern ((Seq_index s n) (Seq_update s i v))
  :qid |$Seq[RoseTree]_prog.Seq_update_index|)))
(assert (forall ((s Seq<RoseTree>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s)))))
    (=> (< n 0) (= (Seq_length (Seq_take s n)) 0)))
  :pattern ((Seq_length (Seq_take s n)))
  :pattern ((Seq_take s n) (Seq_length s))
  :qid |$Seq[RoseTree]_prog.Seq_take_length|)))
(assert (forall ((s Seq<RoseTree>) (n Int) (j Int)) (!
  (=>
    (and (<= 0 j) (and (< j n) (< j (Seq_length s))))
    (= (Seq_index (Seq_take s n) j) (Seq_index s j)))
  :pattern ((Seq_index (Seq_take s n) j))
  :pattern ((Seq_index s j) (Seq_take s n))
  :qid |$Seq[RoseTree]_prog.Seq_take_index|)))
(assert (forall ((s Seq<RoseTree>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=>
          (<= n (Seq_length s))
          (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n)))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0))))
    (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s))))
  :pattern ((Seq_length (Seq_drop s n)))
  :pattern ((Seq_length s) (Seq_drop s n))
  :qid |$Seq[RoseTree]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<RoseTree>) (n Int) (j Int)) (!
  (=>
    (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n))))
    (and
      (= (Seq_sub (Seq_add j n) n) j)
      (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n)))))
  :pattern ((Seq_index (Seq_drop s n) j))
  :qid |$Seq[RoseTree]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<RoseTree>) (n Int) (i Int)) (!
  (=>
    (and (< 0 n) (and (<= n i) (< i (Seq_length s))))
    (and
      (= (Seq_add (Seq_sub i n) n) i)
      (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i))))
  :pattern ((Seq_drop s n) (Seq_index s i))
  :qid |$Seq[RoseTree]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<RoseTree>) (t Seq<RoseTree>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_take (Seq_append s t) n) (Seq_take s n)))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[RoseTree]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<RoseTree>) (t Seq<RoseTree>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (=
        (Seq_take (Seq_append s t) n)
        (Seq_append s (Seq_take t (Seq_sub n (Seq_length s)))))))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[RoseTree]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<RoseTree>) (t Seq<RoseTree>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t)))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[RoseTree]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<RoseTree>) (t Seq<RoseTree>) (n Int)) (!
  (=>
    (and (> n 0) (> n (Seq_length s)))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s))))))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[RoseTree]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<RoseTree>) (n Int)) (!
  (=> (<= n 0) (= (Seq_take s n) (as Seq_empty  Seq<RoseTree>)))
  :pattern ((Seq_take s n))
  :qid |$Seq[RoseTree]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<RoseTree>) (n Int)) (!
  (=> (<= n 0) (= (Seq_drop s n) s))
  :pattern ((Seq_drop s n))
  :qid |$Seq[RoseTree]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<RoseTree>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_take s n) s))
  :pattern ((Seq_take s n))
  :qid |$Seq[RoseTree]_prog.Seq_take_all|)))
(assert (forall ((s Seq<RoseTree>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty  Seq<RoseTree>)))
  :pattern ((Seq_drop s n))
  :qid |$Seq[RoseTree]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<RoseTree>) (x RoseTree)) (!
  (=>
    (Seq_contains s x)
    (and
      (<= 0 (Seq_skolem s x))
      (and
        (< (Seq_skolem s x) (Seq_length s))
        (= (Seq_index s (Seq_skolem s x)) x))))
  :pattern ((Seq_contains s x))
  :qid |$Seq[RoseTree]_prog.Seq_contains1|)))
(assert (forall ((s Seq<RoseTree>) (x RoseTree) (i Int)) (!
  (=>
    (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x)))
    (Seq_contains s x))
  :pattern ((Seq_contains s x) (Seq_index s i))
  :qid |$Seq[RoseTree]_prog.Seq_contains2|)))
(assert (forall ((s Seq<RoseTree>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (Seq_contains_trigger s (Seq_index s i)))
  :pattern ((Seq_index s i))
  :qid |$Seq[RoseTree]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<RoseTree>) (s1 Seq<RoseTree>)) (!
  (or
    (and (= s0 s1) (Seq_equal s0 s1))
    (or
      (and
        (not (= s0 s1))
        (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1)))))
      (and
        (not (= s0 s1))
        (and
          (not (Seq_equal s0 s1))
          (and
            (= (Seq_length s0) (Seq_length s1))
            (and
              (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0))
              (and
                (<= 0 (Seq_skolem_diff s0 s1))
                (and
                  (< (Seq_skolem_diff s0 s1) (Seq_length s0))
                  (not
                    (=
                      (Seq_index s0 (Seq_skolem_diff s0 s1))
                      (Seq_index s1 (Seq_skolem_diff s0 s1))))))))))))
  :pattern ((Seq_equal s0 s1))
  :qid |$Seq[RoseTree]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<RoseTree>) (b Seq<RoseTree>)) (!
  (=> (Seq_equal a b) (= a b))
  :pattern ((Seq_equal a b))
  :qid |$Seq[RoseTree]_prog.Seq_equal_ext|)))
(assert (forall ((x RoseTree) (y RoseTree)) (!
  (= (Seq_contains (Seq_singleton x) y) (= x y))
  :pattern ((Seq_contains (Seq_singleton x) y))
  :qid |$Seq[RoseTree]_prog.Seq_singleton_contains|)))
(assert (forall ((s Seq<Trie>)) (!
  (<= 0 (Seq_length s))
  :pattern ((Seq_length s))
  :qid |$Seq[Trie]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty  Seq<Trie>)) 0))
(assert (forall ((s Seq<Trie>)) (!
  (=> (= (Seq_length s) 0) (= s (as Seq_empty  Seq<Trie>)))
  :pattern ((Seq_length s))
  :qid |$Seq[Trie]_prog.Seq_length_zero|)))
(assert (forall ((e Trie)) (!
  (= (Seq_length (Seq_singleton e)) 1)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Trie]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<Trie>) (s1 Seq<Trie>)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Trie>)))
      (not (= s1 (as Seq_empty  Seq<Trie>))))
    (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1))))
  :pattern ((Seq_length (Seq_append s0 s1)))
  :qid |$Seq[Trie]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<Trie>) (s1 Seq<Trie>)) (!
  (and
    (=> (= s0 (as Seq_empty  Seq<Trie>)) (= (Seq_append s0 s1) s1))
    (=> (= s1 (as Seq_empty  Seq<Trie>)) (= (Seq_append s0 s1) s0)))
  :pattern ((Seq_append s0 s1))
  :qid |$Seq[Trie]_prog.Seq_append_empty|)))
(assert (forall ((e Trie)) (!
  (= (Seq_index (Seq_singleton e) 0) e)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Trie]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_add i j) (+ i j))
  :pattern ((Seq_add i j))
  :qid |$Seq[Trie]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_sub i j) (- i j))
  :pattern ((Seq_sub i j))
  :qid |$Seq[Trie]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<Trie>) (s1 Seq<Trie>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Trie>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Trie>)))
        (and (<= 0 n) (< n (Seq_length s0)))))
    (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n)))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :pattern ((Seq_index s0 n) (Seq_append s0 s1))
  :qid |$Seq[Trie]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<Trie>) (s1 Seq<Trie>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Trie>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Trie>)))
        (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1))))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n)
      (=
        (Seq_index (Seq_append s0 s1) n)
        (Seq_index s1 (Seq_sub n (Seq_length s0))))))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :qid |$Seq[Trie]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<Trie>) (s1 Seq<Trie>) (m Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Trie>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Trie>)))
        (and (<= 0 m) (< m (Seq_length s1)))))
    (and
      (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m)
      (=
        (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0)))
        (Seq_index s1 m))))
  :pattern ((Seq_index s1 m) (Seq_append s0 s1))
  :qid |$Seq[Trie]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<Trie>) (i Int) (v Trie)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (Seq_length (Seq_update s i v)) (Seq_length s)))
  :pattern ((Seq_length (Seq_update s i v)))
  :pattern ((Seq_length s) (Seq_update s i v))
  :qid |$Seq[Trie]_prog.Seq_update_length|)))
(assert (forall ((s Seq<Trie>) (i Int) (v Trie) (n Int)) (!
  (=>
    (and (<= 0 n) (< n (Seq_length s)))
    (and
      (=> (= i n) (= (Seq_index (Seq_update s i v) n) v))
      (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n)))))
  :pattern ((Seq_index (Seq_update s i v) n))
  :pattern ((Seq_index s n) (Seq_update s i v))
  :qid |$Seq[Trie]_prog.Seq_update_index|)))
(assert (forall ((s Seq<Trie>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s)))))
    (=> (< n 0) (= (Seq_length (Seq_take s n)) 0)))
  :pattern ((Seq_length (Seq_take s n)))
  :pattern ((Seq_take s n) (Seq_length s))
  :qid |$Seq[Trie]_prog.Seq_take_length|)))
(assert (forall ((s Seq<Trie>) (n Int) (j Int)) (!
  (=>
    (and (<= 0 j) (and (< j n) (< j (Seq_length s))))
    (= (Seq_index (Seq_take s n) j) (Seq_index s j)))
  :pattern ((Seq_index (Seq_take s n) j))
  :pattern ((Seq_index s j) (Seq_take s n))
  :qid |$Seq[Trie]_prog.Seq_take_index|)))
(assert (forall ((s Seq<Trie>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=>
          (<= n (Seq_length s))
          (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n)))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0))))
    (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s))))
  :pattern ((Seq_length (Seq_drop s n)))
  :pattern ((Seq_length s) (Seq_drop s n))
  :qid |$Seq[Trie]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<Trie>) (n Int) (j Int)) (!
  (=>
    (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n))))
    (and
      (= (Seq_sub (Seq_add j n) n) j)
      (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n)))))
  :pattern ((Seq_index (Seq_drop s n) j))
  :qid |$Seq[Trie]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<Trie>) (n Int) (i Int)) (!
  (=>
    (and (< 0 n) (and (<= n i) (< i (Seq_length s))))
    (and
      (= (Seq_add (Seq_sub i n) n) i)
      (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i))))
  :pattern ((Seq_drop s n) (Seq_index s i))
  :qid |$Seq[Trie]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<Trie>) (t Seq<Trie>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_take (Seq_append s t) n) (Seq_take s n)))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Trie]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<Trie>) (t Seq<Trie>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (=
        (Seq_take (Seq_append s t) n)
        (Seq_append s (Seq_take t (Seq_sub n (Seq_length s)))))))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Trie]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<Trie>) (t Seq<Trie>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t)))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Trie]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<Trie>) (t Seq<Trie>) (n Int)) (!
  (=>
    (and (> n 0) (> n (Seq_length s)))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s))))))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Trie]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<Trie>) (n Int)) (!
  (=> (<= n 0) (= (Seq_take s n) (as Seq_empty  Seq<Trie>)))
  :pattern ((Seq_take s n))
  :qid |$Seq[Trie]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<Trie>) (n Int)) (!
  (=> (<= n 0) (= (Seq_drop s n) s))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Trie]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<Trie>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_take s n) s))
  :pattern ((Seq_take s n))
  :qid |$Seq[Trie]_prog.Seq_take_all|)))
(assert (forall ((s Seq<Trie>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty  Seq<Trie>)))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Trie]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<Trie>) (x Trie)) (!
  (=>
    (Seq_contains s x)
    (and
      (<= 0 (Seq_skolem s x))
      (and
        (< (Seq_skolem s x) (Seq_length s))
        (= (Seq_index s (Seq_skolem s x)) x))))
  :pattern ((Seq_contains s x))
  :qid |$Seq[Trie]_prog.Seq_contains1|)))
(assert (forall ((s Seq<Trie>) (x Trie) (i Int)) (!
  (=>
    (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x)))
    (Seq_contains s x))
  :pattern ((Seq_contains s x) (Seq_index s i))
  :qid |$Seq[Trie]_prog.Seq_contains2|)))
(assert (forall ((s Seq<Trie>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (Seq_contains_trigger s (Seq_index s i)))
  :pattern ((Seq_index s i))
  :qid |$Seq[Trie]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<Trie>) (s1 Seq<Trie>)) (!
  (or
    (and (= s0 s1) (Seq_equal s0 s1))
    (or
      (and
        (not (= s0 s1))
        (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1)))))
      (and
        (not (= s0 s1))
        (and
          (not (Seq_equal s0 s1))
          (and
            (= (Seq_length s0) (Seq_length s1))
            (and
              (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0))
              (and
                (<= 0 (Seq_skolem_diff s0 s1))
                (and
                  (< (Seq_skolem_diff s0 s1) (Seq_length s0))
                  (not
                    (=
                      (Seq_index s0 (Seq_skolem_diff s0 s1))
                      (Seq_index s1 (Seq_skolem_diff s0 s1))))))))))))
  :pattern ((Seq_equal s0 s1))
  :qid |$Seq[Trie]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<Trie>) (b Seq<Trie>)) (!
  (=> (Seq_equal a b) (= a b))
  :pattern ((Seq_equal a b))
  :qid |$Seq[Trie]_prog.Seq_equal_ext|)))
(assert (forall ((x Trie) (y Trie)) (!
  (= (Seq_contains (Seq_singleton x) y) (= x y))
  :pattern ((Seq_contains (Seq_singleton x) y))
  :qid |$Seq[Trie]_prog.Seq_singleton_contains|)))
(assert (forall ((s Seq<Int>)) (!
  (<= 0 (Seq_length s))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty  Seq<Int>)) 0))
(assert (forall ((s Seq<Int>)) (!
  (=> (= (Seq_length s) 0) (= s (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_zero|)))
(assert (forall ((e Int)) (!
  (= (Seq_length (Seq_singleton e)) 1)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (not (= s1 (as Seq_empty  Seq<Int>))))
    (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1))))
  :pattern ((Seq_length (Seq_append s0 s1)))
  :qid |$Seq[Int]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (and
    (=> (= s0 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s1))
    (=> (= s1 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s0)))
  :pattern ((Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_empty|)))
(assert (forall ((e Int)) (!
  (= (Seq_index (Seq_singleton e) 0) e)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_add i j) (+ i j))
  :pattern ((Seq_add i j))
  :qid |$Seq[Int]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_sub i j) (- i j))
  :pattern ((Seq_sub i j))
  :qid |$Seq[Int]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= 0 n) (< n (Seq_length s0)))))
    (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n)))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :pattern ((Seq_index s0 n) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1))))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n)
      (=
        (Seq_index (Seq_append s0 s1) n)
        (Seq_index s1 (Seq_sub n (Seq_length s0))))))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :qid |$Seq[Int]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (m Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= 0 m) (< m (Seq_length s1)))))
    (and
      (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m)
      (=
        (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0)))
        (Seq_index s1 m))))
  :pattern ((Seq_index s1 m) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (Seq_length (Seq_update s i v)) (Seq_length s)))
  :pattern ((Seq_length (Seq_update s i v)))
  :pattern ((Seq_length s) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_length|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int) (n Int)) (!
  (=>
    (and (<= 0 n) (< n (Seq_length s)))
    (and
      (=> (= i n) (= (Seq_index (Seq_update s i v) n) v))
      (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n)))))
  :pattern ((Seq_index (Seq_update s i v) n))
  :pattern ((Seq_index s n) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s)))))
    (=> (< n 0) (= (Seq_length (Seq_take s n)) 0)))
  :pattern ((Seq_length (Seq_take s n)))
  :pattern ((Seq_take s n) (Seq_length s))
  :qid |$Seq[Int]_prog.Seq_take_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (<= 0 j) (and (< j n) (< j (Seq_length s))))
    (= (Seq_index (Seq_take s n) j) (Seq_index s j)))
  :pattern ((Seq_index (Seq_take s n) j))
  :pattern ((Seq_index s j) (Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=>
          (<= n (Seq_length s))
          (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n)))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0))))
    (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s))))
  :pattern ((Seq_length (Seq_drop s n)))
  :pattern ((Seq_length s) (Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n))))
    (and
      (= (Seq_sub (Seq_add j n) n) j)
      (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n)))))
  :pattern ((Seq_index (Seq_drop s n) j))
  :qid |$Seq[Int]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<Int>) (n Int) (i Int)) (!
  (=>
    (and (< 0 n) (and (<= n i) (< i (Seq_length s))))
    (and
      (= (Seq_add (Seq_sub i n) n) i)
      (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i))))
  :pattern ((Seq_drop s n) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_take (Seq_append s t) n) (Seq_take s n)))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (=
        (Seq_take (Seq_append s t) n)
        (Seq_append s (Seq_take t (Seq_sub n (Seq_length s)))))))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t)))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (> n (Seq_length s)))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s))))))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_take s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_drop s n) s))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_take s n) s))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_all|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<Int>) (x Int)) (!
  (=>
    (Seq_contains s x)
    (and
      (<= 0 (Seq_skolem s x))
      (and
        (< (Seq_skolem s x) (Seq_length s))
        (= (Seq_index s (Seq_skolem s x)) x))))
  :pattern ((Seq_contains s x))
  :qid |$Seq[Int]_prog.Seq_contains1|)))
(assert (forall ((s Seq<Int>) (x Int) (i Int)) (!
  (=>
    (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x)))
    (Seq_contains s x))
  :pattern ((Seq_contains s x) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains2|)))
(assert (forall ((s Seq<Int>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (Seq_contains_trigger s (Seq_index s i)))
  :pattern ((Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (or
    (and (= s0 s1) (Seq_equal s0 s1))
    (or
      (and
        (not (= s0 s1))
        (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1)))))
      (and
        (not (= s0 s1))
        (and
          (not (Seq_equal s0 s1))
          (and
            (= (Seq_length s0) (Seq_length s1))
            (and
              (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0))
              (and
                (<= 0 (Seq_skolem_diff s0 s1))
                (and
                  (< (Seq_skolem_diff s0 s1) (Seq_length s0))
                  (not
                    (=
                      (Seq_index s0 (Seq_skolem_diff s0 s1))
                      (Seq_index s1 (Seq_skolem_diff s0 s1))))))))))))
  :pattern ((Seq_equal s0 s1))
  :qid |$Seq[Int]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<Int>) (b Seq<Int>)) (!
  (=> (Seq_equal a b) (= a b))
  :pattern ((Seq_equal a b))
  :qid |$Seq[Int]_prog.Seq_equal_ext|)))
(assert (forall ((x Int) (y Int)) (!
  (= (Seq_contains (Seq_singleton x) y) (= x y))
  :pattern ((Seq_contains (Seq_singleton x) y))
  :qid |$Seq[Int]_prog.Seq_singleton_contains|)))
(assert (forall ((min_ Int) (max Int)) (!
  (and
    (=> (< min_ max) (= (Seq_length (Seq_range min_ max)) (- max min_)))
    (=> (<= max min_) (= (Seq_length (Seq_range min_ max)) 0)))
  :pattern ((Seq_length (Seq_range min_ max)))
  :qid |$Seq[Int]_prog.Seq_range_length|)))
(assert (forall ((min_ Int) (max Int) (j Int)) (!
  (=>
    (and (<= 0 j) (< j (- max min_)))
    (= (Seq_index (Seq_range min_ max) j) (+ min_ j)))
  :pattern ((Seq_index (Seq_range min_ max) j))
  :qid |$Seq[Int]_prog.Seq_range_index|)))
(assert (forall ((min_ Int) (max Int) (v Int)) (!
  (= (Seq_contains (Seq_range min_ max) v) (and (<= min_ v) (< v max)))
  :pattern ((Seq_contains (Seq_range min_ max) v))
  :qid |$Seq[Int]_prog.Seq_range_contains|)))
(assert (forall ((before Seq<Int>) (focus Option<Int>) (after Seq<Int>)) (!
  (Seq_equal
    before
    (get_ListZipper_before<Seq<Int>> (Zipper<ListZipper<Int>> before focus after)))
  :pattern ((Zipper<ListZipper<Int>> before focus after))
  )))
(assert (forall ((before Seq<Int>) (focus Option<Int>) (after Seq<Int>)) (!
  (=
    focus
    (get_ListZipper_focus<Option<Int>> (Zipper<ListZipper<Int>> before focus after)))
  :pattern ((Zipper<ListZipper<Int>> before focus after))
  )))
(assert (forall ((before Seq<Int>) (focus Option<Int>) (after Seq<Int>)) (!
  (Seq_equal
    after
    (get_ListZipper_after<Seq<Int>> (Zipper<ListZipper<Int>> before focus after)))
  :pattern ((Zipper<ListZipper<Int>> before focus after))
  )))
(assert (forall ((before Seq<Int>) (focus Option<Int>) (after Seq<Int>)) (!
  (= (ListZipper_tag<Int> (Zipper<ListZipper<Int>> before focus after)) 0)
  :pattern ((Zipper<ListZipper<Int>> before focus after))
  )))
(assert (forall ((t ListZipper<Int>)) (!
  (=
    t
    (Zipper<ListZipper<Int>> (get_ListZipper_before<Seq<Int>> t) (get_ListZipper_focus<Option<Int>> t) (get_ListZipper_after<Seq<Int>> t)))
  :pattern ((ListZipper_tag<Int> t))
  :pattern ((get_ListZipper_before<Seq<Int>> t))
  :pattern ((get_ListZipper_focus<Option<Int>> t))
  :pattern ((get_ListZipper_after<Seq<Int>> t))
  )))
(assert (forall ((value Int) (children Seq<RoseTree>)) (!
  (= value (get_RoseTree_value<Int> (RoseNode<RoseTree> value children)))
  :pattern ((RoseNode<RoseTree> value children))
  )))
(assert (forall ((value Int) (children Seq<RoseTree>)) (!
  (Seq_equal
    children
    (get_RoseTree_children<Seq<RoseTree>> (RoseNode<RoseTree> value children)))
  :pattern ((RoseNode<RoseTree> value children))
  )))
(assert (= (RoseTree_tag<Int> (as Empty<RoseTree>  RoseTree)) 0))
(assert (forall ((value Int) (children Seq<RoseTree>)) (!
  (= (RoseTree_tag<Int> (RoseNode<RoseTree> value children)) 1)
  :pattern ((RoseNode<RoseTree> value children))
  )))
(assert (forall ((t RoseTree)) (!
  (or
    (= t (as Empty<RoseTree>  RoseTree))
    (=
      t
      (RoseNode<RoseTree> (get_RoseTree_value<Int> t) (get_RoseTree_children<Seq<RoseTree>> t))))
  :pattern ((RoseTree_tag<Int> t))
  :pattern ((get_RoseTree_value<Int> t))
  :pattern ((get_RoseTree_children<Seq<RoseTree>> t))
  )))
(assert (forall ((left BST) (value Int) (right BST)) (!
  (= left (get_BST_left<BST> (BSTNode<BST> left value right)))
  :pattern ((BSTNode<BST> left value right))
  )))
(assert (forall ((left BST) (value Int) (right BST)) (!
  (= value (get_BST_value<Int> (BSTNode<BST> left value right)))
  :pattern ((BSTNode<BST> left value right))
  )))
(assert (forall ((left BST) (value Int) (right BST)) (!
  (= right (get_BST_right<BST> (BSTNode<BST> left value right)))
  :pattern ((BSTNode<BST> left value right))
  )))
(assert (= (BST_tag<Int> (as BSTLeaf<BST>  BST)) 0))
(assert (forall ((left BST) (value Int) (right BST)) (!
  (= (BST_tag<Int> (BSTNode<BST> left value right)) 1)
  :pattern ((BSTNode<BST> left value right))
  )))
(assert (forall ((t BST)) (!
  (or
    (= t (as BSTLeaf<BST>  BST))
    (=
      t
      (BSTNode<BST> (get_BST_left<BST> t) (get_BST_value<Int> t) (get_BST_right<BST> t))))
  :pattern ((BST_tag<Int> t))
  :pattern ((get_BST_left<BST> t))
  :pattern ((get_BST_value<Int> t))
  :pattern ((get_BST_right<BST> t))
  )))
(assert (forall ((value Int)) (!
  (= value (get_Option_value<Int> (Some<Option<Int>> value)))
  :pattern ((Some<Option<Int>> value))
  )))
(assert (= (Option_tag<Int> (as None<Option<Int>>  Option<Int>)) 0))
(assert (forall ((value Int)) (!
  (= (Option_tag<Int> (Some<Option<Int>> value)) 1)
  :pattern ((Some<Option<Int>> value))
  )))
(assert (forall ((t Option<Int>)) (!
  (or
    (= t (as None<Option<Int>>  Option<Int>))
    (= t (Some<Option<Int>> (get_Option_value<Int> t))))
  :pattern ((Option_tag<Int> t))
  :pattern ((get_Option_value<Int> t))
  )))
(assert (forall ((isEnd Bool) (children Seq<Trie>)) (!
  (= isEnd (get_Trie_isEnd<Bool> (TrieNode<Trie> isEnd children)))
  :pattern ((TrieNode<Trie> isEnd children))
  )))
(assert (forall ((isEnd Bool) (children Seq<Trie>)) (!
  (Seq_equal
    children
    (get_Trie_children<Seq<Trie>> (TrieNode<Trie> isEnd children)))
  :pattern ((TrieNode<Trie> isEnd children))
  )))
(assert (= (Trie_tag<Int> (as EmptyTrie<Trie>  Trie)) 0))
(assert (forall ((isEnd Bool) (children Seq<Trie>)) (!
  (= (Trie_tag<Int> (TrieNode<Trie> isEnd children)) 1)
  :pattern ((TrieNode<Trie> isEnd children))
  )))
(assert (forall ((t Trie)) (!
  (or
    (= t (as EmptyTrie<Trie>  Trie))
    (=
      t
      (TrieNode<Trie> (get_Trie_isEnd<Bool> t) (get_Trie_children<Seq<Trie>> t))))
  :pattern ((Trie_tag<Int> t))
  :pattern ((get_Trie_isEnd<Bool> t))
  :pattern ((get_Trie_children<Seq<Trie>> t))
  )))
; End preamble
; ------------------------------------------------------------
; State saturation: after preamble
(set-option :rlimit 160000)
(check-sat)
; unknown
; ---------- FUNCTION find_root----------
(declare-fun parent@0@00 () Seq<Int>)
(declare-fun x@1@00 () Int)
(declare-fun depth@2@00 () Int)
(declare-fun result@3@00 () Int)
; ----- Well-definedness of specifications -----
(set-option :rlimit 0)
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] depth >= 0
(assert (>= depth@2@00 0))
(assert (=
  ($Snap.second s@$)
  ($Snap.combine
    ($Snap.first ($Snap.second s@$))
    ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.first ($Snap.second s@$)) $Snap.unit))
; [eval] x >= 0
(assert (>= x@1@00 0))
(assert (= ($Snap.second ($Snap.second s@$)) $Snap.unit))
; [eval] x < |parent|
; [eval] |parent|
(assert (< x@1@00 (Seq_length parent@0@00)))
(declare-const $t@61@00 $Snap)
(assert (= $t@61@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@3@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (parent@0@00 Seq<Int>) (x@1@00 Int) (depth@2@00 Int)) (!
  (=
    (find_root%limited s@$ parent@0@00 x@1@00 depth@2@00)
    (find_root s@$ parent@0@00 x@1@00 depth@2@00))
  :pattern ((find_root s@$ parent@0@00 x@1@00 depth@2@00))
  :qid |quant-u-0|)))
(assert (forall ((s@$ $Snap) (parent@0@00 Seq<Int>) (x@1@00 Int) (depth@2@00 Int)) (!
  (find_root%stateless parent@0@00 x@1@00 depth@2@00)
  :pattern ((find_root%limited s@$ parent@0@00 x@1@00 depth@2@00))
  :qid |quant-u-1|)))
(assert (forall ((s@$ $Snap) (parent@0@00 Seq<Int>) (x@1@00 Int) (depth@2@00 Int)) (!
  (let ((result@3@00 (find_root%limited s@$ parent@0@00 x@1@00 depth@2@00))) (=>
    (find_root%precondition s@$ parent@0@00 x@1@00 depth@2@00)
    (>= result@3@00 0)))
  :pattern ((find_root%limited s@$ parent@0@00 x@1@00 depth@2@00))
  :qid |quant-u-40|)))
(assert (forall ((s@$ $Snap) (parent@0@00 Seq<Int>) (x@1@00 Int) (depth@2@00 Int)) (!
  (let ((result@3@00 (find_root%limited s@$ parent@0@00 x@1@00 depth@2@00))) true)
  :pattern ((find_root%limited s@$ parent@0@00 x@1@00 depth@2@00))
  :qid |quant-u-41|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (>= depth@2@00 0))
(assert (=
  ($Snap.second s@$)
  ($Snap.combine
    ($Snap.first ($Snap.second s@$))
    ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.first ($Snap.second s@$)) $Snap.unit))
(assert (>= x@1@00 0))
(assert (= ($Snap.second ($Snap.second s@$)) $Snap.unit))
(assert (< x@1@00 (Seq_length parent@0@00)))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (depth == 0 || x >= |parent| ? x : (parent[x] == x ? x : find_root(parent, parent[x], depth - 1)))
; [eval] depth == 0 || x >= |parent|
; [eval] depth == 0
(set-option :rlimit 0)
(push) ; 2
; [then-branch: 0 | depth@2@00 == 0 | live]
; [else-branch: 0 | depth@2@00 != 0 | live]
(push) ; 3
; [then-branch: 0 | depth@2@00 == 0]
(assert (= depth@2@00 0))
(pop) ; 3
(push) ; 3
; [else-branch: 0 | depth@2@00 != 0]
(assert (not (= depth@2@00 0)))
; [eval] x >= |parent|
; [eval] |parent|
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (= depth@2@00 0)) (= depth@2@00 0)))
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (or (= depth@2@00 0) (>= x@1@00 (Seq_length parent@0@00))))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (or (= depth@2@00 0) (>= x@1@00 (Seq_length parent@0@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 1 | depth@2@00 == 0 || x@1@00 >= |parent@0@00| | live]
; [else-branch: 1 | !(depth@2@00 == 0 || x@1@00 >= |parent@0@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 1 | depth@2@00 == 0 || x@1@00 >= |parent@0@00|]
(assert (or (= depth@2@00 0) (>= x@1@00 (Seq_length parent@0@00))))
(pop) ; 3
(push) ; 3
; [else-branch: 1 | !(depth@2@00 == 0 || x@1@00 >= |parent@0@00|)]
(assert (not (or (= depth@2@00 0) (>= x@1@00 (Seq_length parent@0@00)))))
; [eval] (parent[x] == x ? x : find_root(parent, parent[x], depth - 1))
; [eval] parent[x] == x
; [eval] parent[x]
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (= (Seq_index parent@0@00 x@1@00) x@1@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= (Seq_index parent@0@00 x@1@00) x@1@00)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 2 | parent@0@00[x@1@00] == x@1@00 | live]
; [else-branch: 2 | parent@0@00[x@1@00] != x@1@00 | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 2 | parent@0@00[x@1@00] == x@1@00]
(assert (= (Seq_index parent@0@00 x@1@00) x@1@00))
(pop) ; 5
(push) ; 5
; [else-branch: 2 | parent@0@00[x@1@00] != x@1@00]
(assert (not (= (Seq_index parent@0@00 x@1@00) x@1@00)))
; [eval] find_root(parent, parent[x], depth - 1)
; [eval] parent[x]
; [eval] depth - 1
(push) ; 6
; [eval] depth >= 0
(push) ; 7
(assert (not (>= (- depth@2@00 1) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (>= (- depth@2@00 1) 0))
; [eval] x >= 0
(push) ; 7
(assert (not (>= (Seq_index parent@0@00 x@1@00) 0)))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] x >= 0
(set-option :rlimit 0)
(push) ; 7
(assert (not (>= (Seq_index parent@0@00 x@1@00) 0)))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] x >= 0
(set-option :rlimit 0)
(push) ; 7
(assert (not (>= (Seq_index parent@0@00 x@1@00) 0)))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] x >= 0
(set-option :rlimit 0)
(push) ; 7
(assert (not (>= (Seq_index parent@0@00 x@1@00) 0)))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(pop) ; 6
(pop) ; 5
(pop) ; 4
(pop) ; 3
(pop) ; 2
(pop) ; 1
; ---------- FUNCTION trie_is_empty----------
(declare-fun t@4@00 () Trie)
(declare-fun result@5@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@4@00 Trie)) (!
  (= (trie_is_empty%limited s@$ t@4@00) (trie_is_empty s@$ t@4@00))
  :pattern ((trie_is_empty s@$ t@4@00))
  :qid |quant-u-2|)))
(assert (forall ((s@$ $Snap) (t@4@00 Trie)) (!
  (trie_is_empty%stateless t@4@00)
  :pattern ((trie_is_empty%limited s@$ t@4@00))
  :qid |quant-u-3|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] !get_Trie_isEnd(t) && |get_Trie_children(t)| == 0
; [eval] !get_Trie_isEnd(t)
; [eval] get_Trie_isEnd(t)
(set-option :rlimit 0)
(push) ; 2
; [then-branch: 3 | get_Trie_isEnd[Bool](t@4@00) | live]
; [else-branch: 3 | !(get_Trie_isEnd[Bool](t@4@00)) | live]
(push) ; 3
; [then-branch: 3 | get_Trie_isEnd[Bool](t@4@00)]
(assert (get_Trie_isEnd<Bool> t@4@00))
(pop) ; 3
(push) ; 3
; [else-branch: 3 | !(get_Trie_isEnd[Bool](t@4@00))]
(assert (not (get_Trie_isEnd<Bool> t@4@00)))
; [eval] |get_Trie_children(t)| == 0
; [eval] |get_Trie_children(t)|
; [eval] get_Trie_children(t)
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (get_Trie_isEnd<Bool> t@4@00)) (get_Trie_isEnd<Bool> t@4@00)))
(assert (=
  result@5@00
  (and
    (not (get_Trie_isEnd<Bool> t@4@00))
    (= (Seq_length (get_Trie_children<Seq<Trie>> t@4@00)) 0))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@4@00 Trie)) (!
  (=>
    (trie_is_empty%precondition s@$ t@4@00)
    (=
      (trie_is_empty s@$ t@4@00)
      (and
        (not (get_Trie_isEnd<Bool> t@4@00))
        (= (Seq_length (get_Trie_children<Seq<Trie>> t@4@00)) 0))))
  :pattern ((trie_is_empty s@$ t@4@00))
  :qid |quant-u-42|)))
(assert (forall ((s@$ $Snap) (t@4@00 Trie)) (!
  true
  :pattern ((trie_is_empty s@$ t@4@00))
  :qid |quant-u-43|)))
; ---------- FUNCTION bst_max----------
(declare-fun t@6@00 () BST)
(declare-fun result@7@00 () Option<Int>)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@6@00 BST)) (!
  (= (bst_max%limited s@$ t@6@00) (bst_max s@$ t@6@00))
  :pattern ((bst_max s@$ t@6@00))
  :qid |quant-u-4|)))
(assert (forall ((s@$ $Snap) (t@6@00 BST)) (!
  (bst_max%stateless t@6@00)
  :pattern ((bst_max%limited s@$ t@6@00))
  :qid |quant-u-5|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (BST_tag(t) == 0 ? (None(): Option[Int]) : (BST_tag(get_BST_right(t)) == 0 ? (Some(get_BST_value(t)): Option[Int]) : bst_max(get_BST_right(t))))
; [eval] BST_tag(t) == 0
; [eval] BST_tag(t)
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (BST_tag<Int> t@6@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (BST_tag<Int> t@6@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 4 | BST_tag[Int](t@6@00) == 0 | live]
; [else-branch: 4 | BST_tag[Int](t@6@00) != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 4 | BST_tag[Int](t@6@00) == 0]
(assert (= (BST_tag<Int> t@6@00) 0))
; [eval] (None(): Option[Int])
(pop) ; 3
(push) ; 3
; [else-branch: 4 | BST_tag[Int](t@6@00) != 0]
(assert (not (= (BST_tag<Int> t@6@00) 0)))
; [eval] (BST_tag(get_BST_right(t)) == 0 ? (Some(get_BST_value(t)): Option[Int]) : bst_max(get_BST_right(t)))
; [eval] BST_tag(get_BST_right(t)) == 0
; [eval] BST_tag(get_BST_right(t))
; [eval] get_BST_right(t)
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (= (BST_tag<Int> (get_BST_right<BST> t@6@00)) 0))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= (BST_tag<Int> (get_BST_right<BST> t@6@00)) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 5 | BST_tag[Int](get_BST_right[BST](t@6@00)) == 0 | live]
; [else-branch: 5 | BST_tag[Int](get_BST_right[BST](t@6@00)) != 0 | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 5 | BST_tag[Int](get_BST_right[BST](t@6@00)) == 0]
(assert (= (BST_tag<Int> (get_BST_right<BST> t@6@00)) 0))
; [eval] (Some(get_BST_value(t)): Option[Int])
; [eval] get_BST_value(t)
(pop) ; 5
(push) ; 5
; [else-branch: 5 | BST_tag[Int](get_BST_right[BST](t@6@00)) != 0]
(assert (not (= (BST_tag<Int> (get_BST_right<BST> t@6@00)) 0)))
; [eval] bst_max(get_BST_right(t))
; [eval] get_BST_right(t)
(push) ; 6
(assert (bst_max%precondition $Snap.unit (get_BST_right<BST> t@6@00)))
(pop) ; 6
; Joined path conditions
(assert (bst_max%precondition $Snap.unit (get_BST_right<BST> t@6@00)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (BST_tag<Int> (get_BST_right<BST> t@6@00)) 0))
  (and
    (not (= (BST_tag<Int> (get_BST_right<BST> t@6@00)) 0))
    (bst_max%precondition $Snap.unit (get_BST_right<BST> t@6@00)))))
(assert (or
  (not (= (BST_tag<Int> (get_BST_right<BST> t@6@00)) 0))
  (= (BST_tag<Int> (get_BST_right<BST> t@6@00)) 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (BST_tag<Int> t@6@00) 0))
  (and
    (not (= (BST_tag<Int> t@6@00) 0))
    (=>
      (not (= (BST_tag<Int> (get_BST_right<BST> t@6@00)) 0))
      (and
        (not (= (BST_tag<Int> (get_BST_right<BST> t@6@00)) 0))
        (bst_max%precondition $Snap.unit (get_BST_right<BST> t@6@00))))
    (or
      (not (= (BST_tag<Int> (get_BST_right<BST> t@6@00)) 0))
      (= (BST_tag<Int> (get_BST_right<BST> t@6@00)) 0)))))
(assert (or (not (= (BST_tag<Int> t@6@00) 0)) (= (BST_tag<Int> t@6@00) 0)))
(assert (=
  result@7@00
  (ite
    (= (BST_tag<Int> t@6@00) 0)
    (as None<Option<Int>>  Option<Int>)
    (ite
      (= (BST_tag<Int> (get_BST_right<BST> t@6@00)) 0)
      (Some<Option<Int>> (get_BST_value<Int> t@6@00))
      (bst_max $Snap.unit (get_BST_right<BST> t@6@00))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@6@00 BST)) (!
  (=>
    (bst_max%precondition s@$ t@6@00)
    (=
      (bst_max s@$ t@6@00)
      (ite
        (= (BST_tag<Int> t@6@00) 0)
        (as None<Option<Int>>  Option<Int>)
        (ite
          (= (BST_tag<Int> (get_BST_right<BST> t@6@00)) 0)
          (Some<Option<Int>> (get_BST_value<Int> t@6@00))
          (bst_max%limited $Snap.unit (get_BST_right<BST> t@6@00))))))
  :pattern ((bst_max s@$ t@6@00))
  :qid |quant-u-44|)))
(assert (forall ((s@$ $Snap) (t@6@00 BST)) (!
  (=>
    (bst_max%precondition s@$ t@6@00)
    (ite
      (= (BST_tag<Int> t@6@00) 0)
      true
      (ite
        (= (BST_tag<Int> (get_BST_right<BST> t@6@00)) 0)
        true
        (bst_max%precondition $Snap.unit (get_BST_right<BST> t@6@00)))))
  :pattern ((bst_max s@$ t@6@00))
  :qid |quant-u-45|)))
; ---------- FUNCTION zipper_backward----------
(declare-fun z@8@00 () ListZipper<Int>)
(declare-fun result@9@00 () ListZipper<Int>)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (z@8@00 ListZipper<Int>)) (!
  (= (zipper_backward%limited s@$ z@8@00) (zipper_backward s@$ z@8@00))
  :pattern ((zipper_backward s@$ z@8@00))
  :qid |quant-u-6|)))
(assert (forall ((s@$ $Snap) (z@8@00 ListZipper<Int>)) (!
  (zipper_backward%stateless z@8@00)
  :pattern ((zipper_backward%limited s@$ z@8@00))
  :qid |quant-u-7|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (|(get_ListZipper_before(z): Seq[Int])| == 0 ? z : (Zipper((get_ListZipper_before(z): Seq[Int])[..|(get_ListZipper_before(z): Seq[Int])| - 1], (Some((get_ListZipper_before(z): Seq[Int])[|(get_ListZipper_before(z): Seq[Int])| - 1]): Option[Int]), ((Option_tag((get_ListZipper_focus(z): Option[Int])): Int) == 0 ? (get_ListZipper_after(z): Seq[Int]) : Seq((get_Option_value((get_ListZipper_focus(z): Option[Int])): Int)) ++ (get_ListZipper_after(z): Seq[Int]))): ListZipper[Int]))
; [eval] |(get_ListZipper_before(z): Seq[Int])| == 0
; [eval] |(get_ListZipper_before(z): Seq[Int])|
; [eval] (get_ListZipper_before(z): Seq[Int])
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 6 | |get_ListZipper_before[Seq[Int]](z@8@00)| == 0 | live]
; [else-branch: 6 | |get_ListZipper_before[Seq[Int]](z@8@00)| != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 6 | |get_ListZipper_before[Seq[Int]](z@8@00)| == 0]
(assert (= (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 6 | |get_ListZipper_before[Seq[Int]](z@8@00)| != 0]
(assert (not (= (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 0)))
; [eval] (Zipper((get_ListZipper_before(z): Seq[Int])[..|(get_ListZipper_before(z): Seq[Int])| - 1], (Some((get_ListZipper_before(z): Seq[Int])[|(get_ListZipper_before(z): Seq[Int])| - 1]): Option[Int]), ((Option_tag((get_ListZipper_focus(z): Option[Int])): Int) == 0 ? (get_ListZipper_after(z): Seq[Int]) : Seq((get_Option_value((get_ListZipper_focus(z): Option[Int])): Int)) ++ (get_ListZipper_after(z): Seq[Int]))): ListZipper[Int])
; [eval] (get_ListZipper_before(z): Seq[Int])[..|(get_ListZipper_before(z): Seq[Int])| - 1]
; [eval] (get_ListZipper_before(z): Seq[Int])
; [eval] |(get_ListZipper_before(z): Seq[Int])| - 1
; [eval] |(get_ListZipper_before(z): Seq[Int])|
; [eval] (get_ListZipper_before(z): Seq[Int])
; [eval] (Some((get_ListZipper_before(z): Seq[Int])[|(get_ListZipper_before(z): Seq[Int])| - 1]): Option[Int])
; [eval] (get_ListZipper_before(z): Seq[Int])[|(get_ListZipper_before(z): Seq[Int])| - 1]
; [eval] (get_ListZipper_before(z): Seq[Int])
; [eval] |(get_ListZipper_before(z): Seq[Int])| - 1
; [eval] |(get_ListZipper_before(z): Seq[Int])|
; [eval] (get_ListZipper_before(z): Seq[Int])
(push) ; 4
(assert (not (>= (- (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 1) 0)))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(push) ; 4
(assert (not (<
  (- (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 1)
  (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [eval] ((Option_tag((get_ListZipper_focus(z): Option[Int])): Int) == 0 ? (get_ListZipper_after(z): Seq[Int]) : Seq((get_Option_value((get_ListZipper_focus(z): Option[Int])): Int)) ++ (get_ListZipper_after(z): Seq[Int]))
; [eval] (Option_tag((get_ListZipper_focus(z): Option[Int])): Int) == 0
; [eval] (Option_tag((get_ListZipper_focus(z): Option[Int])): Int)
; [eval] (get_ListZipper_focus(z): Option[Int])
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@8@00)) 0))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@8@00)) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 7 | Option_tag[Int](get_ListZipper_focus[Option[Int]](z@8@00)) == 0 | live]
; [else-branch: 7 | Option_tag[Int](get_ListZipper_focus[Option[Int]](z@8@00)) != 0 | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 7 | Option_tag[Int](get_ListZipper_focus[Option[Int]](z@8@00)) == 0]
(assert (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@8@00)) 0))
; [eval] (get_ListZipper_after(z): Seq[Int])
(pop) ; 5
(push) ; 5
; [else-branch: 7 | Option_tag[Int](get_ListZipper_focus[Option[Int]](z@8@00)) != 0]
(assert (not (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@8@00)) 0)))
; [eval] Seq((get_Option_value((get_ListZipper_focus(z): Option[Int])): Int)) ++ (get_ListZipper_after(z): Seq[Int])
; [eval] Seq((get_Option_value((get_ListZipper_focus(z): Option[Int])): Int))
; [eval] (get_Option_value((get_ListZipper_focus(z): Option[Int])): Int)
; [eval] (get_ListZipper_focus(z): Option[Int])
(assert (=
  (Seq_length
    (Seq_singleton (get_Option_value<Int> (get_ListZipper_focus<Option<Int>> z@8@00))))
  1))
; [eval] (get_ListZipper_after(z): Seq[Int])
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@8@00)) 0))
  (and
    (not (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@8@00)) 0))
    (=
      (Seq_length
        (Seq_singleton (get_Option_value<Int> (get_ListZipper_focus<Option<Int>> z@8@00))))
      1))))
(assert (or
  (not (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@8@00)) 0))
  (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@8@00)) 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 0))
  (and
    (not (= (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 0))
    (=>
      (not (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@8@00)) 0))
      (and
        (not (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@8@00)) 0))
        (=
          (Seq_length
            (Seq_singleton (get_Option_value<Int> (get_ListZipper_focus<Option<Int>> z@8@00))))
          1)))
    (or
      (not (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@8@00)) 0))
      (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@8@00)) 0)))))
(assert (or
  (not (= (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 0))
  (= (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 0)))
(assert (=
  result@9@00
  (ite
    (= (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 0)
    z@8@00
    (Zipper<ListZipper<Int>> (Seq_take
      (get_ListZipper_before<Seq<Int>> z@8@00)
      (- (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 1)) (Some<Option<Int>> (Seq_index
      (get_ListZipper_before<Seq<Int>> z@8@00)
      (- (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 1))) (ite
      (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@8@00)) 0)
      (get_ListZipper_after<Seq<Int>> z@8@00)
      (Seq_append
        (Seq_singleton (get_Option_value<Int> (get_ListZipper_focus<Option<Int>> z@8@00)))
        (get_ListZipper_after<Seq<Int>> z@8@00)))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (z@8@00 ListZipper<Int>)) (!
  (=>
    (zipper_backward%precondition s@$ z@8@00)
    (=
      (zipper_backward s@$ z@8@00)
      (ite
        (= (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 0)
        z@8@00
        (Zipper<ListZipper<Int>> (Seq_take
          (get_ListZipper_before<Seq<Int>> z@8@00)
          (- (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 1)) (Some<Option<Int>> (Seq_index
          (get_ListZipper_before<Seq<Int>> z@8@00)
          (- (Seq_length (get_ListZipper_before<Seq<Int>> z@8@00)) 1))) (ite
          (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@8@00)) 0)
          (get_ListZipper_after<Seq<Int>> z@8@00)
          (Seq_append
            (Seq_singleton (get_Option_value<Int> (get_ListZipper_focus<Option<Int>> z@8@00)))
            (get_ListZipper_after<Seq<Int>> z@8@00)))))))
  :pattern ((zipper_backward s@$ z@8@00))
  :qid |quant-u-46|)))
(assert (forall ((s@$ $Snap) (z@8@00 ListZipper<Int>)) (!
  true
  :pattern ((zipper_backward s@$ z@8@00))
  :qid |quant-u-47|)))
; ---------- FUNCTION rose_size----------
(declare-fun t@10@00 () RoseTree)
(declare-fun result@11@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@10@00 RoseTree)) (!
  (= (rose_size%limited s@$ t@10@00) (rose_size s@$ t@10@00))
  :pattern ((rose_size s@$ t@10@00))
  :qid |quant-u-8|)))
(assert (forall ((s@$ $Snap) (t@10@00 RoseTree)) (!
  (rose_size%stateless t@10@00)
  :pattern ((rose_size%limited s@$ t@10@00))
  :qid |quant-u-9|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] 1 + rose_children_size(get_RoseTree_children(t), 0)
; [eval] rose_children_size(get_RoseTree_children(t), 0)
; [eval] get_RoseTree_children(t)
(set-option :rlimit 0)
(push) ; 2
; [eval] idx >= 0
(assert (rose_children_size%precondition $Snap.unit (get_RoseTree_children<Seq<RoseTree>> t@10@00) 0))
(pop) ; 2
; Joined path conditions
(assert (rose_children_size%precondition $Snap.unit (get_RoseTree_children<Seq<RoseTree>> t@10@00) 0))
(assert (=
  result@11@00
  (+
    1
    (rose_children_size $Snap.unit (get_RoseTree_children<Seq<RoseTree>> t@10@00) 0))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@10@00 RoseTree)) (!
  (=>
    (rose_size%precondition s@$ t@10@00)
    (=
      (rose_size s@$ t@10@00)
      (+
        1
        (rose_children_size%limited $Snap.unit (get_RoseTree_children<Seq<RoseTree>> t@10@00) 0))))
  :pattern ((rose_size s@$ t@10@00))
  :qid |quant-u-48|)))
(assert (forall ((s@$ $Snap) (t@10@00 RoseTree)) (!
  (=>
    (rose_size%precondition s@$ t@10@00)
    (rose_children_size%precondition $Snap.unit (get_RoseTree_children<Seq<RoseTree>> t@10@00) 0))
  :pattern ((rose_size s@$ t@10@00))
  :qid |quant-u-49|)))
; ---------- FUNCTION rose_children_size----------
(declare-fun children@12@00 () Seq<RoseTree>)
(declare-fun idx@13@00 () Int)
(declare-fun result@14@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] idx >= 0
(assert (>= idx@13@00 0))
(declare-const $t@62@00 $Snap)
(assert (= $t@62@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@14@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (children@12@00 Seq<RoseTree>) (idx@13@00 Int)) (!
  (=
    (rose_children_size%limited s@$ children@12@00 idx@13@00)
    (rose_children_size s@$ children@12@00 idx@13@00))
  :pattern ((rose_children_size s@$ children@12@00 idx@13@00))
  :qid |quant-u-10|)))
(assert (forall ((s@$ $Snap) (children@12@00 Seq<RoseTree>) (idx@13@00 Int)) (!
  (rose_children_size%stateless children@12@00 idx@13@00)
  :pattern ((rose_children_size%limited s@$ children@12@00 idx@13@00))
  :qid |quant-u-11|)))
(assert (forall ((s@$ $Snap) (children@12@00 Seq<RoseTree>) (idx@13@00 Int)) (!
  (let ((result@14@00 (rose_children_size%limited s@$ children@12@00 idx@13@00))) (=>
    (rose_children_size%precondition s@$ children@12@00 idx@13@00)
    (>= result@14@00 0)))
  :pattern ((rose_children_size%limited s@$ children@12@00 idx@13@00))
  :qid |quant-u-50|)))
(assert (forall ((s@$ $Snap) (children@12@00 Seq<RoseTree>) (idx@13@00 Int)) (!
  (let ((result@14@00 (rose_children_size%limited s@$ children@12@00 idx@13@00))) true)
  :pattern ((rose_children_size%limited s@$ children@12@00 idx@13@00))
  :qid |quant-u-51|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (>= idx@13@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (idx >= |children| ? 0 : rose_size(children[idx]) + rose_children_size(children, idx + 1))
; [eval] idx >= |children|
; [eval] |children|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= idx@13@00 (Seq_length children@12@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= idx@13@00 (Seq_length children@12@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 8 | idx@13@00 >= |children@12@00| | live]
; [else-branch: 8 | !(idx@13@00 >= |children@12@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 8 | idx@13@00 >= |children@12@00|]
(assert (>= idx@13@00 (Seq_length children@12@00)))
(pop) ; 3
(push) ; 3
; [else-branch: 8 | !(idx@13@00 >= |children@12@00|)]
(assert (not (>= idx@13@00 (Seq_length children@12@00))))
; [eval] rose_size(children[idx]) + rose_children_size(children, idx + 1)
; [eval] rose_size(children[idx])
; [eval] children[idx]
(push) ; 4
(assert (not (< idx@13@00 (Seq_length children@12@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(push) ; 4
(assert (rose_size%precondition $Snap.unit (Seq_index children@12@00 idx@13@00)))
(pop) ; 4
; Joined path conditions
(assert (rose_size%precondition $Snap.unit (Seq_index children@12@00 idx@13@00)))
; [eval] rose_children_size(children, idx + 1)
; [eval] idx + 1
(push) ; 4
; [eval] idx >= 0
(push) ; 5
(assert (not (>= (+ idx@13@00 1) 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (>= (+ idx@13@00 1) 0))
(assert (rose_children_size%precondition $Snap.unit children@12@00 (+ idx@13@00 1)))
(pop) ; 4
; Joined path conditions
(assert (and
  (>= (+ idx@13@00 1) 0)
  (rose_children_size%precondition $Snap.unit children@12@00 (+ idx@13@00 1))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (>= idx@13@00 (Seq_length children@12@00)))
  (and
    (not (>= idx@13@00 (Seq_length children@12@00)))
    (rose_size%precondition $Snap.unit (Seq_index children@12@00 idx@13@00))
    (>= (+ idx@13@00 1) 0)
    (rose_children_size%precondition $Snap.unit children@12@00 (+ idx@13@00 1)))))
(assert (or
  (not (>= idx@13@00 (Seq_length children@12@00)))
  (>= idx@13@00 (Seq_length children@12@00))))
(assert (=
  result@14@00
  (ite
    (>= idx@13@00 (Seq_length children@12@00))
    0
    (+
      (rose_size $Snap.unit (Seq_index children@12@00 idx@13@00))
      (rose_children_size $Snap.unit children@12@00 (+ idx@13@00 1))))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@14@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@14@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (children@12@00 Seq<RoseTree>) (idx@13@00 Int)) (!
  (=>
    (rose_children_size%precondition s@$ children@12@00 idx@13@00)
    (=
      (rose_children_size s@$ children@12@00 idx@13@00)
      (ite
        (>= idx@13@00 (Seq_length children@12@00))
        0
        (+
          (rose_size%limited $Snap.unit (Seq_index children@12@00 idx@13@00))
          (rose_children_size%limited $Snap.unit children@12@00 (+ idx@13@00 1))))))
  :pattern ((rose_children_size s@$ children@12@00 idx@13@00))
  :qid |quant-u-52|)))
(assert (forall ((s@$ $Snap) (children@12@00 Seq<RoseTree>) (idx@13@00 Int)) (!
  (=>
    (rose_children_size%precondition s@$ children@12@00 idx@13@00)
    (ite
      (>= idx@13@00 (Seq_length children@12@00))
      true
      (and
        (rose_size%precondition $Snap.unit (Seq_index children@12@00 idx@13@00))
        (rose_children_size%precondition $Snap.unit children@12@00 (+
          idx@13@00
          1)))))
  :pattern ((rose_children_size s@$ children@12@00 idx@13@00))
  :qid |quant-u-53|)))
; ---------- FUNCTION trie_count_words----------
(declare-fun t@15@00 () Trie)
(declare-fun result@16@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(declare-const $t@63@00 $Snap)
(assert (= $t@63@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@16@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@15@00 Trie)) (!
  (= (trie_count_words%limited s@$ t@15@00) (trie_count_words s@$ t@15@00))
  :pattern ((trie_count_words s@$ t@15@00))
  :qid |quant-u-12|)))
(assert (forall ((s@$ $Snap) (t@15@00 Trie)) (!
  (trie_count_words%stateless t@15@00)
  :pattern ((trie_count_words%limited s@$ t@15@00))
  :qid |quant-u-13|)))
(assert (forall ((s@$ $Snap) (t@15@00 Trie)) (!
  (let ((result@16@00 (trie_count_words%limited s@$ t@15@00))) (=>
    (trie_count_words%precondition s@$ t@15@00)
    (>= result@16@00 0)))
  :pattern ((trie_count_words%limited s@$ t@15@00))
  :qid |quant-u-54|)))
(assert (forall ((s@$ $Snap) (t@15@00 Trie)) (!
  (let ((result@16@00 (trie_count_words%limited s@$ t@15@00))) true)
  :pattern ((trie_count_words%limited s@$ t@15@00))
  :qid |quant-u-55|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (get_Trie_isEnd(t) ? 1 : 0) + trie_count_children_words(get_Trie_children(t), 0)
; [eval] (get_Trie_isEnd(t) ? 1 : 0)
; [eval] get_Trie_isEnd(t)
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (get_Trie_isEnd<Bool> t@15@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (get_Trie_isEnd<Bool> t@15@00)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 9 | get_Trie_isEnd[Bool](t@15@00) | live]
; [else-branch: 9 | !(get_Trie_isEnd[Bool](t@15@00)) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 9 | get_Trie_isEnd[Bool](t@15@00)]
(assert (get_Trie_isEnd<Bool> t@15@00))
(pop) ; 3
(push) ; 3
; [else-branch: 9 | !(get_Trie_isEnd[Bool](t@15@00))]
(assert (not (get_Trie_isEnd<Bool> t@15@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or (not (get_Trie_isEnd<Bool> t@15@00)) (get_Trie_isEnd<Bool> t@15@00)))
; [eval] trie_count_children_words(get_Trie_children(t), 0)
; [eval] get_Trie_children(t)
(push) ; 2
; [eval] idx >= 0
(assert (trie_count_children_words%precondition $Snap.unit (get_Trie_children<Seq<Trie>> t@15@00) 0))
(pop) ; 2
; Joined path conditions
(assert (trie_count_children_words%precondition $Snap.unit (get_Trie_children<Seq<Trie>> t@15@00) 0))
(assert (=
  result@16@00
  (+
    (ite (get_Trie_isEnd<Bool> t@15@00) 1 0)
    (trie_count_children_words $Snap.unit (get_Trie_children<Seq<Trie>> t@15@00) 0))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@16@00 0)))
(check-sat)
; unknown
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] result >= 0
(set-option :rlimit 0)
(push) ; 2
(assert (not (>= result@16@00 0)))
(check-sat)
; unknown
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] result >= 0
(set-option :rlimit 0)
(push) ; 2
(assert (not (>= result@16@00 0)))
(check-sat)
; unknown
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] result >= 0
(set-option :rlimit 0)
(push) ; 2
(assert (not (>= result@16@00 0)))
(check-sat)
; unknown
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(pop) ; 1
; ---------- FUNCTION trie_count_children_words----------
(declare-fun children@17@00 () Seq<Trie>)
(declare-fun idx@18@00 () Int)
(declare-fun result@19@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] idx >= 0
(assert (>= idx@18@00 0))
(declare-const $t@64@00 $Snap)
(assert (= $t@64@00 $Snap.unit))
; [eval] result >= 0
(assert (>= result@19@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (children@17@00 Seq<Trie>) (idx@18@00 Int)) (!
  (=
    (trie_count_children_words%limited s@$ children@17@00 idx@18@00)
    (trie_count_children_words s@$ children@17@00 idx@18@00))
  :pattern ((trie_count_children_words s@$ children@17@00 idx@18@00))
  :qid |quant-u-14|)))
(assert (forall ((s@$ $Snap) (children@17@00 Seq<Trie>) (idx@18@00 Int)) (!
  (trie_count_children_words%stateless children@17@00 idx@18@00)
  :pattern ((trie_count_children_words%limited s@$ children@17@00 idx@18@00))
  :qid |quant-u-15|)))
(assert (forall ((s@$ $Snap) (children@17@00 Seq<Trie>) (idx@18@00 Int)) (!
  (let ((result@19@00 (trie_count_children_words%limited s@$ children@17@00 idx@18@00))) (=>
    (trie_count_children_words%precondition s@$ children@17@00 idx@18@00)
    (>= result@19@00 0)))
  :pattern ((trie_count_children_words%limited s@$ children@17@00 idx@18@00))
  :qid |quant-u-56|)))
(assert (forall ((s@$ $Snap) (children@17@00 Seq<Trie>) (idx@18@00 Int)) (!
  (let ((result@19@00 (trie_count_children_words%limited s@$ children@17@00 idx@18@00))) true)
  :pattern ((trie_count_children_words%limited s@$ children@17@00 idx@18@00))
  :qid |quant-u-57|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (>= idx@18@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (idx >= |children| ? 0 : trie_count_words(children[idx]) + trie_count_children_words(children, idx + 1))
; [eval] idx >= |children|
; [eval] |children|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= idx@18@00 (Seq_length children@17@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= idx@18@00 (Seq_length children@17@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 10 | idx@18@00 >= |children@17@00| | live]
; [else-branch: 10 | !(idx@18@00 >= |children@17@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 10 | idx@18@00 >= |children@17@00|]
(assert (>= idx@18@00 (Seq_length children@17@00)))
(pop) ; 3
(push) ; 3
; [else-branch: 10 | !(idx@18@00 >= |children@17@00|)]
(assert (not (>= idx@18@00 (Seq_length children@17@00))))
; [eval] trie_count_words(children[idx]) + trie_count_children_words(children, idx + 1)
; [eval] trie_count_words(children[idx])
; [eval] children[idx]
(push) ; 4
(assert (not (< idx@18@00 (Seq_length children@17@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(push) ; 4
(assert (trie_count_words%precondition $Snap.unit (Seq_index children@17@00 idx@18@00)))
(pop) ; 4
; Joined path conditions
(assert (trie_count_words%precondition $Snap.unit (Seq_index children@17@00 idx@18@00)))
; [eval] trie_count_children_words(children, idx + 1)
; [eval] idx + 1
(push) ; 4
; [eval] idx >= 0
(push) ; 5
(assert (not (>= (+ idx@18@00 1) 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (>= (+ idx@18@00 1) 0))
(assert (trie_count_children_words%precondition $Snap.unit children@17@00 (+ idx@18@00 1)))
(pop) ; 4
; Joined path conditions
(assert (and
  (>= (+ idx@18@00 1) 0)
  (trie_count_children_words%precondition $Snap.unit children@17@00 (+
    idx@18@00
    1))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (>= idx@18@00 (Seq_length children@17@00)))
  (and
    (not (>= idx@18@00 (Seq_length children@17@00)))
    (trie_count_words%precondition $Snap.unit (Seq_index
      children@17@00
      idx@18@00))
    (>= (+ idx@18@00 1) 0)
    (trie_count_children_words%precondition $Snap.unit children@17@00 (+
      idx@18@00
      1)))))
(assert (or
  (not (>= idx@18@00 (Seq_length children@17@00)))
  (>= idx@18@00 (Seq_length children@17@00))))
(assert (=
  result@19@00
  (ite
    (>= idx@18@00 (Seq_length children@17@00))
    0
    (+
      (trie_count_words $Snap.unit (Seq_index children@17@00 idx@18@00))
      (trie_count_children_words $Snap.unit children@17@00 (+ idx@18@00 1))))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@19@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@19@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (children@17@00 Seq<Trie>) (idx@18@00 Int)) (!
  (=>
    (trie_count_children_words%precondition s@$ children@17@00 idx@18@00)
    (=
      (trie_count_children_words s@$ children@17@00 idx@18@00)
      (ite
        (>= idx@18@00 (Seq_length children@17@00))
        0
        (+
          (trie_count_words%limited $Snap.unit (Seq_index
            children@17@00
            idx@18@00))
          (trie_count_children_words%limited $Snap.unit children@17@00 (+
            idx@18@00
            1))))))
  :pattern ((trie_count_children_words s@$ children@17@00 idx@18@00))
  :qid |quant-u-58|)))
(assert (forall ((s@$ $Snap) (children@17@00 Seq<Trie>) (idx@18@00 Int)) (!
  (=>
    (trie_count_children_words%precondition s@$ children@17@00 idx@18@00)
    (ite
      (>= idx@18@00 (Seq_length children@17@00))
      true
      (and
        (trie_count_words%precondition $Snap.unit (Seq_index
          children@17@00
          idx@18@00))
        (trie_count_children_words%precondition $Snap.unit children@17@00 (+
          idx@18@00
          1)))))
  :pattern ((trie_count_children_words s@$ children@17@00 idx@18@00))
  :qid |quant-u-59|)))
; ---------- FUNCTION bst_insert----------
(declare-fun t@20@00 () BST)
(declare-fun x@21@00 () Int)
(declare-fun result@22@00 () BST)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@20@00 BST) (x@21@00 Int)) (!
  (= (bst_insert%limited s@$ t@20@00 x@21@00) (bst_insert s@$ t@20@00 x@21@00))
  :pattern ((bst_insert s@$ t@20@00 x@21@00))
  :qid |quant-u-16|)))
(assert (forall ((s@$ $Snap) (t@20@00 BST) (x@21@00 Int)) (!
  (bst_insert%stateless t@20@00 x@21@00)
  :pattern ((bst_insert%limited s@$ t@20@00 x@21@00))
  :qid |quant-u-17|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (BST_tag(t) == 0 ? BSTNode(BSTLeaf(), x, BSTLeaf()) : (x < get_BST_value(t) ? BSTNode(bst_insert(get_BST_left(t), x), get_BST_value(t), get_BST_right(t)) : (x > get_BST_value(t) ? BSTNode(get_BST_left(t), get_BST_value(t), bst_insert(get_BST_right(t), x)) : t)))
; [eval] BST_tag(t) == 0
; [eval] BST_tag(t)
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (BST_tag<Int> t@20@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (BST_tag<Int> t@20@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 11 | BST_tag[Int](t@20@00) == 0 | live]
; [else-branch: 11 | BST_tag[Int](t@20@00) != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 11 | BST_tag[Int](t@20@00) == 0]
(assert (= (BST_tag<Int> t@20@00) 0))
; [eval] BSTNode(BSTLeaf(), x, BSTLeaf())
; [eval] BSTLeaf()
; [eval] BSTLeaf()
(pop) ; 3
(push) ; 3
; [else-branch: 11 | BST_tag[Int](t@20@00) != 0]
(assert (not (= (BST_tag<Int> t@20@00) 0)))
; [eval] (x < get_BST_value(t) ? BSTNode(bst_insert(get_BST_left(t), x), get_BST_value(t), get_BST_right(t)) : (x > get_BST_value(t) ? BSTNode(get_BST_left(t), get_BST_value(t), bst_insert(get_BST_right(t), x)) : t))
; [eval] x < get_BST_value(t)
; [eval] get_BST_value(t)
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (< x@21@00 (get_BST_value<Int> t@20@00)))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (< x@21@00 (get_BST_value<Int> t@20@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 12 | x@21@00 < get_BST_value[Int](t@20@00) | live]
; [else-branch: 12 | !(x@21@00 < get_BST_value[Int](t@20@00)) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 12 | x@21@00 < get_BST_value[Int](t@20@00)]
(assert (< x@21@00 (get_BST_value<Int> t@20@00)))
; [eval] BSTNode(bst_insert(get_BST_left(t), x), get_BST_value(t), get_BST_right(t))
; [eval] bst_insert(get_BST_left(t), x)
; [eval] get_BST_left(t)
(push) ; 6
(assert (bst_insert%precondition $Snap.unit (get_BST_left<BST> t@20@00) x@21@00))
(pop) ; 6
; Joined path conditions
(assert (bst_insert%precondition $Snap.unit (get_BST_left<BST> t@20@00) x@21@00))
; [eval] get_BST_value(t)
; [eval] get_BST_right(t)
(pop) ; 5
(push) ; 5
; [else-branch: 12 | !(x@21@00 < get_BST_value[Int](t@20@00))]
(assert (not (< x@21@00 (get_BST_value<Int> t@20@00))))
; [eval] (x > get_BST_value(t) ? BSTNode(get_BST_left(t), get_BST_value(t), bst_insert(get_BST_right(t), x)) : t)
; [eval] x > get_BST_value(t)
; [eval] get_BST_value(t)
(push) ; 6
(push) ; 7
(set-option :rlimit 16000)
(assert (not (not (> x@21@00 (get_BST_value<Int> t@20@00)))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 16000)
(assert (not (> x@21@00 (get_BST_value<Int> t@20@00))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 13 | x@21@00 > get_BST_value[Int](t@20@00) | live]
; [else-branch: 13 | !(x@21@00 > get_BST_value[Int](t@20@00)) | live]
(set-option :rlimit 0)
(push) ; 7
; [then-branch: 13 | x@21@00 > get_BST_value[Int](t@20@00)]
(assert (> x@21@00 (get_BST_value<Int> t@20@00)))
; [eval] BSTNode(get_BST_left(t), get_BST_value(t), bst_insert(get_BST_right(t), x))
; [eval] get_BST_left(t)
; [eval] get_BST_value(t)
; [eval] bst_insert(get_BST_right(t), x)
; [eval] get_BST_right(t)
(push) ; 8
(assert (bst_insert%precondition $Snap.unit (get_BST_right<BST> t@20@00) x@21@00))
(pop) ; 8
; Joined path conditions
(assert (bst_insert%precondition $Snap.unit (get_BST_right<BST> t@20@00) x@21@00))
(pop) ; 7
(push) ; 7
; [else-branch: 13 | !(x@21@00 > get_BST_value[Int](t@20@00))]
(assert (not (> x@21@00 (get_BST_value<Int> t@20@00))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=>
  (> x@21@00 (get_BST_value<Int> t@20@00))
  (and
    (> x@21@00 (get_BST_value<Int> t@20@00))
    (bst_insert%precondition $Snap.unit (get_BST_right<BST> t@20@00) x@21@00))))
; Joined path conditions
(assert (or
  (not (> x@21@00 (get_BST_value<Int> t@20@00)))
  (> x@21@00 (get_BST_value<Int> t@20@00))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=>
  (< x@21@00 (get_BST_value<Int> t@20@00))
  (and
    (< x@21@00 (get_BST_value<Int> t@20@00))
    (bst_insert%precondition $Snap.unit (get_BST_left<BST> t@20@00) x@21@00))))
; Joined path conditions
(assert (=>
  (not (< x@21@00 (get_BST_value<Int> t@20@00)))
  (and
    (not (< x@21@00 (get_BST_value<Int> t@20@00)))
    (=>
      (> x@21@00 (get_BST_value<Int> t@20@00))
      (and
        (> x@21@00 (get_BST_value<Int> t@20@00))
        (bst_insert%precondition $Snap.unit (get_BST_right<BST> t@20@00) x@21@00)))
    (or
      (not (> x@21@00 (get_BST_value<Int> t@20@00)))
      (> x@21@00 (get_BST_value<Int> t@20@00))))))
(assert (or
  (not (< x@21@00 (get_BST_value<Int> t@20@00)))
  (< x@21@00 (get_BST_value<Int> t@20@00))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (BST_tag<Int> t@20@00) 0))
  (and
    (not (= (BST_tag<Int> t@20@00) 0))
    (=>
      (< x@21@00 (get_BST_value<Int> t@20@00))
      (and
        (< x@21@00 (get_BST_value<Int> t@20@00))
        (bst_insert%precondition $Snap.unit (get_BST_left<BST> t@20@00) x@21@00)))
    (=>
      (not (< x@21@00 (get_BST_value<Int> t@20@00)))
      (and
        (not (< x@21@00 (get_BST_value<Int> t@20@00)))
        (=>
          (> x@21@00 (get_BST_value<Int> t@20@00))
          (and
            (> x@21@00 (get_BST_value<Int> t@20@00))
            (bst_insert%precondition $Snap.unit (get_BST_right<BST> t@20@00) x@21@00)))
        (or
          (not (> x@21@00 (get_BST_value<Int> t@20@00)))
          (> x@21@00 (get_BST_value<Int> t@20@00)))))
    (or
      (not (< x@21@00 (get_BST_value<Int> t@20@00)))
      (< x@21@00 (get_BST_value<Int> t@20@00))))))
(assert (or (not (= (BST_tag<Int> t@20@00) 0)) (= (BST_tag<Int> t@20@00) 0)))
(assert (=
  result@22@00
  (ite
    (= (BST_tag<Int> t@20@00) 0)
    (BSTNode<BST> (as BSTLeaf<BST>  BST) x@21@00 (as BSTLeaf<BST>  BST))
    (ite
      (< x@21@00 (get_BST_value<Int> t@20@00))
      (BSTNode<BST> (bst_insert $Snap.unit (get_BST_left<BST> t@20@00) x@21@00) (get_BST_value<Int> t@20@00) (get_BST_right<BST> t@20@00))
      (ite
        (> x@21@00 (get_BST_value<Int> t@20@00))
        (BSTNode<BST> (get_BST_left<BST> t@20@00) (get_BST_value<Int> t@20@00) (bst_insert $Snap.unit (get_BST_right<BST> t@20@00) x@21@00))
        t@20@00)))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@20@00 BST) (x@21@00 Int)) (!
  (=>
    (bst_insert%precondition s@$ t@20@00 x@21@00)
    (=
      (bst_insert s@$ t@20@00 x@21@00)
      (ite
        (= (BST_tag<Int> t@20@00) 0)
        (BSTNode<BST> (as BSTLeaf<BST>  BST) x@21@00 (as BSTLeaf<BST>  BST))
        (ite
          (< x@21@00 (get_BST_value<Int> t@20@00))
          (BSTNode<BST> (bst_insert%limited $Snap.unit (get_BST_left<BST> t@20@00) x@21@00) (get_BST_value<Int> t@20@00) (get_BST_right<BST> t@20@00))
          (ite
            (> x@21@00 (get_BST_value<Int> t@20@00))
            (BSTNode<BST> (get_BST_left<BST> t@20@00) (get_BST_value<Int> t@20@00) (bst_insert%limited $Snap.unit (get_BST_right<BST> t@20@00) x@21@00))
            t@20@00)))))
  :pattern ((bst_insert s@$ t@20@00 x@21@00))
  :qid |quant-u-60|)))
(assert (forall ((s@$ $Snap) (t@20@00 BST) (x@21@00 Int)) (!
  (=>
    (bst_insert%precondition s@$ t@20@00 x@21@00)
    (ite
      (= (BST_tag<Int> t@20@00) 0)
      true
      (ite
        (< x@21@00 (get_BST_value<Int> t@20@00))
        (bst_insert%precondition $Snap.unit (get_BST_left<BST> t@20@00) x@21@00)
        (ite
          (> x@21@00 (get_BST_value<Int> t@20@00))
          (bst_insert%precondition $Snap.unit (get_BST_right<BST> t@20@00) x@21@00)
          true))))
  :pattern ((bst_insert s@$ t@20@00 x@21@00))
  :qid |quant-u-61|)))
; ---------- FUNCTION is_valid_bst----------
(declare-fun t@23@00 () BST)
(declare-fun min@24@00 () Int)
(declare-fun max@25@00 () Int)
(declare-fun result@26@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@23@00 BST) (min@24@00 Int) (max@25@00 Int)) (!
  (=
    (is_valid_bst%limited s@$ t@23@00 min@24@00 max@25@00)
    (is_valid_bst s@$ t@23@00 min@24@00 max@25@00))
  :pattern ((is_valid_bst s@$ t@23@00 min@24@00 max@25@00))
  :qid |quant-u-18|)))
(assert (forall ((s@$ $Snap) (t@23@00 BST) (min@24@00 Int) (max@25@00 Int)) (!
  (is_valid_bst%stateless t@23@00 min@24@00 max@25@00)
  :pattern ((is_valid_bst%limited s@$ t@23@00 min@24@00 max@25@00))
  :qid |quant-u-19|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (BST_tag(t) == 0 ? true : (get_BST_value(t) <= min || get_BST_value(t) >= max ? false : is_valid_bst(get_BST_left(t), min, get_BST_value(t)) && is_valid_bst(get_BST_right(t), get_BST_value(t), max)))
; [eval] BST_tag(t) == 0
; [eval] BST_tag(t)
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (BST_tag<Int> t@23@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (BST_tag<Int> t@23@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 14 | BST_tag[Int](t@23@00) == 0 | live]
; [else-branch: 14 | BST_tag[Int](t@23@00) != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 14 | BST_tag[Int](t@23@00) == 0]
(assert (= (BST_tag<Int> t@23@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 14 | BST_tag[Int](t@23@00) != 0]
(assert (not (= (BST_tag<Int> t@23@00) 0)))
; [eval] (get_BST_value(t) <= min || get_BST_value(t) >= max ? false : is_valid_bst(get_BST_left(t), min, get_BST_value(t)) && is_valid_bst(get_BST_right(t), get_BST_value(t), max))
; [eval] get_BST_value(t) <= min || get_BST_value(t) >= max
; [eval] get_BST_value(t) <= min
; [eval] get_BST_value(t)
(push) ; 4
; [then-branch: 15 | get_BST_value[Int](t@23@00) <= min@24@00 | live]
; [else-branch: 15 | !(get_BST_value[Int](t@23@00) <= min@24@00) | live]
(push) ; 5
; [then-branch: 15 | get_BST_value[Int](t@23@00) <= min@24@00]
(assert (<= (get_BST_value<Int> t@23@00) min@24@00))
(pop) ; 5
(push) ; 5
; [else-branch: 15 | !(get_BST_value[Int](t@23@00) <= min@24@00)]
(assert (not (<= (get_BST_value<Int> t@23@00) min@24@00)))
; [eval] get_BST_value(t) >= max
; [eval] get_BST_value(t)
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or
  (not (<= (get_BST_value<Int> t@23@00) min@24@00))
  (<= (get_BST_value<Int> t@23@00) min@24@00)))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (or
    (<= (get_BST_value<Int> t@23@00) min@24@00)
    (>= (get_BST_value<Int> t@23@00) max@25@00)))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (or
  (<= (get_BST_value<Int> t@23@00) min@24@00)
  (>= (get_BST_value<Int> t@23@00) max@25@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 16 | get_BST_value[Int](t@23@00) <= min@24@00 || get_BST_value[Int](t@23@00) >= max@25@00 | live]
; [else-branch: 16 | !(get_BST_value[Int](t@23@00) <= min@24@00 || get_BST_value[Int](t@23@00) >= max@25@00) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 16 | get_BST_value[Int](t@23@00) <= min@24@00 || get_BST_value[Int](t@23@00) >= max@25@00]
(assert (or
  (<= (get_BST_value<Int> t@23@00) min@24@00)
  (>= (get_BST_value<Int> t@23@00) max@25@00)))
(pop) ; 5
(push) ; 5
; [else-branch: 16 | !(get_BST_value[Int](t@23@00) <= min@24@00 || get_BST_value[Int](t@23@00) >= max@25@00)]
(assert (not
  (or
    (<= (get_BST_value<Int> t@23@00) min@24@00)
    (>= (get_BST_value<Int> t@23@00) max@25@00))))
; [eval] is_valid_bst(get_BST_left(t), min, get_BST_value(t)) && is_valid_bst(get_BST_right(t), get_BST_value(t), max)
; [eval] is_valid_bst(get_BST_left(t), min, get_BST_value(t))
; [eval] get_BST_left(t)
; [eval] get_BST_value(t)
(push) ; 6
(assert (is_valid_bst%precondition $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00)))
(pop) ; 6
; Joined path conditions
(assert (is_valid_bst%precondition $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00)))
(push) ; 6
; [then-branch: 17 | !(is_valid_bst(_, get_BST_left[BST](t@23@00), min@24@00, get_BST_value[Int](t@23@00))) | live]
; [else-branch: 17 | is_valid_bst(_, get_BST_left[BST](t@23@00), min@24@00, get_BST_value[Int](t@23@00)) | live]
(push) ; 7
; [then-branch: 17 | !(is_valid_bst(_, get_BST_left[BST](t@23@00), min@24@00, get_BST_value[Int](t@23@00)))]
(assert (not
  (is_valid_bst $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))))
(pop) ; 7
(push) ; 7
; [else-branch: 17 | is_valid_bst(_, get_BST_left[BST](t@23@00), min@24@00, get_BST_value[Int](t@23@00))]
(assert (is_valid_bst $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00)))
; [eval] is_valid_bst(get_BST_right(t), get_BST_value(t), max)
; [eval] get_BST_right(t)
; [eval] get_BST_value(t)
(push) ; 8
(assert (is_valid_bst%precondition $Snap.unit (get_BST_right<BST> t@23@00) (get_BST_value<Int> t@23@00) max@25@00))
(pop) ; 8
; Joined path conditions
(assert (is_valid_bst%precondition $Snap.unit (get_BST_right<BST> t@23@00) (get_BST_value<Int> t@23@00) max@25@00))
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=>
  (is_valid_bst $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
  (and
    (is_valid_bst $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
    (is_valid_bst%precondition $Snap.unit (get_BST_right<BST> t@23@00) (get_BST_value<Int> t@23@00) max@25@00))))
(assert (or
  (is_valid_bst $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
  (not
    (is_valid_bst $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00)))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not
    (or
      (<= (get_BST_value<Int> t@23@00) min@24@00)
      (>= (get_BST_value<Int> t@23@00) max@25@00)))
  (and
    (not
      (or
        (<= (get_BST_value<Int> t@23@00) min@24@00)
        (>= (get_BST_value<Int> t@23@00) max@25@00)))
    (is_valid_bst%precondition $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
    (=>
      (is_valid_bst $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
      (and
        (is_valid_bst $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
        (is_valid_bst%precondition $Snap.unit (get_BST_right<BST> t@23@00) (get_BST_value<Int> t@23@00) max@25@00)))
    (or
      (is_valid_bst $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
      (not
        (is_valid_bst $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00)))))))
(assert (or
  (not
    (or
      (<= (get_BST_value<Int> t@23@00) min@24@00)
      (>= (get_BST_value<Int> t@23@00) max@25@00)))
  (or
    (<= (get_BST_value<Int> t@23@00) min@24@00)
    (>= (get_BST_value<Int> t@23@00) max@25@00))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (BST_tag<Int> t@23@00) 0))
  (and
    (not (= (BST_tag<Int> t@23@00) 0))
    (or
      (not (<= (get_BST_value<Int> t@23@00) min@24@00))
      (<= (get_BST_value<Int> t@23@00) min@24@00))
    (=>
      (not
        (or
          (<= (get_BST_value<Int> t@23@00) min@24@00)
          (>= (get_BST_value<Int> t@23@00) max@25@00)))
      (and
        (not
          (or
            (<= (get_BST_value<Int> t@23@00) min@24@00)
            (>= (get_BST_value<Int> t@23@00) max@25@00)))
        (is_valid_bst%precondition $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
        (=>
          (is_valid_bst $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
          (and
            (is_valid_bst $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
            (is_valid_bst%precondition $Snap.unit (get_BST_right<BST> t@23@00) (get_BST_value<Int> t@23@00) max@25@00)))
        (or
          (is_valid_bst $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
          (not
            (is_valid_bst $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))))))
    (or
      (not
        (or
          (<= (get_BST_value<Int> t@23@00) min@24@00)
          (>= (get_BST_value<Int> t@23@00) max@25@00)))
      (or
        (<= (get_BST_value<Int> t@23@00) min@24@00)
        (>= (get_BST_value<Int> t@23@00) max@25@00))))))
(assert (or (not (= (BST_tag<Int> t@23@00) 0)) (= (BST_tag<Int> t@23@00) 0)))
(assert (=
  result@26@00
  (ite
    (= (BST_tag<Int> t@23@00) 0)
    true
    (ite
      (or
        (<= (get_BST_value<Int> t@23@00) min@24@00)
        (>= (get_BST_value<Int> t@23@00) max@25@00))
      false
      (and
        (is_valid_bst $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
        (is_valid_bst $Snap.unit (get_BST_right<BST> t@23@00) (get_BST_value<Int> t@23@00) max@25@00))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@23@00 BST) (min@24@00 Int) (max@25@00 Int)) (!
  (=>
    (is_valid_bst%precondition s@$ t@23@00 min@24@00 max@25@00)
    (=
      (is_valid_bst s@$ t@23@00 min@24@00 max@25@00)
      (ite
        (= (BST_tag<Int> t@23@00) 0)
        true
        (ite
          (or
            (<= (get_BST_value<Int> t@23@00) min@24@00)
            (>= (get_BST_value<Int> t@23@00) max@25@00))
          false
          (and
            (is_valid_bst%limited $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
            (is_valid_bst%limited $Snap.unit (get_BST_right<BST> t@23@00) (get_BST_value<Int> t@23@00) max@25@00))))))
  :pattern ((is_valid_bst s@$ t@23@00 min@24@00 max@25@00))
  :qid |quant-u-62|)))
(assert (forall ((s@$ $Snap) (t@23@00 BST) (min@24@00 Int) (max@25@00 Int)) (!
  (=>
    (is_valid_bst%precondition s@$ t@23@00 min@24@00 max@25@00)
    (ite
      (= (BST_tag<Int> t@23@00) 0)
      true
      (ite
        (or
          (<= (get_BST_value<Int> t@23@00) min@24@00)
          (>= (get_BST_value<Int> t@23@00) max@25@00))
        true
        (and
          (is_valid_bst%precondition $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
          (=>
            (is_valid_bst%limited $Snap.unit (get_BST_left<BST> t@23@00) min@24@00 (get_BST_value<Int> t@23@00))
            (is_valid_bst%precondition $Snap.unit (get_BST_right<BST> t@23@00) (get_BST_value<Int> t@23@00) max@25@00))))))
  :pattern ((is_valid_bst s@$ t@23@00 min@24@00 max@25@00))
  :qid |quant-u-63|)))
; ---------- FUNCTION bst_search----------
(declare-fun t@27@00 () BST)
(declare-fun x@28@00 () Int)
(declare-fun result@29@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@27@00 BST) (x@28@00 Int)) (!
  (= (bst_search%limited s@$ t@27@00 x@28@00) (bst_search s@$ t@27@00 x@28@00))
  :pattern ((bst_search s@$ t@27@00 x@28@00))
  :qid |quant-u-20|)))
(assert (forall ((s@$ $Snap) (t@27@00 BST) (x@28@00 Int)) (!
  (bst_search%stateless t@27@00 x@28@00)
  :pattern ((bst_search%limited s@$ t@27@00 x@28@00))
  :qid |quant-u-21|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (BST_tag(t) == 0 ? false : (get_BST_value(t) == x ? true : (x < get_BST_value(t) ? bst_search(get_BST_left(t), x) : bst_search(get_BST_right(t), x))))
; [eval] BST_tag(t) == 0
; [eval] BST_tag(t)
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (BST_tag<Int> t@27@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (BST_tag<Int> t@27@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 18 | BST_tag[Int](t@27@00) == 0 | live]
; [else-branch: 18 | BST_tag[Int](t@27@00) != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 18 | BST_tag[Int](t@27@00) == 0]
(assert (= (BST_tag<Int> t@27@00) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 18 | BST_tag[Int](t@27@00) != 0]
(assert (not (= (BST_tag<Int> t@27@00) 0)))
; [eval] (get_BST_value(t) == x ? true : (x < get_BST_value(t) ? bst_search(get_BST_left(t), x) : bst_search(get_BST_right(t), x)))
; [eval] get_BST_value(t) == x
; [eval] get_BST_value(t)
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (= (get_BST_value<Int> t@27@00) x@28@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= (get_BST_value<Int> t@27@00) x@28@00)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 19 | get_BST_value[Int](t@27@00) == x@28@00 | live]
; [else-branch: 19 | get_BST_value[Int](t@27@00) != x@28@00 | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 19 | get_BST_value[Int](t@27@00) == x@28@00]
(assert (= (get_BST_value<Int> t@27@00) x@28@00))
(pop) ; 5
(push) ; 5
; [else-branch: 19 | get_BST_value[Int](t@27@00) != x@28@00]
(assert (not (= (get_BST_value<Int> t@27@00) x@28@00)))
; [eval] (x < get_BST_value(t) ? bst_search(get_BST_left(t), x) : bst_search(get_BST_right(t), x))
; [eval] x < get_BST_value(t)
; [eval] get_BST_value(t)
(push) ; 6
(push) ; 7
(set-option :rlimit 16000)
(assert (not (not (< x@28@00 (get_BST_value<Int> t@27@00)))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 7
(set-option :rlimit 16000)
(assert (not (< x@28@00 (get_BST_value<Int> t@27@00))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [then-branch: 20 | x@28@00 < get_BST_value[Int](t@27@00) | live]
; [else-branch: 20 | !(x@28@00 < get_BST_value[Int](t@27@00)) | live]
(set-option :rlimit 0)
(push) ; 7
; [then-branch: 20 | x@28@00 < get_BST_value[Int](t@27@00)]
(assert (< x@28@00 (get_BST_value<Int> t@27@00)))
; [eval] bst_search(get_BST_left(t), x)
; [eval] get_BST_left(t)
(push) ; 8
(assert (bst_search%precondition $Snap.unit (get_BST_left<BST> t@27@00) x@28@00))
(pop) ; 8
; Joined path conditions
(assert (bst_search%precondition $Snap.unit (get_BST_left<BST> t@27@00) x@28@00))
(pop) ; 7
(push) ; 7
; [else-branch: 20 | !(x@28@00 < get_BST_value[Int](t@27@00))]
(assert (not (< x@28@00 (get_BST_value<Int> t@27@00))))
; [eval] bst_search(get_BST_right(t), x)
; [eval] get_BST_right(t)
(push) ; 8
(assert (bst_search%precondition $Snap.unit (get_BST_right<BST> t@27@00) x@28@00))
(pop) ; 8
; Joined path conditions
(assert (bst_search%precondition $Snap.unit (get_BST_right<BST> t@27@00) x@28@00))
(pop) ; 7
(pop) ; 6
; Joined path conditions
(assert (=>
  (< x@28@00 (get_BST_value<Int> t@27@00))
  (and
    (< x@28@00 (get_BST_value<Int> t@27@00))
    (bst_search%precondition $Snap.unit (get_BST_left<BST> t@27@00) x@28@00))))
; Joined path conditions
(assert (=>
  (not (< x@28@00 (get_BST_value<Int> t@27@00)))
  (and
    (not (< x@28@00 (get_BST_value<Int> t@27@00)))
    (bst_search%precondition $Snap.unit (get_BST_right<BST> t@27@00) x@28@00))))
(assert (or
  (not (< x@28@00 (get_BST_value<Int> t@27@00)))
  (< x@28@00 (get_BST_value<Int> t@27@00))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (get_BST_value<Int> t@27@00) x@28@00))
  (and
    (not (= (get_BST_value<Int> t@27@00) x@28@00))
    (=>
      (< x@28@00 (get_BST_value<Int> t@27@00))
      (and
        (< x@28@00 (get_BST_value<Int> t@27@00))
        (bst_search%precondition $Snap.unit (get_BST_left<BST> t@27@00) x@28@00)))
    (=>
      (not (< x@28@00 (get_BST_value<Int> t@27@00)))
      (and
        (not (< x@28@00 (get_BST_value<Int> t@27@00)))
        (bst_search%precondition $Snap.unit (get_BST_right<BST> t@27@00) x@28@00)))
    (or
      (not (< x@28@00 (get_BST_value<Int> t@27@00)))
      (< x@28@00 (get_BST_value<Int> t@27@00))))))
(assert (or
  (not (= (get_BST_value<Int> t@27@00) x@28@00))
  (= (get_BST_value<Int> t@27@00) x@28@00)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (BST_tag<Int> t@27@00) 0))
  (and
    (not (= (BST_tag<Int> t@27@00) 0))
    (=>
      (not (= (get_BST_value<Int> t@27@00) x@28@00))
      (and
        (not (= (get_BST_value<Int> t@27@00) x@28@00))
        (=>
          (< x@28@00 (get_BST_value<Int> t@27@00))
          (and
            (< x@28@00 (get_BST_value<Int> t@27@00))
            (bst_search%precondition $Snap.unit (get_BST_left<BST> t@27@00) x@28@00)))
        (=>
          (not (< x@28@00 (get_BST_value<Int> t@27@00)))
          (and
            (not (< x@28@00 (get_BST_value<Int> t@27@00)))
            (bst_search%precondition $Snap.unit (get_BST_right<BST> t@27@00) x@28@00)))
        (or
          (not (< x@28@00 (get_BST_value<Int> t@27@00)))
          (< x@28@00 (get_BST_value<Int> t@27@00)))))
    (or
      (not (= (get_BST_value<Int> t@27@00) x@28@00))
      (= (get_BST_value<Int> t@27@00) x@28@00)))))
(assert (or (not (= (BST_tag<Int> t@27@00) 0)) (= (BST_tag<Int> t@27@00) 0)))
(assert (=
  result@29@00
  (ite
    (= (BST_tag<Int> t@27@00) 0)
    false
    (ite
      (= (get_BST_value<Int> t@27@00) x@28@00)
      true
      (ite
        (< x@28@00 (get_BST_value<Int> t@27@00))
        (bst_search $Snap.unit (get_BST_left<BST> t@27@00) x@28@00)
        (bst_search $Snap.unit (get_BST_right<BST> t@27@00) x@28@00))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@27@00 BST) (x@28@00 Int)) (!
  (=>
    (bst_search%precondition s@$ t@27@00 x@28@00)
    (=
      (bst_search s@$ t@27@00 x@28@00)
      (ite
        (= (BST_tag<Int> t@27@00) 0)
        false
        (ite
          (= (get_BST_value<Int> t@27@00) x@28@00)
          true
          (ite
            (< x@28@00 (get_BST_value<Int> t@27@00))
            (bst_search%limited $Snap.unit (get_BST_left<BST> t@27@00) x@28@00)
            (bst_search%limited $Snap.unit (get_BST_right<BST> t@27@00) x@28@00))))))
  :pattern ((bst_search s@$ t@27@00 x@28@00))
  :qid |quant-u-64|)))
(assert (forall ((s@$ $Snap) (t@27@00 BST) (x@28@00 Int)) (!
  (=>
    (bst_search%precondition s@$ t@27@00 x@28@00)
    (ite
      (= (BST_tag<Int> t@27@00) 0)
      true
      (ite
        (= (get_BST_value<Int> t@27@00) x@28@00)
        true
        (ite
          (< x@28@00 (get_BST_value<Int> t@27@00))
          (bst_search%precondition $Snap.unit (get_BST_left<BST> t@27@00) x@28@00)
          (bst_search%precondition $Snap.unit (get_BST_right<BST> t@27@00) x@28@00)))))
  :pattern ((bst_search s@$ t@27@00 x@28@00))
  :qid |quant-u-65|)))
; ---------- FUNCTION bst_min----------
(declare-fun t@30@00 () BST)
(declare-fun result@31@00 () Option<Int>)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@30@00 BST)) (!
  (= (bst_min%limited s@$ t@30@00) (bst_min s@$ t@30@00))
  :pattern ((bst_min s@$ t@30@00))
  :qid |quant-u-22|)))
(assert (forall ((s@$ $Snap) (t@30@00 BST)) (!
  (bst_min%stateless t@30@00)
  :pattern ((bst_min%limited s@$ t@30@00))
  :qid |quant-u-23|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (BST_tag(t) == 0 ? (None(): Option[Int]) : (BST_tag(get_BST_left(t)) == 0 ? (Some(get_BST_value(t)): Option[Int]) : bst_min(get_BST_left(t))))
; [eval] BST_tag(t) == 0
; [eval] BST_tag(t)
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (= (BST_tag<Int> t@30@00) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (= (BST_tag<Int> t@30@00) 0)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 21 | BST_tag[Int](t@30@00) == 0 | live]
; [else-branch: 21 | BST_tag[Int](t@30@00) != 0 | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 21 | BST_tag[Int](t@30@00) == 0]
(assert (= (BST_tag<Int> t@30@00) 0))
; [eval] (None(): Option[Int])
(pop) ; 3
(push) ; 3
; [else-branch: 21 | BST_tag[Int](t@30@00) != 0]
(assert (not (= (BST_tag<Int> t@30@00) 0)))
; [eval] (BST_tag(get_BST_left(t)) == 0 ? (Some(get_BST_value(t)): Option[Int]) : bst_min(get_BST_left(t)))
; [eval] BST_tag(get_BST_left(t)) == 0
; [eval] BST_tag(get_BST_left(t))
; [eval] get_BST_left(t)
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (= (BST_tag<Int> (get_BST_left<BST> t@30@00)) 0))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= (BST_tag<Int> (get_BST_left<BST> t@30@00)) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 22 | BST_tag[Int](get_BST_left[BST](t@30@00)) == 0 | live]
; [else-branch: 22 | BST_tag[Int](get_BST_left[BST](t@30@00)) != 0 | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 22 | BST_tag[Int](get_BST_left[BST](t@30@00)) == 0]
(assert (= (BST_tag<Int> (get_BST_left<BST> t@30@00)) 0))
; [eval] (Some(get_BST_value(t)): Option[Int])
; [eval] get_BST_value(t)
(pop) ; 5
(push) ; 5
; [else-branch: 22 | BST_tag[Int](get_BST_left[BST](t@30@00)) != 0]
(assert (not (= (BST_tag<Int> (get_BST_left<BST> t@30@00)) 0)))
; [eval] bst_min(get_BST_left(t))
; [eval] get_BST_left(t)
(push) ; 6
(assert (bst_min%precondition $Snap.unit (get_BST_left<BST> t@30@00)))
(pop) ; 6
; Joined path conditions
(assert (bst_min%precondition $Snap.unit (get_BST_left<BST> t@30@00)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (BST_tag<Int> (get_BST_left<BST> t@30@00)) 0))
  (and
    (not (= (BST_tag<Int> (get_BST_left<BST> t@30@00)) 0))
    (bst_min%precondition $Snap.unit (get_BST_left<BST> t@30@00)))))
(assert (or
  (not (= (BST_tag<Int> (get_BST_left<BST> t@30@00)) 0))
  (= (BST_tag<Int> (get_BST_left<BST> t@30@00)) 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (= (BST_tag<Int> t@30@00) 0))
  (and
    (not (= (BST_tag<Int> t@30@00) 0))
    (=>
      (not (= (BST_tag<Int> (get_BST_left<BST> t@30@00)) 0))
      (and
        (not (= (BST_tag<Int> (get_BST_left<BST> t@30@00)) 0))
        (bst_min%precondition $Snap.unit (get_BST_left<BST> t@30@00))))
    (or
      (not (= (BST_tag<Int> (get_BST_left<BST> t@30@00)) 0))
      (= (BST_tag<Int> (get_BST_left<BST> t@30@00)) 0)))))
(assert (or (not (= (BST_tag<Int> t@30@00) 0)) (= (BST_tag<Int> t@30@00) 0)))
(assert (=
  result@31@00
  (ite
    (= (BST_tag<Int> t@30@00) 0)
    (as None<Option<Int>>  Option<Int>)
    (ite
      (= (BST_tag<Int> (get_BST_left<BST> t@30@00)) 0)
      (Some<Option<Int>> (get_BST_value<Int> t@30@00))
      (bst_min $Snap.unit (get_BST_left<BST> t@30@00))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@30@00 BST)) (!
  (=>
    (bst_min%precondition s@$ t@30@00)
    (=
      (bst_min s@$ t@30@00)
      (ite
        (= (BST_tag<Int> t@30@00) 0)
        (as None<Option<Int>>  Option<Int>)
        (ite
          (= (BST_tag<Int> (get_BST_left<BST> t@30@00)) 0)
          (Some<Option<Int>> (get_BST_value<Int> t@30@00))
          (bst_min%limited $Snap.unit (get_BST_left<BST> t@30@00))))))
  :pattern ((bst_min s@$ t@30@00))
  :qid |quant-u-66|)))
(assert (forall ((s@$ $Snap) (t@30@00 BST)) (!
  (=>
    (bst_min%precondition s@$ t@30@00)
    (ite
      (= (BST_tag<Int> t@30@00) 0)
      true
      (ite
        (= (BST_tag<Int> (get_BST_left<BST> t@30@00)) 0)
        true
        (bst_min%precondition $Snap.unit (get_BST_left<BST> t@30@00)))))
  :pattern ((bst_min s@$ t@30@00))
  :qid |quant-u-67|)))
; ---------- FUNCTION is_same_set----------
(declare-fun parent@32@00 () Seq<Int>)
(declare-fun x@33@00 () Int)
(declare-fun y@34@00 () Int)
(declare-fun depth@35@00 () Int)
(declare-fun result@36@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] depth >= 0
(assert (>= depth@35@00 0))
(assert (=
  ($Snap.second s@$)
  ($Snap.combine
    ($Snap.first ($Snap.second s@$))
    ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.first ($Snap.second s@$)) $Snap.unit))
; [eval] x >= 0
(assert (>= x@33@00 0))
(assert (=
  ($Snap.second ($Snap.second s@$))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second s@$)))
    ($Snap.second ($Snap.second ($Snap.second s@$))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))
; [eval] x < |parent|
; [eval] |parent|
(assert (< x@33@00 (Seq_length parent@32@00)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second s@$)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second s@$)))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$)))) $Snap.unit))
; [eval] y >= 0
(assert (>= y@34@00 0))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second s@$)))) $Snap.unit))
; [eval] y < |parent|
; [eval] |parent|
(assert (< y@34@00 (Seq_length parent@32@00)))
(pop) ; 1
(assert (forall ((s@$ $Snap) (parent@32@00 Seq<Int>) (x@33@00 Int) (y@34@00 Int) (depth@35@00 Int)) (!
  (=
    (is_same_set%limited s@$ parent@32@00 x@33@00 y@34@00 depth@35@00)
    (is_same_set s@$ parent@32@00 x@33@00 y@34@00 depth@35@00))
  :pattern ((is_same_set s@$ parent@32@00 x@33@00 y@34@00 depth@35@00))
  :qid |quant-u-24|)))
(assert (forall ((s@$ $Snap) (parent@32@00 Seq<Int>) (x@33@00 Int) (y@34@00 Int) (depth@35@00 Int)) (!
  (is_same_set%stateless parent@32@00 x@33@00 y@34@00 depth@35@00)
  :pattern ((is_same_set%limited s@$ parent@32@00 x@33@00 y@34@00 depth@35@00))
  :qid |quant-u-25|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (>= depth@35@00 0))
(assert (=
  ($Snap.second s@$)
  ($Snap.combine
    ($Snap.first ($Snap.second s@$))
    ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.first ($Snap.second s@$)) $Snap.unit))
(assert (>= x@33@00 0))
(assert (=
  ($Snap.second ($Snap.second s@$))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second s@$)))
    ($Snap.second ($Snap.second ($Snap.second s@$))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))
(assert (< x@33@00 (Seq_length parent@32@00)))
(assert (=
  ($Snap.second ($Snap.second ($Snap.second s@$)))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$))))
    ($Snap.second ($Snap.second ($Snap.second ($Snap.second s@$)))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second ($Snap.second s@$)))) $Snap.unit))
(assert (>= y@34@00 0))
(assert (= ($Snap.second ($Snap.second ($Snap.second ($Snap.second s@$)))) $Snap.unit))
(assert (< y@34@00 (Seq_length parent@32@00)))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] find_root(parent, x, depth) == find_root(parent, y, depth)
; [eval] find_root(parent, x, depth)
(set-option :rlimit 0)
(push) ; 2
; [eval] depth >= 0
; [eval] x >= 0
; [eval] x < |parent|
; [eval] |parent|
(assert (find_root%precondition ($Snap.combine
  $Snap.unit
  ($Snap.combine $Snap.unit $Snap.unit)) parent@32@00 x@33@00 depth@35@00))
(pop) ; 2
; Joined path conditions
(assert (find_root%precondition ($Snap.combine
  $Snap.unit
  ($Snap.combine $Snap.unit $Snap.unit)) parent@32@00 x@33@00 depth@35@00))
; [eval] find_root(parent, y, depth)
(push) ; 2
; [eval] depth >= 0
; [eval] x >= 0
; [eval] x < |parent|
; [eval] |parent|
(assert (find_root%precondition ($Snap.combine
  $Snap.unit
  ($Snap.combine $Snap.unit $Snap.unit)) parent@32@00 y@34@00 depth@35@00))
(pop) ; 2
; Joined path conditions
(assert (find_root%precondition ($Snap.combine
  $Snap.unit
  ($Snap.combine $Snap.unit $Snap.unit)) parent@32@00 y@34@00 depth@35@00))
(assert (=
  result@36@00
  (=
    (find_root ($Snap.combine $Snap.unit ($Snap.combine $Snap.unit $Snap.unit)) parent@32@00 x@33@00 depth@35@00)
    (find_root ($Snap.combine $Snap.unit ($Snap.combine $Snap.unit $Snap.unit)) parent@32@00 y@34@00 depth@35@00))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (parent@32@00 Seq<Int>) (x@33@00 Int) (y@34@00 Int) (depth@35@00 Int)) (!
  (=>
    (is_same_set%precondition s@$ parent@32@00 x@33@00 y@34@00 depth@35@00)
    (=
      (is_same_set s@$ parent@32@00 x@33@00 y@34@00 depth@35@00)
      (=
        (find_root ($Snap.combine
          $Snap.unit
          ($Snap.combine $Snap.unit $Snap.unit)) parent@32@00 x@33@00 depth@35@00)
        (find_root ($Snap.combine
          $Snap.unit
          ($Snap.combine $Snap.unit $Snap.unit)) parent@32@00 y@34@00 depth@35@00))))
  :pattern ((is_same_set s@$ parent@32@00 x@33@00 y@34@00 depth@35@00))
  :qid |quant-u-68|)))
(assert (forall ((s@$ $Snap) (parent@32@00 Seq<Int>) (x@33@00 Int) (y@34@00 Int) (depth@35@00 Int)) (!
  (=>
    (is_same_set%precondition s@$ parent@32@00 x@33@00 y@34@00 depth@35@00)
    (and
      (find_root%precondition ($Snap.combine
        $Snap.unit
        ($Snap.combine $Snap.unit $Snap.unit)) parent@32@00 x@33@00 depth@35@00)
      (find_root%precondition ($Snap.combine
        $Snap.unit
        ($Snap.combine $Snap.unit $Snap.unit)) parent@32@00 y@34@00 depth@35@00)))
  :pattern ((is_same_set s@$ parent@32@00 x@33@00 y@34@00 depth@35@00))
  :qid |quant-u-69|)))
; ---------- FUNCTION is_max_heap----------
(declare-fun arr@37@00 () Seq<Int>)
(declare-fun idx@38@00 () Int)
(declare-fun result@39@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] idx >= 0
(assert (>= idx@38@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (arr@37@00 Seq<Int>) (idx@38@00 Int)) (!
  (=
    (is_max_heap%limited s@$ arr@37@00 idx@38@00)
    (is_max_heap s@$ arr@37@00 idx@38@00))
  :pattern ((is_max_heap s@$ arr@37@00 idx@38@00))
  :qid |quant-u-26|)))
(assert (forall ((s@$ $Snap) (arr@37@00 Seq<Int>) (idx@38@00 Int)) (!
  (is_max_heap%stateless arr@37@00 idx@38@00)
  :pattern ((is_max_heap%limited s@$ arr@37@00 idx@38@00))
  :qid |quant-u-27|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (>= idx@38@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (idx >= |arr| ? true : (let left == (2 * idx + 1) in (let right == (2 * idx + 2) in (left >= |arr| || arr[idx] >= arr[left]) && ((right >= |arr| || arr[idx] >= arr[right]) && is_max_heap(arr, idx + 1)))))
; [eval] idx >= |arr|
; [eval] |arr|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= idx@38@00 (Seq_length arr@37@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= idx@38@00 (Seq_length arr@37@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 23 | idx@38@00 >= |arr@37@00| | live]
; [else-branch: 23 | !(idx@38@00 >= |arr@37@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 23 | idx@38@00 >= |arr@37@00|]
(assert (>= idx@38@00 (Seq_length arr@37@00)))
(pop) ; 3
(push) ; 3
; [else-branch: 23 | !(idx@38@00 >= |arr@37@00|)]
(assert (not (>= idx@38@00 (Seq_length arr@37@00))))
; [eval] (let left == (2 * idx + 1) in (let right == (2 * idx + 2) in (left >= |arr| || arr[idx] >= arr[left]) && ((right >= |arr| || arr[idx] >= arr[right]) && is_max_heap(arr, idx + 1))))
; [eval] 2 * idx + 1
; [eval] 2 * idx
(declare-fun letvar@65@00 ($Snap Seq<Int> Int) Int)
(assert (= (letvar@65@00 s@$ arr@37@00 idx@38@00) (+ (* 2 idx@38@00) 1)))
; [eval] (let right == (2 * idx + 2) in (left >= |arr| || arr[idx] >= arr[left]) && ((right >= |arr| || arr[idx] >= arr[right]) && is_max_heap(arr, idx + 1)))
; [eval] 2 * idx + 2
; [eval] 2 * idx
(declare-fun letvar@66@00 ($Snap Seq<Int> Int) Int)
(assert (= (letvar@66@00 s@$ arr@37@00 idx@38@00) (+ (* 2 idx@38@00) 2)))
; [eval] (left >= |arr| || arr[idx] >= arr[left]) && ((right >= |arr| || arr[idx] >= arr[right]) && is_max_heap(arr, idx + 1))
; [eval] left >= |arr| || arr[idx] >= arr[left]
; [eval] left >= |arr|
; [eval] |arr|
(push) ; 4
; [then-branch: 24 | 2 * idx@38@00 + 1 >= |arr@37@00| | live]
; [else-branch: 24 | !(2 * idx@38@00 + 1 >= |arr@37@00|) | live]
(push) ; 5
; [then-branch: 24 | 2 * idx@38@00 + 1 >= |arr@37@00|]
(assert (>= (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00)))
(pop) ; 5
(push) ; 5
; [else-branch: 24 | !(2 * idx@38@00 + 1 >= |arr@37@00|)]
(assert (not (>= (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00))))
; [eval] arr[idx] >= arr[left]
; [eval] arr[idx]
(push) ; 6
(assert (not (< idx@38@00 (Seq_length arr@37@00))))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [eval] arr[left]
(push) ; 6
(assert (not (>= (+ (* 2 idx@38@00) 1) 0)))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(push) ; 6
(assert (not (< (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00))))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or
  (not (>= (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00)))
  (>= (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00))))
(push) ; 4
; [then-branch: 25 | !(2 * idx@38@00 + 1 >= |arr@37@00| || arr@37@00[idx@38@00] >= arr@37@00[2 * idx@38@00 + 1]) | live]
; [else-branch: 25 | 2 * idx@38@00 + 1 >= |arr@37@00| || arr@37@00[idx@38@00] >= arr@37@00[2 * idx@38@00 + 1] | live]
(push) ; 5
; [then-branch: 25 | !(2 * idx@38@00 + 1 >= |arr@37@00| || arr@37@00[idx@38@00] >= arr@37@00[2 * idx@38@00 + 1])]
(assert (not
  (or
    (>= (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00))
    (>=
      (Seq_index arr@37@00 idx@38@00)
      (Seq_index arr@37@00 (+ (* 2 idx@38@00) 1))))))
(pop) ; 5
(push) ; 5
; [else-branch: 25 | 2 * idx@38@00 + 1 >= |arr@37@00| || arr@37@00[idx@38@00] >= arr@37@00[2 * idx@38@00 + 1]]
(assert (or
  (>= (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00))
  (>=
    (Seq_index arr@37@00 idx@38@00)
    (Seq_index arr@37@00 (+ (* 2 idx@38@00) 1)))))
; [eval] right >= |arr| || arr[idx] >= arr[right]
; [eval] right >= |arr|
; [eval] |arr|
(push) ; 6
; [then-branch: 26 | 2 * idx@38@00 + 2 >= |arr@37@00| | live]
; [else-branch: 26 | !(2 * idx@38@00 + 2 >= |arr@37@00|) | live]
(push) ; 7
; [then-branch: 26 | 2 * idx@38@00 + 2 >= |arr@37@00|]
(assert (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00)))
(pop) ; 7
(push) ; 7
; [else-branch: 26 | !(2 * idx@38@00 + 2 >= |arr@37@00|)]
(assert (not (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))))
; [eval] arr[idx] >= arr[right]
; [eval] arr[idx]
(push) ; 8
(assert (not (< idx@38@00 (Seq_length arr@37@00))))
(check-sat)
; unsat
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
; [eval] arr[right]
(push) ; 8
(assert (not (>= (+ (* 2 idx@38@00) 2) 0)))
(check-sat)
; unsat
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
(push) ; 8
(assert (not (< (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))))
(check-sat)
; unsat
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (or
  (not (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00)))
  (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))))
(push) ; 6
; [then-branch: 27 | !(2 * idx@38@00 + 2 >= |arr@37@00| || arr@37@00[idx@38@00] >= arr@37@00[2 * idx@38@00 + 2]) | live]
; [else-branch: 27 | 2 * idx@38@00 + 2 >= |arr@37@00| || arr@37@00[idx@38@00] >= arr@37@00[2 * idx@38@00 + 2] | live]
(push) ; 7
; [then-branch: 27 | !(2 * idx@38@00 + 2 >= |arr@37@00| || arr@37@00[idx@38@00] >= arr@37@00[2 * idx@38@00 + 2])]
(assert (not
  (or
    (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))
    (>=
      (Seq_index arr@37@00 idx@38@00)
      (Seq_index arr@37@00 (+ (* 2 idx@38@00) 2))))))
(pop) ; 7
(push) ; 7
; [else-branch: 27 | 2 * idx@38@00 + 2 >= |arr@37@00| || arr@37@00[idx@38@00] >= arr@37@00[2 * idx@38@00 + 2]]
(assert (or
  (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))
  (>=
    (Seq_index arr@37@00 idx@38@00)
    (Seq_index arr@37@00 (+ (* 2 idx@38@00) 2)))))
; [eval] is_max_heap(arr, idx + 1)
; [eval] idx + 1
(push) ; 8
; [eval] idx >= 0
(push) ; 9
(assert (not (>= (+ idx@38@00 1) 0)))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(assert (>= (+ idx@38@00 1) 0))
(assert (is_max_heap%precondition $Snap.unit arr@37@00 (+ idx@38@00 1)))
(pop) ; 8
; Joined path conditions
(assert (and
  (>= (+ idx@38@00 1) 0)
  (is_max_heap%precondition $Snap.unit arr@37@00 (+ idx@38@00 1))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=>
  (or
    (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))
    (>=
      (Seq_index arr@37@00 idx@38@00)
      (Seq_index arr@37@00 (+ (* 2 idx@38@00) 2))))
  (and
    (or
      (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))
      (>=
        (Seq_index arr@37@00 idx@38@00)
        (Seq_index arr@37@00 (+ (* 2 idx@38@00) 2))))
    (>= (+ idx@38@00 1) 0)
    (is_max_heap%precondition $Snap.unit arr@37@00 (+ idx@38@00 1)))))
(assert (or
  (or
    (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))
    (>=
      (Seq_index arr@37@00 idx@38@00)
      (Seq_index arr@37@00 (+ (* 2 idx@38@00) 2))))
  (not
    (or
      (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))
      (>=
        (Seq_index arr@37@00 idx@38@00)
        (Seq_index arr@37@00 (+ (* 2 idx@38@00) 2)))))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (or
    (>= (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00))
    (>=
      (Seq_index arr@37@00 idx@38@00)
      (Seq_index arr@37@00 (+ (* 2 idx@38@00) 1))))
  (and
    (or
      (>= (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00))
      (>=
        (Seq_index arr@37@00 idx@38@00)
        (Seq_index arr@37@00 (+ (* 2 idx@38@00) 1))))
    (or
      (not (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00)))
      (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00)))
    (=>
      (or
        (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))
        (>=
          (Seq_index arr@37@00 idx@38@00)
          (Seq_index arr@37@00 (+ (* 2 idx@38@00) 2))))
      (and
        (or
          (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))
          (>=
            (Seq_index arr@37@00 idx@38@00)
            (Seq_index arr@37@00 (+ (* 2 idx@38@00) 2))))
        (>= (+ idx@38@00 1) 0)
        (is_max_heap%precondition $Snap.unit arr@37@00 (+ idx@38@00 1))))
    (or
      (or
        (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))
        (>=
          (Seq_index arr@37@00 idx@38@00)
          (Seq_index arr@37@00 (+ (* 2 idx@38@00) 2))))
      (not
        (or
          (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))
          (>=
            (Seq_index arr@37@00 idx@38@00)
            (Seq_index arr@37@00 (+ (* 2 idx@38@00) 2)))))))))
(assert (or
  (or
    (>= (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00))
    (>=
      (Seq_index arr@37@00 idx@38@00)
      (Seq_index arr@37@00 (+ (* 2 idx@38@00) 1))))
  (not
    (or
      (>= (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00))
      (>=
        (Seq_index arr@37@00 idx@38@00)
        (Seq_index arr@37@00 (+ (* 2 idx@38@00) 1)))))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (>= idx@38@00 (Seq_length arr@37@00)))
  (and
    (not (>= idx@38@00 (Seq_length arr@37@00)))
    (= (letvar@65@00 s@$ arr@37@00 idx@38@00) (+ (* 2 idx@38@00) 1))
    (= (letvar@66@00 s@$ arr@37@00 idx@38@00) (+ (* 2 idx@38@00) 2))
    (or
      (not (>= (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00)))
      (>= (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00)))
    (=>
      (or
        (>= (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00))
        (>=
          (Seq_index arr@37@00 idx@38@00)
          (Seq_index arr@37@00 (+ (* 2 idx@38@00) 1))))
      (and
        (or
          (>= (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00))
          (>=
            (Seq_index arr@37@00 idx@38@00)
            (Seq_index arr@37@00 (+ (* 2 idx@38@00) 1))))
        (or
          (not (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00)))
          (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00)))
        (=>
          (or
            (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))
            (>=
              (Seq_index arr@37@00 idx@38@00)
              (Seq_index arr@37@00 (+ (* 2 idx@38@00) 2))))
          (and
            (or
              (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))
              (>=
                (Seq_index arr@37@00 idx@38@00)
                (Seq_index arr@37@00 (+ (* 2 idx@38@00) 2))))
            (>= (+ idx@38@00 1) 0)
            (is_max_heap%precondition $Snap.unit arr@37@00 (+ idx@38@00 1))))
        (or
          (or
            (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))
            (>=
              (Seq_index arr@37@00 idx@38@00)
              (Seq_index arr@37@00 (+ (* 2 idx@38@00) 2))))
          (not
            (or
              (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))
              (>=
                (Seq_index arr@37@00 idx@38@00)
                (Seq_index arr@37@00 (+ (* 2 idx@38@00) 2))))))))
    (or
      (or
        (>= (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00))
        (>=
          (Seq_index arr@37@00 idx@38@00)
          (Seq_index arr@37@00 (+ (* 2 idx@38@00) 1))))
      (not
        (or
          (>= (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00))
          (>=
            (Seq_index arr@37@00 idx@38@00)
            (Seq_index arr@37@00 (+ (* 2 idx@38@00) 1)))))))))
(assert (or
  (not (>= idx@38@00 (Seq_length arr@37@00)))
  (>= idx@38@00 (Seq_length arr@37@00))))
(assert (=
  result@39@00
  (ite
    (>= idx@38@00 (Seq_length arr@37@00))
    true
    (and
      (or
        (>= (+ (* 2 idx@38@00) 1) (Seq_length arr@37@00))
        (>=
          (Seq_index arr@37@00 idx@38@00)
          (Seq_index arr@37@00 (+ (* 2 idx@38@00) 1))))
      (and
        (or
          (>= (+ (* 2 idx@38@00) 2) (Seq_length arr@37@00))
          (>=
            (Seq_index arr@37@00 idx@38@00)
            (Seq_index arr@37@00 (+ (* 2 idx@38@00) 2))))
        (is_max_heap $Snap.unit arr@37@00 (+ idx@38@00 1)))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (arr@37@00 Seq<Int>) (idx@38@00 Int)) (!
  (=>
    (is_max_heap%precondition s@$ arr@37@00 idx@38@00)
    (=
      (is_max_heap s@$ arr@37@00 idx@38@00)
      (ite
        (>= idx@38@00 (Seq_length arr@37@00))
        true
        (let ((left (+ (* 2 idx@38@00) 1))) (let ((right (+ (* 2 idx@38@00) 2))) (and
          (or
            (>= left (Seq_length arr@37@00))
            (>= (Seq_index arr@37@00 idx@38@00) (Seq_index arr@37@00 left)))
          (and
            (or
              (>= right (Seq_length arr@37@00))
              (>= (Seq_index arr@37@00 idx@38@00) (Seq_index arr@37@00 right)))
            (is_max_heap%limited $Snap.unit arr@37@00 (+ idx@38@00 1)))))))))
  :pattern ((is_max_heap s@$ arr@37@00 idx@38@00))
  :qid |quant-u-70|)))
(assert (forall ((s@$ $Snap) (arr@37@00 Seq<Int>) (idx@38@00 Int)) (!
  (=>
    (is_max_heap%precondition s@$ arr@37@00 idx@38@00)
    (ite
      (>= idx@38@00 (Seq_length arr@37@00))
      true
      (let ((left (+ (* 2 idx@38@00) 1))) (let ((right (+ (* 2 idx@38@00) 2))) (=>
        (and
          (or
            (>= left (Seq_length arr@37@00))
            (>= (Seq_index arr@37@00 idx@38@00) (Seq_index arr@37@00 left)))
          (or
            (>= right (Seq_length arr@37@00))
            (>= (Seq_index arr@37@00 idx@38@00) (Seq_index arr@37@00 right))))
        (is_max_heap%precondition $Snap.unit arr@37@00 (+ idx@38@00 1)))))))
  :pattern ((is_max_heap s@$ arr@37@00 idx@38@00))
  :qid |quant-u-71|)))
; ---------- FUNCTION skip_list_level----------
(declare-fun n@40@00 () Int)
(declare-fun max_level@41@00 () Int)
(declare-fun result@42@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] n >= 0
(assert (>= n@40@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
; [eval] max_level >= 0
(assert (>= max_level@41@00 0))
(declare-const $t@67@00 $Snap)
(assert (= $t@67@00 ($Snap.combine ($Snap.first $t@67@00) ($Snap.second $t@67@00))))
(assert (= ($Snap.first $t@67@00) $Snap.unit))
; [eval] result >= 0
(assert (>= result@42@00 0))
(assert (= ($Snap.second $t@67@00) $Snap.unit))
; [eval] result <= max_level
(assert (<= result@42@00 max_level@41@00))
(pop) ; 1
(assert (forall ((s@$ $Snap) (n@40@00 Int) (max_level@41@00 Int)) (!
  (=
    (skip_list_level%limited s@$ n@40@00 max_level@41@00)
    (skip_list_level s@$ n@40@00 max_level@41@00))
  :pattern ((skip_list_level s@$ n@40@00 max_level@41@00))
  :qid |quant-u-28|)))
(assert (forall ((s@$ $Snap) (n@40@00 Int) (max_level@41@00 Int)) (!
  (skip_list_level%stateless n@40@00 max_level@41@00)
  :pattern ((skip_list_level%limited s@$ n@40@00 max_level@41@00))
  :qid |quant-u-29|)))
(assert (forall ((s@$ $Snap) (n@40@00 Int) (max_level@41@00 Int)) (!
  (let ((result@42@00 (skip_list_level%limited s@$ n@40@00 max_level@41@00))) (=>
    (skip_list_level%precondition s@$ n@40@00 max_level@41@00)
    (and (>= result@42@00 0) (<= result@42@00 max_level@41@00))))
  :pattern ((skip_list_level%limited s@$ n@40@00 max_level@41@00))
  :qid |quant-u-72|)))
(assert (forall ((s@$ $Snap) (n@40@00 Int) (max_level@41@00 Int)) (!
  (let ((result@42@00 (skip_list_level%limited s@$ n@40@00 max_level@41@00))) true)
  :pattern ((skip_list_level%limited s@$ n@40@00 max_level@41@00))
  :qid |quant-u-73|)))
(assert (forall ((s@$ $Snap) (n@40@00 Int) (max_level@41@00 Int)) (!
  (let ((result@42@00 (skip_list_level%limited s@$ n@40@00 max_level@41@00))) true)
  :pattern ((skip_list_level%limited s@$ n@40@00 max_level@41@00))
  :qid |quant-u-74|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (>= n@40@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
(assert (>= max_level@41@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (n >= max_level ? max_level : (n % 2 == 0 ? 1 + skip_list_level(n \ 2, max_level) : 1))
; [eval] n >= max_level
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= n@40@00 max_level@41@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= n@40@00 max_level@41@00)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 28 | n@40@00 >= max_level@41@00 | live]
; [else-branch: 28 | !(n@40@00 >= max_level@41@00) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 28 | n@40@00 >= max_level@41@00]
(assert (>= n@40@00 max_level@41@00))
(pop) ; 3
(push) ; 3
; [else-branch: 28 | !(n@40@00 >= max_level@41@00)]
(assert (not (>= n@40@00 max_level@41@00)))
; [eval] (n % 2 == 0 ? 1 + skip_list_level(n \ 2, max_level) : 1)
; [eval] n % 2 == 0
; [eval] n % 2
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not (= (mod n@40@00 2) 0))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (= (mod n@40@00 2) 0)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 29 | n@40@00 % 2 == 0 | live]
; [else-branch: 29 | n@40@00 % 2 != 0 | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 29 | n@40@00 % 2 == 0]
(assert (= (mod n@40@00 2) 0))
; [eval] 1 + skip_list_level(n \ 2, max_level)
; [eval] skip_list_level(n \ 2, max_level)
; [eval] n \ 2
(push) ; 6
; [eval] n >= 0
(push) ; 7
(assert (not (>= (div n@40@00 2) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (>= (div n@40@00 2) 0))
; [eval] max_level >= 0
(assert (skip_list_level%precondition ($Snap.combine $Snap.unit $Snap.unit) (div
  n@40@00
  2) max_level@41@00))
(pop) ; 6
; Joined path conditions
(assert (and
  (>= (div n@40@00 2) 0)
  (skip_list_level%precondition ($Snap.combine $Snap.unit $Snap.unit) (div
    n@40@00
    2) max_level@41@00)))
(pop) ; 5
(push) ; 5
; [else-branch: 29 | n@40@00 % 2 != 0]
(assert (not (= (mod n@40@00 2) 0)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
(assert (=>
  (= (mod n@40@00 2) 0)
  (and
    (= (mod n@40@00 2) 0)
    (>= (div n@40@00 2) 0)
    (skip_list_level%precondition ($Snap.combine $Snap.unit $Snap.unit) (div
      n@40@00
      2) max_level@41@00))))
; Joined path conditions
(assert (or (not (= (mod n@40@00 2) 0)) (= (mod n@40@00 2) 0)))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (>= n@40@00 max_level@41@00))
  (and
    (not (>= n@40@00 max_level@41@00))
    (=>
      (= (mod n@40@00 2) 0)
      (and
        (= (mod n@40@00 2) 0)
        (>= (div n@40@00 2) 0)
        (skip_list_level%precondition ($Snap.combine $Snap.unit $Snap.unit) (div
          n@40@00
          2) max_level@41@00)))
    (or (not (= (mod n@40@00 2) 0)) (= (mod n@40@00 2) 0)))))
(assert (or (not (>= n@40@00 max_level@41@00)) (>= n@40@00 max_level@41@00)))
(assert (=
  result@42@00
  (ite
    (>= n@40@00 max_level@41@00)
    max_level@41@00
    (ite
      (= (mod n@40@00 2) 0)
      (+
        1
        (skip_list_level ($Snap.combine $Snap.unit $Snap.unit) (div n@40@00 2) max_level@41@00))
      1))))
; [eval] result >= 0
(push) ; 2
(assert (not (>= result@42@00 0)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@42@00 0))
; [eval] result <= max_level
(push) ; 2
(assert (not (<= result@42@00 max_level@41@00)))
(check-sat)
; unknown
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] result <= max_level
(set-option :rlimit 0)
(push) ; 2
(assert (not (<= result@42@00 max_level@41@00)))
(check-sat)
; unknown
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] result <= max_level
(set-option :rlimit 0)
(push) ; 2
(assert (not (<= result@42@00 max_level@41@00)))
(check-sat)
; unknown
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] result <= max_level
(set-option :rlimit 0)
(push) ; 2
(assert (not (<= result@42@00 max_level@41@00)))
(check-sat)
; unknown
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(pop) ; 1
; ---------- FUNCTION is_min_heap----------
(declare-fun arr@43@00 () Seq<Int>)
(declare-fun idx@44@00 () Int)
(declare-fun result@45@00 () Bool)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ $Snap.unit))
; [eval] idx >= 0
(assert (>= idx@44@00 0))
(pop) ; 1
(assert (forall ((s@$ $Snap) (arr@43@00 Seq<Int>) (idx@44@00 Int)) (!
  (=
    (is_min_heap%limited s@$ arr@43@00 idx@44@00)
    (is_min_heap s@$ arr@43@00 idx@44@00))
  :pattern ((is_min_heap s@$ arr@43@00 idx@44@00))
  :qid |quant-u-30|)))
(assert (forall ((s@$ $Snap) (arr@43@00 Seq<Int>) (idx@44@00 Int)) (!
  (is_min_heap%stateless arr@43@00 idx@44@00)
  :pattern ((is_min_heap%limited s@$ arr@43@00 idx@44@00))
  :qid |quant-u-31|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ $Snap.unit))
(assert (>= idx@44@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (idx >= |arr| ? true : (let left == (2 * idx + 1) in (let right == (2 * idx + 2) in (left >= |arr| || arr[idx] <= arr[left]) && ((right >= |arr| || arr[idx] <= arr[right]) && is_min_heap(arr, idx + 1)))))
; [eval] idx >= |arr|
; [eval] |arr|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= idx@44@00 (Seq_length arr@43@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= idx@44@00 (Seq_length arr@43@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 30 | idx@44@00 >= |arr@43@00| | live]
; [else-branch: 30 | !(idx@44@00 >= |arr@43@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 30 | idx@44@00 >= |arr@43@00|]
(assert (>= idx@44@00 (Seq_length arr@43@00)))
(pop) ; 3
(push) ; 3
; [else-branch: 30 | !(idx@44@00 >= |arr@43@00|)]
(assert (not (>= idx@44@00 (Seq_length arr@43@00))))
; [eval] (let left == (2 * idx + 1) in (let right == (2 * idx + 2) in (left >= |arr| || arr[idx] <= arr[left]) && ((right >= |arr| || arr[idx] <= arr[right]) && is_min_heap(arr, idx + 1))))
; [eval] 2 * idx + 1
; [eval] 2 * idx
(declare-fun letvar@68@00 ($Snap Seq<Int> Int) Int)
(assert (= (letvar@68@00 s@$ arr@43@00 idx@44@00) (+ (* 2 idx@44@00) 1)))
; [eval] (let right == (2 * idx + 2) in (left >= |arr| || arr[idx] <= arr[left]) && ((right >= |arr| || arr[idx] <= arr[right]) && is_min_heap(arr, idx + 1)))
; [eval] 2 * idx + 2
; [eval] 2 * idx
(declare-fun letvar@69@00 ($Snap Seq<Int> Int) Int)
(assert (= (letvar@69@00 s@$ arr@43@00 idx@44@00) (+ (* 2 idx@44@00) 2)))
; [eval] (left >= |arr| || arr[idx] <= arr[left]) && ((right >= |arr| || arr[idx] <= arr[right]) && is_min_heap(arr, idx + 1))
; [eval] left >= |arr| || arr[idx] <= arr[left]
; [eval] left >= |arr|
; [eval] |arr|
(push) ; 4
; [then-branch: 31 | 2 * idx@44@00 + 1 >= |arr@43@00| | live]
; [else-branch: 31 | !(2 * idx@44@00 + 1 >= |arr@43@00|) | live]
(push) ; 5
; [then-branch: 31 | 2 * idx@44@00 + 1 >= |arr@43@00|]
(assert (>= (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00)))
(pop) ; 5
(push) ; 5
; [else-branch: 31 | !(2 * idx@44@00 + 1 >= |arr@43@00|)]
(assert (not (>= (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00))))
; [eval] arr[idx] <= arr[left]
; [eval] arr[idx]
(push) ; 6
(assert (not (< idx@44@00 (Seq_length arr@43@00))))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
; [eval] arr[left]
(push) ; 6
(assert (not (>= (+ (* 2 idx@44@00) 1) 0)))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(push) ; 6
(assert (not (< (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00))))
(check-sat)
; unsat
(pop) ; 6
; 0.00s
; (get-info :all-statistics)
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or
  (not (>= (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00)))
  (>= (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00))))
(push) ; 4
; [then-branch: 32 | !(2 * idx@44@00 + 1 >= |arr@43@00| || arr@43@00[idx@44@00] <= arr@43@00[2 * idx@44@00 + 1]) | live]
; [else-branch: 32 | 2 * idx@44@00 + 1 >= |arr@43@00| || arr@43@00[idx@44@00] <= arr@43@00[2 * idx@44@00 + 1] | live]
(push) ; 5
; [then-branch: 32 | !(2 * idx@44@00 + 1 >= |arr@43@00| || arr@43@00[idx@44@00] <= arr@43@00[2 * idx@44@00 + 1])]
(assert (not
  (or
    (>= (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00))
    (<=
      (Seq_index arr@43@00 idx@44@00)
      (Seq_index arr@43@00 (+ (* 2 idx@44@00) 1))))))
(pop) ; 5
(push) ; 5
; [else-branch: 32 | 2 * idx@44@00 + 1 >= |arr@43@00| || arr@43@00[idx@44@00] <= arr@43@00[2 * idx@44@00 + 1]]
(assert (or
  (>= (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00))
  (<=
    (Seq_index arr@43@00 idx@44@00)
    (Seq_index arr@43@00 (+ (* 2 idx@44@00) 1)))))
; [eval] right >= |arr| || arr[idx] <= arr[right]
; [eval] right >= |arr|
; [eval] |arr|
(push) ; 6
; [then-branch: 33 | 2 * idx@44@00 + 2 >= |arr@43@00| | live]
; [else-branch: 33 | !(2 * idx@44@00 + 2 >= |arr@43@00|) | live]
(push) ; 7
; [then-branch: 33 | 2 * idx@44@00 + 2 >= |arr@43@00|]
(assert (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00)))
(pop) ; 7
(push) ; 7
; [else-branch: 33 | !(2 * idx@44@00 + 2 >= |arr@43@00|)]
(assert (not (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))))
; [eval] arr[idx] <= arr[right]
; [eval] arr[idx]
(push) ; 8
(assert (not (< idx@44@00 (Seq_length arr@43@00))))
(check-sat)
; unsat
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
; [eval] arr[right]
(push) ; 8
(assert (not (>= (+ (* 2 idx@44@00) 2) 0)))
(check-sat)
; unsat
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
(push) ; 8
(assert (not (< (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))))
(check-sat)
; unsat
(pop) ; 8
; 0.00s
; (get-info :all-statistics)
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (or
  (not (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00)))
  (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))))
(push) ; 6
; [then-branch: 34 | !(2 * idx@44@00 + 2 >= |arr@43@00| || arr@43@00[idx@44@00] <= arr@43@00[2 * idx@44@00 + 2]) | live]
; [else-branch: 34 | 2 * idx@44@00 + 2 >= |arr@43@00| || arr@43@00[idx@44@00] <= arr@43@00[2 * idx@44@00 + 2] | live]
(push) ; 7
; [then-branch: 34 | !(2 * idx@44@00 + 2 >= |arr@43@00| || arr@43@00[idx@44@00] <= arr@43@00[2 * idx@44@00 + 2])]
(assert (not
  (or
    (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))
    (<=
      (Seq_index arr@43@00 idx@44@00)
      (Seq_index arr@43@00 (+ (* 2 idx@44@00) 2))))))
(pop) ; 7
(push) ; 7
; [else-branch: 34 | 2 * idx@44@00 + 2 >= |arr@43@00| || arr@43@00[idx@44@00] <= arr@43@00[2 * idx@44@00 + 2]]
(assert (or
  (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))
  (<=
    (Seq_index arr@43@00 idx@44@00)
    (Seq_index arr@43@00 (+ (* 2 idx@44@00) 2)))))
; [eval] is_min_heap(arr, idx + 1)
; [eval] idx + 1
(push) ; 8
; [eval] idx >= 0
(push) ; 9
(assert (not (>= (+ idx@44@00 1) 0)))
(check-sat)
; unsat
(pop) ; 9
; 0.00s
; (get-info :all-statistics)
(assert (>= (+ idx@44@00 1) 0))
(assert (is_min_heap%precondition $Snap.unit arr@43@00 (+ idx@44@00 1)))
(pop) ; 8
; Joined path conditions
(assert (and
  (>= (+ idx@44@00 1) 0)
  (is_min_heap%precondition $Snap.unit arr@43@00 (+ idx@44@00 1))))
(pop) ; 7
(pop) ; 6
; Joined path conditions
; Joined path conditions
(assert (=>
  (or
    (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))
    (<=
      (Seq_index arr@43@00 idx@44@00)
      (Seq_index arr@43@00 (+ (* 2 idx@44@00) 2))))
  (and
    (or
      (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))
      (<=
        (Seq_index arr@43@00 idx@44@00)
        (Seq_index arr@43@00 (+ (* 2 idx@44@00) 2))))
    (>= (+ idx@44@00 1) 0)
    (is_min_heap%precondition $Snap.unit arr@43@00 (+ idx@44@00 1)))))
(assert (or
  (or
    (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))
    (<=
      (Seq_index arr@43@00 idx@44@00)
      (Seq_index arr@43@00 (+ (* 2 idx@44@00) 2))))
  (not
    (or
      (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))
      (<=
        (Seq_index arr@43@00 idx@44@00)
        (Seq_index arr@43@00 (+ (* 2 idx@44@00) 2)))))))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (=>
  (or
    (>= (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00))
    (<=
      (Seq_index arr@43@00 idx@44@00)
      (Seq_index arr@43@00 (+ (* 2 idx@44@00) 1))))
  (and
    (or
      (>= (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00))
      (<=
        (Seq_index arr@43@00 idx@44@00)
        (Seq_index arr@43@00 (+ (* 2 idx@44@00) 1))))
    (or
      (not (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00)))
      (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00)))
    (=>
      (or
        (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))
        (<=
          (Seq_index arr@43@00 idx@44@00)
          (Seq_index arr@43@00 (+ (* 2 idx@44@00) 2))))
      (and
        (or
          (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))
          (<=
            (Seq_index arr@43@00 idx@44@00)
            (Seq_index arr@43@00 (+ (* 2 idx@44@00) 2))))
        (>= (+ idx@44@00 1) 0)
        (is_min_heap%precondition $Snap.unit arr@43@00 (+ idx@44@00 1))))
    (or
      (or
        (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))
        (<=
          (Seq_index arr@43@00 idx@44@00)
          (Seq_index arr@43@00 (+ (* 2 idx@44@00) 2))))
      (not
        (or
          (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))
          (<=
            (Seq_index arr@43@00 idx@44@00)
            (Seq_index arr@43@00 (+ (* 2 idx@44@00) 2)))))))))
(assert (or
  (or
    (>= (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00))
    (<=
      (Seq_index arr@43@00 idx@44@00)
      (Seq_index arr@43@00 (+ (* 2 idx@44@00) 1))))
  (not
    (or
      (>= (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00))
      (<=
        (Seq_index arr@43@00 idx@44@00)
        (Seq_index arr@43@00 (+ (* 2 idx@44@00) 1)))))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (>= idx@44@00 (Seq_length arr@43@00)))
  (and
    (not (>= idx@44@00 (Seq_length arr@43@00)))
    (= (letvar@68@00 s@$ arr@43@00 idx@44@00) (+ (* 2 idx@44@00) 1))
    (= (letvar@69@00 s@$ arr@43@00 idx@44@00) (+ (* 2 idx@44@00) 2))
    (or
      (not (>= (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00)))
      (>= (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00)))
    (=>
      (or
        (>= (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00))
        (<=
          (Seq_index arr@43@00 idx@44@00)
          (Seq_index arr@43@00 (+ (* 2 idx@44@00) 1))))
      (and
        (or
          (>= (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00))
          (<=
            (Seq_index arr@43@00 idx@44@00)
            (Seq_index arr@43@00 (+ (* 2 idx@44@00) 1))))
        (or
          (not (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00)))
          (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00)))
        (=>
          (or
            (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))
            (<=
              (Seq_index arr@43@00 idx@44@00)
              (Seq_index arr@43@00 (+ (* 2 idx@44@00) 2))))
          (and
            (or
              (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))
              (<=
                (Seq_index arr@43@00 idx@44@00)
                (Seq_index arr@43@00 (+ (* 2 idx@44@00) 2))))
            (>= (+ idx@44@00 1) 0)
            (is_min_heap%precondition $Snap.unit arr@43@00 (+ idx@44@00 1))))
        (or
          (or
            (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))
            (<=
              (Seq_index arr@43@00 idx@44@00)
              (Seq_index arr@43@00 (+ (* 2 idx@44@00) 2))))
          (not
            (or
              (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))
              (<=
                (Seq_index arr@43@00 idx@44@00)
                (Seq_index arr@43@00 (+ (* 2 idx@44@00) 2))))))))
    (or
      (or
        (>= (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00))
        (<=
          (Seq_index arr@43@00 idx@44@00)
          (Seq_index arr@43@00 (+ (* 2 idx@44@00) 1))))
      (not
        (or
          (>= (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00))
          (<=
            (Seq_index arr@43@00 idx@44@00)
            (Seq_index arr@43@00 (+ (* 2 idx@44@00) 1)))))))))
(assert (or
  (not (>= idx@44@00 (Seq_length arr@43@00)))
  (>= idx@44@00 (Seq_length arr@43@00))))
(assert (=
  result@45@00
  (ite
    (>= idx@44@00 (Seq_length arr@43@00))
    true
    (and
      (or
        (>= (+ (* 2 idx@44@00) 1) (Seq_length arr@43@00))
        (<=
          (Seq_index arr@43@00 idx@44@00)
          (Seq_index arr@43@00 (+ (* 2 idx@44@00) 1))))
      (and
        (or
          (>= (+ (* 2 idx@44@00) 2) (Seq_length arr@43@00))
          (<=
            (Seq_index arr@43@00 idx@44@00)
            (Seq_index arr@43@00 (+ (* 2 idx@44@00) 2))))
        (is_min_heap $Snap.unit arr@43@00 (+ idx@44@00 1)))))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (arr@43@00 Seq<Int>) (idx@44@00 Int)) (!
  (=>
    (is_min_heap%precondition s@$ arr@43@00 idx@44@00)
    (=
      (is_min_heap s@$ arr@43@00 idx@44@00)
      (ite
        (>= idx@44@00 (Seq_length arr@43@00))
        true
        (let ((left (+ (* 2 idx@44@00) 1))) (let ((right (+ (* 2 idx@44@00) 2))) (and
          (or
            (>= left (Seq_length arr@43@00))
            (<= (Seq_index arr@43@00 idx@44@00) (Seq_index arr@43@00 left)))
          (and
            (or
              (>= right (Seq_length arr@43@00))
              (<= (Seq_index arr@43@00 idx@44@00) (Seq_index arr@43@00 right)))
            (is_min_heap%limited $Snap.unit arr@43@00 (+ idx@44@00 1)))))))))
  :pattern ((is_min_heap s@$ arr@43@00 idx@44@00))
  :qid |quant-u-75|)))
(assert (forall ((s@$ $Snap) (arr@43@00 Seq<Int>) (idx@44@00 Int)) (!
  (=>
    (is_min_heap%precondition s@$ arr@43@00 idx@44@00)
    (ite
      (>= idx@44@00 (Seq_length arr@43@00))
      true
      (let ((left (+ (* 2 idx@44@00) 1))) (let ((right (+ (* 2 idx@44@00) 2))) (=>
        (and
          (or
            (>= left (Seq_length arr@43@00))
            (<= (Seq_index arr@43@00 idx@44@00) (Seq_index arr@43@00 left)))
          (or
            (>= right (Seq_length arr@43@00))
            (<= (Seq_index arr@43@00 idx@44@00) (Seq_index arr@43@00 right))))
        (is_min_heap%precondition $Snap.unit arr@43@00 (+ idx@44@00 1)))))))
  :pattern ((is_min_heap s@$ arr@43@00 idx@44@00))
  :qid |quant-u-76|)))
; ---------- FUNCTION zipper_forward----------
(declare-fun z@46@00 () ListZipper<Int>)
(declare-fun result@47@00 () ListZipper<Int>)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (z@46@00 ListZipper<Int>)) (!
  (= (zipper_forward%limited s@$ z@46@00) (zipper_forward s@$ z@46@00))
  :pattern ((zipper_forward s@$ z@46@00))
  :qid |quant-u-32|)))
(assert (forall ((s@$ $Snap) (z@46@00 ListZipper<Int>)) (!
  (zipper_forward%stateless z@46@00)
  :pattern ((zipper_forward%limited s@$ z@46@00))
  :qid |quant-u-33|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] ((Option_tag((get_ListZipper_focus(z): Option[Int])): Int) == 0 || |(get_ListZipper_after(z): Seq[Int])| == 0 ? z : (Zipper((get_ListZipper_before(z): Seq[Int]) ++ Seq((get_Option_value((get_ListZipper_focus(z): Option[Int])): Int)), (Some((get_ListZipper_after(z): Seq[Int])[0]): Option[Int]), (get_ListZipper_after(z): Seq[Int])[1..]): ListZipper[Int]))
; [eval] (Option_tag((get_ListZipper_focus(z): Option[Int])): Int) == 0 || |(get_ListZipper_after(z): Seq[Int])| == 0
; [eval] (Option_tag((get_ListZipper_focus(z): Option[Int])): Int) == 0
; [eval] (Option_tag((get_ListZipper_focus(z): Option[Int])): Int)
; [eval] (get_ListZipper_focus(z): Option[Int])
(set-option :rlimit 0)
(push) ; 2
; [then-branch: 35 | Option_tag[Int](get_ListZipper_focus[Option[Int]](z@46@00)) == 0 | live]
; [else-branch: 35 | Option_tag[Int](get_ListZipper_focus[Option[Int]](z@46@00)) != 0 | live]
(push) ; 3
; [then-branch: 35 | Option_tag[Int](get_ListZipper_focus[Option[Int]](z@46@00)) == 0]
(assert (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@46@00)) 0))
(pop) ; 3
(push) ; 3
; [else-branch: 35 | Option_tag[Int](get_ListZipper_focus[Option[Int]](z@46@00)) != 0]
(assert (not (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@46@00)) 0)))
; [eval] |(get_ListZipper_after(z): Seq[Int])| == 0
; [eval] |(get_ListZipper_after(z): Seq[Int])|
; [eval] (get_ListZipper_after(z): Seq[Int])
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or
  (not (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@46@00)) 0))
  (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@46@00)) 0)))
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not
  (or
    (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@46@00)) 0)
    (= (Seq_length (get_ListZipper_after<Seq<Int>> z@46@00)) 0)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (or
  (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@46@00)) 0)
  (= (Seq_length (get_ListZipper_after<Seq<Int>> z@46@00)) 0))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 36 | Option_tag[Int](get_ListZipper_focus[Option[Int]](z@46@00)) == 0 || |get_ListZipper_after[Seq[Int]](z@46@00)| == 0 | live]
; [else-branch: 36 | !(Option_tag[Int](get_ListZipper_focus[Option[Int]](z@46@00)) == 0 || |get_ListZipper_after[Seq[Int]](z@46@00)| == 0) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 36 | Option_tag[Int](get_ListZipper_focus[Option[Int]](z@46@00)) == 0 || |get_ListZipper_after[Seq[Int]](z@46@00)| == 0]
(assert (or
  (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@46@00)) 0)
  (= (Seq_length (get_ListZipper_after<Seq<Int>> z@46@00)) 0)))
(pop) ; 3
(push) ; 3
; [else-branch: 36 | !(Option_tag[Int](get_ListZipper_focus[Option[Int]](z@46@00)) == 0 || |get_ListZipper_after[Seq[Int]](z@46@00)| == 0)]
(assert (not
  (or
    (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@46@00)) 0)
    (= (Seq_length (get_ListZipper_after<Seq<Int>> z@46@00)) 0))))
; [eval] (Zipper((get_ListZipper_before(z): Seq[Int]) ++ Seq((get_Option_value((get_ListZipper_focus(z): Option[Int])): Int)), (Some((get_ListZipper_after(z): Seq[Int])[0]): Option[Int]), (get_ListZipper_after(z): Seq[Int])[1..]): ListZipper[Int])
; [eval] (get_ListZipper_before(z): Seq[Int]) ++ Seq((get_Option_value((get_ListZipper_focus(z): Option[Int])): Int))
; [eval] (get_ListZipper_before(z): Seq[Int])
; [eval] Seq((get_Option_value((get_ListZipper_focus(z): Option[Int])): Int))
; [eval] (get_Option_value((get_ListZipper_focus(z): Option[Int])): Int)
; [eval] (get_ListZipper_focus(z): Option[Int])
(assert (=
  (Seq_length
    (Seq_singleton (get_Option_value<Int> (get_ListZipper_focus<Option<Int>> z@46@00))))
  1))
; [eval] (Some((get_ListZipper_after(z): Seq[Int])[0]): Option[Int])
; [eval] (get_ListZipper_after(z): Seq[Int])[0]
; [eval] (get_ListZipper_after(z): Seq[Int])
(push) ; 4
(assert (not (< 0 (Seq_length (get_ListZipper_after<Seq<Int>> z@46@00)))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
; [eval] (get_ListZipper_after(z): Seq[Int])[1..]
; [eval] (get_ListZipper_after(z): Seq[Int])
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not
    (or
      (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@46@00)) 0)
      (= (Seq_length (get_ListZipper_after<Seq<Int>> z@46@00)) 0)))
  (and
    (not
      (or
        (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@46@00)) 0)
        (= (Seq_length (get_ListZipper_after<Seq<Int>> z@46@00)) 0)))
    (=
      (Seq_length
        (Seq_singleton (get_Option_value<Int> (get_ListZipper_focus<Option<Int>> z@46@00))))
      1))))
(assert (or
  (not
    (or
      (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@46@00)) 0)
      (= (Seq_length (get_ListZipper_after<Seq<Int>> z@46@00)) 0)))
  (or
    (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@46@00)) 0)
    (= (Seq_length (get_ListZipper_after<Seq<Int>> z@46@00)) 0))))
(assert (=
  result@47@00
  (ite
    (or
      (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@46@00)) 0)
      (= (Seq_length (get_ListZipper_after<Seq<Int>> z@46@00)) 0))
    z@46@00
    (Zipper<ListZipper<Int>> (Seq_append
      (get_ListZipper_before<Seq<Int>> z@46@00)
      (Seq_singleton (get_Option_value<Int> (get_ListZipper_focus<Option<Int>> z@46@00)))) (Some<Option<Int>> (Seq_index
      (get_ListZipper_after<Seq<Int>> z@46@00)
      0)) (Seq_drop (get_ListZipper_after<Seq<Int>> z@46@00) 1)))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (z@46@00 ListZipper<Int>)) (!
  (=>
    (zipper_forward%precondition s@$ z@46@00)
    (=
      (zipper_forward s@$ z@46@00)
      (ite
        (or
          (= (Option_tag<Int> (get_ListZipper_focus<Option<Int>> z@46@00)) 0)
          (= (Seq_length (get_ListZipper_after<Seq<Int>> z@46@00)) 0))
        z@46@00
        (Zipper<ListZipper<Int>> (Seq_append
          (get_ListZipper_before<Seq<Int>> z@46@00)
          (Seq_singleton (get_Option_value<Int> (get_ListZipper_focus<Option<Int>> z@46@00)))) (Some<Option<Int>> (Seq_index
          (get_ListZipper_after<Seq<Int>> z@46@00)
          0)) (Seq_drop (get_ListZipper_after<Seq<Int>> z@46@00) 1)))))
  :pattern ((zipper_forward s@$ z@46@00))
  :qid |quant-u-77|)))
(assert (forall ((s@$ $Snap) (z@46@00 ListZipper<Int>)) (!
  true
  :pattern ((zipper_forward s@$ z@46@00))
  :qid |quant-u-78|)))
; ---------- FUNCTION rose_height----------
(declare-fun t@48@00 () RoseTree)
(declare-fun result@49@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@48@00 RoseTree)) (!
  (= (rose_height%limited s@$ t@48@00) (rose_height s@$ t@48@00))
  :pattern ((rose_height s@$ t@48@00))
  :qid |quant-u-34|)))
(assert (forall ((s@$ $Snap) (t@48@00 RoseTree)) (!
  (rose_height%stateless t@48@00)
  :pattern ((rose_height%limited s@$ t@48@00))
  :qid |quant-u-35|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] 1 + rose_children_max_height(get_RoseTree_children(t), 0, 0)
; [eval] rose_children_max_height(get_RoseTree_children(t), 0, 0)
; [eval] get_RoseTree_children(t)
(set-option :rlimit 0)
(push) ; 2
; [eval] idx >= 0
; [eval] max_h >= 0
(assert (rose_children_max_height%precondition ($Snap.combine $Snap.unit $Snap.unit) (get_RoseTree_children<Seq<RoseTree>> t@48@00) 0 0))
(pop) ; 2
; Joined path conditions
(assert (rose_children_max_height%precondition ($Snap.combine $Snap.unit $Snap.unit) (get_RoseTree_children<Seq<RoseTree>> t@48@00) 0 0))
(assert (=
  result@49@00
  (+
    1
    (rose_children_max_height ($Snap.combine $Snap.unit $Snap.unit) (get_RoseTree_children<Seq<RoseTree>> t@48@00) 0 0))))
(pop) ; 1
(assert (forall ((s@$ $Snap) (t@48@00 RoseTree)) (!
  (=>
    (rose_height%precondition s@$ t@48@00)
    (=
      (rose_height s@$ t@48@00)
      (+
        1
        (rose_children_max_height%limited ($Snap.combine $Snap.unit $Snap.unit) (get_RoseTree_children<Seq<RoseTree>> t@48@00) 0 0))))
  :pattern ((rose_height s@$ t@48@00))
  :qid |quant-u-79|)))
(assert (forall ((s@$ $Snap) (t@48@00 RoseTree)) (!
  (=>
    (rose_height%precondition s@$ t@48@00)
    (rose_children_max_height%precondition ($Snap.combine $Snap.unit $Snap.unit) (get_RoseTree_children<Seq<RoseTree>> t@48@00) 0 0))
  :pattern ((rose_height s@$ t@48@00))
  :qid |quant-u-80|)))
; ---------- FUNCTION rose_children_max_height----------
(declare-fun children@50@00 () Seq<RoseTree>)
(declare-fun idx@51@00 () Int)
(declare-fun max_h@52@00 () Int)
(declare-fun result@53@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] idx >= 0
(assert (>= idx@51@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
; [eval] max_h >= 0
(assert (>= max_h@52@00 0))
(declare-const $t@70@00 $Snap)
(assert (= $t@70@00 $Snap.unit))
; [eval] result >= max_h
(assert (>= result@53@00 max_h@52@00))
(pop) ; 1
(assert (forall ((s@$ $Snap) (children@50@00 Seq<RoseTree>) (idx@51@00 Int) (max_h@52@00 Int)) (!
  (=
    (rose_children_max_height%limited s@$ children@50@00 idx@51@00 max_h@52@00)
    (rose_children_max_height s@$ children@50@00 idx@51@00 max_h@52@00))
  :pattern ((rose_children_max_height s@$ children@50@00 idx@51@00 max_h@52@00))
  :qid |quant-u-36|)))
(assert (forall ((s@$ $Snap) (children@50@00 Seq<RoseTree>) (idx@51@00 Int) (max_h@52@00 Int)) (!
  (rose_children_max_height%stateless children@50@00 idx@51@00 max_h@52@00)
  :pattern ((rose_children_max_height%limited s@$ children@50@00 idx@51@00 max_h@52@00))
  :qid |quant-u-37|)))
(assert (forall ((s@$ $Snap) (children@50@00 Seq<RoseTree>) (idx@51@00 Int) (max_h@52@00 Int)) (!
  (let ((result@53@00 (rose_children_max_height%limited s@$ children@50@00 idx@51@00 max_h@52@00))) (=>
    (rose_children_max_height%precondition s@$ children@50@00 idx@51@00 max_h@52@00)
    (>= result@53@00 max_h@52@00)))
  :pattern ((rose_children_max_height%limited s@$ children@50@00 idx@51@00 max_h@52@00))
  :qid |quant-u-81|)))
(assert (forall ((s@$ $Snap) (children@50@00 Seq<RoseTree>) (idx@51@00 Int) (max_h@52@00 Int)) (!
  (let ((result@53@00 (rose_children_max_height%limited s@$ children@50@00 idx@51@00 max_h@52@00))) true)
  :pattern ((rose_children_max_height%limited s@$ children@50@00 idx@51@00 max_h@52@00))
  :qid |quant-u-82|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (>= idx@51@00 0))
(assert (= ($Snap.second s@$) $Snap.unit))
(assert (>= max_h@52@00 0))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (idx >= |children| ? max_h : (let h == (rose_height(children[idx])) in rose_children_max_height(children, idx + 1, (h > max_h ? h : max_h))))
; [eval] idx >= |children|
; [eval] |children|
(set-option :rlimit 0)
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not (>= idx@51@00 (Seq_length children@50@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (>= idx@51@00 (Seq_length children@50@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 37 | idx@51@00 >= |children@50@00| | live]
; [else-branch: 37 | !(idx@51@00 >= |children@50@00|) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 37 | idx@51@00 >= |children@50@00|]
(assert (>= idx@51@00 (Seq_length children@50@00)))
(pop) ; 3
(push) ; 3
; [else-branch: 37 | !(idx@51@00 >= |children@50@00|)]
(assert (not (>= idx@51@00 (Seq_length children@50@00))))
; [eval] (let h == (rose_height(children[idx])) in rose_children_max_height(children, idx + 1, (h > max_h ? h : max_h)))
; [eval] rose_height(children[idx])
; [eval] children[idx]
(push) ; 4
(assert (not (< idx@51@00 (Seq_length children@50@00))))
(check-sat)
; unsat
(pop) ; 4
; 0.00s
; (get-info :all-statistics)
(push) ; 4
(assert (rose_height%precondition $Snap.unit (Seq_index children@50@00 idx@51@00)))
(pop) ; 4
; Joined path conditions
(assert (rose_height%precondition $Snap.unit (Seq_index children@50@00 idx@51@00)))
(declare-fun letvar@71@00 ($Snap Seq<RoseTree> Int Int) Int)
(assert (=
  (letvar@71@00 s@$ children@50@00 idx@51@00 max_h@52@00)
  (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00))))
; [eval] rose_children_max_height(children, idx + 1, (h > max_h ? h : max_h))
; [eval] idx + 1
; [eval] (h > max_h ? h : max_h)
; [eval] h > max_h
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (> (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00)) max_h@52@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (> (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00)) max_h@52@00)))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 38 | rose_height(_, children@50@00[idx@51@00]) > max_h@52@00 | live]
; [else-branch: 38 | !(rose_height(_, children@50@00[idx@51@00]) > max_h@52@00) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 38 | rose_height(_, children@50@00[idx@51@00]) > max_h@52@00]
(assert (> (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00)) max_h@52@00))
(pop) ; 5
(push) ; 5
; [else-branch: 38 | !(rose_height(_, children@50@00[idx@51@00]) > max_h@52@00)]
(assert (not
  (> (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00)) max_h@52@00)))
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or
  (not
    (> (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00)) max_h@52@00))
  (> (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00)) max_h@52@00)))
(push) ; 4
; [eval] idx >= 0
(push) ; 5
(assert (not (>= (+ idx@51@00 1) 0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (>= (+ idx@51@00 1) 0))
; [eval] max_h >= 0
(push) ; 5
(assert (not (>=
  (ite
    (> (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00)) max_h@52@00)
    (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00))
    max_h@52@00)
  0)))
(check-sat)
; unsat
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(assert (>=
  (ite
    (> (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00)) max_h@52@00)
    (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00))
    max_h@52@00)
  0))
(assert (rose_children_max_height%precondition ($Snap.combine $Snap.unit $Snap.unit) children@50@00 (+
  idx@51@00
  1) (ite
  (> (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00)) max_h@52@00)
  (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00))
  max_h@52@00)))
(pop) ; 4
; Joined path conditions
(assert (and
  (>= (+ idx@51@00 1) 0)
  (>=
    (ite
      (>
        (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00))
        max_h@52@00)
      (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00))
      max_h@52@00)
    0)
  (rose_children_max_height%precondition ($Snap.combine $Snap.unit $Snap.unit) children@50@00 (+
    idx@51@00
    1) (ite
    (> (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00)) max_h@52@00)
    (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00))
    max_h@52@00))))
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (=>
  (not (>= idx@51@00 (Seq_length children@50@00)))
  (and
    (not (>= idx@51@00 (Seq_length children@50@00)))
    (rose_height%precondition $Snap.unit (Seq_index children@50@00 idx@51@00))
    (=
      (letvar@71@00 s@$ children@50@00 idx@51@00 max_h@52@00)
      (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00)))
    (or
      (not
        (>
          (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00))
          max_h@52@00))
      (>
        (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00))
        max_h@52@00))
    (>= (+ idx@51@00 1) 0)
    (>=
      (ite
        (>
          (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00))
          max_h@52@00)
        (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00))
        max_h@52@00)
      0)
    (rose_children_max_height%precondition ($Snap.combine $Snap.unit $Snap.unit) children@50@00 (+
      idx@51@00
      1) (ite
      (>
        (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00))
        max_h@52@00)
      (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00))
      max_h@52@00)))))
(assert (or
  (not (>= idx@51@00 (Seq_length children@50@00)))
  (>= idx@51@00 (Seq_length children@50@00))))
(assert (=
  result@53@00
  (ite
    (>= idx@51@00 (Seq_length children@50@00))
    max_h@52@00
    (rose_children_max_height ($Snap.combine $Snap.unit $Snap.unit) children@50@00 (+
      idx@51@00
      1) (ite
      (>
        (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00))
        max_h@52@00)
      (rose_height $Snap.unit (Seq_index children@50@00 idx@51@00))
      max_h@52@00)))))
; [eval] result >= max_h
(push) ; 2
(assert (not (>= result@53@00 max_h@52@00)))
(check-sat)
; unsat
(pop) ; 2
; 0.00s
; (get-info :all-statistics)
(assert (>= result@53@00 max_h@52@00))
(pop) ; 1
(assert (forall ((s@$ $Snap) (children@50@00 Seq<RoseTree>) (idx@51@00 Int) (max_h@52@00 Int)) (!
  (=>
    (rose_children_max_height%precondition s@$ children@50@00 idx@51@00 max_h@52@00)
    (=
      (rose_children_max_height s@$ children@50@00 idx@51@00 max_h@52@00)
      (ite
        (>= idx@51@00 (Seq_length children@50@00))
        max_h@52@00
        (let ((h (rose_height%limited $Snap.unit (Seq_index
          children@50@00
          idx@51@00)))) (rose_children_max_height%limited ($Snap.combine
          $Snap.unit
          $Snap.unit) children@50@00 (+ idx@51@00 1) (ite
          (> h max_h@52@00)
          h
          max_h@52@00))))))
  :pattern ((rose_children_max_height s@$ children@50@00 idx@51@00 max_h@52@00))
  :qid |quant-u-83|)))
(assert (forall ((s@$ $Snap) (children@50@00 Seq<RoseTree>) (idx@51@00 Int) (max_h@52@00 Int)) (!
  (=>
    (rose_children_max_height%precondition s@$ children@50@00 idx@51@00 max_h@52@00)
    (ite
      (>= idx@51@00 (Seq_length children@50@00))
      true
      (and
        (rose_height%precondition $Snap.unit (Seq_index children@50@00 idx@51@00))
        (let ((h (rose_height%limited $Snap.unit (Seq_index
          children@50@00
          idx@51@00)))) (rose_children_max_height%precondition ($Snap.combine
          $Snap.unit
          $Snap.unit) children@50@00 (+ idx@51@00 1) (ite
          (> h max_h@52@00)
          h
          max_h@52@00))))))
  :pattern ((rose_children_max_height s@$ children@50@00 idx@51@00 max_h@52@00))
  :qid |quant-u-84|)))
; ---------- FUNCTION segment_tree_query----------
(declare-fun tree@54@00 () Seq<Int>)
(declare-fun node@55@00 () Int)
(declare-fun node_left@56@00 () Int)
(declare-fun node_right@57@00 () Int)
(declare-fun query_left@58@00 () Int)
(declare-fun query_right@59@00 () Int)
(declare-fun result@60@00 () Int)
; ----- Well-definedness of specifications -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
; [eval] node >= 0
(assert (>= node@55@00 0))
(assert (=
  ($Snap.second s@$)
  ($Snap.combine
    ($Snap.first ($Snap.second s@$))
    ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.first ($Snap.second s@$)) $Snap.unit))
; [eval] node < |tree|
; [eval] |tree|
(assert (< node@55@00 (Seq_length tree@54@00)))
(assert (=
  ($Snap.second ($Snap.second s@$))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second s@$)))
    ($Snap.second ($Snap.second ($Snap.second s@$))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))
; [eval] node_left <= node_right
(assert (<= node_left@56@00 node_right@57@00))
(assert (= ($Snap.second ($Snap.second ($Snap.second s@$))) $Snap.unit))
; [eval] query_left <= query_right
(assert (<= query_left@58@00 query_right@59@00))
(pop) ; 1
(assert (forall ((s@$ $Snap) (tree@54@00 Seq<Int>) (node@55@00 Int) (node_left@56@00 Int) (node_right@57@00 Int) (query_left@58@00 Int) (query_right@59@00 Int)) (!
  (=
    (segment_tree_query%limited s@$ tree@54@00 node@55@00 node_left@56@00 node_right@57@00 query_left@58@00 query_right@59@00)
    (segment_tree_query s@$ tree@54@00 node@55@00 node_left@56@00 node_right@57@00 query_left@58@00 query_right@59@00))
  :pattern ((segment_tree_query s@$ tree@54@00 node@55@00 node_left@56@00 node_right@57@00 query_left@58@00 query_right@59@00))
  :qid |quant-u-38|)))
(assert (forall ((s@$ $Snap) (tree@54@00 Seq<Int>) (node@55@00 Int) (node_left@56@00 Int) (node_right@57@00 Int) (query_left@58@00 Int) (query_right@59@00 Int)) (!
  (segment_tree_query%stateless tree@54@00 node@55@00 node_left@56@00 node_right@57@00 query_left@58@00 query_right@59@00)
  :pattern ((segment_tree_query%limited s@$ tree@54@00 node@55@00 node_left@56@00 node_right@57@00 query_left@58@00 query_right@59@00))
  :qid |quant-u-39|)))
; ----- Verification of function body and postcondition -----
(push) ; 1
(assert (= s@$ ($Snap.combine ($Snap.first s@$) ($Snap.second s@$))))
(assert (= ($Snap.first s@$) $Snap.unit))
(assert (>= node@55@00 0))
(assert (=
  ($Snap.second s@$)
  ($Snap.combine
    ($Snap.first ($Snap.second s@$))
    ($Snap.second ($Snap.second s@$)))))
(assert (= ($Snap.first ($Snap.second s@$)) $Snap.unit))
(assert (< node@55@00 (Seq_length tree@54@00)))
(assert (=
  ($Snap.second ($Snap.second s@$))
  ($Snap.combine
    ($Snap.first ($Snap.second ($Snap.second s@$)))
    ($Snap.second ($Snap.second ($Snap.second s@$))))))
(assert (= ($Snap.first ($Snap.second ($Snap.second s@$))) $Snap.unit))
(assert (<= node_left@56@00 node_right@57@00))
(assert (= ($Snap.second ($Snap.second ($Snap.second s@$))) $Snap.unit))
(assert (<= query_left@58@00 query_right@59@00))
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
; [eval] (query_left > node_right || query_right < node_left ? 0 : (query_left <= node_left && node_right <= query_right ? tree[node] : (let mid == ((node_left + node_right) \ 2) in segment_tree_query(tree, 2 * node + 1, node_left, mid, query_left, query_right) + segment_tree_query(tree, 2 * node + 2, mid + 1, node_right, query_left, query_right))))
; [eval] query_left > node_right || query_right < node_left
; [eval] query_left > node_right
(set-option :rlimit 0)
(push) ; 2
; [then-branch: 39 | query_left@58@00 > node_right@57@00 | live]
; [else-branch: 39 | !(query_left@58@00 > node_right@57@00) | live]
(push) ; 3
; [then-branch: 39 | query_left@58@00 > node_right@57@00]
(assert (> query_left@58@00 node_right@57@00))
(pop) ; 3
(push) ; 3
; [else-branch: 39 | !(query_left@58@00 > node_right@57@00)]
(assert (not (> query_left@58@00 node_right@57@00)))
; [eval] query_right < node_left
(pop) ; 3
(pop) ; 2
; Joined path conditions
; Joined path conditions
(assert (or
  (not (> query_left@58@00 node_right@57@00))
  (> query_left@58@00 node_right@57@00)))
(push) ; 2
(push) ; 3
(set-option :rlimit 16000)
(assert (not (not
  (or
    (> query_left@58@00 node_right@57@00)
    (< query_right@59@00 node_left@56@00)))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 3
(set-option :rlimit 16000)
(assert (not (or (> query_left@58@00 node_right@57@00) (< query_right@59@00 node_left@56@00))))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [then-branch: 40 | query_left@58@00 > node_right@57@00 || query_right@59@00 < node_left@56@00 | live]
; [else-branch: 40 | !(query_left@58@00 > node_right@57@00 || query_right@59@00 < node_left@56@00) | live]
(set-option :rlimit 0)
(push) ; 3
; [then-branch: 40 | query_left@58@00 > node_right@57@00 || query_right@59@00 < node_left@56@00]
(assert (or (> query_left@58@00 node_right@57@00) (< query_right@59@00 node_left@56@00)))
(pop) ; 3
(push) ; 3
; [else-branch: 40 | !(query_left@58@00 > node_right@57@00 || query_right@59@00 < node_left@56@00)]
(assert (not
  (or
    (> query_left@58@00 node_right@57@00)
    (< query_right@59@00 node_left@56@00))))
; [eval] (query_left <= node_left && node_right <= query_right ? tree[node] : (let mid == ((node_left + node_right) \ 2) in segment_tree_query(tree, 2 * node + 1, node_left, mid, query_left, query_right) + segment_tree_query(tree, 2 * node + 2, mid + 1, node_right, query_left, query_right)))
; [eval] query_left <= node_left && node_right <= query_right
; [eval] query_left <= node_left
(push) ; 4
; [then-branch: 41 | !(query_left@58@00 <= node_left@56@00) | live]
; [else-branch: 41 | query_left@58@00 <= node_left@56@00 | live]
(push) ; 5
; [then-branch: 41 | !(query_left@58@00 <= node_left@56@00)]
(assert (not (<= query_left@58@00 node_left@56@00)))
(pop) ; 5
(push) ; 5
; [else-branch: 41 | query_left@58@00 <= node_left@56@00]
(assert (<= query_left@58@00 node_left@56@00))
; [eval] node_right <= query_right
(pop) ; 5
(pop) ; 4
; Joined path conditions
; Joined path conditions
(assert (or
  (<= query_left@58@00 node_left@56@00)
  (not (<= query_left@58@00 node_left@56@00))))
(push) ; 4
(push) ; 5
(set-option :rlimit 16000)
(assert (not (not
  (and
    (<= query_left@58@00 node_left@56@00)
    (<= node_right@57@00 query_right@59@00)))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
(set-option :rlimit 0)
(push) ; 5
(set-option :rlimit 16000)
(assert (not (and
  (<= query_left@58@00 node_left@56@00)
  (<= node_right@57@00 query_right@59@00))))
(check-sat)
; unknown
(pop) ; 5
; 0.00s
; (get-info :all-statistics)
; [then-branch: 42 | query_left@58@00 <= node_left@56@00 && node_right@57@00 <= query_right@59@00 | live]
; [else-branch: 42 | !(query_left@58@00 <= node_left@56@00 && node_right@57@00 <= query_right@59@00) | live]
(set-option :rlimit 0)
(push) ; 5
; [then-branch: 42 | query_left@58@00 <= node_left@56@00 && node_right@57@00 <= query_right@59@00]
(assert (and
  (<= query_left@58@00 node_left@56@00)
  (<= node_right@57@00 query_right@59@00)))
; [eval] tree[node]
(pop) ; 5
(push) ; 5
; [else-branch: 42 | !(query_left@58@00 <= node_left@56@00 && node_right@57@00 <= query_right@59@00)]
(assert (not
  (and
    (<= query_left@58@00 node_left@56@00)
    (<= node_right@57@00 query_right@59@00))))
; [eval] (let mid == ((node_left + node_right) \ 2) in segment_tree_query(tree, 2 * node + 1, node_left, mid, query_left, query_right) + segment_tree_query(tree, 2 * node + 2, mid + 1, node_right, query_left, query_right))
; [eval] (node_left + node_right) \ 2
; [eval] node_left + node_right
(declare-fun letvar@72@00 ($Snap Seq<Int> Int Int Int Int Int) Int)
(assert (=
  (letvar@72@00 s@$ tree@54@00 node@55@00 node_left@56@00 node_right@57@00 query_left@58@00 query_right@59@00)
  (div (+ node_left@56@00 node_right@57@00) 2)))
; [eval] segment_tree_query(tree, 2 * node + 1, node_left, mid, query_left, query_right) + segment_tree_query(tree, 2 * node + 2, mid + 1, node_right, query_left, query_right)
; [eval] segment_tree_query(tree, 2 * node + 1, node_left, mid, query_left, query_right)
; [eval] 2 * node + 1
; [eval] 2 * node
(push) ; 6
; [eval] node >= 0
(push) ; 7
(assert (not (>= (+ (* 2 node@55@00) 1) 0)))
(check-sat)
; unsat
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(assert (>= (+ (* 2 node@55@00) 1) 0))
; [eval] node < |tree|
; [eval] |tree|
(push) ; 7
(assert (not (< (+ (* 2 node@55@00) 1) (Seq_length tree@54@00))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] node < |tree|
; [eval] |tree|
(set-option :rlimit 0)
(push) ; 7
(assert (not (< (+ (* 2 node@55@00) 1) (Seq_length tree@54@00))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] node < |tree|
; [eval] |tree|
(set-option :rlimit 0)
(push) ; 7
(assert (not (< (+ (* 2 node@55@00) 1) (Seq_length tree@54@00))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] node < |tree|
; [eval] |tree|
(set-option :rlimit 0)
(push) ; 7
(assert (not (< (+ (* 2 node@55@00) 1) (Seq_length tree@54@00))))
(check-sat)
; unknown
(pop) ; 7
; 0.00s
; (get-info :all-statistics)
(pop) ; 6
(pop) ; 5
(pop) ; 4
(pop) ; 3
(pop) ; 2
(pop) ; 1
