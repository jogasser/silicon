(get-info :version)
; (:version "4.8.7")
; Started: 2025-12-05 12:41:58
; Silicon.version: 1.1-SNAPSHOT (95328487@(detached))
; Input file: ./functions/sequence_operations.vpr
; Verifier id: 00
; ------------------------------------------------------------
; Begin preamble
; ////////// Static preamble
; 
; ; /z3config.smt2
(set-option :print-success true) ; Boogie: false
(set-option :global-decls true) ; Necessary for push pop mode
(set-option :auto_config false)
(set-option :smt.case_split 3)
(set-option :smt.delay_units true)
(set-option :type_check true)
(set-option :smt.mbqi false)
(set-option :pp.bv_literals false)
(set-option :smt.qi.eager_threshold 100)
(set-option :smt.arith.solver 2)
(set-option :model.v2 true)
(set-option :smt.qi.max_multi_patterns 1000)
; 
; ; /preamble.smt2
(declare-datatypes (($Snap 0)) ((
    ($Snap.unit)
    ($Snap.combine ($Snap.first $Snap) ($Snap.second $Snap)))))
(declare-sort $Ref 0)
(declare-const $Ref.null $Ref)
(declare-sort $FPM 0)
(declare-sort $PPM 0)
(define-sort $Perm () Real)
(define-const $Perm.Write $Perm 1.0)
(define-const $Perm.No $Perm 0.0)
(define-fun $Perm.isValidVar ((p $Perm)) Bool
	(<= $Perm.No p))
(define-fun $Perm.isReadVar ((p $Perm)) Bool
    (and ($Perm.isValidVar p)
         (not (= p $Perm.No))))
(define-fun $Perm.min ((p1 $Perm) (p2 $Perm)) Real
    (ite (<= p1 p2) p1 p2))
(define-fun $Math.min ((a Int) (b Int)) Int
    (ite (<= a b) a b))
(define-fun $Math.clip ((a Int)) Int
    (ite (< a 0) 0 a))
; ////////// Sorts
(declare-sort Seq<Seq<Int>> 0)
(declare-sort Seq<Int> 0)
(declare-sort Set<Int> 0)
; ////////// Sort wrappers
; Declaring additional sort wrappers
(declare-fun $SortWrappers.IntTo$Snap (Int) $Snap)
(declare-fun $SortWrappers.$SnapToInt ($Snap) Int)
(assert (forall ((x Int)) (!
    (= x ($SortWrappers.$SnapToInt($SortWrappers.IntTo$Snap x)))
    :pattern (($SortWrappers.IntTo$Snap x))
    :qid |$Snap.$SnapToIntTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.IntTo$Snap($SortWrappers.$SnapToInt x)))
    :pattern (($SortWrappers.$SnapToInt x))
    :qid |$Snap.IntTo$SnapToInt|
    )))
(declare-fun $SortWrappers.BoolTo$Snap (Bool) $Snap)
(declare-fun $SortWrappers.$SnapToBool ($Snap) Bool)
(assert (forall ((x Bool)) (!
    (= x ($SortWrappers.$SnapToBool($SortWrappers.BoolTo$Snap x)))
    :pattern (($SortWrappers.BoolTo$Snap x))
    :qid |$Snap.$SnapToBoolTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.BoolTo$Snap($SortWrappers.$SnapToBool x)))
    :pattern (($SortWrappers.$SnapToBool x))
    :qid |$Snap.BoolTo$SnapToBool|
    )))
(declare-fun $SortWrappers.$RefTo$Snap ($Ref) $Snap)
(declare-fun $SortWrappers.$SnapTo$Ref ($Snap) $Ref)
(assert (forall ((x $Ref)) (!
    (= x ($SortWrappers.$SnapTo$Ref($SortWrappers.$RefTo$Snap x)))
    :pattern (($SortWrappers.$RefTo$Snap x))
    :qid |$Snap.$SnapTo$RefTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$RefTo$Snap($SortWrappers.$SnapTo$Ref x)))
    :pattern (($SortWrappers.$SnapTo$Ref x))
    :qid |$Snap.$RefTo$SnapTo$Ref|
    )))
(declare-fun $SortWrappers.$PermTo$Snap ($Perm) $Snap)
(declare-fun $SortWrappers.$SnapTo$Perm ($Snap) $Perm)
(assert (forall ((x $Perm)) (!
    (= x ($SortWrappers.$SnapTo$Perm($SortWrappers.$PermTo$Snap x)))
    :pattern (($SortWrappers.$PermTo$Snap x))
    :qid |$Snap.$SnapTo$PermTo$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.$PermTo$Snap($SortWrappers.$SnapTo$Perm x)))
    :pattern (($SortWrappers.$SnapTo$Perm x))
    :qid |$Snap.$PermTo$SnapTo$Perm|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.Seq<Seq<Int>>To$Snap (Seq<Seq<Int>>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<Seq<Int>> ($Snap) Seq<Seq<Int>>)
(assert (forall ((x Seq<Seq<Int>>)) (!
    (= x ($SortWrappers.$SnapToSeq<Seq<Int>>($SortWrappers.Seq<Seq<Int>>To$Snap x)))
    :pattern (($SortWrappers.Seq<Seq<Int>>To$Snap x))
    :qid |$Snap.$SnapToSeq<Seq<Int>>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<Seq<Int>>To$Snap($SortWrappers.$SnapToSeq<Seq<Int>> x)))
    :pattern (($SortWrappers.$SnapToSeq<Seq<Int>> x))
    :qid |$Snap.Seq<Seq<Int>>To$SnapToSeq<Seq<Int>>|
    )))
(declare-fun $SortWrappers.Seq<Int>To$Snap (Seq<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToSeq<Int> ($Snap) Seq<Int>)
(assert (forall ((x Seq<Int>)) (!
    (= x ($SortWrappers.$SnapToSeq<Int>($SortWrappers.Seq<Int>To$Snap x)))
    :pattern (($SortWrappers.Seq<Int>To$Snap x))
    :qid |$Snap.$SnapToSeq<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Seq<Int>To$Snap($SortWrappers.$SnapToSeq<Int> x)))
    :pattern (($SortWrappers.$SnapToSeq<Int> x))
    :qid |$Snap.Seq<Int>To$SnapToSeq<Int>|
    )))
; Declaring additional sort wrappers
(declare-fun $SortWrappers.Set<Int>To$Snap (Set<Int>) $Snap)
(declare-fun $SortWrappers.$SnapToSet<Int> ($Snap) Set<Int>)
(assert (forall ((x Set<Int>)) (!
    (= x ($SortWrappers.$SnapToSet<Int>($SortWrappers.Set<Int>To$Snap x)))
    :pattern (($SortWrappers.Set<Int>To$Snap x))
    :qid |$Snap.$SnapToSet<Int>To$Snap|
    )))
(assert (forall ((x $Snap)) (!
    (= x ($SortWrappers.Set<Int>To$Snap($SortWrappers.$SnapToSet<Int> x)))
    :pattern (($SortWrappers.$SnapToSet<Int> x))
    :qid |$Snap.Set<Int>To$SnapToSet<Int>|
    )))
; ////////// Symbols
(declare-fun Set_card (Set<Int>) Int)
(declare-const Set_empty Set<Int>)
(declare-fun Set_in (Int Set<Int>) Bool)
(declare-fun Set_singleton (Int) Set<Int>)
(declare-fun Set_unionone (Set<Int> Int) Set<Int>)
(declare-fun Set_union (Set<Int> Set<Int>) Set<Int>)
(declare-fun Set_intersection (Set<Int> Set<Int>) Set<Int>)
(declare-fun Set_difference (Set<Int> Set<Int>) Set<Int>)
(declare-fun Set_subset (Set<Int> Set<Int>) Bool)
(declare-fun Set_equal (Set<Int> Set<Int>) Bool)
(declare-fun Set_skolem_diff (Set<Int> Set<Int>) Int)
(declare-fun Seq_length (Seq<Seq<Int>>) Int)
(declare-const Seq_empty Seq<Seq<Int>>)
(declare-fun Seq_singleton (Seq<Int>) Seq<Seq<Int>>)
(declare-fun Seq_append (Seq<Seq<Int>> Seq<Seq<Int>>) Seq<Seq<Int>>)
(declare-fun Seq_index (Seq<Seq<Int>> Int) Seq<Int>)
(declare-fun Seq_add (Int Int) Int)
(declare-fun Seq_sub (Int Int) Int)
(declare-fun Seq_update (Seq<Seq<Int>> Int Seq<Int>) Seq<Seq<Int>>)
(declare-fun Seq_take (Seq<Seq<Int>> Int) Seq<Seq<Int>>)
(declare-fun Seq_drop (Seq<Seq<Int>> Int) Seq<Seq<Int>>)
(declare-fun Seq_contains (Seq<Seq<Int>> Seq<Int>) Bool)
(declare-fun Seq_contains_trigger (Seq<Seq<Int>> Seq<Int>) Bool)
(declare-fun Seq_skolem (Seq<Seq<Int>> Seq<Int>) Int)
(declare-fun Seq_equal (Seq<Seq<Int>> Seq<Seq<Int>>) Bool)
(declare-fun Seq_skolem_diff (Seq<Seq<Int>> Seq<Seq<Int>>) Int)
(declare-fun Seq_length (Seq<Int>) Int)
(declare-const Seq_empty Seq<Int>)
(declare-fun Seq_singleton (Int) Seq<Int>)
(declare-fun Seq_append (Seq<Int> Seq<Int>) Seq<Int>)
(declare-fun Seq_index (Seq<Int> Int) Int)
(declare-fun Seq_update (Seq<Int> Int Int) Seq<Int>)
(declare-fun Seq_take (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_drop (Seq<Int> Int) Seq<Int>)
(declare-fun Seq_contains (Seq<Int> Int) Bool)
(declare-fun Seq_contains_trigger (Seq<Int> Int) Bool)
(declare-fun Seq_skolem (Seq<Int> Int) Int)
(declare-fun Seq_equal (Seq<Int> Seq<Int>) Bool)
(declare-fun Seq_skolem_diff (Seq<Int> Seq<Int>) Int)
(declare-fun Seq_range (Int Int) Seq<Int>)
; Declaring symbols related to program functions (from program analysis)
(declare-fun min_int ($Snap Int Int) Int)
(declare-fun min_int%limited ($Snap Int Int) Int)
(declare-fun min_int%stateless (Int Int) Bool)
(declare-fun min_int%precondition ($Snap Int Int) Bool)
(declare-fun max_int ($Snap Int Int) Int)
(declare-fun max_int%limited ($Snap Int Int) Int)
(declare-fun max_int%stateless (Int Int) Bool)
(declare-fun max_int%precondition ($Snap Int Int) Bool)
(declare-fun min_of_three ($Snap Int Int Int) Int)
(declare-fun min_of_three%limited ($Snap Int Int Int) Int)
(declare-fun min_of_three%stateless (Int Int Int) Bool)
(declare-fun min_of_three%precondition ($Snap Int Int Int) Bool)
(declare-fun adjacent_products_sum ($Snap Seq<Int>) Int)
(declare-fun adjacent_products_sum%limited ($Snap Seq<Int>) Int)
(declare-fun adjacent_products_sum%stateless (Seq<Int>) Bool)
(declare-fun adjacent_products_sum%precondition ($Snap Seq<Int>) Bool)
(declare-fun split_at_first ($Snap Seq<Int> Int Int) Seq<Int>)
(declare-fun split_at_first%limited ($Snap Seq<Int> Int Int) Seq<Int>)
(declare-fun split_at_first%stateless (Seq<Int> Int Int) Bool)
(declare-fun split_at_first%precondition ($Snap Seq<Int> Int Int) Bool)
(declare-fun max_subarray_sum ($Snap Seq<Int> Int Int Int) Int)
(declare-fun max_subarray_sum%limited ($Snap Seq<Int> Int Int Int) Int)
(declare-fun max_subarray_sum%stateless (Seq<Int> Int Int Int) Bool)
(declare-fun max_subarray_sum%precondition ($Snap Seq<Int> Int Int Int) Bool)
(declare-fun is_decreasing ($Snap Seq<Int>) Bool)
(declare-fun is_decreasing%limited ($Snap Seq<Int>) Bool)
(declare-fun is_decreasing%stateless (Seq<Int>) Bool)
(declare-fun is_decreasing%precondition ($Snap Seq<Int>) Bool)
(declare-fun lcp_length ($Snap Seq<Int> Seq<Int> Int) Int)
(declare-fun lcp_length%limited ($Snap Seq<Int> Seq<Int> Int) Int)
(declare-fun lcp_length%stateless (Seq<Int> Seq<Int> Int) Bool)
(declare-fun lcp_length%precondition ($Snap Seq<Int> Seq<Int> Int) Bool)
(declare-fun interleave ($Snap Seq<Int> Seq<Int>) Seq<Int>)
(declare-fun interleave%limited ($Snap Seq<Int> Seq<Int>) Seq<Int>)
(declare-fun interleave%stateless (Seq<Int> Seq<Int>) Bool)
(declare-fun interleave%precondition ($Snap Seq<Int> Seq<Int>) Bool)
(declare-fun is_palindrome ($Snap Seq<Int>) Bool)
(declare-fun is_palindrome%limited ($Snap Seq<Int>) Bool)
(declare-fun is_palindrome%stateless (Seq<Int>) Bool)
(declare-fun is_palindrome%precondition ($Snap Seq<Int>) Bool)
(declare-fun count_palindromes ($Snap Seq<Int> Int Int) Int)
(declare-fun count_palindromes%limited ($Snap Seq<Int> Int Int) Int)
(declare-fun count_palindromes%stateless (Seq<Int> Int Int) Bool)
(declare-fun count_palindromes%precondition ($Snap Seq<Int> Int Int) Bool)
(declare-fun alternating_sum ($Snap Seq<Int> Int) Int)
(declare-fun alternating_sum%limited ($Snap Seq<Int> Int) Int)
(declare-fun alternating_sum%stateless (Seq<Int> Int) Bool)
(declare-fun alternating_sum%precondition ($Snap Seq<Int> Int) Bool)
(declare-fun run_length_count ($Snap Seq<Int> Int Int Int) Int)
(declare-fun run_length_count%limited ($Snap Seq<Int> Int Int Int) Int)
(declare-fun run_length_count%stateless (Seq<Int> Int Int Int) Bool)
(declare-fun run_length_count%precondition ($Snap Seq<Int> Int Int Int) Bool)
(declare-fun flatten_sequences ($Snap Seq<Seq<Int>> Int) Seq<Int>)
(declare-fun flatten_sequences%limited ($Snap Seq<Seq<Int>> Int) Seq<Int>)
(declare-fun flatten_sequences%stateless (Seq<Seq<Int>> Int) Bool)
(declare-fun flatten_sequences%precondition ($Snap Seq<Seq<Int>> Int) Bool)
(declare-fun lcs_length ($Snap Seq<Int> Seq<Int>) Int)
(declare-fun lcs_length%limited ($Snap Seq<Int> Seq<Int>) Int)
(declare-fun lcs_length%stateless (Seq<Int> Seq<Int>) Bool)
(declare-fun lcs_length%precondition ($Snap Seq<Int> Seq<Int>) Bool)
(declare-fun count_inversions ($Snap Seq<Int> Int Int) Int)
(declare-fun count_inversions%limited ($Snap Seq<Int> Int Int) Int)
(declare-fun count_inversions%stateless (Seq<Int> Int Int) Bool)
(declare-fun count_inversions%precondition ($Snap Seq<Int> Int Int) Bool)
(declare-fun rotate_left_ ($Snap Seq<Int> Int) Seq<Int>)
(declare-fun rotate_left%limited ($Snap Seq<Int> Int) Seq<Int>)
(declare-fun rotate_left%stateless (Seq<Int> Int) Bool)
(declare-fun rotate_left%precondition ($Snap Seq<Int> Int) Bool)
(declare-fun has_duplicates ($Snap Seq<Int> Set<Int>) Bool)
(declare-fun has_duplicates%limited ($Snap Seq<Int> Set<Int>) Bool)
(declare-fun has_duplicates%stateless (Seq<Int> Set<Int>) Bool)
(declare-fun has_duplicates%precondition ($Snap Seq<Int> Set<Int>) Bool)
(declare-fun edit_distance ($Snap Seq<Int> Seq<Int>) Int)
(declare-fun edit_distance%limited ($Snap Seq<Int> Seq<Int>) Int)
(declare-fun edit_distance%stateless (Seq<Int> Seq<Int>) Bool)
(declare-fun edit_distance%precondition ($Snap Seq<Int> Seq<Int>) Bool)
(declare-fun remove_duplicates ($Snap Seq<Int> Set<Int>) Seq<Int>)
(declare-fun remove_duplicates%limited ($Snap Seq<Int> Set<Int>) Seq<Int>)
(declare-fun remove_duplicates%stateless (Seq<Int> Set<Int>) Bool)
(declare-fun remove_duplicates%precondition ($Snap Seq<Int> Set<Int>) Bool)
(declare-fun is_increasing ($Snap Seq<Int>) Bool)
(declare-fun is_increasing%limited ($Snap Seq<Int>) Bool)
(declare-fun is_increasing%stateless (Seq<Int>) Bool)
(declare-fun is_increasing%precondition ($Snap Seq<Int>) Bool)
; Snapshot variable to be used during function verification
(declare-fun s@$ () $Snap)
; Declaring predicate trigger functions
; ////////// Uniqueness assumptions from domains
; ////////// Axioms
(assert (forall ((s Seq<Seq<Int>>)) (!
  (<= 0 (Seq_length s))
  :pattern ((Seq_length s))
  :qid |$Seq[Seq[Int]]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty  Seq<Seq<Int>>)) 0))
(assert (forall ((s Seq<Seq<Int>>)) (!
  (=> (= (Seq_length s) 0) (= s (as Seq_empty  Seq<Seq<Int>>)))
  :pattern ((Seq_length s))
  :qid |$Seq[Seq[Int]]_prog.Seq_length_zero|)))
(assert (forall ((e Seq<Int>)) (!
  (= (Seq_length (Seq_singleton e)) 1)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Seq[Int]]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<Seq<Int>>) (s1 Seq<Seq<Int>>)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Seq<Int>>)))
      (not (= s1 (as Seq_empty  Seq<Seq<Int>>))))
    (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1))))
  :pattern ((Seq_length (Seq_append s0 s1)))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<Seq<Int>>) (s1 Seq<Seq<Int>>)) (!
  (and
    (=> (= s0 (as Seq_empty  Seq<Seq<Int>>)) (= (Seq_append s0 s1) s1))
    (=> (= s1 (as Seq_empty  Seq<Seq<Int>>)) (= (Seq_append s0 s1) s0)))
  :pattern ((Seq_append s0 s1))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_empty|)))
(assert (forall ((e Seq<Int>)) (!
  (= (Seq_index (Seq_singleton e) 0) e)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Seq[Int]]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_add i j) (+ i j))
  :pattern ((Seq_add i j))
  :qid |$Seq[Seq[Int]]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_sub i j) (- i j))
  :pattern ((Seq_sub i j))
  :qid |$Seq[Seq[Int]]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<Seq<Int>>) (s1 Seq<Seq<Int>>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Seq<Int>>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Seq<Int>>)))
        (and (<= 0 n) (< n (Seq_length s0)))))
    (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n)))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :pattern ((Seq_index s0 n) (Seq_append s0 s1))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<Seq<Int>>) (s1 Seq<Seq<Int>>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Seq<Int>>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Seq<Int>>)))
        (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1))))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n)
      (=
        (Seq_index (Seq_append s0 s1) n)
        (Seq_index s1 (Seq_sub n (Seq_length s0))))))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<Seq<Int>>) (s1 Seq<Seq<Int>>) (m Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Seq<Int>>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Seq<Int>>)))
        (and (<= 0 m) (< m (Seq_length s1)))))
    (and
      (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m)
      (=
        (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0)))
        (Seq_index s1 m))))
  :pattern ((Seq_index s1 m) (Seq_append s0 s1))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<Seq<Int>>) (i Int) (v Seq<Int>)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (Seq_length (Seq_update s i v)) (Seq_length s)))
  :pattern ((Seq_length (Seq_update s i v)))
  :pattern ((Seq_length s) (Seq_update s i v))
  :qid |$Seq[Seq[Int]]_prog.Seq_update_length|)))
(assert (forall ((s Seq<Seq<Int>>) (i Int) (v Seq<Int>) (n Int)) (!
  (=>
    (and (<= 0 n) (< n (Seq_length s)))
    (and
      (=> (= i n) (= (Seq_index (Seq_update s i v) n) v))
      (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n)))))
  :pattern ((Seq_index (Seq_update s i v) n))
  :pattern ((Seq_index s n) (Seq_update s i v))
  :qid |$Seq[Seq[Int]]_prog.Seq_update_index|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s)))))
    (=> (< n 0) (= (Seq_length (Seq_take s n)) 0)))
  :pattern ((Seq_length (Seq_take s n)))
  :pattern ((Seq_take s n) (Seq_length s))
  :qid |$Seq[Seq[Int]]_prog.Seq_take_length|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int) (j Int)) (!
  (=>
    (and (<= 0 j) (and (< j n) (< j (Seq_length s))))
    (= (Seq_index (Seq_take s n) j) (Seq_index s j)))
  :pattern ((Seq_index (Seq_take s n) j))
  :pattern ((Seq_index s j) (Seq_take s n))
  :qid |$Seq[Seq[Int]]_prog.Seq_take_index|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=>
          (<= n (Seq_length s))
          (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n)))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0))))
    (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s))))
  :pattern ((Seq_length (Seq_drop s n)))
  :pattern ((Seq_length s) (Seq_drop s n))
  :qid |$Seq[Seq[Int]]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int) (j Int)) (!
  (=>
    (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n))))
    (and
      (= (Seq_sub (Seq_add j n) n) j)
      (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n)))))
  :pattern ((Seq_index (Seq_drop s n) j))
  :qid |$Seq[Seq[Int]]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int) (i Int)) (!
  (=>
    (and (< 0 n) (and (<= n i) (< i (Seq_length s))))
    (and
      (= (Seq_add (Seq_sub i n) n) i)
      (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i))))
  :pattern ((Seq_drop s n) (Seq_index s i))
  :qid |$Seq[Seq[Int]]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<Seq<Int>>) (t Seq<Seq<Int>>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_take (Seq_append s t) n) (Seq_take s n)))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<Seq<Int>>) (t Seq<Seq<Int>>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (=
        (Seq_take (Seq_append s t) n)
        (Seq_append s (Seq_take t (Seq_sub n (Seq_length s)))))))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<Seq<Int>>) (t Seq<Seq<Int>>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t)))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<Seq<Int>>) (t Seq<Seq<Int>>) (n Int)) (!
  (=>
    (and (> n 0) (> n (Seq_length s)))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s))))))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Seq[Int]]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int)) (!
  (=> (<= n 0) (= (Seq_take s n) (as Seq_empty  Seq<Seq<Int>>)))
  :pattern ((Seq_take s n))
  :qid |$Seq[Seq[Int]]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int)) (!
  (=> (<= n 0) (= (Seq_drop s n) s))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Seq[Int]]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_take s n) s))
  :pattern ((Seq_take s n))
  :qid |$Seq[Seq[Int]]_prog.Seq_take_all|)))
(assert (forall ((s Seq<Seq<Int>>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty  Seq<Seq<Int>>)))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Seq[Int]]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<Seq<Int>>) (x Seq<Int>)) (!
  (=>
    (Seq_contains s x)
    (and
      (<= 0 (Seq_skolem s x))
      (and
        (< (Seq_skolem s x) (Seq_length s))
        (= (Seq_index s (Seq_skolem s x)) x))))
  :pattern ((Seq_contains s x))
  :qid |$Seq[Seq[Int]]_prog.Seq_contains1|)))
(assert (forall ((s Seq<Seq<Int>>) (x Seq<Int>) (i Int)) (!
  (=>
    (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x)))
    (Seq_contains s x))
  :pattern ((Seq_contains s x) (Seq_index s i))
  :qid |$Seq[Seq[Int]]_prog.Seq_contains2|)))
(assert (forall ((s Seq<Seq<Int>>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (Seq_contains_trigger s (Seq_index s i)))
  :pattern ((Seq_index s i))
  :qid |$Seq[Seq[Int]]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<Seq<Int>>) (s1 Seq<Seq<Int>>)) (!
  (or
    (and (= s0 s1) (Seq_equal s0 s1))
    (or
      (and
        (not (= s0 s1))
        (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1)))))
      (and
        (not (= s0 s1))
        (and
          (not (Seq_equal s0 s1))
          (and
            (= (Seq_length s0) (Seq_length s1))
            (and
              (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0))
              (and
                (<= 0 (Seq_skolem_diff s0 s1))
                (and
                  (< (Seq_skolem_diff s0 s1) (Seq_length s0))
                  (not
                    (=
                      (Seq_index s0 (Seq_skolem_diff s0 s1))
                      (Seq_index s1 (Seq_skolem_diff s0 s1))))))))))))
  :pattern ((Seq_equal s0 s1))
  :qid |$Seq[Seq[Int]]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<Seq<Int>>) (b Seq<Seq<Int>>)) (!
  (=> (Seq_equal a b) (= a b))
  :pattern ((Seq_equal a b))
  :qid |$Seq[Seq[Int]]_prog.Seq_equal_ext|)))
(assert (forall ((x Seq<Int>) (y Seq<Int>)) (!
  (= (Seq_contains (Seq_singleton x) y) (= x y))
  :pattern ((Seq_contains (Seq_singleton x) y))
  :qid |$Seq[Seq[Int]]_prog.Seq_singleton_contains|)))
(assert (forall ((s Seq<Int>)) (!
  (<= 0 (Seq_length s))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_nonneg|)))
(assert (= (Seq_length (as Seq_empty  Seq<Int>)) 0))
(assert (forall ((s Seq<Int>)) (!
  (=> (= (Seq_length s) 0) (= s (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_length s))
  :qid |$Seq[Int]_prog.Seq_length_zero|)))
(assert (forall ((e Int)) (!
  (= (Seq_length (Seq_singleton e)) 1)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (not (= s1 (as Seq_empty  Seq<Int>))))
    (= (Seq_length (Seq_append s0 s1)) (+ (Seq_length s0) (Seq_length s1))))
  :pattern ((Seq_length (Seq_append s0 s1)))
  :qid |$Seq[Int]_prog.Seq_append_length|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (and
    (=> (= s0 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s1))
    (=> (= s1 (as Seq_empty  Seq<Int>)) (= (Seq_append s0 s1) s0)))
  :pattern ((Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_empty|)))
(assert (forall ((e Int)) (!
  (= (Seq_index (Seq_singleton e) 0) e)
  :pattern ((Seq_singleton e))
  :qid |$Seq[Int]_prog.Seq_singleton_index|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_add i j) (+ i j))
  :pattern ((Seq_add i j))
  :qid |$Seq[Int]_prog.Seq_add_def|)))
(assert (forall ((i Int) (j Int)) (!
  (= (Seq_sub i j) (- i j))
  :pattern ((Seq_sub i j))
  :qid |$Seq[Int]_prog.Seq_sub_def|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= 0 n) (< n (Seq_length s0)))))
    (= (Seq_index (Seq_append s0 s1) n) (Seq_index s0 n)))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :pattern ((Seq_index s0 n) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index1|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (n Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= (Seq_length s0) n) (< n (Seq_length (Seq_append s0 s1))))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s0)) (Seq_length s0)) n)
      (=
        (Seq_index (Seq_append s0 s1) n)
        (Seq_index s1 (Seq_sub n (Seq_length s0))))))
  :pattern ((Seq_index (Seq_append s0 s1) n))
  :qid |$Seq[Int]_prog.Seq_append_index2|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>) (m Int)) (!
  (=>
    (and
      (not (= s0 (as Seq_empty  Seq<Int>)))
      (and
        (not (= s1 (as Seq_empty  Seq<Int>)))
        (and (<= 0 m) (< m (Seq_length s1)))))
    (and
      (= (Seq_sub (Seq_add m (Seq_length s0)) (Seq_length s0)) m)
      (=
        (Seq_index (Seq_append s0 s1) (Seq_add m (Seq_length s0)))
        (Seq_index s1 m))))
  :pattern ((Seq_index s1 m) (Seq_append s0 s1))
  :qid |$Seq[Int]_prog.Seq_append_index3|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (= (Seq_length (Seq_update s i v)) (Seq_length s)))
  :pattern ((Seq_length (Seq_update s i v)))
  :pattern ((Seq_length s) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_length|)))
(assert (forall ((s Seq<Int>) (i Int) (v Int) (n Int)) (!
  (=>
    (and (<= 0 n) (< n (Seq_length s)))
    (and
      (=> (= i n) (= (Seq_index (Seq_update s i v) n) v))
      (=> (not (= i n)) (= (Seq_index (Seq_update s i v) n) (Seq_index s n)))))
  :pattern ((Seq_index (Seq_update s i v) n))
  :pattern ((Seq_index s n) (Seq_update s i v))
  :qid |$Seq[Int]_prog.Seq_update_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=> (<= n (Seq_length s)) (= (Seq_length (Seq_take s n)) n))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_take s n)) (Seq_length s)))))
    (=> (< n 0) (= (Seq_length (Seq_take s n)) 0)))
  :pattern ((Seq_length (Seq_take s n)))
  :pattern ((Seq_take s n) (Seq_length s))
  :qid |$Seq[Int]_prog.Seq_take_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (<= 0 j) (and (< j n) (< j (Seq_length s))))
    (= (Seq_index (Seq_take s n) j) (Seq_index s j)))
  :pattern ((Seq_index (Seq_take s n) j))
  :pattern ((Seq_index s j) (Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_index|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (and
    (=>
      (<= 0 n)
      (and
        (=>
          (<= n (Seq_length s))
          (= (Seq_length (Seq_drop s n)) (- (Seq_length s) n)))
        (=> (< (Seq_length s) n) (= (Seq_length (Seq_drop s n)) 0))))
    (=> (< n 0) (= (Seq_length (Seq_drop s n)) (Seq_length s))))
  :pattern ((Seq_length (Seq_drop s n)))
  :pattern ((Seq_length s) (Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_length|)))
(assert (forall ((s Seq<Int>) (n Int) (j Int)) (!
  (=>
    (and (< 0 n) (and (<= 0 j) (< j (- (Seq_length s) n))))
    (and
      (= (Seq_sub (Seq_add j n) n) j)
      (= (Seq_index (Seq_drop s n) j) (Seq_index s (Seq_add j n)))))
  :pattern ((Seq_index (Seq_drop s n) j))
  :qid |$Seq[Int]_prog.Seq_drop_index1|)))
(assert (forall ((s Seq<Int>) (n Int) (i Int)) (!
  (=>
    (and (< 0 n) (and (<= n i) (< i (Seq_length s))))
    (and
      (= (Seq_add (Seq_sub i n) n) i)
      (= (Seq_index (Seq_drop s n) (Seq_sub i n)) (Seq_index s i))))
  :pattern ((Seq_drop s n) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_drop_index2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_take (Seq_append s t) n) (Seq_take s n)))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (and (> n (Seq_length s)) (< n (Seq_length (Seq_append s t)))))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (=
        (Seq_take (Seq_append s t) n)
        (Seq_append s (Seq_take t (Seq_sub n (Seq_length s)))))))
  :pattern ((Seq_take (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_take2|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (< 0 n) (<= n (Seq_length s)))
    (= (Seq_drop (Seq_append s t) n) (Seq_append (Seq_drop s n) t)))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop1|)))
(assert (forall ((s Seq<Int>) (t Seq<Int>) (n Int)) (!
  (=>
    (and (> n 0) (> n (Seq_length s)))
    (and
      (= (Seq_add (Seq_sub n (Seq_length s)) (Seq_length s)) n)
      (= (Seq_drop (Seq_append s t) n) (Seq_drop t (Seq_sub n (Seq_length s))))))
  :pattern ((Seq_drop (Seq_append s t) n))
  :qid |$Seq[Int]_prog.Seq_append_drop2|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_take s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (<= n 0) (= (Seq_drop s n) s))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_zero|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_take s n) s))
  :pattern ((Seq_take s n))
  :qid |$Seq[Int]_prog.Seq_take_all|)))
(assert (forall ((s Seq<Int>) (n Int)) (!
  (=> (>= n (Seq_length s)) (= (Seq_drop s n) (as Seq_empty  Seq<Int>)))
  :pattern ((Seq_drop s n))
  :qid |$Seq[Int]_prog.Seq_drop_all|)))
(assert (forall ((s Seq<Int>) (x Int)) (!
  (=>
    (Seq_contains s x)
    (and
      (<= 0 (Seq_skolem s x))
      (and
        (< (Seq_skolem s x) (Seq_length s))
        (= (Seq_index s (Seq_skolem s x)) x))))
  :pattern ((Seq_contains s x))
  :qid |$Seq[Int]_prog.Seq_contains1|)))
(assert (forall ((s Seq<Int>) (x Int) (i Int)) (!
  (=>
    (and (<= 0 i) (and (< i (Seq_length s)) (= (Seq_index s i) x)))
    (Seq_contains s x))
  :pattern ((Seq_contains s x) (Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains2|)))
(assert (forall ((s Seq<Int>) (i Int)) (!
  (=>
    (and (<= 0 i) (< i (Seq_length s)))
    (Seq_contains_trigger s (Seq_index s i)))
  :pattern ((Seq_index s i))
  :qid |$Seq[Int]_prog.Seq_contains_trigger|)))
(assert (forall ((s0 Seq<Int>) (s1 Seq<Int>)) (!
  (or
    (and (= s0 s1) (Seq_equal s0 s1))
    (or
      (and
        (not (= s0 s1))
        (and (not (Seq_equal s0 s1)) (not (= (Seq_length s0) (Seq_length s1)))))
      (and
        (not (= s0 s1))
        (and
          (not (Seq_equal s0 s1))
          (and
            (= (Seq_length s0) (Seq_length s1))
            (and
              (= (Seq_skolem_diff s0 s1) (Seq_skolem_diff s1 s0))
              (and
                (<= 0 (Seq_skolem_diff s0 s1))
                (and
                  (< (Seq_skolem_diff s0 s1) (Seq_length s0))
                  (not
                    (=
                      (Seq_index s0 (Seq_skolem_diff s0 s1))
                      (Seq_index s1 (Seq_skolem_diff s0 s1))))))))))))
  :pattern ((Seq_equal s0 s1))
  :qid |$Seq[Int]_prog.Seq_equal_def|)))
(assert (forall ((a Seq<Int>) (b Seq<Int>)) (!
  (=> (Seq_equal a b) (= a b))
  :pattern ((Seq_equal a b))
  :qid |$Seq[Int]_prog.Seq_equal_ext|)))
(assert (forall ((x Int) (y Int)) (!
  (= (Seq_contains (Seq_singleton x) y) (= x y))
  :pattern ((Seq_contains (Seq_singleton x) y))
  :qid |$Seq[Int]_prog.Seq_singleton_contains|)))
(assert (forall ((min_ Int) (max Int)) (!
  (and
    (=> (< min_ max) (= (Seq_length (Seq_range min_ max)) (- max min_)))
    (=> (<= max min_) (= (Seq_length (Seq_range min_ max)) 0)))
  :pattern ((Seq_length (Seq_range min_ max)))
  :qid |$Seq[Int]_prog.Seq_range_length|)))
(assert (forall ((min_ Int) (max Int) (j Int)) (!
  (=>
    (and (<= 0 j) (< j (- max min_)))
    (= (Seq_index (Seq_range min_ max) j) (+ min_ j)))
  :pattern ((Seq_index (Seq_range min_ max) j))
  :qid |$Seq[Int]_prog.Seq_range_index|)))
(assert (forall ((min_ Int) (max Int) (v Int)) (!
  (= (Seq_contains (Seq_range min_ max) v) (and (<= min_ v) (< v max)))
  :pattern ((Seq_contains (Seq_range min_ max) v))
  :qid |$Seq[Int]_prog.Seq_range_contains|)))
(assert (forall ((s Set<Int>)) (!
  (<= 0 (Set_card s))
  :pattern ((Set_card s))
  :qid |$Set[Int]_prog.Set_card_nonneg|)))
(assert (forall ((o Int)) (!
  (not (Set_in o (as Set_empty  Set<Int>)))
  :pattern ((Set_in o (as Set_empty  Set<Int>)))
  :qid |$Set[Int]_prog.Set_empty_contains_nothing|)))
(assert (forall ((s Set<Int>)) (!
  (and
    (=> (= (Set_card s) 0) (= s (as Set_empty  Set<Int>)))
    (=> (not (= (Set_card s) 0)) (exists ((x Int))  (Set_in x s))))
  :pattern ((Set_card s))
  :qid |$Set[Int]_prog.Set_card_zero|)))
(assert (forall ((r Int)) (!
  (Set_in r (Set_singleton r))
  :pattern ((Set_singleton r))
  :qid |$Set[Int]_prog.Set_singleton_contains1|)))
(assert (forall ((r Int) (o Int)) (!
  (= (Set_in o (Set_singleton r)) (= r o))
  :pattern ((Set_in o (Set_singleton r)))
  :qid |$Set[Int]_prog.Set_singleton_contains2|)))
(assert (forall ((r Int)) (!
  (= (Set_card (Set_singleton r)) 1)
  :pattern ((Set_card (Set_singleton r)))
  :qid |$Set[Int]_prog.Set_singleton_card|)))
(assert (forall ((a Set<Int>) (x Int) (o Int)) (!
  (= (Set_in o (Set_unionone a x)) (or (= o x) (Set_in o a)))
  :pattern ((Set_in o (Set_unionone a x)))
  :qid |$Set[Int]_prog.Set_unionone_contains1|)))
(assert (forall ((a Set<Int>) (x Int)) (!
  (Set_in x (Set_unionone a x))
  :pattern ((Set_unionone a x))
  :qid |$Set[Int]_prog.Set_unionone_contains2|)))
(assert (forall ((a Set<Int>) (x Int) (y Int)) (!
  (=> (Set_in y a) (Set_in y (Set_unionone a x)))
  :pattern ((Set_unionone a x) (Set_in y a))
  :qid |$Set[Int]_prog.Set_unionone_contains3|)))
(assert (forall ((a Set<Int>) (x Int)) (!
  (=> (Set_in x a) (= (Set_card (Set_unionone a x)) (Set_card a)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[Int]_prog.Set_unionone_card1|)))
(assert (forall ((a Set<Int>) (x Int)) (!
  (=> (not (Set_in x a)) (= (Set_card (Set_unionone a x)) (+ (Set_card a) 1)))
  :pattern ((Set_card (Set_unionone a x)))
  :qid |$Set[Int]_prog.Set_unionone_card2|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (o Int)) (!
  (= (Set_in o (Set_union a b)) (or (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_union a b)))
  :qid |$Set[Int]_prog.Set_union_contains1|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (y Int)) (!
  (=> (Set_in y a) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y a))
  :qid |$Set[Int]_prog.Set_union_contains2|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (y Int)) (!
  (=> (Set_in y b) (Set_in y (Set_union a b)))
  :pattern ((Set_union a b) (Set_in y b))
  :qid |$Set[Int]_prog.Set_union_contains3|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (o Int)) (!
  (= (Set_in o (Set_intersection a b)) (and (Set_in o a) (Set_in o b)))
  :pattern ((Set_in o (Set_intersection a b)))
  :pattern ((Set_intersection a b) (Set_in o a))
  :pattern ((Set_intersection a b) (Set_in o b))
  :qid |$Set[Int]_prog.Set_intersection_contains|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (= (Set_union (Set_union a b) b) (Set_union a b))
  :pattern ((Set_union (Set_union a b) b))
  :qid |$Set[Int]_prog.Set_union_absorb1|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (= (Set_union a (Set_union a b)) (Set_union a b))
  :pattern ((Set_union a (Set_union a b)))
  :qid |$Set[Int]_prog.Set_union_absorb2|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (= (Set_intersection (Set_intersection a b) b) (Set_intersection a b))
  :pattern ((Set_intersection (Set_intersection a b) b))
  :qid |$Set[Int]_prog.Set_intersection_absorb1|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (= (Set_intersection a (Set_intersection a b)) (Set_intersection a b))
  :pattern ((Set_intersection a (Set_intersection a b)))
  :qid |$Set[Int]_prog.Set_intersection_absorb2|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (=
    (+ (Set_card (Set_union a b)) (Set_card (Set_intersection a b)))
    (+ (Set_card a) (Set_card b)))
  :pattern ((Set_card (Set_union a b)))
  :pattern ((Set_card (Set_intersection a b)))
  :qid |$Set[Int]_prog.Set_card_union_intersection|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (o Int)) (!
  (= (Set_in o (Set_difference a b)) (and (Set_in o a) (not (Set_in o b))))
  :pattern ((Set_in o (Set_difference a b)))
  :pattern ((Set_difference a b) (Set_in o a))
  :qid |$Set[Int]_prog.Set_diff_contains1|)))
(assert (forall ((a Set<Int>) (b Set<Int>) (y Int)) (!
  (=> (Set_in y b) (not (Set_in y (Set_difference a b))))
  :pattern ((Set_difference a b) (Set_in y b))
  :qid |$Set[Int]_prog.Set_diff_contains2|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (and
    (=
      (+
        (+ (Set_card (Set_difference a b)) (Set_card (Set_difference b a)))
        (Set_card (Set_intersection a b)))
      (Set_card (Set_union a b)))
    (=
      (Set_card (Set_difference a b))
      (- (Set_card a) (Set_card (Set_intersection a b)))))
  :pattern ((Set_card (Set_difference a b)))
  :qid |$Set[Int]_prog.Set_diff_card|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (=
    (Set_subset a b)
    (forall ((o Int)) (!
      (=> (Set_in o a) (Set_in o b))
      :pattern ((Set_in o a))
      :pattern ((Set_in o b))
      )))
  :pattern ((Set_subset a b))
  :qid |$Set[Int]_prog.Set_subset_def|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (or
    (and (Set_equal a b) (= a b))
    (and
      (not (Set_equal a b))
      (and
        (not (= a b))
        (and
          (= (Set_skolem_diff a b) (Set_skolem_diff b a))
          (not
            (= (Set_in (Set_skolem_diff a b) a) (Set_in (Set_skolem_diff a b) b)))))))
  :pattern ((Set_equal a b))
  :qid |$Set[Int]_prog.Set_equal_def|)))
(assert (forall ((a Set<Int>) (b Set<Int>)) (!
  (=> (Set_equal a b) (= a b))
  :pattern ((Set_equal a b))
  :qid |$Set[Int]_prog.Set_equal_ext|)))
; End preamble
; ------------------------------------------------------------
; State saturation: after preamble
(set-option :rlimit 160000)
(check-sat)
; unknown
; ------------------------------------------------------------
; Begin function- and predicate-related preamble
; Declaring symbols related to program functions (from verification)
; Declaring symbols related to program functions (from verification)
(declare-fun letvar@74@00 ($Snap Seq<Int> Int Int Int) Int)
(declare-fun letvar@75@00 ($Snap Seq<Int> Int Int Int) Int)
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (= (min_int%limited s@$ a@0@00 b@1@00) (min_int s@$ a@0@00 b@1@00))
  :pattern ((min_int s@$ a@0@00 b@1@00))
  :qid |quant-u-0|)))
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (min_int%stateless a@0@00 b@1@00)
  :pattern ((min_int%limited s@$ a@0@00 b@1@00))
  :qid |quant-u-1|)))
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (let ((result@2@00 (min_int%limited s@$ a@0@00 b@1@00))) (=>
    (min_int%precondition s@$ a@0@00 b@1@00)
    (and
      (and (<= result@2@00 a@0@00) (<= result@2@00 b@1@00))
      (or (= result@2@00 a@0@00) (= result@2@00 b@1@00)))))
  :pattern ((min_int%limited s@$ a@0@00 b@1@00))
  :qid |quant-u-42|)))
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (let ((result@2@00 (min_int%limited s@$ a@0@00 b@1@00))) true)
  :pattern ((min_int%limited s@$ a@0@00 b@1@00))
  :qid |quant-u-43|)))
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (let ((result@2@00 (min_int%limited s@$ a@0@00 b@1@00))) true)
  :pattern ((min_int%limited s@$ a@0@00 b@1@00))
  :qid |quant-u-44|)))
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  (=>
    (min_int%precondition s@$ a@0@00 b@1@00)
    (= (min_int s@$ a@0@00 b@1@00) (ite (< a@0@00 b@1@00) a@0@00 b@1@00)))
  :pattern ((min_int s@$ a@0@00 b@1@00))
  :qid |quant-u-45|)))
(assert (forall ((s@$ $Snap) (a@0@00 Int) (b@1@00 Int)) (!
  true
  :pattern ((min_int s@$ a@0@00 b@1@00))
  :qid |quant-u-46|)))
(assert (forall ((s@$ $Snap) (a@3@00 Int) (b@4@00 Int)) (!
  (= (max_int%limited s@$ a@3@00 b@4@00) (max_int s@$ a@3@00 b@4@00))
  :pattern ((max_int s@$ a@3@00 b@4@00))
  :qid |quant-u-2|)))
(assert (forall ((s@$ $Snap) (a@3@00 Int) (b@4@00 Int)) (!
  (max_int%stateless a@3@00 b@4@00)
  :pattern ((max_int%limited s@$ a@3@00 b@4@00))
  :qid |quant-u-3|)))
(assert (forall ((s@$ $Snap) (a@3@00 Int) (b@4@00 Int)) (!
  (let ((result@5@00 (max_int%limited s@$ a@3@00 b@4@00))) (=>
    (max_int%precondition s@$ a@3@00 b@4@00)
    (and
      (and (>= result@5@00 a@3@00) (>= result@5@00 b@4@00))
      (or (= result@5@00 a@3@00) (= result@5@00 b@4@00)))))
  :pattern ((max_int%limited s@$ a@3@00 b@4@00))
  :qid |quant-u-47|)))
(assert (forall ((s@$ $Snap) (a@3@00 Int) (b@4@00 Int)) (!
  (let ((result@5@00 (max_int%limited s@$ a@3@00 b@4@00))) true)
  :pattern ((max_int%limited s@$ a@3@00 b@4@00))
  :qid |quant-u-48|)))
(assert (forall ((s@$ $Snap) (a@3@00 Int) (b@4@00 Int)) (!
  (let ((result@5@00 (max_int%limited s@$ a@3@00 b@4@00))) true)
  :pattern ((max_int%limited s@$ a@3@00 b@4@00))
  :qid |quant-u-49|)))
(assert (forall ((s@$ $Snap) (a@3@00 Int) (b@4@00 Int)) (!
  (=>
    (max_int%precondition s@$ a@3@00 b@4@00)
    (= (max_int s@$ a@3@00 b@4@00) (ite (> a@3@00 b@4@00) a@3@00 b@4@00)))
  :pattern ((max_int s@$ a@3@00 b@4@00))
  :qid |quant-u-50|)))
(assert (forall ((s@$ $Snap) (a@3@00 Int) (b@4@00 Int)) (!
  true
  :pattern ((max_int s@$ a@3@00 b@4@00))
  :qid |quant-u-51|)))
(assert (forall ((s@$ $Snap) (a@6@00 Int) (b@7@00 Int) (c@8@00 Int)) (!
  (=
    (min_of_three%limited s@$ a@6@00 b@7@00 c@8@00)
    (min_of_three s@$ a@6@00 b@7@00 c@8@00))
  :pattern ((min_of_three s@$ a@6@00 b@7@00 c@8@00))
  :qid |quant-u-4|)))
(assert (forall ((s@$ $Snap) (a@6@00 Int) (b@7@00 Int) (c@8@00 Int)) (!
  (min_of_three%stateless a@6@00 b@7@00 c@8@00)
  :pattern ((min_of_three%limited s@$ a@6@00 b@7@00 c@8@00))
  :qid |quant-u-5|)))
(assert (forall ((s@$ $Snap) (a@6@00 Int) (b@7@00 Int) (c@8@00 Int)) (!
  (let ((result@9@00 (min_of_three%limited s@$ a@6@00 b@7@00 c@8@00))) (=>
    (min_of_three%precondition s@$ a@6@00 b@7@00 c@8@00)
    (and
      (<= result@9@00 a@6@00)
      (and (<= result@9@00 b@7@00) (<= result@9@00 c@8@00)))))
  :pattern ((min_of_three%limited s@$ a@6@00 b@7@00 c@8@00))
  :qid |quant-u-52|)))
(assert (forall ((s@$ $Snap) (a@6@00 Int) (b@7@00 Int) (c@8@00 Int)) (!
  (let ((result@9@00 (min_of_three%limited s@$ a@6@00 b@7@00 c@8@00))) true)
  :pattern ((min_of_three%limited s@$ a@6@00 b@7@00 c@8@00))
  :qid |quant-u-53|)))
(assert (forall ((s@$ $Snap) (a@6@00 Int) (b@7@00 Int) (c@8@00 Int)) (!
  (=>
    (min_of_three%precondition s@$ a@6@00 b@7@00 c@8@00)
    (=
      (min_of_three s@$ a@6@00 b@7@00 c@8@00)
      (min_int $Snap.unit (min_int $Snap.unit a@6@00 b@7@00) c@8@00)))
  :pattern ((min_of_three s@$ a@6@00 b@7@00 c@8@00))
  :qid |quant-u-54|)))
(assert (forall ((s@$ $Snap) (a@6@00 Int) (b@7@00 Int) (c@8@00 Int)) (!
  (=>
    (min_of_three%precondition s@$ a@6@00 b@7@00 c@8@00)
    (and
      (min_int%precondition $Snap.unit a@6@00 b@7@00)
      (min_int%precondition $Snap.unit (min_int $Snap.unit a@6@00 b@7@00) c@8@00)))
  :pattern ((min_of_three s@$ a@6@00 b@7@00 c@8@00))
  :qid |quant-u-55|)))
(assert (forall ((s@$ $Snap) (s@10@00 Seq<Int>)) (!
  (=
    (adjacent_products_sum%limited s@$ s@10@00)
    (adjacent_products_sum s@$ s@10@00))
  :pattern ((adjacent_products_sum s@$ s@10@00))
  :qid |quant-u-6|)))
(assert (forall ((s@$ $Snap) (s@10@00 Seq<Int>)) (!
  (adjacent_products_sum%stateless s@10@00)
  :pattern ((adjacent_products_sum%limited s@$ s@10@00))
  :qid |quant-u-7|)))
(assert (forall ((s@$ $Snap) (s@10@00 Seq<Int>)) (!
  (let ((result@11@00 (adjacent_products_sum%limited s@$ s@10@00))) (=>
    (and
      (adjacent_products_sum%precondition s@$ s@10@00)
      (<= (Seq_length s@10@00) 1))
    (= result@11@00 0)))
  :pattern ((adjacent_products_sum%limited s@$ s@10@00))
  :qid |quant-u-56|)))
(assert (forall ((s@$ $Snap) (s@10@00 Seq<Int>)) (!
  (let ((result@11@00 (adjacent_products_sum%limited s@$ s@10@00))) true)
  :pattern ((adjacent_products_sum%limited s@$ s@10@00))
  :qid |quant-u-57|)))
(assert (forall ((s@$ $Snap) (s@10@00 Seq<Int>)) (!
  (=>
    (adjacent_products_sum%precondition s@$ s@10@00)
    (=
      (adjacent_products_sum s@$ s@10@00)
      (ite
        (<= (Seq_length s@10@00) 1)
        0
        (+
          (* (Seq_index s@10@00 0) (Seq_index s@10@00 1))
          (adjacent_products_sum%limited $Snap.unit (Seq_drop s@10@00 1))))))
  :pattern ((adjacent_products_sum s@$ s@10@00))
  :qid |quant-u-58|)))
(assert (forall ((s@$ $Snap) (s@10@00 Seq<Int>)) (!
  (=>
    (adjacent_products_sum%precondition s@$ s@10@00)
    (ite
      (<= (Seq_length s@10@00) 1)
      true
      (adjacent_products_sum%precondition $Snap.unit (Seq_drop s@10@00 1))))
  :pattern ((adjacent_products_sum s@$ s@10@00))
  :qid |quant-u-59|)))
(assert (forall ((s@$ $Snap) (s@12@00 Seq<Int>) (x@13@00 Int) (idx@14@00 Int)) (!
  (=
    (split_at_first%limited s@$ s@12@00 x@13@00 idx@14@00)
    (split_at_first s@$ s@12@00 x@13@00 idx@14@00))
  :pattern ((split_at_first s@$ s@12@00 x@13@00 idx@14@00))
  :qid |quant-u-8|)))
(assert (forall ((s@$ $Snap) (s@12@00 Seq<Int>) (x@13@00 Int) (idx@14@00 Int)) (!
  (split_at_first%stateless s@12@00 x@13@00 idx@14@00)
  :pattern ((split_at_first%limited s@$ s@12@00 x@13@00 idx@14@00))
  :qid |quant-u-9|)))
(assert (forall ((s@$ $Snap) (s@12@00 Seq<Int>) (x@13@00 Int) (idx@14@00 Int)) (!
  (let ((result@15@00 (split_at_first%limited s@$ s@12@00 x@13@00 idx@14@00))) (=>
    (and
      (split_at_first%precondition s@$ s@12@00 x@13@00 idx@14@00)
      (>= idx@14@00 (Seq_length s@12@00)))
    (Seq_equal result@15@00 s@12@00)))
  :pattern ((split_at_first%limited s@$ s@12@00 x@13@00 idx@14@00))
  :qid |quant-u-60|)))
(assert (forall ((s@$ $Snap) (s@12@00 Seq<Int>) (x@13@00 Int) (idx@14@00 Int)) (!
  (let ((result@15@00 (split_at_first%limited s@$ s@12@00 x@13@00 idx@14@00))) true)
  :pattern ((split_at_first%limited s@$ s@12@00 x@13@00 idx@14@00))
  :qid |quant-u-61|)))
(assert (forall ((s@$ $Snap) (s@12@00 Seq<Int>) (x@13@00 Int) (idx@14@00 Int)) (!
  (=>
    (split_at_first%precondition s@$ s@12@00 x@13@00 idx@14@00)
    (=
      (split_at_first s@$ s@12@00 x@13@00 idx@14@00)
      (ite
        (>= idx@14@00 (Seq_length s@12@00))
        s@12@00
        (ite
          (= (Seq_index s@12@00 idx@14@00) x@13@00)
          (Seq_take s@12@00 idx@14@00)
          (split_at_first%limited $Snap.unit s@12@00 x@13@00 (+ idx@14@00 1))))))
  :pattern ((split_at_first s@$ s@12@00 x@13@00 idx@14@00))
  :qid |quant-u-62|)))
(assert (forall ((s@$ $Snap) (s@12@00 Seq<Int>) (x@13@00 Int) (idx@14@00 Int)) (!
  (=>
    (split_at_first%precondition s@$ s@12@00 x@13@00 idx@14@00)
    (ite
      (>= idx@14@00 (Seq_length s@12@00))
      true
      (ite
        (= (Seq_index s@12@00 idx@14@00) x@13@00)
        true
        (split_at_first%precondition $Snap.unit s@12@00 x@13@00 (+ idx@14@00 1)))))
  :pattern ((split_at_first s@$ s@12@00 x@13@00 idx@14@00))
  :qid |quant-u-63|)))
(assert (forall ((s@$ $Snap) (s@16@00 Seq<Int>) (idx@17@00 Int) (current_sum@18@00 Int) (max_sum@19@00 Int)) (!
  (=
    (max_subarray_sum%limited s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00)
    (max_subarray_sum s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))
  :pattern ((max_subarray_sum s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))
  :qid |quant-u-10|)))
(assert (forall ((s@$ $Snap) (s@16@00 Seq<Int>) (idx@17@00 Int) (current_sum@18@00 Int) (max_sum@19@00 Int)) (!
  (max_subarray_sum%stateless s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00)
  :pattern ((max_subarray_sum%limited s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))
  :qid |quant-u-11|)))
(assert (forall ((s@$ $Snap) (s@16@00 Seq<Int>) (idx@17@00 Int) (current_sum@18@00 Int) (max_sum@19@00 Int)) (!
  (let ((result@20@00 (max_subarray_sum%limited s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))) (=>
    (and
      (max_subarray_sum%precondition s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00)
      (>= idx@17@00 (Seq_length s@16@00)))
    (= result@20@00 max_sum@19@00)))
  :pattern ((max_subarray_sum%limited s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))
  :qid |quant-u-64|)))
(assert (forall ((s@$ $Snap) (s@16@00 Seq<Int>) (idx@17@00 Int) (current_sum@18@00 Int) (max_sum@19@00 Int)) (!
  (let ((result@20@00 (max_subarray_sum%limited s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))) true)
  :pattern ((max_subarray_sum%limited s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))
  :qid |quant-u-65|)))
(assert (forall ((s@$ $Snap) (s@16@00 Seq<Int>) (idx@17@00 Int) (current_sum@18@00 Int) (max_sum@19@00 Int)) (!
  (=>
    (max_subarray_sum%precondition s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00)
    (=
      (max_subarray_sum s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00)
      (ite
        (>= idx@17@00 (Seq_length s@16@00))
        max_sum@19@00
        (let ((new_current (max_int $Snap.unit (Seq_index s@16@00 idx@17@00) (+
          current_sum@18@00
          (Seq_index s@16@00 idx@17@00))))) (let ((new_max (max_int $Snap.unit max_sum@19@00 new_current))) (max_subarray_sum%limited $Snap.unit s@16@00 (+
          idx@17@00
          1) new_current new_max))))))
  :pattern ((max_subarray_sum s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))
  :qid |quant-u-66|)))
(assert (forall ((s@$ $Snap) (s@16@00 Seq<Int>) (idx@17@00 Int) (current_sum@18@00 Int) (max_sum@19@00 Int)) (!
  (=>
    (max_subarray_sum%precondition s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00)
    (ite
      (>= idx@17@00 (Seq_length s@16@00))
      true
      (and
        (max_int%precondition $Snap.unit (Seq_index s@16@00 idx@17@00) (+
          current_sum@18@00
          (Seq_index s@16@00 idx@17@00)))
        (let ((new_current (max_int $Snap.unit (Seq_index s@16@00 idx@17@00) (+
          current_sum@18@00
          (Seq_index s@16@00 idx@17@00))))) (and
          (max_int%precondition $Snap.unit max_sum@19@00 new_current)
          (let ((new_max (max_int $Snap.unit max_sum@19@00 new_current))) (max_subarray_sum%precondition $Snap.unit s@16@00 (+
            idx@17@00
            1) new_current new_max)))))))
  :pattern ((max_subarray_sum s@$ s@16@00 idx@17@00 current_sum@18@00 max_sum@19@00))
  :qid |quant-u-67|)))
(assert (forall ((s@$ $Snap) (s@21@00 Seq<Int>)) (!
  (= (is_decreasing%limited s@$ s@21@00) (is_decreasing s@$ s@21@00))
  :pattern ((is_decreasing s@$ s@21@00))
  :qid |quant-u-12|)))
(assert (forall ((s@$ $Snap) (s@21@00 Seq<Int>)) (!
  (is_decreasing%stateless s@21@00)
  :pattern ((is_decreasing%limited s@$ s@21@00))
  :qid |quant-u-13|)))
(assert (forall ((s@$ $Snap) (s@21@00 Seq<Int>)) (!
  (=>
    (is_decreasing%precondition s@$ s@21@00)
    (=
      (is_decreasing s@$ s@21@00)
      (ite
        (<= (Seq_length s@21@00) 1)
        true
        (and
          (>= (Seq_index s@21@00 0) (Seq_index s@21@00 1))
          (is_decreasing%limited $Snap.unit (Seq_drop s@21@00 1))))))
  :pattern ((is_decreasing s@$ s@21@00))
  :qid |quant-u-68|)))
(assert (forall ((s@$ $Snap) (s@21@00 Seq<Int>)) (!
  (=>
    (is_decreasing%precondition s@$ s@21@00)
    (ite
      (<= (Seq_length s@21@00) 1)
      true
      (=>
        (>= (Seq_index s@21@00 0) (Seq_index s@21@00 1))
        (is_decreasing%precondition $Snap.unit (Seq_drop s@21@00 1)))))
  :pattern ((is_decreasing s@$ s@21@00))
  :qid |quant-u-69|)))
(assert (forall ((s@$ $Snap) (s1@23@00 Seq<Int>) (s2@24@00 Seq<Int>) (idx@25@00 Int)) (!
  (=
    (lcp_length%limited s@$ s1@23@00 s2@24@00 idx@25@00)
    (lcp_length s@$ s1@23@00 s2@24@00 idx@25@00))
  :pattern ((lcp_length s@$ s1@23@00 s2@24@00 idx@25@00))
  :qid |quant-u-14|)))
(assert (forall ((s@$ $Snap) (s1@23@00 Seq<Int>) (s2@24@00 Seq<Int>) (idx@25@00 Int)) (!
  (lcp_length%stateless s1@23@00 s2@24@00 idx@25@00)
  :pattern ((lcp_length%limited s@$ s1@23@00 s2@24@00 idx@25@00))
  :qid |quant-u-15|)))
(assert (forall ((s@$ $Snap) (s1@23@00 Seq<Int>) (s2@24@00 Seq<Int>) (idx@25@00 Int)) (!
  (let ((result@26@00 (lcp_length%limited s@$ s1@23@00 s2@24@00 idx@25@00))) (=>
    (lcp_length%precondition s@$ s1@23@00 s2@24@00 idx@25@00)
    (>= result@26@00 0)))
  :pattern ((lcp_length%limited s@$ s1@23@00 s2@24@00 idx@25@00))
  :qid |quant-u-70|)))
(assert (forall ((s@$ $Snap) (s1@23@00 Seq<Int>) (s2@24@00 Seq<Int>) (idx@25@00 Int)) (!
  (let ((result@26@00 (lcp_length%limited s@$ s1@23@00 s2@24@00 idx@25@00))) true)
  :pattern ((lcp_length%limited s@$ s1@23@00 s2@24@00 idx@25@00))
  :qid |quant-u-71|)))
(assert (forall ((s@$ $Snap) (s1@23@00 Seq<Int>) (s2@24@00 Seq<Int>) (idx@25@00 Int)) (!
  (=>
    (lcp_length%precondition s@$ s1@23@00 s2@24@00 idx@25@00)
    (=
      (lcp_length s@$ s1@23@00 s2@24@00 idx@25@00)
      (ite
        (or
          (>= idx@25@00 (Seq_length s1@23@00))
          (>= idx@25@00 (Seq_length s2@24@00)))
        idx@25@00
        (ite
          (not (= (Seq_index s1@23@00 idx@25@00) (Seq_index s2@24@00 idx@25@00)))
          idx@25@00
          (lcp_length%limited $Snap.unit s1@23@00 s2@24@00 (+ idx@25@00 1))))))
  :pattern ((lcp_length s@$ s1@23@00 s2@24@00 idx@25@00))
  :qid |quant-u-72|)))
(assert (forall ((s@$ $Snap) (s1@23@00 Seq<Int>) (s2@24@00 Seq<Int>) (idx@25@00 Int)) (!
  (=>
    (lcp_length%precondition s@$ s1@23@00 s2@24@00 idx@25@00)
    (ite
      (or
        (>= idx@25@00 (Seq_length s1@23@00))
        (>= idx@25@00 (Seq_length s2@24@00)))
      true
      (ite
        (not (= (Seq_index s1@23@00 idx@25@00) (Seq_index s2@24@00 idx@25@00)))
        true
        (lcp_length%precondition $Snap.unit s1@23@00 s2@24@00 (+ idx@25@00 1)))))
  :pattern ((lcp_length s@$ s1@23@00 s2@24@00 idx@25@00))
  :qid |quant-u-73|)))
(assert (forall ((s@$ $Snap) (s1@27@00 Seq<Int>) (s2@28@00 Seq<Int>)) (!
  (=
    (interleave%limited s@$ s1@27@00 s2@28@00)
    (interleave s@$ s1@27@00 s2@28@00))
  :pattern ((interleave s@$ s1@27@00 s2@28@00))
  :qid |quant-u-16|)))
(assert (forall ((s@$ $Snap) (s1@27@00 Seq<Int>) (s2@28@00 Seq<Int>)) (!
  (interleave%stateless s1@27@00 s2@28@00)
  :pattern ((interleave%limited s@$ s1@27@00 s2@28@00))
  :qid |quant-u-17|)))
(assert (forall ((s@$ $Snap) (s1@27@00 Seq<Int>) (s2@28@00 Seq<Int>)) (!
  (let ((result@29@00 (interleave%limited s@$ s1@27@00 s2@28@00))) (=>
    (interleave%precondition s@$ s1@27@00 s2@28@00)
    (and
      (=
        (Seq_length result@29@00)
        (+ (Seq_length s1@27@00) (Seq_length s2@28@00)))
      (=> (= (Seq_length s1@27@00) 0) (Seq_equal result@29@00 s2@28@00))
      (=> (= (Seq_length s2@28@00) 0) (Seq_equal result@29@00 s1@27@00)))))
  :pattern ((interleave%limited s@$ s1@27@00 s2@28@00))
  :qid |quant-u-74|)))
(assert (forall ((s@$ $Snap) (s1@27@00 Seq<Int>) (s2@28@00 Seq<Int>)) (!
  (let ((result@29@00 (interleave%limited s@$ s1@27@00 s2@28@00))) true)
  :pattern ((interleave%limited s@$ s1@27@00 s2@28@00))
  :qid |quant-u-75|)))
(assert (forall ((s@$ $Snap) (s1@27@00 Seq<Int>) (s2@28@00 Seq<Int>)) (!
  (let ((result@29@00 (interleave%limited s@$ s1@27@00 s2@28@00))) true)
  :pattern ((interleave%limited s@$ s1@27@00 s2@28@00))
  :qid |quant-u-76|)))
(assert (forall ((s@$ $Snap) (s1@27@00 Seq<Int>) (s2@28@00 Seq<Int>)) (!
  (let ((result@29@00 (interleave%limited s@$ s1@27@00 s2@28@00))) true)
  :pattern ((interleave%limited s@$ s1@27@00 s2@28@00))
  :qid |quant-u-77|)))
(assert (forall ((s@$ $Snap) (s1@27@00 Seq<Int>) (s2@28@00 Seq<Int>)) (!
  (=>
    (interleave%precondition s@$ s1@27@00 s2@28@00)
    (=
      (interleave s@$ s1@27@00 s2@28@00)
      (ite
        (= (Seq_length s1@27@00) 0)
        s2@28@00
        (ite
          (= (Seq_length s2@28@00) 0)
          s1@27@00
          (Seq_append
            (Seq_append
              (Seq_singleton (Seq_index s1@27@00 0))
              (Seq_singleton (Seq_index s2@28@00 0)))
            (interleave%limited $Snap.unit (Seq_drop s1@27@00 1) (Seq_drop
              s2@28@00
              1)))))))
  :pattern ((interleave s@$ s1@27@00 s2@28@00))
  :qid |quant-u-78|)))
(assert (forall ((s@$ $Snap) (s1@27@00 Seq<Int>) (s2@28@00 Seq<Int>)) (!
  (=>
    (interleave%precondition s@$ s1@27@00 s2@28@00)
    (ite
      (= (Seq_length s1@27@00) 0)
      true
      (ite
        (= (Seq_length s2@28@00) 0)
        true
        (interleave%precondition $Snap.unit (Seq_drop s1@27@00 1) (Seq_drop
          s2@28@00
          1)))))
  :pattern ((interleave s@$ s1@27@00 s2@28@00))
  :qid |quant-u-79|)))
(assert (forall ((s@$ $Snap) (s@30@00 Seq<Int>)) (!
  (= (is_palindrome%limited s@$ s@30@00) (is_palindrome s@$ s@30@00))
  :pattern ((is_palindrome s@$ s@30@00))
  :qid |quant-u-18|)))
(assert (forall ((s@$ $Snap) (s@30@00 Seq<Int>)) (!
  (is_palindrome%stateless s@30@00)
  :pattern ((is_palindrome%limited s@$ s@30@00))
  :qid |quant-u-19|)))
(assert (forall ((s@$ $Snap) (s@30@00 Seq<Int>)) (!
  (=>
    (is_palindrome%precondition s@$ s@30@00)
    (=
      (is_palindrome s@$ s@30@00)
      (ite
        (<= (Seq_length s@30@00) 1)
        true
        (and
          (=
            (Seq_index s@30@00 0)
            (Seq_index s@30@00 (- (Seq_length s@30@00) 1)))
          (is_palindrome%limited $Snap.unit (Seq_drop
            (Seq_take s@30@00 (- (Seq_length s@30@00) 1))
            1))))))
  :pattern ((is_palindrome s@$ s@30@00))
  :qid |quant-u-80|)))
(assert (forall ((s@$ $Snap) (s@30@00 Seq<Int>)) (!
  (=>
    (is_palindrome%precondition s@$ s@30@00)
    (ite
      (<= (Seq_length s@30@00) 1)
      true
      (=>
        (= (Seq_index s@30@00 0) (Seq_index s@30@00 (- (Seq_length s@30@00) 1)))
        (is_palindrome%precondition $Snap.unit (Seq_drop
          (Seq_take s@30@00 (- (Seq_length s@30@00) 1))
          1)))))
  :pattern ((is_palindrome s@$ s@30@00))
  :qid |quant-u-81|)))
(assert (forall ((s@$ $Snap) (s@32@00 Seq<Int>) (start@33@00 Int) (end@34@00 Int)) (!
  (=
    (count_palindromes%limited s@$ s@32@00 start@33@00 end@34@00)
    (count_palindromes s@$ s@32@00 start@33@00 end@34@00))
  :pattern ((count_palindromes s@$ s@32@00 start@33@00 end@34@00))
  :qid |quant-u-20|)))
(assert (forall ((s@$ $Snap) (s@32@00 Seq<Int>) (start@33@00 Int) (end@34@00 Int)) (!
  (count_palindromes%stateless s@32@00 start@33@00 end@34@00)
  :pattern ((count_palindromes%limited s@$ s@32@00 start@33@00 end@34@00))
  :qid |quant-u-21|)))
(assert (forall ((s@$ $Snap) (s@32@00 Seq<Int>) (start@33@00 Int) (end@34@00 Int)) (!
  (let ((result@35@00 (count_palindromes%limited s@$ s@32@00 start@33@00 end@34@00))) (=>
    (count_palindromes%precondition s@$ s@32@00 start@33@00 end@34@00)
    (>= result@35@00 0)))
  :pattern ((count_palindromes%limited s@$ s@32@00 start@33@00 end@34@00))
  :qid |quant-u-82|)))
(assert (forall ((s@$ $Snap) (s@32@00 Seq<Int>) (start@33@00 Int) (end@34@00 Int)) (!
  (let ((result@35@00 (count_palindromes%limited s@$ s@32@00 start@33@00 end@34@00))) true)
  :pattern ((count_palindromes%limited s@$ s@32@00 start@33@00 end@34@00))
  :qid |quant-u-83|)))
(assert (forall ((s@$ $Snap) (s@32@00 Seq<Int>) (start@33@00 Int) (end@34@00 Int)) (!
  (=>
    (count_palindromes%precondition s@$ s@32@00 start@33@00 end@34@00)
    (=
      (count_palindromes s@$ s@32@00 start@33@00 end@34@00)
      (ite
        (>= start@33@00 end@34@00)
        0
        (ite
          (= (- end@34@00 start@33@00) 1)
          1
          (ite
            (=
              (Seq_index s@32@00 start@33@00)
              (Seq_index s@32@00 (- end@34@00 1)))
            (+
              (+
                (+
                  1
                  (count_palindromes%limited ($Snap.combine
                    $Snap.unit
                    ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+
                    start@33@00
                    1) (- end@34@00 1)))
                (count_palindromes%limited ($Snap.combine
                  $Snap.unit
                  ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+
                  start@33@00
                  1) end@34@00))
              (count_palindromes%limited ($Snap.combine
                $Snap.unit
                ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (-
                end@34@00
                1)))
            (+
              (count_palindromes%limited ($Snap.combine
                $Snap.unit
                ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00)
              (count_palindromes%limited ($Snap.combine
                $Snap.unit
                ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (-
                end@34@00
                1))))))))
  :pattern ((count_palindromes s@$ s@32@00 start@33@00 end@34@00))
  :qid |quant-u-84|)))
(assert (forall ((s@$ $Snap) (s@32@00 Seq<Int>) (start@33@00 Int) (end@34@00 Int)) (!
  (=>
    (count_palindromes%precondition s@$ s@32@00 start@33@00 end@34@00)
    (ite
      (>= start@33@00 end@34@00)
      true
      (ite
        (= (- end@34@00 start@33@00) 1)
        true
        (ite
          (= (Seq_index s@32@00 start@33@00) (Seq_index s@32@00 (- end@34@00 1)))
          (and
            (and
              (count_palindromes%precondition ($Snap.combine
                $Snap.unit
                ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) (-
                end@34@00
                1))
              (count_palindromes%precondition ($Snap.combine
                $Snap.unit
                ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00))
            (count_palindromes%precondition ($Snap.combine
              $Snap.unit
              ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (-
              end@34@00
              1)))
          (and
            (count_palindromes%precondition ($Snap.combine
              $Snap.unit
              ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 (+ start@33@00 1) end@34@00)
            (count_palindromes%precondition ($Snap.combine
              $Snap.unit
              ($Snap.combine $Snap.unit $Snap.unit)) s@32@00 start@33@00 (-
              end@34@00
              1)))))))
  :pattern ((count_palindromes s@$ s@32@00 start@33@00 end@34@00))
  :qid |quant-u-85|)))
(assert (forall ((s@$ $Snap) (s@36@00 Seq<Int>) (sign@37@00 Int)) (!
  (=
    (alternating_sum%limited s@$ s@36@00 sign@37@00)
    (alternating_sum s@$ s@36@00 sign@37@00))
  :pattern ((alternating_sum s@$ s@36@00 sign@37@00))
  :qid |quant-u-22|)))
(assert (forall ((s@$ $Snap) (s@36@00 Seq<Int>) (sign@37@00 Int)) (!
  (alternating_sum%stateless s@36@00 sign@37@00)
  :pattern ((alternating_sum%limited s@$ s@36@00 sign@37@00))
  :qid |quant-u-23|)))
(assert (forall ((s@$ $Snap) (s@36@00 Seq<Int>) (sign@37@00 Int)) (!
  (=>
    (alternating_sum%precondition s@$ s@36@00 sign@37@00)
    (=
      (alternating_sum s@$ s@36@00 sign@37@00)
      (ite
        (= (Seq_length s@36@00) 0)
        0
        (+
          (* sign@37@00 (Seq_index s@36@00 0))
          (alternating_sum%limited $Snap.unit (Seq_drop s@36@00 1) (-
            0
            sign@37@00))))))
  :pattern ((alternating_sum s@$ s@36@00 sign@37@00))
  :qid |quant-u-86|)))
(assert (forall ((s@$ $Snap) (s@36@00 Seq<Int>) (sign@37@00 Int)) (!
  (=>
    (alternating_sum%precondition s@$ s@36@00 sign@37@00)
    (ite
      (= (Seq_length s@36@00) 0)
      true
      (alternating_sum%precondition $Snap.unit (Seq_drop s@36@00 1) (-
        0
        sign@37@00))))
  :pattern ((alternating_sum s@$ s@36@00 sign@37@00))
  :qid |quant-u-87|)))
(assert (forall ((s@$ $Snap) (s@39@00 Seq<Int>) (idx@40@00 Int) (current@41@00 Int) (count@42@00 Int)) (!
  (=
    (run_length_count%limited s@$ s@39@00 idx@40@00 current@41@00 count@42@00)
    (run_length_count s@$ s@39@00 idx@40@00 current@41@00 count@42@00))
  :pattern ((run_length_count s@$ s@39@00 idx@40@00 current@41@00 count@42@00))
  :qid |quant-u-24|)))
(assert (forall ((s@$ $Snap) (s@39@00 Seq<Int>) (idx@40@00 Int) (current@41@00 Int) (count@42@00 Int)) (!
  (run_length_count%stateless s@39@00 idx@40@00 current@41@00 count@42@00)
  :pattern ((run_length_count%limited s@$ s@39@00 idx@40@00 current@41@00 count@42@00))
  :qid |quant-u-25|)))
(assert (forall ((s@$ $Snap) (s@39@00 Seq<Int>) (idx@40@00 Int) (current@41@00 Int) (count@42@00 Int)) (!
  (let ((result@43@00 (run_length_count%limited s@$ s@39@00 idx@40@00 current@41@00 count@42@00))) (=>
    (run_length_count%precondition s@$ s@39@00 idx@40@00 current@41@00 count@42@00)
    (>= result@43@00 0)))
  :pattern ((run_length_count%limited s@$ s@39@00 idx@40@00 current@41@00 count@42@00))
  :qid |quant-u-88|)))
(assert (forall ((s@$ $Snap) (s@39@00 Seq<Int>) (idx@40@00 Int) (current@41@00 Int) (count@42@00 Int)) (!
  (let ((result@43@00 (run_length_count%limited s@$ s@39@00 idx@40@00 current@41@00 count@42@00))) true)
  :pattern ((run_length_count%limited s@$ s@39@00 idx@40@00 current@41@00 count@42@00))
  :qid |quant-u-89|)))
(assert (forall ((s@$ $Snap) (s@39@00 Seq<Int>) (idx@40@00 Int) (current@41@00 Int) (count@42@00 Int)) (!
  (=>
    (run_length_count%precondition s@$ s@39@00 idx@40@00 current@41@00 count@42@00)
    (=
      (run_length_count s@$ s@39@00 idx@40@00 current@41@00 count@42@00)
      (ite
        (>= idx@40@00 (Seq_length s@39@00))
        (ite (> count@42@00 0) 1 0)
        (ite
          (= idx@40@00 0)
          (run_length_count%limited ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
            idx@40@00
            1) (Seq_index s@39@00 idx@40@00) 1)
          (ite
            (= (Seq_index s@39@00 idx@40@00) current@41@00)
            (run_length_count%limited ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
              idx@40@00
              1) current@41@00 (+ count@42@00 1))
            (+
              1
              (run_length_count%limited ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
                idx@40@00
                1) (Seq_index s@39@00 idx@40@00) 1)))))))
  :pattern ((run_length_count s@$ s@39@00 idx@40@00 current@41@00 count@42@00))
  :qid |quant-u-90|)))
(assert (forall ((s@$ $Snap) (s@39@00 Seq<Int>) (idx@40@00 Int) (current@41@00 Int) (count@42@00 Int)) (!
  (=>
    (run_length_count%precondition s@$ s@39@00 idx@40@00 current@41@00 count@42@00)
    (ite
      (>= idx@40@00 (Seq_length s@39@00))
      true
      (ite
        (= idx@40@00 0)
        (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
          idx@40@00
          1) (Seq_index s@39@00 idx@40@00) 1)
        (ite
          (= (Seq_index s@39@00 idx@40@00) current@41@00)
          (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
            idx@40@00
            1) current@41@00 (+ count@42@00 1))
          (run_length_count%precondition ($Snap.combine $Snap.unit $Snap.unit) s@39@00 (+
            idx@40@00
            1) (Seq_index s@39@00 idx@40@00) 1)))))
  :pattern ((run_length_count s@$ s@39@00 idx@40@00 current@41@00 count@42@00))
  :qid |quant-u-91|)))
(assert (forall ((s@$ $Snap) (seqs@44@00 Seq<Seq<Int>>) (idx@45@00 Int)) (!
  (=
    (flatten_sequences%limited s@$ seqs@44@00 idx@45@00)
    (flatten_sequences s@$ seqs@44@00 idx@45@00))
  :pattern ((flatten_sequences s@$ seqs@44@00 idx@45@00))
  :qid |quant-u-26|)))
(assert (forall ((s@$ $Snap) (seqs@44@00 Seq<Seq<Int>>) (idx@45@00 Int)) (!
  (flatten_sequences%stateless seqs@44@00 idx@45@00)
  :pattern ((flatten_sequences%limited s@$ seqs@44@00 idx@45@00))
  :qid |quant-u-27|)))
(assert (forall ((s@$ $Snap) (seqs@44@00 Seq<Seq<Int>>) (idx@45@00 Int)) (!
  (let ((result@46@00 (flatten_sequences%limited s@$ seqs@44@00 idx@45@00))) (=>
    (and
      (flatten_sequences%precondition s@$ seqs@44@00 idx@45@00)
      (>= idx@45@00 (Seq_length seqs@44@00)))
    (Seq_equal result@46@00 (as Seq_empty  Seq<Int>))))
  :pattern ((flatten_sequences%limited s@$ seqs@44@00 idx@45@00))
  :qid |quant-u-92|)))
(assert (forall ((s@$ $Snap) (seqs@44@00 Seq<Seq<Int>>) (idx@45@00 Int)) (!
  (let ((result@46@00 (flatten_sequences%limited s@$ seqs@44@00 idx@45@00))) true)
  :pattern ((flatten_sequences%limited s@$ seqs@44@00 idx@45@00))
  :qid |quant-u-93|)))
(assert (forall ((s@$ $Snap) (seqs@44@00 Seq<Seq<Int>>) (idx@45@00 Int)) (!
  (=>
    (flatten_sequences%precondition s@$ seqs@44@00 idx@45@00)
    (=
      (flatten_sequences s@$ seqs@44@00 idx@45@00)
      (ite
        (>= idx@45@00 (Seq_length seqs@44@00))
        (as Seq_empty  Seq<Int>)
        (Seq_append
          (Seq_index seqs@44@00 idx@45@00)
          (flatten_sequences%limited $Snap.unit seqs@44@00 (+ idx@45@00 1))))))
  :pattern ((flatten_sequences s@$ seqs@44@00 idx@45@00))
  :qid |quant-u-94|)))
(assert (forall ((s@$ $Snap) (seqs@44@00 Seq<Seq<Int>>) (idx@45@00 Int)) (!
  (=>
    (flatten_sequences%precondition s@$ seqs@44@00 idx@45@00)
    (ite
      (>= idx@45@00 (Seq_length seqs@44@00))
      true
      (flatten_sequences%precondition $Snap.unit seqs@44@00 (+ idx@45@00 1))))
  :pattern ((flatten_sequences s@$ seqs@44@00 idx@45@00))
  :qid |quant-u-95|)))
(assert (forall ((s@$ $Snap) (s1@47@00 Seq<Int>) (s2@48@00 Seq<Int>)) (!
  (=
    (lcs_length%limited s@$ s1@47@00 s2@48@00)
    (lcs_length s@$ s1@47@00 s2@48@00))
  :pattern ((lcs_length s@$ s1@47@00 s2@48@00))
  :qid |quant-u-28|)))
(assert (forall ((s@$ $Snap) (s1@47@00 Seq<Int>) (s2@48@00 Seq<Int>)) (!
  (lcs_length%stateless s1@47@00 s2@48@00)
  :pattern ((lcs_length%limited s@$ s1@47@00 s2@48@00))
  :qid |quant-u-29|)))
(assert (forall ((s@$ $Snap) (s1@47@00 Seq<Int>) (s2@48@00 Seq<Int>)) (!
  (let ((result@49@00 (lcs_length%limited s@$ s1@47@00 s2@48@00))) (=>
    (lcs_length%precondition s@$ s1@47@00 s2@48@00)
    (and
      (>= result@49@00 0)
      (and
        (<= result@49@00 (Seq_length s1@47@00))
        (<= result@49@00 (Seq_length s2@48@00))))))
  :pattern ((lcs_length%limited s@$ s1@47@00 s2@48@00))
  :qid |quant-u-96|)))
(assert (forall ((s@$ $Snap) (s1@47@00 Seq<Int>) (s2@48@00 Seq<Int>)) (!
  (let ((result@49@00 (lcs_length%limited s@$ s1@47@00 s2@48@00))) true)
  :pattern ((lcs_length%limited s@$ s1@47@00 s2@48@00))
  :qid |quant-u-97|)))
(assert (forall ((s@$ $Snap) (s1@47@00 Seq<Int>) (s2@48@00 Seq<Int>)) (!
  (let ((result@49@00 (lcs_length%limited s@$ s1@47@00 s2@48@00))) true)
  :pattern ((lcs_length%limited s@$ s1@47@00 s2@48@00))
  :qid |quant-u-98|)))
(assert (forall ((s@$ $Snap) (s1@47@00 Seq<Int>) (s2@48@00 Seq<Int>)) (!
  (=>
    (lcs_length%precondition s@$ s1@47@00 s2@48@00)
    (=
      (lcs_length s@$ s1@47@00 s2@48@00)
      (ite
        (or (= (Seq_length s1@47@00) 0) (= (Seq_length s2@48@00) 0))
        0
        (ite
          (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0))
          (+
            1
            (lcs_length%limited $Snap.unit (Seq_drop s1@47@00 1) (Seq_drop
              s2@48@00
              1)))
          (max_int $Snap.unit (lcs_length%limited $Snap.unit (Seq_drop
            s1@47@00
            1) s2@48@00) (lcs_length%limited $Snap.unit s1@47@00 (Seq_drop
            s2@48@00
            1)))))))
  :pattern ((lcs_length s@$ s1@47@00 s2@48@00))
  :qid |quant-u-99|)))
(assert (forall ((s@$ $Snap) (s1@47@00 Seq<Int>) (s2@48@00 Seq<Int>)) (!
  (=>
    (lcs_length%precondition s@$ s1@47@00 s2@48@00)
    (ite
      (or (= (Seq_length s1@47@00) 0) (= (Seq_length s2@48@00) 0))
      true
      (ite
        (= (Seq_index s1@47@00 0) (Seq_index s2@48@00 0))
        (lcs_length%precondition $Snap.unit (Seq_drop s1@47@00 1) (Seq_drop
          s2@48@00
          1))
        (and
          (lcs_length%precondition $Snap.unit (Seq_drop s1@47@00 1) s2@48@00)
          (lcs_length%precondition $Snap.unit s1@47@00 (Seq_drop s2@48@00 1))
          (max_int%precondition $Snap.unit (lcs_length%limited $Snap.unit (Seq_drop
            s1@47@00
            1) s2@48@00) (lcs_length%limited $Snap.unit s1@47@00 (Seq_drop
            s2@48@00
            1)))))))
  :pattern ((lcs_length s@$ s1@47@00 s2@48@00))
  :qid |quant-u-100|)))
(assert (forall ((s@$ $Snap) (s@50@00 Seq<Int>) (i@51@00 Int) (j@52@00 Int)) (!
  (=
    (count_inversions%limited s@$ s@50@00 i@51@00 j@52@00)
    (count_inversions s@$ s@50@00 i@51@00 j@52@00))
  :pattern ((count_inversions s@$ s@50@00 i@51@00 j@52@00))
  :qid |quant-u-30|)))
(assert (forall ((s@$ $Snap) (s@50@00 Seq<Int>) (i@51@00 Int) (j@52@00 Int)) (!
  (count_inversions%stateless s@50@00 i@51@00 j@52@00)
  :pattern ((count_inversions%limited s@$ s@50@00 i@51@00 j@52@00))
  :qid |quant-u-31|)))
(assert (forall ((s@$ $Snap) (s@50@00 Seq<Int>) (i@51@00 Int) (j@52@00 Int)) (!
  (let ((result@53@00 (count_inversions%limited s@$ s@50@00 i@51@00 j@52@00))) (=>
    (count_inversions%precondition s@$ s@50@00 i@51@00 j@52@00)
    (>= result@53@00 0)))
  :pattern ((count_inversions%limited s@$ s@50@00 i@51@00 j@52@00))
  :qid |quant-u-101|)))
(assert (forall ((s@$ $Snap) (s@50@00 Seq<Int>) (i@51@00 Int) (j@52@00 Int)) (!
  (let ((result@53@00 (count_inversions%limited s@$ s@50@00 i@51@00 j@52@00))) true)
  :pattern ((count_inversions%limited s@$ s@50@00 i@51@00 j@52@00))
  :qid |quant-u-102|)))
(assert (forall ((s@$ $Snap) (s@54@00 Seq<Int>) (n@55@00 Int)) (!
  (=
    (rotate_left%limited s@$ s@54@00 n@55@00)
    (rotate_left_ s@$ s@54@00 n@55@00))
  :pattern ((rotate_left_ s@$ s@54@00 n@55@00))
  :qid |quant-u-32|)))
(assert (forall ((s@$ $Snap) (s@54@00 Seq<Int>) (n@55@00 Int)) (!
  (rotate_left%stateless s@54@00 n@55@00)
  :pattern ((rotate_left%limited s@$ s@54@00 n@55@00))
  :qid |quant-u-33|)))
(assert (forall ((s@$ $Snap) (s@54@00 Seq<Int>) (n@55@00 Int)) (!
  (let ((result@56@00 (rotate_left%limited s@$ s@54@00 n@55@00))) (=>
    (rotate_left%precondition s@$ s@54@00 n@55@00)
    (and
      (=> (= (Seq_length s@54@00) 0) (Seq_equal result@56@00 s@54@00))
      (=> (= n@55@00 0) (Seq_equal result@56@00 s@54@00)))))
  :pattern ((rotate_left%limited s@$ s@54@00 n@55@00))
  :qid |quant-u-103|)))
(assert (forall ((s@$ $Snap) (s@54@00 Seq<Int>) (n@55@00 Int)) (!
  (let ((result@56@00 (rotate_left%limited s@$ s@54@00 n@55@00))) true)
  :pattern ((rotate_left%limited s@$ s@54@00 n@55@00))
  :qid |quant-u-104|)))
(assert (forall ((s@$ $Snap) (s@54@00 Seq<Int>) (n@55@00 Int)) (!
  (let ((result@56@00 (rotate_left%limited s@$ s@54@00 n@55@00))) true)
  :pattern ((rotate_left%limited s@$ s@54@00 n@55@00))
  :qid |quant-u-105|)))
(assert (forall ((s@$ $Snap) (s@54@00 Seq<Int>) (n@55@00 Int)) (!
  (=>
    (rotate_left%precondition s@$ s@54@00 n@55@00)
    (=
      (rotate_left_ s@$ s@54@00 n@55@00)
      (ite
        (or (= (Seq_length s@54@00) 0) (= n@55@00 0))
        s@54@00
        (ite
          (>= n@55@00 (Seq_length s@54@00))
          (rotate_left%limited $Snap.unit s@54@00 (mod
            n@55@00
            (Seq_length s@54@00)))
          (Seq_append (Seq_drop s@54@00 n@55@00) (Seq_take s@54@00 n@55@00))))))
  :pattern ((rotate_left_ s@$ s@54@00 n@55@00))
  :qid |quant-u-106|)))
(assert (forall ((s@$ $Snap) (s@54@00 Seq<Int>) (n@55@00 Int)) (!
  (=>
    (rotate_left%precondition s@$ s@54@00 n@55@00)
    (ite
      (or (= (Seq_length s@54@00) 0) (= n@55@00 0))
      true
      (ite
        (>= n@55@00 (Seq_length s@54@00))
        (rotate_left%precondition $Snap.unit s@54@00 (mod
          n@55@00
          (Seq_length s@54@00)))
        true)))
  :pattern ((rotate_left_ s@$ s@54@00 n@55@00))
  :qid |quant-u-107|)))
(assert (forall ((s@$ $Snap) (s@57@00 Seq<Int>) (checked@58@00 Set<Int>)) (!
  (=
    (has_duplicates%limited s@$ s@57@00 checked@58@00)
    (has_duplicates s@$ s@57@00 checked@58@00))
  :pattern ((has_duplicates s@$ s@57@00 checked@58@00))
  :qid |quant-u-34|)))
(assert (forall ((s@$ $Snap) (s@57@00 Seq<Int>) (checked@58@00 Set<Int>)) (!
  (has_duplicates%stateless s@57@00 checked@58@00)
  :pattern ((has_duplicates%limited s@$ s@57@00 checked@58@00))
  :qid |quant-u-35|)))
(assert (forall ((s@$ $Snap) (s@57@00 Seq<Int>) (checked@58@00 Set<Int>)) (!
  (=>
    (has_duplicates%precondition s@$ s@57@00 checked@58@00)
    (=
      (has_duplicates s@$ s@57@00 checked@58@00)
      (ite
        (= (Seq_length s@57@00) 0)
        false
        (ite
          (Set_in (Seq_index s@57@00 0) checked@58@00)
          true
          (has_duplicates%limited $Snap.unit (Seq_drop s@57@00 1) (Set_union checked@58@00 (Set_singleton (Seq_index
            s@57@00
            0))))))))
  :pattern ((has_duplicates s@$ s@57@00 checked@58@00))
  :qid |quant-u-108|)))
(assert (forall ((s@$ $Snap) (s@57@00 Seq<Int>) (checked@58@00 Set<Int>)) (!
  (=>
    (has_duplicates%precondition s@$ s@57@00 checked@58@00)
    (ite
      (= (Seq_length s@57@00) 0)
      true
      (ite
        (Set_in (Seq_index s@57@00 0) checked@58@00)
        true
        (has_duplicates%precondition $Snap.unit (Seq_drop s@57@00 1) (Set_union checked@58@00 (Set_singleton (Seq_index
          s@57@00
          0)))))))
  :pattern ((has_duplicates s@$ s@57@00 checked@58@00))
  :qid |quant-u-109|)))
(assert (forall ((s@$ $Snap) (s1@60@00 Seq<Int>) (s2@61@00 Seq<Int>)) (!
  (=
    (edit_distance%limited s@$ s1@60@00 s2@61@00)
    (edit_distance s@$ s1@60@00 s2@61@00))
  :pattern ((edit_distance s@$ s1@60@00 s2@61@00))
  :qid |quant-u-36|)))
(assert (forall ((s@$ $Snap) (s1@60@00 Seq<Int>) (s2@61@00 Seq<Int>)) (!
  (edit_distance%stateless s1@60@00 s2@61@00)
  :pattern ((edit_distance%limited s@$ s1@60@00 s2@61@00))
  :qid |quant-u-37|)))
(assert (forall ((s@$ $Snap) (s1@60@00 Seq<Int>) (s2@61@00 Seq<Int>)) (!
  (let ((result@62@00 (edit_distance%limited s@$ s1@60@00 s2@61@00))) (=>
    (edit_distance%precondition s@$ s1@60@00 s2@61@00)
    (>= result@62@00 0)))
  :pattern ((edit_distance%limited s@$ s1@60@00 s2@61@00))
  :qid |quant-u-110|)))
(assert (forall ((s@$ $Snap) (s1@60@00 Seq<Int>) (s2@61@00 Seq<Int>)) (!
  (let ((result@62@00 (edit_distance%limited s@$ s1@60@00 s2@61@00))) true)
  :pattern ((edit_distance%limited s@$ s1@60@00 s2@61@00))
  :qid |quant-u-111|)))
(assert (forall ((s@$ $Snap) (s1@60@00 Seq<Int>) (s2@61@00 Seq<Int>)) (!
  (=>
    (edit_distance%precondition s@$ s1@60@00 s2@61@00)
    (=
      (edit_distance s@$ s1@60@00 s2@61@00)
      (ite
        (= (Seq_length s1@60@00) 0)
        (Seq_length s2@61@00)
        (ite
          (= (Seq_length s2@61@00) 0)
          (Seq_length s1@60@00)
          (ite
            (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0))
            (edit_distance%limited $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
              s2@61@00
              1))
            (+
              1
              (min_of_three $Snap.unit (edit_distance%limited $Snap.unit (Seq_drop
                s1@60@00
                1) s2@61@00) (edit_distance%limited $Snap.unit s1@60@00 (Seq_drop
                s2@61@00
                1)) (edit_distance%limited $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
                s2@61@00
                1)))))))))
  :pattern ((edit_distance s@$ s1@60@00 s2@61@00))
  :qid |quant-u-112|)))
(assert (forall ((s@$ $Snap) (s1@60@00 Seq<Int>) (s2@61@00 Seq<Int>)) (!
  (=>
    (edit_distance%precondition s@$ s1@60@00 s2@61@00)
    (ite
      (= (Seq_length s1@60@00) 0)
      true
      (ite
        (= (Seq_length s2@61@00) 0)
        true
        (ite
          (= (Seq_index s1@60@00 0) (Seq_index s2@61@00 0))
          (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
            s2@61@00
            1))
          (and
            (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) s2@61@00)
            (edit_distance%precondition $Snap.unit s1@60@00 (Seq_drop s2@61@00 1))
            (edit_distance%precondition $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
              s2@61@00
              1))
            (min_of_three%precondition $Snap.unit (edit_distance%limited $Snap.unit (Seq_drop
              s1@60@00
              1) s2@61@00) (edit_distance%limited $Snap.unit s1@60@00 (Seq_drop
              s2@61@00
              1)) (edit_distance%limited $Snap.unit (Seq_drop s1@60@00 1) (Seq_drop
              s2@61@00
              1))))))))
  :pattern ((edit_distance s@$ s1@60@00 s2@61@00))
  :qid |quant-u-113|)))
(assert (forall ((s@$ $Snap) (s@63@00 Seq<Int>) (seen@64@00 Set<Int>)) (!
  (=
    (remove_duplicates%limited s@$ s@63@00 seen@64@00)
    (remove_duplicates s@$ s@63@00 seen@64@00))
  :pattern ((remove_duplicates s@$ s@63@00 seen@64@00))
  :qid |quant-u-38|)))
(assert (forall ((s@$ $Snap) (s@63@00 Seq<Int>) (seen@64@00 Set<Int>)) (!
  (remove_duplicates%stateless s@63@00 seen@64@00)
  :pattern ((remove_duplicates%limited s@$ s@63@00 seen@64@00))
  :qid |quant-u-39|)))
(assert (forall ((s@$ $Snap) (s@63@00 Seq<Int>) (seen@64@00 Set<Int>)) (!
  (let ((result@65@00 (remove_duplicates%limited s@$ s@63@00 seen@64@00))) (=>
    (and
      (remove_duplicates%precondition s@$ s@63@00 seen@64@00)
      (= (Seq_length s@63@00) 0))
    (Seq_equal result@65@00 s@63@00)))
  :pattern ((remove_duplicates%limited s@$ s@63@00 seen@64@00))
  :qid |quant-u-114|)))
(assert (forall ((s@$ $Snap) (s@63@00 Seq<Int>) (seen@64@00 Set<Int>)) (!
  (let ((result@65@00 (remove_duplicates%limited s@$ s@63@00 seen@64@00))) true)
  :pattern ((remove_duplicates%limited s@$ s@63@00 seen@64@00))
  :qid |quant-u-115|)))
(assert (forall ((s@$ $Snap) (s@63@00 Seq<Int>) (seen@64@00 Set<Int>)) (!
  (=>
    (remove_duplicates%precondition s@$ s@63@00 seen@64@00)
    (=
      (remove_duplicates s@$ s@63@00 seen@64@00)
      (ite
        (= (Seq_length s@63@00) 0)
        s@63@00
        (ite
          (Set_in (Seq_index s@63@00 0) seen@64@00)
          (remove_duplicates%limited $Snap.unit (Seq_drop s@63@00 1) seen@64@00)
          (Seq_append
            (Seq_singleton (Seq_index s@63@00 0))
            (remove_duplicates%limited $Snap.unit (Seq_drop s@63@00 1) (Set_union seen@64@00 (Set_singleton (Seq_index
              s@63@00
              0)))))))))
  :pattern ((remove_duplicates s@$ s@63@00 seen@64@00))
  :qid |quant-u-116|)))
(assert (forall ((s@$ $Snap) (s@63@00 Seq<Int>) (seen@64@00 Set<Int>)) (!
  (=>
    (remove_duplicates%precondition s@$ s@63@00 seen@64@00)
    (ite
      (= (Seq_length s@63@00) 0)
      true
      (ite
        (Set_in (Seq_index s@63@00 0) seen@64@00)
        (remove_duplicates%precondition $Snap.unit (Seq_drop s@63@00 1) seen@64@00)
        (remove_duplicates%precondition $Snap.unit (Seq_drop s@63@00 1) (Set_union seen@64@00 (Set_singleton (Seq_index
          s@63@00
          0)))))))
  :pattern ((remove_duplicates s@$ s@63@00 seen@64@00))
  :qid |quant-u-117|)))
(assert (forall ((s@$ $Snap) (s@66@00 Seq<Int>)) (!
  (= (is_increasing%limited s@$ s@66@00) (is_increasing s@$ s@66@00))
  :pattern ((is_increasing s@$ s@66@00))
  :qid |quant-u-40|)))
(assert (forall ((s@$ $Snap) (s@66@00 Seq<Int>)) (!
  (is_increasing%stateless s@66@00)
  :pattern ((is_increasing%limited s@$ s@66@00))
  :qid |quant-u-41|)))
(assert (forall ((s@$ $Snap) (s@66@00 Seq<Int>)) (!
  (=>
    (is_increasing%precondition s@$ s@66@00)
    (=
      (is_increasing s@$ s@66@00)
      (ite
        (<= (Seq_length s@66@00) 1)
        true
        (and
          (<= (Seq_index s@66@00 0) (Seq_index s@66@00 1))
          (is_increasing%limited $Snap.unit (Seq_drop s@66@00 1))))))
  :pattern ((is_increasing s@$ s@66@00))
  :qid |quant-u-118|)))
(assert (forall ((s@$ $Snap) (s@66@00 Seq<Int>)) (!
  (=>
    (is_increasing%precondition s@$ s@66@00)
    (ite
      (<= (Seq_length s@66@00) 1)
      true
      (=>
        (<= (Seq_index s@66@00 0) (Seq_index s@66@00 1))
        (is_increasing%precondition $Snap.unit (Seq_drop s@66@00 1)))))
  :pattern ((is_increasing s@$ s@66@00))
  :qid |quant-u-119|)))
; End function- and predicate-related preamble
; ------------------------------------------------------------
; ---------- test_sequence_operations ----------
(set-option :rlimit 0)
(push) ; 1
; State saturation: after contract
(set-option :rlimit 80000)
(check-sat)
; unknown
(set-option :rlimit 0)
(push) ; 2
(pop) ; 2
(push) ; 2
; [exec]
; var s1: Seq[Int]
(declare-const s1@0@01 Seq<Int>)
; [exec]
; var s2: Seq[Int]
(declare-const s2@1@01 Seq<Int>)
; [exec]
; var palindrome: Seq[Int]
(declare-const palindrome@2@01 Seq<Int>)
; [exec]
; var increasing: Seq[Int]
(declare-const increasing@3@01 Seq<Int>)
; [exec]
; var decreasing: Seq[Int]
(declare-const decreasing@4@01 Seq<Int>)
; [exec]
; var rotated: Seq[Int]
(declare-const rotated@5@01 Seq<Int>)
; [exec]
; s1 := Seq(1, 2, 3, 4, 5)
; [eval] Seq(1, 2, 3, 4, 5)
(assert (=
  (Seq_length
    (Seq_append
      (Seq_append
        (Seq_append
          (Seq_append (Seq_singleton 1) (Seq_singleton 2))
          (Seq_singleton 3))
        (Seq_singleton 4))
      (Seq_singleton 5)))
  5))
(declare-const s1@6@01 Seq<Int>)
(assert (=
  s1@6@01
  (Seq_append
    (Seq_append
      (Seq_append
        (Seq_append (Seq_singleton 1) (Seq_singleton 2))
        (Seq_singleton 3))
      (Seq_singleton 4))
    (Seq_singleton 5))))
; [exec]
; s2 := Seq(1, 2, 9, 4, 5)
; [eval] Seq(1, 2, 9, 4, 5)
(assert (=
  (Seq_length
    (Seq_append
      (Seq_append
        (Seq_append
          (Seq_append (Seq_singleton 1) (Seq_singleton 2))
          (Seq_singleton 9))
        (Seq_singleton 4))
      (Seq_singleton 5)))
  5))
(declare-const s2@7@01 Seq<Int>)
(assert (=
  s2@7@01
  (Seq_append
    (Seq_append
      (Seq_append
        (Seq_append (Seq_singleton 1) (Seq_singleton 2))
        (Seq_singleton 9))
      (Seq_singleton 4))
    (Seq_singleton 5))))
; [exec]
; assert lcp_length(s1, s2, 0) == 2
; [eval] lcp_length(s1, s2, 0) == 2
; [eval] lcp_length(s1, s2, 0)
(push) ; 3
; [eval] idx >= 0
(assert (lcp_length%precondition $Snap.unit s1@6@01 s2@7@01 0))
(pop) ; 3
; Joined path conditions
(assert (lcp_length%precondition $Snap.unit s1@6@01 s2@7@01 0))
(push) ; 3
(assert (not (= (lcp_length $Snap.unit s1@6@01 s2@7@01 0) 2)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] lcp_length(s1, s2, 0) == 2
; [eval] lcp_length(s1, s2, 0)
(set-option :rlimit 0)
(push) ; 3
; [eval] idx >= 0
(pop) ; 3
; Joined path conditions
(push) ; 3
(assert (not (= (lcp_length $Snap.unit s1@6@01 s2@7@01 0) 2)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] lcp_length(s1, s2, 0) == 2
; [eval] lcp_length(s1, s2, 0)
(set-option :rlimit 0)
(push) ; 3
; [eval] idx >= 0
(pop) ; 3
; Joined path conditions
(push) ; 3
(assert (not (= (lcp_length $Snap.unit s1@6@01 s2@7@01 0) 2)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
; [state consolidation]
; State saturation: before repetition
(set-option :rlimit 16000)
(check-sat)
; unknown
; [eval] lcp_length(s1, s2, 0) == 2
; [eval] lcp_length(s1, s2, 0)
(set-option :rlimit 0)
(push) ; 3
; [eval] idx >= 0
(pop) ; 3
; Joined path conditions
(push) ; 3
(assert (not (= (lcp_length $Snap.unit s1@6@01 s2@7@01 0) 2)))
(check-sat)
; unknown
(pop) ; 3
; 0.00s
; (get-info :all-statistics)
(pop) ; 2
(pop) ; 1
